﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSBC_XML_GENERATOR
{
    public class DB
    {

        private SqlConnection con;
        private SqlConnection objConnection;
        private string connStr = ConfigurationManager.ConnectionStrings["Connstr"].ConnectionString;
        public SqlConnection GetConnection()
        {
            try
            {
                objConnection = new SqlConnection();
                con = new System.Data.SqlClient.SqlConnection(connStr);
                if (con.State == System.Data.ConnectionState.Closed)
                {
                    con.Open();
                }
            }
            catch (System.Exception ex)
            {
                //writing_error_log("connect_3tier_dll Error::" + ex.Message.ToString());
                throw ex;
            }
            return con;
        }

        public System.Int32 ExcuteNonQuery(string commandText, SqlParameter[] Params = null, bool isSP = false)
        {
            SqlCommand Cmd = null;
            SqlConnection conSQL = null;
            try
            {
                conSQL = GetConnection();
                Cmd = new SqlCommand(commandText, conSQL);
                if (isSP == true) { Cmd.CommandType = CommandType.StoredProcedure; }
                if ((Params != null))
                {
                    for (int ia = 0; ia <= Params.Length - 1; ia++)
                    {
                        Cmd.Parameters.Add(Params[ia]);
                    }
                }
                System.Int32 iResult = Cmd.ExecuteNonQuery();
                conSQL.Close();
                conSQL = null;
                Cmd = null;
                Params = null;
                return iResult;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
                con.Dispose();
                conSQL = null;
                Cmd = null;
                Params = null;
            }
        }


        public string getScalarValue(string commandText, string DataBase, bool Exclusive, SqlParameter[] Params = null, bool isSP = false)
        {
            string strScalarValue = null; SqlConnection conSQL = null; SqlCommand Cmd = null;
            try
            {
                conSQL = GetConnection();
                Cmd = new SqlCommand(commandText, conSQL);
                if ((Params != null))
                {
                    for (int ia = 0; ia <= Params.Length - 1; ia++)
                    {
                        Cmd.Parameters.Add(Params[ia]);
                    }
                }
                if (!isSP)
                    Cmd.CommandType = CommandType.Text;
                else
                    Cmd.CommandType = CommandType.StoredProcedure;
                strScalarValue = Convert.ToString(Cmd.ExecuteScalar());
                conSQL.Close();
                conSQL = null;
                Cmd = null;
                Params = null;
                return strScalarValue;
            }
            catch (Exception ex)
            {
                //writing_error_log("connect_3tier_dll Error::" + ex.Message.ToString());
                throw ex;
            }
            finally
            {
                con.Close();
                con.Dispose();
                conSQL = null;
                Cmd = null;
                Params = null;
            }

        }

        public System.Data.DataSet GetDataset(string commandText, SqlParameter[] Params = null, bool isSP = false)
        {
            SqlCommand Cmd = null;
            SqlConnection conSQL = null;
            try
            {
                conSQL = GetConnection();
                Cmd = new SqlCommand(commandText, conSQL);
                if (isSP == true) { Cmd.CommandType = CommandType.StoredProcedure; }
                Cmd.CommandTimeout = 100;
                SqlDataAdapter Da1 = new SqlDataAdapter(Cmd);
                DataSet Ds1 = new DataSet();
                if ((Params != null))
                {
                    for (int ia = 0; ia <= Params.Length - 1; ia++)
                    {
                        Cmd.Parameters.Add(Params[ia]);
                    }
                }
                Da1.Fill(Ds1);
                con.Close();
                conSQL = null;
                Cmd = null;
                Da1 = null;
                Params = null;
                return Ds1;
            }
            catch (System.Exception ex)
            {
                //writing_error_log("connect_3tier_dll Error::" + ex.Message.ToString());
                throw ex;
            }
            finally
            {
                con.Close();
                con.Dispose();
                conSQL = null;
                Cmd = null;
                Params = null;
            }
        }
    }
}
