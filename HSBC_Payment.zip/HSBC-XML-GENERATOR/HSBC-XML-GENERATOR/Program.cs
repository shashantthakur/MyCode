﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace HSBC_XML_GENERATOR
{
    public class Program
    {
        private static DBRepositary db = new DBRepositary();
        public static void Main(string[] args)
        {
            var dt = db.GetLocalXMLDetails();
            if (dt.Rows.Count > 0)
            {
                if (Convert.ToInt32(dt.Rows[0]["TransactionMasterId"]) == 0)
                    dt = db.UpsertTransationMaster();
                XmlDocument doc = new XmlDocument();
                doc.Load(@"Template/USACH_Debtor.xml");



                XmlNodeList AchId = doc.SelectNodes("//*[name()='Dbtr']//*[name()='OrgId']//*[name()='Id']");
                AchId[0].InnerText = Convert.ToString(dt.Rows[0]["AchId"]);
                //XmlNodeList AchId = doc.SelectNodes(@"//Dbtr//OrgId//Id", nms);

                XmlNodeList MsgId = doc.GetElementsByTagName("MsgId");
                MsgId[0].InnerText = Convert.ToString(dt.Rows[0]["MsgId"]);
                XmlNodeList PmtInfId = doc.GetElementsByTagName("PmtInfId");
                PmtInfId[0].InnerText = Convert.ToString(dt.Rows[0]["PmtInfId"]);

                XmlNodeList CreDtTm = doc.GetElementsByTagName("CreDtTm");
                CreDtTm[0].InnerText = DateTime.Now.ToString("yyyy-MM-dd'T'HH:mm:ss");

                XmlNodeList NbOfTxs = doc.GetElementsByTagName("NbOfTxs");
                NbOfTxs[0].InnerText = Convert.ToString(dt.Rows.Count);

                XmlNodeList CtrlSum = doc.GetElementsByTagName("CtrlSum");
                CtrlSum[0].InnerText = dt.Rows.Cast<DataRow>().Select(a => Convert.ToDecimal(a["TotalAmount"])).Sum().ToString("0.00");

                XmlNodeList ReqdExctnDt = doc.GetElementsByTagName("ReqdExctnDt");
                ReqdExctnDt[0].InnerText = DateTime.Now.ToString("yyyy-MM-dd");


            }

            Console.ReadKey();
        }
    }
}
