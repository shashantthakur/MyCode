﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSBC_XML_GENERATOR
{
    public class DBRepositary
    {
        public DB db = new DB();

        public DataTable GetLocalXMLDetails()
        {
            var param = new System.Data.SqlClient.SqlParameter[]
               {
                new SqlParameter()
                {
                    ParameterName = "@PaymentType",
                    Value = "US ACH"
                },
                new SqlParameter()
                {
                    ParameterName = "@ProjectCode",
                    Value = "ESPRO"
                }
            };
            var ds = db.GetDataset("GetLocalXMLDetails", param, true);
            return ds.Tables[0];
        }

        public DataTable UpsertTransationMaster()
        {
            var param = new System.Data.SqlClient.SqlParameter[]
               {
                new SqlParameter()
                {
                    ParameterName = "@PaymentType",
                    Value = "US ACH"
                },
                new SqlParameter()
                {
                    ParameterName = "@ProjectCode",
                    Value = "ESPRO"
                }
            };
            var ds = db.GetDataset("UpsertTransationMaster", param, true);
            return ds.Tables[0];
        }
    }
}
