﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace HSBC_Payment
{

    public partial class Form1 : Form
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(typeof(Program));

        public static IEnumerable<HSBCKeyValue> hsbcheader = DBRepository.GetAPIHeaderDetails(ConfigurationManager.AppSettings["env"]);

        public Form1()
        {
            InitializeComponent();

            log.InfoFormat("Program started with arguments");


            Process();
            CheckStatus();
            log.InfoFormat("Program Ended");
            Environment.Exit(0);

        }

        private void Form1_Load(object sender, EventArgs e)
        {

            //HSBC_API hSBC_API = new HSBC_API();
            //hSBC_API.CheckStatus();
            //string[] arguments = Environment.GetCommandLineArgs();
            //var direct = arguments.Where(a => Regex.Match(a, "^x$", RegexOptions.IgnoreCase).Success);
            //if (direct.Count() > 0)
            //{
            //    log.InfoFormat("Program started with arguments");
            //    Process();
            //    log.InfoFormat("Program Ended");
            //    Environment.Exit(0);
            //}

            //string s1 = GenerateId();
            //string s2 = GenerateId1();
            //string S3 = "";
            //for (int i = 0; i < 100000; i++)
            //{
            //    S3+= Guid.NewGuid().ToString().GetHashCode().ToString("x")+ "\r\n";
            //}

            //MessageBox.Show(s1 + "\r\n" + s2);

        }

        //private string GenerateId()
        //{
        //    long i = 1;
        //    foreach (byte b in Guid.NewGuid().ToByteArray())
        //    {
        //        i *= ((int)b + 1);
        //    }
        //    return string.Format("{0:x}", i - DateTime.Now.Ticks);
        //}

        //private string GenerateId1()
        //{
        //    long i = 1;
        //    foreach (byte b in Guid.NewGuid().ToByteArray())
        //    {
        //        i *= ((int)b + 1);
        //    }
        //    return string.Format("{0:x}", i - DateTime.Now.Ticks);
        //}

        private void button1_Click(object sender, EventArgs e)
        {
            log.InfoFormat("Program started with arguments");
            Process();
            log.InfoFormat("Program Ended");
        }

        public void Process()
        {

            int IsSinglePayment = Convert.ToInt32(ConfigurationManager.AppSettings["IsSinglePayment"].ToString());
            log.InfoFormat("Process started");
            IEnumerable<DebtorAccountDeatils> _debtorAccountDeatilsList = DBRepository.GetDebtorAccountDetails();//.Where(a=> a.ProjectCode != "ESC");

            foreach (DebtorAccountDeatils _debtorAccountDetails in _debtorAccountDeatilsList)
            {
                log.InfoFormat("Payment type: " + _debtorAccountDetails.PaymentType);
                if (_debtorAccountDetails.PaymentType == PaymentTypes.Faster_Payments)
                {
                    bool isdata = false;
                    // for Faster payment it should be single payment only
                    IEnumerable<TransactionDetails> TransactionDetailsList = DBRepository.GetTransactionDetails(_debtorAccountDetails, "YTS", 1);
                    while (TransactionDetailsList.Count() > 0)
                    {
                        TransactionDetailsList = UpdateInstrIdAndEndToEndId(TransactionDetailsList);
                        Faster _faster = new Faster();
                        _faster.Generate_Faster(TransactionDetailsList, _debtorAccountDetails);
                        isdata = true;
                        if (isdata)
                            DBRepository.UpdateStatus(TransactionDetailsList, "WIP");

                        TransactionDetailsList = DBRepository.GetTransactionDetails(_debtorAccountDetails, "YTS", 1);
                    }
                }
                else if (_debtorAccountDetails.PaymentType == PaymentTypes.US_ACH)
                {
                    bool isdata = false;
                    // for Faster payment it should be single payment only
                    IEnumerable<TransactionDetails> TransactionDetailsList = DBRepository.GetTransactionDetails(_debtorAccountDetails, "YTS", 0);
                    while (TransactionDetailsList.Count() > 0)
                    {
                        TransactionDetailsList = UpdateInstrIdAndEndToEndId(TransactionDetailsList);
                        USACH _usach = new USACH();
                        isdata = _usach.Generate_US_ACH(TransactionDetailsList, _debtorAccountDetails);
                        isdata = true;
                        if (isdata)
                            DBRepository.UpdateStatus(TransactionDetailsList, "WIP");

                        TransactionDetailsList = DBRepository.GetTransactionDetails(_debtorAccountDetails, "YTS", 0);
                    }
                }
                else if (_debtorAccountDetails.PaymentType == PaymentTypes.CA_ACH)
                {
                    bool isdata = false;
                    // for Faster payment it should be single payment only
                    IEnumerable<TransactionDetails> TransactionDetailsList = DBRepository.GetTransactionDetails(_debtorAccountDetails, "YTS", 0);
                    while (TransactionDetailsList.Count() > 0)
                    {
                        TransactionDetailsList = UpdateInstrIdAndEndToEndId(TransactionDetailsList);
                        CAACH _caach = new CAACH();
                        isdata = _caach.Generate_CA_ACH(TransactionDetailsList, _debtorAccountDetails);
                        isdata = true;
                        if (isdata)
                            DBRepository.UpdateStatus(TransactionDetailsList, "WIP");

                        TransactionDetailsList = DBRepository.GetTransactionDetails(_debtorAccountDetails, "YTS", 0);
                    }
                }
                else
                {
                    IEnumerable<TransactionDetails> TransactionDetailsList = DBRepository.GetTransactionDetails(_debtorAccountDetails, "YTS", IsSinglePayment);
                    while (TransactionDetailsList.Count() > 0)
                    {
                        TransactionDetailsList = UpdateInstrIdAndEndToEndId(TransactionDetailsList);
                        bool isdata = false;
                        log.InfoFormat("TransactionDetailsList count: " + TransactionDetailsList.Count());
                        //if (_debtorAccountDetails.PaymentType == PaymentTypes.US_ACH)
                        //{
                        //    USACH _usach = new USACH();
                        //    _usach.Generate_US_ACH(TransactionDetailsList, _debtorAccountDetails);
                        //    isdata = true;
                        //}
                        //else 
                        if (_debtorAccountDetails.PaymentType == PaymentTypes.US_Wire)
                        {
                            US_Wire _us_Wire = new US_Wire();
                            _us_Wire.Generate_US_Wire(TransactionDetailsList, _debtorAccountDetails);
                            isdata = true;
                        }
                        else if (_debtorAccountDetails.PaymentType == PaymentTypes.CA_Wire)
                        {
                            CA_Wire _ca_Wire = new CA_Wire();
                            _ca_Wire.Generate_CA_Wire(TransactionDetailsList, _debtorAccountDetails);
                            isdata = true;
                        }
                        else if (_debtorAccountDetails.PaymentType == PaymentTypes.SEPA_Payments)
                        {
                            SEPA sepa = new SEPA();
                            sepa.Generate_SEPA_XML(TransactionDetailsList, _debtorAccountDetails);
                            isdata = true;
                        }
                        else if (_debtorAccountDetails.PaymentType == PaymentTypes.CHAPS_Payments)
                        {
                            PP_Chaps _pp_Chaps = new PP_Chaps();
                            _pp_Chaps.Generate_PP_Chaps(TransactionDetailsList, _debtorAccountDetails);
                            isdata = true;
                        }

                        if (isdata)
                            DBRepository.UpdateStatus(TransactionDetailsList, "WIP");

                        TransactionDetailsList = DBRepository.GetTransactionDetails(_debtorAccountDetails, "YTS", IsSinglePayment);
                    }

                }
            }
        }
        public void CheckStatus()
        {
            log.InfoFormat("Payment Calls ended");
            IEnumerable<TransactionDetails> WIPTransactionDetailsList = DBRepository.GetTransactionDetailsByStatus("WIP");
            log.InfoFormat("WIPTransactionDetailsList: " + WIPTransactionDetailsList.Count());
            var wipgp = WIPTransactionDetailsList.GroupBy(a => a.MsgId).Select(b => new { MsgId = b.Key, items = b, cnt = b.Count() });
            log.InfoFormat("Wip Groups: " + wipgp.Count());
            int i = 1;
            foreach (var ibi in wipgp)
            {
                log.InfoFormat("CheckStatus for payment type: " + ibi.items.FirstOrDefault().PaymentTypeId + ", Message ID: " + ibi.MsgId);
                try
                {
                    string CheckStatus = "<StatusEnquiry><ProfileID>" + hsbcheader.Where(a => a.Key == "x-hsbc-profile-id").FirstOrDefault().Value + "</ProfileID><Key><MessageID>" + ibi.MsgId + "</MessageID></Key></StatusEnquiry>";

                    PGPData pg = new PGPData();

                    pg.Text = CheckStatus;

                    string EncryptJson = CommonResource.Encrypt(pg);

                    HSBC_API HAPI = new HSBC_API();

                    PaymentStatusResponce dt = new PaymentStatusResponce();

                    if (ibi.items.FirstOrDefault().PaymentType == PaymentTypes.Faster_Payments)
                    {
                        //continue;
                        dt = HAPI.CheckStatusFasterPayment(ibi.items.FirstOrDefault().referenceId);
                    }
                    else
                    {                       
                        dt = HAPI.CheckStatus(EncryptJson);
                    }


                    pg.Text = dt.responseBase64;

                    var response = CommonResource.Decrypt(pg);
                    if (string.IsNullOrEmpty(response) || (!string.IsNullOrEmpty(response) && !response.Contains("<TxInfAndSts")))
                    {
                        foreach (var item in ibi.items)
                        {
                            dt.responseBase64 = response;

                            if (Regex.Match(dt.statusDesc, "System error occurred",RegexOptions.IgnoreCase).Success)
                            {
                                DBRepository.UpdateTransactionDetailsStatus(dt, item, "WIP");
                            }
                            else if ((dt.statusCode == "ACCP" && Regex.Match(dt.statusDesc, "Accepted Instruction Validation \\(L([2-5])\\)").Success) || dt.statusCode == "RJCT")
                            {
                                DBRepository.UpdateTransactionDetailsStatus(dt, item, dt.statusCode);
                            }
                            else if ((dt.statusCode == "ACWC" && Regex.Match(dt.statusDesc, "Accepted With Changes \\(L([2-5])\\)").Success))
                            {
                                DBRepository.UpdateTransactionDetailsStatus(dt, item, "ACCP");
                            }
                            else if (dt.statusCode == "ACSC")
                            {
                                DBRepository.UpdateTransactionDetailsStatus(dt, item, "ACCP");
                            }
                            else if (dt.statusCode == "ACSP" && dt.statusDesc.Contains("AcceptedSettlementInProcess"))
                            {
                                DBRepository.UpdateTransactionDetailsStatus(dt, item, "ACCP");
                            }
                            else
                            {
                                DBRepository.UpdateTransactionDetailsStatus(dt, item, "WIP");
                            }
                            DBRepository.InsertStatusReponse(item.TransactionDetailsId.Value, dt);
                        }
                    }
                    else
                    {
                        XmlDocument doc = new XmlDocument();

                        doc.LoadXml(response);

                        XmlNodeList nodeList = doc.GetElementsByTagName("TxInfAndSts");

                        foreach (XmlNode nd in nodeList)
                        {
                            string xml = nd.OuterXml;

                            XmlDocument tempdoc = new XmlDocument();

                            tempdoc.LoadXml(xml);

                            string OrgnlInstrId = tempdoc.GetElementsByTagName("OrgnlEndToEndId")[0].InnerText;

                            string status = tempdoc.GetElementsByTagName("TxSts")[0].InnerText;

                            var item = ibi.items.Where(a => a.EndToEndId == OrgnlInstrId).FirstOrDefault();

                            if (item == null)
                                continue;
                            dt.responseBase64 = xml;

                            if (Regex.Match(dt.statusDesc, "System error occurred", RegexOptions.IgnoreCase).Success)
                            {
                                DBRepository.UpdateTransactionDetailsStatus(dt, item, "WIP");
                            }
                            else if((dt.statusCode == "ACCP" && Regex.Match(dt.statusDesc, "Accepted Instruction Validation \\(L([2-5])\\)").Success) || status == "RJCT" || (dt.statusCode == "PART" && status == "ACCP"))
                            {
                                DBRepository.UpdateTransactionDetailsStatus(dt, item, status);
                            }
                            else if ((dt.statusCode == "ACWC" && Regex.Match(dt.statusDesc, "Accepted With Changes \\(L([2-5])\\)").Success))
                            {
                                DBRepository.UpdateTransactionDetailsStatus(dt, item, "ACCP");
                            }
                            else if (dt.statusCode == "ACSC")
                            {
                                DBRepository.UpdateTransactionDetailsStatus(dt, item, "ACCP");
                            }
                            else if (dt.statusCode == "ACSP" && dt.statusDesc.Contains("AcceptedSettlementInProcess"))
                            {
                                DBRepository.UpdateTransactionDetailsStatus(dt, item, "ACCP");
                            }
                            else
                            {
                                DBRepository.UpdateTransactionDetailsStatus(dt, item, "WIP");
                            }
                            DBRepository.InsertStatusReponse(item.TransactionDetailsId.Value, dt);


                        }
                    }
                    log.InfoFormat("Status checked for " + ibi.MsgId + ", Count: " + i);
                    i++;
                }
                catch (Exception ex)
                {
                    log.FatalFormat("Exception occured for " + ibi.MsgId + ", Message: " + ex.Message + "\n Stack Trace: " + ex.StackTrace);
                }
            }
        }
        public void Process_old()
        {
            log.InfoFormat("Process started");
            IEnumerable<DebtorAccountDeatils> _debtorAccountDeatilsList = DBRepository.GetDebtorAccountDetails();

            foreach (DebtorAccountDeatils _debtorAccountDetails in _debtorAccountDeatilsList)
            {
                log.InfoFormat("Payment type: " + _debtorAccountDetails.PaymentType);
                if (_debtorAccountDetails.PaymentType.Replace(" ", "_") == Convert.ToString(CommonResource.PaymentTypes.Faster_Payments))
                {
                    bool isdata = false;

                    IEnumerable<TransactionDetails> TransactionDetailsList = DBRepository.GetTransactionDetails(_debtorAccountDetails, "YTS", 1);
                    while (TransactionDetailsList.Count() > 0)
                    {
                        TransactionDetailsList = UpdateInstrIdAndEndToEndId(TransactionDetailsList);
                        Faster _faster = new Faster();
                        _faster.Generate_Faster(TransactionDetailsList, _debtorAccountDetails);
                        isdata = true;
                        if (isdata)
                            DBRepository.UpdateStatus(TransactionDetailsList, "WIP");

                        TransactionDetailsList = DBRepository.GetTransactionDetails(_debtorAccountDetails, "YTS", 1);
                    }
                }
                else
                {
                    IEnumerable<TransactionDetails> TransactionDetailsList = DBRepository.GetTransactionDetails(_debtorAccountDetails, "YTS", 0);
                    if (TransactionDetailsList.Count() > 0)
                    {
                        TransactionDetailsList = UpdateInstrIdAndEndToEndId(TransactionDetailsList);
                        bool isdata = false;
                        log.InfoFormat("TransactionDetailsList count: " + TransactionDetailsList.Count());
                        if (_debtorAccountDetails.PaymentType.Replace(" ", "_") == Convert.ToString(CommonResource.PaymentTypes.US_ACH))
                        {
                            USACH _usach = new USACH();
                            _usach.Generate_US_ACH(TransactionDetailsList, _debtorAccountDetails);
                            isdata = true;
                        }
                        else if (_debtorAccountDetails.PaymentType.Replace(" ", "_") == Convert.ToString(CommonResource.PaymentTypes.US_Wire))
                        {
                            US_Wire _us_Wire = new US_Wire();
                            _us_Wire.Generate_US_Wire(TransactionDetailsList, _debtorAccountDetails);
                            isdata = true;
                        }
                        else if (_debtorAccountDetails.PaymentType.Replace(" ", "_") == Convert.ToString(CommonResource.PaymentTypes.SEPA_Payments))
                        {
                            SEPA sepa = new SEPA();
                            sepa.Generate_SEPA_XML(TransactionDetailsList, _debtorAccountDetails);
                            isdata = true;
                        }
                        else if (_debtorAccountDetails.PaymentType.Replace(" ", "_") == Convert.ToString(CommonResource.PaymentTypes.CHAPS_Payments))
                        {
                            PP_Chaps _pp_Chaps = new PP_Chaps();
                            _pp_Chaps.Generate_PP_Chaps(TransactionDetailsList, _debtorAccountDetails);
                            isdata = true;
                        }
                        else if (_debtorAccountDetails.PaymentType.Replace(" ", "_") == Convert.ToString(CommonResource.PaymentTypes.Faster_Payments))
                        {
                            Faster _faster = new Faster();
                            _faster.Generate_Faster(TransactionDetailsList, _debtorAccountDetails);
                            isdata = true;
                        }
                        if (isdata)
                            DBRepository.UpdateStatus(TransactionDetailsList, "WIP");
                    }

                }
            }
            log.InfoFormat("Payment Calls ended");
            IEnumerable<TransactionDetails> WIPTransactionDetailsList = DBRepository.GetTransactionDetailsByStatus("WIP");
            log.InfoFormat("WIPTransactionDetailsList: " + WIPTransactionDetailsList.Count());
            var wipgp = WIPTransactionDetailsList.GroupBy(a => a.MsgId).Select(b => new { MsgId = b.Key, items = b, cnt = b.Count() });
            log.InfoFormat("Wip Groups: " + wipgp.Count());
            int i = 1;
            foreach (var ibi in wipgp)
            {
                log.InfoFormat("CheckStatus for payment type: " + ibi.items.FirstOrDefault().PaymentTypeId + ", Message ID: " + ibi.MsgId);
                try
                {
                    string CheckStatus = "<StatusEnquiry><ProfileID>" + hsbcheader.Where(a => a.Key == "x-hsbc-profile-id").FirstOrDefault().Value + "</ProfileID><Key><MessageID>" + ibi.MsgId + "</MessageID></Key></StatusEnquiry>";

                    PGPData pg = new PGPData();

                    pg.Text = CheckStatus;

                    string EncryptJson = CommonResource.Encrypt(pg);

                    HSBC_API HAPI = new HSBC_API();

                    var dt = HAPI.CheckStatus(EncryptJson);

                    pg.Text = dt.responseBase64;

                    var response = CommonResource.Decrypt(pg);
                    if (string.IsNullOrEmpty(response))
                    {
                        foreach (var item in ibi.items)
                        {
                            if ((dt.statusCode == "ACCP" && Regex.Match(dt.statusDesc, "Accepted Instruction Validation \\(L([2-5])\\)").Success) || dt.statusCode == "RJCT")
                            {
                                DBRepository.UpdateTransactionDetailsStatus(dt, item, dt.statusCode);
                            }
                            else if ((dt.statusCode == "ACWC" && Regex.Match(dt.statusDesc, "Accepted With Changes \\(L([2-5])\\)").Success))
                            {
                                DBRepository.UpdateTransactionDetailsStatus(dt, item, "ACCP");
                            }
                            else
                            {
                                DBRepository.UpdateTransactionDetailsStatus(dt, item, "WIP");
                            }
                            DBRepository.InsertStatusReponse(item.TransactionDetailsId.Value, dt);
                        }
                    }
                    else
                    {
                        XmlDocument doc = new XmlDocument();

                        doc.LoadXml(response);

                        XmlNodeList nodeList = doc.GetElementsByTagName("TxInfAndSts");

                        foreach (XmlNode nd in nodeList)
                        {
                            string xml = nd.OuterXml;

                            XmlDocument tempdoc = new XmlDocument();

                            tempdoc.LoadXml(xml);

                            string OrgnlInstrId = tempdoc.GetElementsByTagName("OrgnlEndToEndId")[0].InnerText;

                            string status = tempdoc.GetElementsByTagName("TxSts")[0].InnerText;

                            var item = ibi.items.Where(a => a.EndToEndId == OrgnlInstrId).FirstOrDefault();

                            if (item == null)
                                continue;
                            dt.responseBase64 = xml;

                            if ((dt.statusCode == "ACCP" && Regex.Match(dt.statusDesc, "Accepted Instruction Validation \\(L([2-5])\\)").Success) || status == "RJCT")
                            {
                                DBRepository.UpdateTransactionDetailsStatus(dt, item, status);
                            }
                            else if ((dt.statusCode == "ACWC" && Regex.Match(dt.statusDesc, "Accepted With Changes \\(L([2-5])\\)").Success))
                            {
                                DBRepository.UpdateTransactionDetailsStatus(dt, item, "ACCP");
                            }
                            else
                            {
                                DBRepository.UpdateTransactionDetailsStatus(dt, item, "WIP");
                            }
                            DBRepository.InsertStatusReponse(item.TransactionDetailsId.Value, dt);
                        }
                    }
                    log.InfoFormat("Status checked for " + ibi.MsgId + ", Count: " + i);
                    i++;
                }
                catch (Exception ex)
                {
                    log.FatalFormat("Exception occured for " + ibi.MsgId + ", Message: " + ex.Message + "\n Stack Trace: " + ex.StackTrace);
                }
            }
            //DB dB = new DB();
            //DataTable DT = dB.GetData("GetDebtorAccountDeatils", null, true);
            //for (int i = 0; i < DT.Rows.Count; i++)
            //{

            //    DataTable TransactionDt = DBRepository.get(DT.Rows[i]["ProjectCode"].ToString(), Convert.ToInt32(DT.Rows[i]["PaymentTypeId"]), "YTS");
            //}
        }

        public IEnumerable<TransactionDetails> UpdateInstrIdAndEndToEndId(IEnumerable<TransactionDetails> TransactionDetailsList)
        {
            foreach (TransactionDetails _transactionDetails in TransactionDetailsList)
            {
                string InstrId = DateTime.Now.ToString("yyyyMMdd") + Guid.NewGuid().ToString().GetHashCode().ToString("x");

                int InstrIdCnt = DBRepository.UpdateInstrId(InstrId, _transactionDetails.TransactionDetailsId.Value);
                if (InstrIdCnt < 1)
                {
                    while (InstrIdCnt < 1)
                    {
                        InstrId = DateTime.Now.ToString("yyyyMMdd") + Guid.NewGuid().ToString().GetHashCode().ToString("x");
                        InstrIdCnt = DBRepository.UpdateInstrId(InstrId, _transactionDetails.TransactionDetailsId.Value);
                    }
                }
                _transactionDetails.InstrId = InstrId;


                string EndToEndId = DateTime.Now.ToString("yyyyMMdd") + Guid.NewGuid().ToString().GetHashCode().ToString("x");
                int EndToEndIdCnt = DBRepository.UpdateEndToEndId(EndToEndId, _transactionDetails.TransactionDetailsId.Value);
                if (EndToEndIdCnt < 1)
                {
                    while (EndToEndIdCnt < 1)
                    {
                        EndToEndId = DateTime.Now.ToString("yyyyMMdd") + Guid.NewGuid().ToString().GetHashCode().ToString("x");
                        EndToEndIdCnt = DBRepository.UpdateEndToEndId(EndToEndId, _transactionDetails.TransactionDetailsId.Value);
                    }
                }
                _transactionDetails.EndToEndId = EndToEndId;
            }
            return TransactionDetailsList;
        }
    }
}
