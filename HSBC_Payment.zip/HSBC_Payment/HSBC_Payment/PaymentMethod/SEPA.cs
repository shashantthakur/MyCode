﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace HSBC_Payment
{
    class SEPA
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(typeof(Program));
        public IEnumerable<HSBCKeyValue> hsbcheader = DBRepository.GetAPIHeaderDetails(ConfigurationManager.AppSettings["env"]);
        public void Generate_SEPA_XML(IEnumerable<TransactionDetails> transactionDetailsList, DebtorAccountDeatils debtorAccountDetails)
        {
            log.InfoFormat("Generate_SEPA_XML started");
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(Application.StartupPath + @"/Template/SEPA.xml");

                string ProfileID = hsbcheader.Where(a => a.Key == "x-hsbc-profile-id").FirstOrDefault().Value;

                CommonResource.AssignValueByPath(doc, "//*[name()='GrpHdr']//*[name()='InitgPty']//*[name()='Othr']//*[name()='Id']", ProfileID);
                CommonResource.AssignValueByTagName(doc, "MsgId", Convert.ToString(transactionDetailsList.FirstOrDefault().MsgId));
                CommonResource.AssignValueByTagName(doc, "PmtInfId", Convert.ToString(transactionDetailsList.FirstOrDefault().PmtInfId));
                CommonResource.AssignValueByTagName(doc, "CreDtTm", DateTime.Now.ToString("yyyy-MM-dd'T'HH:mm:ss"));
                CommonResource.AssignValueByTagName(doc, "NbOfTxs", Convert.ToString(transactionDetailsList.Count()));
                CommonResource.AssignValueByTagName(doc, "CtrlSum", transactionDetailsList.Select(a => a.TotalAmount.Value).Sum().ToString("0.00"));
                CommonResource.AssignValueByTagName(doc, "ReqdExctnDt", DateTime.Now.ToString("yyyy-MM-dd"));
                CommonResource.AssignValueByPath(doc, "//*[name()='Dbtr']//*[name()='OrgId']//*[name()='Id']", Convert.ToString(debtorAccountDetails.AchId));
                CommonResource.AssignValueByPath(doc, "//*[name()='DbtrAcct']//*[name()='IBAN']", debtorAccountDetails.IBAN);
                CommonResource.AssignValueByPath(doc, "//*[name()='DbtrAgt']//*[name()='FinInstnId']//*[name()='BIC']", debtorAccountDetails.BIC);
                CommonResource.AssignValueByPath(doc, "//*[name()='DbtrAgt']//*[name()='FinInstnId']//*[name()='Ctry']", debtorAccountDetails.Location);


                //string FileDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location) + "//OutPut";

                PGPData pg = new PGPData();

                //string EsproApi = ConfigurationManager.AppSettings["EsproApi"];

                //pg.Text = CommonResource.PostURI(EsproApi + "HSBC/GetInvoiceBankInfo?InvoiceSummaryIDs=" + string.Join(",", transactionDetailsList.Select(a => a.InvoiceSummaryId)));

                if (debtorAccountDetails.ProjectCode == "ESPRO")
                {
                    string EsproApi = ConfigurationManager.AppSettings["EsproApi"];

                    pg.Text = CommonResource.PostURI(EsproApi + "HSBC/GetInvoiceBankInfo?InvoiceSummaryIDs=" + string.Join(",", transactionDetailsList.Select(a => a.InvoiceSummaryId)), debtorAccountDetails.ProjectCode);
                }
                else if (debtorAccountDetails.ProjectCode == "ESC")
                {
                    string EsproApi = ConfigurationManager.AppSettings["ESCApi"];

                    pg.Text = CommonResource.PostURI(EsproApi + "Bank/GetInvoiceBankInfo?InvoiceSummaryIDs=" + string.Join(",", transactionDetailsList.Select(a => a.InvoiceSummaryId)), debtorAccountDetails.ProjectCode);
                }
                else if (debtorAccountDetails.ProjectCode == "ES2")
                {
                    string EsproApi = ConfigurationManager.AppSettings["ES2Api"];

                    pg.Text = CommonResource.PostURI(EsproApi + "Bank/GetInvoiceBankInfo?InvoiceSummaryIDs=" + string.Join(",", transactionDetailsList.Select(a => a.InvoiceSummaryId)), debtorAccountDetails.ProjectCode);
                }
                else
                {
                    log.FatalFormat("Generate_SEPA: Invalid Project code : " + debtorAccountDetails.ProjectCode);
                    return;
                }

                var json = CommonResource.Decrypt(pg);

                invoiceBankInfos invoiceBankInfo = CommonResource.JsonToClass<invoiceBankInfos>(json);

                foreach (var ibi in invoiceBankInfo.invoiceBankInfosList)
                {
                    XmlDocument creditdoc = new XmlDocument();
                    creditdoc.Load(Application.StartupPath + @"/Template/SEPA_Cdt.xml");
                    var invoice = transactionDetailsList.Where(a => a.InvoiceSummaryId == ibi.InvoiceID).FirstOrDefault();
                    CommonResource.AssignValueByTagName(creditdoc, "InstrId", Convert.ToString(invoice.InstrId));
                    CommonResource.AssignValueByTagName(creditdoc, "EndToEndId", Convert.ToString(invoice.EndToEndId));
                    CommonResource.AssignValueByTagName(creditdoc, "MmbId", Convert.ToString(ibi.RoutingID));
                    CommonResource.AssignValueByPath(creditdoc, "//*[name()='FinInstnId']//*[name()='Ctry']", Convert.ToString(ibi.BankISOCode));
                    CommonResource.AssignValueByPath(creditdoc, "//*[name()='FinInstnId']//*[name()='BIC']", Convert.ToString(ibi.SwiftCode));
                    CommonResource.AssignValueByTagName(creditdoc, "Nm", Convert.ToString(ibi.AccountName));
                    CommonResource.AssignValueByTagName(creditdoc, "StrtNm", Convert.ToString(ibi.Street));
                    CommonResource.AssignValueByTagName(creditdoc, "PstCd", Convert.ToString(ibi.PostalCode));
                    CommonResource.AssignValueByTagName(creditdoc, "TwnNm", Convert.ToString(ibi.City));
                    CommonResource.AssignValueByTagName(creditdoc, "CtrySubDvsn", Convert.ToString(ibi.State));
                    CommonResource.AssignValueByPath(creditdoc, "//*[name()='Cdtr']//*[name()='Ctry']", Convert.ToString(ibi.HomeAddressISOCode));
                    CommonResource.AssignValueByPath(creditdoc, "//*[name()='CdtrAcct']//*[name()='IBAN']", Convert.ToString(ibi.IBANNumber));
                    CommonResource.AssignValueByTagName(creditdoc, "Nb", Convert.ToString(invoice.InvoiceName));
                    CommonResource.AssignValueByTagName(creditdoc, "RltdDt", Convert.ToString(invoice.InvoiceDate.ToString("yyyy-MM-dd")));

                    XmlNodeList InstdAmt = creditdoc.GetElementsByTagName("InstdAmt");
                    InstdAmt[0].InnerText = invoice.TotalAmount.Value.ToString("0.00");
                    InstdAmt[0].Attributes.GetNamedItem("Ccy").Value = ibi.Currency;

                    XmlNodeList DuePyblAmt = creditdoc.GetElementsByTagName("DuePyblAmt");
                    DuePyblAmt[0].InnerText = invoice.TotalAmount.Value.ToString("0.00");
                    DuePyblAmt[0].Attributes.GetNamedItem("Ccy").Value = ibi.Currency;


                    XmlNode PmtInf = doc.GetElementsByTagName("PmtInf")[0];
                    XmlNode newNode = doc.CreateElement("CdtTrfTxInf");
                    newNode.InnerXml = creditdoc.GetElementsByTagName("CdtTrfTxInf")[0].InnerXml;
                    PmtInf.AppendChild(newNode);
                }

                //if (!System.IO.Directory.Exists(FileDirectory))
                //{
                //    System.IO.Directory.CreateDirectory(FileDirectory);
                //}

                string Buf = doc.OuterXml;

                Buf = Buf.Replace(" xmlns=\"\"", "");

                pg = new PGPData();

                pg.Text = Buf;

                DBRepository.InsertXMLDetails(transactionDetailsList.FirstOrDefault().TransactionMasterId.Value, Buf);

                string EncryptJson = CommonResource.Encrypt(pg);

                HSBC_API HAPI = new HSBC_API();

                var result = HAPI.PostDataToHSBC(EncryptJson);

                string outputXML = CommonResource.Decrypt(new PGPData() { Text = result.responseBase64 });

                if (!string.IsNullOrEmpty(outputXML))
                    result.responseBase64 = outputXML;

               

                DBRepository.UpdateHSBCTranscationMasterResponse(transactionDetailsList.FirstOrDefault().TransactionMasterId.Value, result, debtorAccountDetails.ProjectCode);

                //if (result.statusCode == "RJCT")
                //{
                DBRepository.InsertPaymentReponse(transactionDetailsList.FirstOrDefault().TransactionMasterId.Value, result);
                //}

                //foreach (var ibi in invoiceBankInfo.invoiceBankInfosList)
                //{
                //    var invoice = transactionDetailsList.Where(a => a.InvoiceSummaryId == ibi.InvoiceID).FirstOrDefault();

                //    string CheckStatus = "<StatusEnquiry><ProfileID>" + hsbcheader.Where(a => a.Key == "x-hsbc-profile-id").FirstOrDefault().Value + "</ProfileID><Key><MessageID>" + invoice.MsgId + "</MessageID></Key></StatusEnquiry>";

                //    pg = new PGPData();

                //    pg.Text = CheckStatus;

                //    EncryptJson = CommonResource.Encrypt(pg);

                //    var dt = HAPI.CheckStatus(EncryptJson);
                //}

                //File.WriteAllText(FileDirectory + @"/SEPA_" + DateTime.Now.ToString("yyyyMM-dd_HHmmss") + ".xml", Buf);
            }
            catch (Exception ex)
            {
                log.FatalFormat("Generate_SEPA_XML: exception occured,message: " + ex.Message + "\n Stack trace: " + ex.StackTrace);
            }
            log.InfoFormat("Generate_SEPA_XML Ended");
        }
    }
}
