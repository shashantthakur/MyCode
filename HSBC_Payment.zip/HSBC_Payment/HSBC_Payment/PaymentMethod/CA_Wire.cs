﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace HSBC_Payment
{
    class CA_Wire
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(typeof(Program));

        public IEnumerable<HSBCKeyValue> hsbcheader = DBRepository.GetAPIHeaderDetails(ConfigurationManager.AppSettings["env"]);
        public void Generate_CA_Wire(IEnumerable<TransactionDetails> transactionDetailsList, DebtorAccountDeatils debtorAccountDetails)
        {
            log.InfoFormat("Generate_CA_Wire started");
            try
            {
                XmlDocument doc = new XmlDocument();

                doc.Load(Application.StartupPath + @"/Template/CA_Wire.xml");

                string ProfileID = hsbcheader.Where(a => a.Key == "x-hsbc-profile-id").FirstOrDefault().Value;

                CommonResource.AssignValueByPath(doc, "//*[name()='GrpHdr']//*[name()='InitgPty']//*[name()='Othr']//*[name()='Id']", ProfileID);

                CommonResource.AssignValueByTagName(doc, "MsgId", transactionDetailsList.FirstOrDefault().MsgId);
                CommonResource.AssignValueByTagName(doc, "PmtInfId", transactionDetailsList.FirstOrDefault().PmtInfId);
                CommonResource.AssignValueByTagName(doc, "CreDtTm", transactionDetailsList.FirstOrDefault().CreDtTm.ToString("yyyy-MM-dd'T'HH:mm:ss"));

                CommonResource.AssignValueByTagName(doc, "NbOfTxs", transactionDetailsList.Count().ToString());

                CommonResource.AssignValueByTagName(doc, "CtrlSum", transactionDetailsList.Select(a => a.TotalAmount.Value).Sum().ToString("0.00"));
                CommonResource.AssignValueByTagName(doc, "ReqdExctnDt", DateTime.Now.ToString("yyyy-MM-dd"));

                CommonResource.AssignValueByPath(doc, "//*[name()='DbtrAcct']//*[name()='Othr']//*[name()='Id']", debtorAccountDetails.AccountNumber);
                CommonResource.AssignValueByPath(doc, "//*[name()='DbtrAgt']//*[name()='FinInstnId']//*[name()='BIC']", debtorAccountDetails.BIC);
                CommonResource.AssignValueByPath(doc, "//*[name()='DbtrAgt']//*[name()='FinInstnId']//*[name()='Ctry']", debtorAccountDetails.Location);


                PGPData pg = new PGPData();

                //string EsproApi = ConfigurationManager.AppSettings["EsproApi"];
                //pg.Text = CommonResource.PostURI(EsproApi + "HSBC/GetInvoiceBankInfo?InvoiceSummaryIDs=" + string.Join(",", transactionDetailsList.Select(a => a.InvoiceSummaryId)));

                if (debtorAccountDetails.ProjectCode == "ESPRO")
                {
                    string EsproApi = ConfigurationManager.AppSettings["EsproApi"];

                    pg.Text = CommonResource.PostURI(EsproApi + "HSBC/GetInvoiceBankInfo?InvoiceSummaryIDs=" + string.Join(",", transactionDetailsList.Select(a => a.InvoiceSummaryId)), debtorAccountDetails.ProjectCode);
                }
                else if (debtorAccountDetails.ProjectCode == "ES2")
                {
                    string EsproApi = ConfigurationManager.AppSettings["ES2Api"];

                    pg.Text = CommonResource.PostURI(EsproApi + "Bank/GetInvoiceBankInfo?InvoiceSummaryIDs=" + string.Join(",", transactionDetailsList.Select(a => a.InvoiceSummaryId)), debtorAccountDetails.ProjectCode);
                }
                else if (debtorAccountDetails.ProjectCode == "ESC")
                {
                    string EsproApi = ConfigurationManager.AppSettings["ESCApi"];

                    pg.Text = CommonResource.PostURI(EsproApi + "Bank/GetInvoiceBankInfo?InvoiceSummaryIDs=" + string.Join(",", transactionDetailsList.Select(a => a.InvoiceSummaryId)), debtorAccountDetails.ProjectCode);
                }
                else
                {
                    log.FatalFormat("Generate_CA_Wire: Invalid Project code : " + debtorAccountDetails.ProjectCode);
                    return;
                }

                var json = CommonResource.Decrypt(pg);

                if (String.IsNullOrEmpty(json.ToString()))
                {
                    log.FatalFormat("Generate_CA_Wire: Invoice Return empty : " + string.Join(",", transactionDetailsList.Select(a => a.InvoiceSummaryId)));
                    return;
                }
                invoiceBankInfos invoiceBankInfo = CommonResource.JsonToClass<invoiceBankInfos>(json);

                foreach (var ibi in invoiceBankInfo.invoiceBankInfosList)
                {
                    XmlDocument creditdoc = new XmlDocument();
                   
                        creditdoc.Load(Application.StartupPath + @"/Template/CA_Wire_Cdt.xml");
                        var invoice = transactionDetailsList.Where(a => a.InvoiceSummaryId == ibi.InvoiceID).FirstOrDefault();
                        CommonResource.AssignValueByTagName(creditdoc, "InstrId", Convert.ToString(invoice.InstrId));
                        CommonResource.AssignValueByTagName(creditdoc, "EndToEndId", Convert.ToString(invoice.EndToEndId));
                        CommonResource.AssignValueByTagName(creditdoc, "BIC", Convert.ToString(ibi.SwiftCode));
                        CommonResource.AssignValueByPath(creditdoc, "//*[name()='FinInstnId']//*[name()='Ctry']", Convert.ToString(ibi.BankISOCode));


                        CommonResource.AssignValueByPath(creditdoc, "//*[name()='Cdtr']//*[name()='Nm']", Convert.ToString(ibi.AccountName));
                        CommonResource.AssignValueByPath(creditdoc, "//*[name()='Cdtr']//*[name()='StrtNm']", Convert.ToString(ibi.Street));
                        CommonResource.AssignValueByPath(creditdoc, "//*[name()='Cdtr']//*[name()='PstCd']", Convert.ToString(ibi.PostalCode));
                        CommonResource.AssignValueByPath(creditdoc, "//*[name()='Cdtr']//*[name()='TwnNm']", Convert.ToString(ibi.City));
                        CommonResource.AssignValueByPath(creditdoc, "//*[name()='Cdtr']//*[name()='CtrySubDvsn']", Convert.ToString(ibi.State));
                        CommonResource.AssignValueByPath(creditdoc, "//*[name()='Cdtr']//*[name()='Ctry']", Convert.ToString(ibi.HomeAddressISOCode));

                        if (ibi.BankISOCode == "GB")
                        {
                            CommonResource.AssignValueByPath(creditdoc, "//*[name()='CdtrAcct']//*[name()='Othr']//*[name()='Id']", Convert.ToString(ibi.IBANNumber));
                        }
                        else
                        {
                            CommonResource.AssignValueByPath(creditdoc, "//*[name()='CdtrAcct']//*[name()='Othr']//*[name()='Id']", Convert.ToString(ibi.AccountNumber));
                        }

                        CommonResource.AssignValueByTagName(creditdoc, "Ustrd", Convert.ToString(invoice.InvoiceName));
                        //if (invoice.ContractCurrency == "USD")
                        //{
                        //    //CommonResource.AssignValueByTagName(creditdoc, "InstrInf", "ACC /PPRO/");
                        //    CommonResource.AssignValueByTagName(creditdoc, "InstrInf", "/ACC//PPRO/");
                        //}
                        //CommonResource.AssignValueByTagName(creditdoc, "Nb", Convert.ToString(invoice.InvoiceName));
                        //CommonResource.AssignValueByTagName(creditdoc, "RltdDt", Convert.ToString(invoice.InvoiceDate.ToString("yyyy-MM-dd")));

                        XmlNodeList InstdAmt = creditdoc.GetElementsByTagName("InstdAmt");
                        InstdAmt[0].InnerText = invoice.TotalAmount.Value.ToString("0.00");
                        InstdAmt[0].Attributes.GetNamedItem("Ccy").Value = invoice.ContractCurrency;

                        //XmlNodeList DuePyblAmt = creditdoc.GetElementsByTagName("DuePyblAmt");
                        //DuePyblAmt[0].InnerText = invoice.TotalAmount.Value.ToString("0.00");
                        //DuePyblAmt[0].Attributes.GetNamedItem("Ccy").Value = invoice.ContractCurrency;


                        XmlNode PmtInf = doc.GetElementsByTagName("PmtInf")[0];
                        XmlNode newNode = doc.CreateElement("CdtTrfTxInf");
                        newNode.InnerXml = creditdoc.GetElementsByTagName("CdtTrfTxInf")[0].InnerXml;
                        PmtInf.AppendChild(newNode);
                    

                }

                //string FileDirectory = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location) + "//OutPut";
                //if (!System.IO.Directory.Exists(FileDirectory))
                //{
                //    System.IO.Directory.CreateDirectory(FileDirectory);
                //}

                string Buf = doc.OuterXml;

                Buf = Buf.Replace(" xmlns=\"\"", "");

                pg = new PGPData();

                pg.Text = Buf;

                DBRepository.InsertXMLDetails(transactionDetailsList.FirstOrDefault().TransactionMasterId.Value, Buf);

                string EncryptJson = CommonResource.Encrypt(pg);

                HSBC_API HAPI = new HSBC_API();

                var result = HAPI.PostDataToHSBC(EncryptJson);

                string outputXML = CommonResource.Decrypt(new PGPData() { Text = result.responseBase64 });

                if (!string.IsNullOrEmpty(outputXML))
                    result.responseBase64 = outputXML;



                DBRepository.UpdateHSBCTranscationMasterResponse(transactionDetailsList.FirstOrDefault().TransactionMasterId.Value, result, debtorAccountDetails.ProjectCode);

                DBRepository.InsertPaymentReponse(transactionDetailsList.FirstOrDefault().TransactionMasterId.Value, result);

            }
            catch (Exception ex)
            {
                log.FatalFormat("Generate_CA_Wire: exception occured,message: " + ex.Message + "\n Stack trace: " + ex.StackTrace);
            }
            log.InfoFormat("Generate_CA_Wire Ended");
        }
    }
}

