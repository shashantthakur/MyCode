﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSBC_Payment
{
    public class DebtorAccountDeatils
    {
        public int? PaymentTypeId { get; set; }
        public int? BankAccountId { get; set; }
        public string AccountNumber { get; set; }
        public string AccountName { get; set; }
        public string BankName { get; set; }
        public string AccountType { get; set; }
        public string Location { get; set; }
        public string Currency { get; set; }
        public string BIC { get; set; }
        public string IBAN { get; set; }
        public string AchId { get; set; }
        public string RoutingId { get; set; }
        public string ProjectCode { get; set; }
        public string PaymentType { get; set; }
    }

    
    public class TransactionDetails
    {
        public int? TransactionDetailsId { get; set; }
        public int? BankAccountId { get; set; }
        public int? PaymentTypeId { get; set; }
        public string PaymentType { get; set; }        
        public int? TransactionMasterId { get; set; }
        public int? UsersId { get; set; }
        public int? InvoiceSummaryId { get; set; }
        public string InvoiceName { get; set; }
        public DateTime InvoiceDate { get; set; }
        public DateTime ApproveDate { get; set; }
        public DateTime PaymentDate { get; set; }
        public string ProfileCurrency { get; set; }
        public string ContractCurrency { get; set; }
        public Decimal? TotalAmount { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string InstrId { get; set; }
        public string EndToEndId { get; set; }
        public string referenceId { get; set; }
        public string EnqStatusCode { get; set; }
        public string EnqStatusDesc { get; set; }
        public string MsgId { get; set; }
        public string PmtInfId { get; set; }
        public DateTime CreDtTm { get; set; }

    }

    public class ClientLogin
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public string Client { get; set; }
    }
    public class ApiResponce
    {
        public string Text { get; set; }
    }
}
