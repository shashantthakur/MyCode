﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSBC_Payment
{
    public class InvoiceBankInfosList
    {
        public int? InvoiceID { get; set; }
        public string InvoiceName { get; set; }
        public string ProfileName { get; set; }
        public string ProfileCurrency { get; set; }
        public string Street { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string PostalCode { get; set; }
        public string HomeAddressISOCode { get; set; }
        public string AccountName { get; set; }
        public string BankAddress { get; set; }
        public string BankISOCode { get; set; }
        public string BankName { get; set; }
        public string AccountNumber { get; set; }
        public string BeneficiaryType { get; set; }
        public string RoutingID { get; set; }
        public string SwiftCode { get; set; }
        public string IBANNumber { get; set; }
        public string Currency { get; set; }
        public string EINSSN { get; set; }
        public string AccountType { get; set; }


        public string union_Street { get; set; }
        public string union_City { get; set; }
        public string union_State { get; set; }
        public string union_PostalCode { get; set; }
        public string union_CountryISOCode { get; set; }
        public string union_Name { get; set; }
        public string union_MmbId { get; set; }
    }

    public class invoiceBankInfos
    {
        public List<InvoiceBankInfosList> invoiceBankInfosList { get; set; }
    }
}
