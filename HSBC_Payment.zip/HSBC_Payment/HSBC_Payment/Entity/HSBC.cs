﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSBC_Payment
{
    public class HSBC
    {
        public string paymentBase64 { get; set; }
    }

    public class PaymentStatusEnq
    {
        public string paymentEnquiryBase64 { get; set; }
    }

    public class PaymentStatusResponce
    {
        public string referenceId { get; set; }
        public string profileId { get; set; }
        public string statusCode { get; set; }
        public string statusDesc { get; set; }
        public string responseBase64 { get; set; }
    }


    public class HSBCHeaders
    {
        public string XHsbcClientId { get; set; }
        public string XHsbcClientSecret { get; set; }
        public string XHsbcProfileId { get; set; }
        public string XPayloadType { get; set; }
    }

    public class HSBCKeyValue
    {
        public string Key { get; set; }
        public string Value { get; set; }

    }


    public class Error
    {
        public string ErrorCode { get; set; }
        public string Message { get; set; }
    }

    public class ErrorResponse
    {
        public string Message { get; set; }
        public string Code { get; set; }
        public List<Error> Errors { get; set; }
    }

}
