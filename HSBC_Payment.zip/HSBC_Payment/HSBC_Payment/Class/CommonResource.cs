﻿using PgpCore;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace HSBC_Payment
{
    public static class CommonResource
    {
        private static IPGP _pgp = new IPGP();
        public static HttpClient client = new HttpClient();
        public static string ES2ApiToken { get; set; }
        public static string ESProApiToken { get; set; }
        public static List<T> ToCollection<T>(this DataTable dt)
        {
            if (dt.Rows.Count > 0)
            {
                string js = Newtonsoft.Json.JsonConvert.SerializeObject(dt);
                List<T> lst = Newtonsoft.Json.JsonConvert.DeserializeObject<List<T>>(js);
                return lst;
            }
            else
            {
                List<T> lst = new System.Collections.Generic.List<T>();
                return lst;
            }
        }


        public static List<T> JsonListToCollection<T>(this string json)
        {
            if (!string.IsNullOrEmpty(json))
            {
                List<T> lst = Newtonsoft.Json.JsonConvert.DeserializeObject<List<T>>(json);
                return lst;
            }
            else
            {
                List<T> lst = new System.Collections.Generic.List<T>();
                return lst;
            }
        }

        public static T JsonToClass<T>(this string json)
        {
            if (!string.IsNullOrEmpty(json))
            {
                T lst = Newtonsoft.Json.JsonConvert.DeserializeObject<T>(json);
                return lst;
            }
            else
            {
                T lst = default(T);
                return lst;
            }
        }

        public static string GetEsproToken()
        {
            ESProApiToken = "";
            string ApiPath = ConfigurationManager.AppSettings["EsproApi"] + "/auth/generate.token";
            ClientLogin _clientLogin = new ClientLogin();

            _clientLogin.UserName = ConfigurationManager.AppSettings["ClientUserName"].ToString();// "ESPRO_Schedular";
            _clientLogin.Password = ConfigurationManager.AppSettings["ClientPassword"].ToString();//"123";
            HttpClient _client = new HttpClient();
            _client.DefaultRequestHeaders.Add("Client", "ESPRO");

            string jsonUserString = Newtonsoft.Json.JsonConvert.SerializeObject(_clientLogin);
            var content = new StringContent(jsonUserString, Encoding.UTF8, "application/json");
            _client.Timeout = TimeSpan.FromMinutes(10);
            HttpResponseMessage response = _client.PostAsync(ApiPath, content).Result;
            var Json = response.Content.ReadAsStringAsync().Result;
            if (response.StatusCode == HttpStatusCode.OK)
            {
                ApiResponce _ApiResponce = Newtonsoft.Json.JsonConvert.DeserializeObject<ApiResponce>(Json);
                ESProApiToken = _ApiResponce.Text;
            }
            else
            {
                return "";
            }
            return ESProApiToken;
        }
        //public static string PostURI(string ApiURL, List<KeyValuePair<string, string>> postData = null)
        //{
        //    List<KeyValuePair<string, string>> postInternalData = new List<KeyValuePair<string, string>>();
        //    if (postData != null)
        //    {
        //        postInternalData = postData;
        //    }           
        //    HttpResponseMessage response = client.PostAsync(ApiURL, new FormUrlEncodedContent(postInternalData)).Result;
        //    var Json = response.Content.ReadAsStringAsync().Result;

        //    return Json;
        //}
        public static string PostURI(string ApiURL, string ProjectCode, List<KeyValuePair<string, string>> postData = null)
        {
            int cnt = 0;
        onTokenExpired:
            cnt++;
            List<KeyValuePair<string, string>> postInternalData = new List<KeyValuePair<string, string>>();
            if (postData != null)
            {
                postInternalData = postData;
            }

            if (ProjectCode == "ESPRO")
            {
                if (string.IsNullOrEmpty(ESProApiToken))
                {
                    GetEsproToken();
                }
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", ESProApiToken);
            }
            else if (ProjectCode == "ES2")
            {
                ES2ApiToken = ConfigurationManager.AppSettings["ES2ApiToken"];
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", ES2ApiToken);
            }
            else if (ProjectCode == "ESC")
            {
                ES2ApiToken = ConfigurationManager.AppSettings["ESCApiToken"];
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", ES2ApiToken);
            }

            HttpResponseMessage response = client.PostAsync(ApiURL, new FormUrlEncodedContent(postInternalData)).Result;

            if (response.StatusCode == HttpStatusCode.Unauthorized)
            {
                if (cnt < 2)
                {
                    GetEsproToken();
                    goto onTokenExpired;
                }
            }
            var Json = response.Content.ReadAsStringAsync().Result;
            return Json;
        }

        public static String Decrypt(PGPData pGPData)
        {
            string PrivateKeyPath = Application.StartupPath + "/PGPKeys/" + ConfigurationManager.AppSettings["LuminaPrivateKey"];
            string HSBC_PublicKeyPath = Application.StartupPath + "/PGPKeys/" + ConfigurationManager.AppSettings["HSBCPublicKey"];

            string Buf = "";
            try
            {

                byte[] byteArray = Encoding.ASCII.GetBytes(_pgp.Base64Decode(pGPData.Text));
                MemoryStream inputFileStream = new MemoryStream(byteArray, 0, byteArray.Length);

                // convert stream to string
                Stream outputFileStream = new MemoryStream();

                using (PGP pgp = new PGP())
                {
                    using (Stream privateKeyStream = new FileStream(PrivateKeyPath, FileMode.Open))
                    {
                        pgp.DecryptStream(inputFileStream, outputFileStream, privateKeyStream, "#espro#1234");
                        outputFileStream.Position = 0;
                        StreamReader reader = new StreamReader(outputFileStream);
                        Buf = reader.ReadToEnd();
                    }

                }
            }
            catch (Exception ex)
            {

                return "";
            }
            return Buf;
        }

        public static String Encrypt(PGPData pGPData)
        {
            string PrivateKeyPath = Application.StartupPath + "/PGPKeys/" + ConfigurationManager.AppSettings["LuminaPrivateKey"];
            string HSBC_PublicKeyPath = Application.StartupPath + "/PGPKeys/" + ConfigurationManager.AppSettings["HSBCPublicKey"];

            string Buf = "";
            try
            {
                byte[] byteArray = Encoding.ASCII.GetBytes(pGPData.Text);
                MemoryStream inputFileStream = new MemoryStream(byteArray, 0, byteArray.Length);

                // convert stream to string
                Stream outputFileStream = new MemoryStream();


                using (PGP pgp = new PGP())
                {

                    using (Stream privateKeyStream = new FileStream(PrivateKeyPath, FileMode.Open))
                    {
                        using (Stream publicKeyStream = new FileStream(HSBC_PublicKeyPath, FileMode.Open))
                        {
                            pgp.EncryptStreamAndSign(inputFileStream, outputFileStream, publicKeyStream, privateKeyStream, "#espro#1234", true, true);

                            outputFileStream.Position = 0;
                            StreamReader reader = new StreamReader(outputFileStream);
                            Buf = _pgp.Base64Encode(reader.ReadToEnd());
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                return ex.ToString();

            }
            return Buf;
        }


        public static String LuminaEncrypt(PGPData pGPData)
        {
            string PrivateKeyPath = Application.StartupPath + "/PGPKeys/" + ConfigurationManager.AppSettings["LuminaPrivateKey"];
            string PublicKeyPath = Application.StartupPath + "/PGPKeys/" + ConfigurationManager.AppSettings["LuminaPublicKey"];

            string Buf = "";
            try
            {
                byte[] byteArray = Encoding.ASCII.GetBytes(pGPData.Text);
                MemoryStream inputFileStream = new MemoryStream(byteArray, 0, byteArray.Length);

                // convert stream to string
                Stream outputFileStream = new MemoryStream();


                using (PGP pgp = new PGP())
                {

                    using (Stream privateKeyStream = new FileStream(PrivateKeyPath, FileMode.Open))
                    {
                        using (Stream publicKeyStream = new FileStream(PublicKeyPath, FileMode.Open))
                        {
                            pgp.EncryptStreamAndSign(inputFileStream, outputFileStream, publicKeyStream, privateKeyStream, "#espro#1234", true, true);

                            outputFileStream.Position = 0;
                            StreamReader reader = new StreamReader(outputFileStream);
                            Buf = _pgp.Base64Encode(reader.ReadToEnd());
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                return ex.ToString();

            }
            return Buf;
        }

        public static bool AssignValueByPath(XmlDocument doc, string xPath, string Value)
        {
            XmlNode Node = doc.SelectSingleNode(xPath);
            if (Node != null)
            {
                Node.InnerText = Value;
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool AssignValueByTagName(XmlDocument doc, string TagName, string Value)
        {
            XmlNodeList nodeList = doc.GetElementsByTagName(TagName);

            if (nodeList.Count > 0)
            {
                nodeList[0].InnerText = Value;
                return true;
            }
            else
            {
                return false;
            }
        }

        public enum PaymentTypes
        {
            US_ACH,
            US_Wire,
            CHAPS_Payments,
            Faster_Payments,
            SEPA_Payments,
            CA_ACH
        }
    }

    public static class PaymentTypes
    {
        public const string
            US_ACH = "US ACH",
            US_Wire = "US Wire",
            CHAPS_Payments = "CHAPS Payments",
            Faster_Payments = "Faster Payments",
            SEPA_Payments = "SEPA Payments",
            CA_ACH = "CA ACH",
            CA_Wire = "CA Wire";

    }
}
