﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace HSBC_Payment
{
    public class HSBC_API
    {
        public string env = ConfigurationManager.AppSettings["env"];
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(typeof(Program));
        public PaymentStatusResponce CheckStatus(string paymentEnquiryBase64)
        {
            log.InfoFormat("Status API Call started");
            PaymentStatusResponce paymentStatusResponce = new PaymentStatusResponce();
            HttpClient client = new HttpClient();
            var hsbcheader = DBRepository.GetAPIHeaderDetails(env);
            client.DefaultRequestHeaders.Add("x-hsbc-client-id", hsbcheader.Where(a => a.Key == "x-hsbc-client-id").FirstOrDefault().Value);// [HttpRequestHeader.ContentType] = "application/json";
            client.DefaultRequestHeaders.Add("x-hsbc-client-secret", hsbcheader.Where(a => a.Key == "x-hsbc-client-secret").FirstOrDefault().Value);
            client.DefaultRequestHeaders.Add("x-hsbc-profile-id", hsbcheader.Where(a => a.Key == "x-hsbc-profile-id").FirstOrDefault().Value);
            //string ApiPath = "https://devcluster.api.p2g.netd2.hsbc.com.hk/cmb-connect-payments-pa-payment-cert-proxy/v1/payments/status";
            string ApiPath = ConfigurationManager.AppSettings["statusEnq"];
            PaymentStatusEnq paymentStatus = new PaymentStatusEnq();
            //paymentEnquiryBase64 = "LS0tLS1CRUdJTiBQR1AgTUVTU0FHRS0tLS0tDQpWZXJzaW9uOiBCQ1BHIEMjIHYxLjguOC4wDQoNCmhRSU1BOHh4ZG5rQTd1OW9BUS85SGZ3a1Z3SDFqNnRVYmZpSGlvaHdsdDdlcUV6YSsrWFpSWHk1dmEzODRXdjINCktJRGp6bzVOY0d5STYzNDJISE9XR012N1JHVGUxamxPSXFoT3JRQzNQZ0MzSXhnSUd1MTk1bThHTlVxSFJsT2cNClVIUjM1YWo5dWhlYnNyZm0yRVo4UkwrR0M1YVZFSTVqWFh2MkZyLzkybVJFR1FyaXVZelBwZFdqRFBJZW40UDgNCmxYUTBidDFDRDVOUVpNOTBFSEFWOVlUdDNRVmJjOE5jbUZKZ1E4R2l5d3NzeDBhZldDbldTY3NyTFdETllzVE4NCmZsK1VjbGZLdndURWRJNjhlYVFReTNkWlUzYVRmR0dja09sN25RdzV5M05SU0pmK2NKNURPeDdTZDZYM2hYRzQNCktiakVnb3NYUEI3QzhXRytXemg4bHVmQTU3QkVMVlBibllxTHRIYU51VDQ5U2ZHcEpiVHg5cmkzNXp5WHpUQzcNCkt4MEZmWk5YYlAzUk1oM3VHS3NRYTMrTnpIcTE2VGhYS2RzTmlPYlpKb1pCUVNGRkV4WEF4c3FocTNCOVFTYWwNCm45WjFtckEvbzFWQnI3b3c3bHhtTjR0Yk1Rb1c0dTlENVNCOTNmM3NpWnI4eDVFV0xQZitNSW1sRVZzRFgxNG4NCk5wSDIydFkyaXZzeHVTV1JzNEZMRk1ZM1N5bndiaXB0TmdYVW5LQmhxRks5SDVyT2dqQ3R5d0dTTFd0aXJsZWENClFxcDlBZG1wV0paRFZMSFZtK0tMNytualJhNmNuUGw3RlJMWDVPS3Q0RXpiM2oxOGlRMi9LNlBOVU16V2lqcnkNCnB2S0Y5ZVUrbStINk5JK3owa3JtVVF6eFRsUEk2djFCbFZUK3FGL3FoYS9SUCtkTHUrQmRLVllKR3RFYmZ5clMNCndZY0JFeGlacFh5bmRaRnF2TnZwc1A4RkhXcldoeTc3dWdrRXZ6OHkzcktQck5pTXJqU3VEZERremlTRjJyRVYNCmlhMnluR0x5cTJKSDFxSWMrWnZwejN3TEpZcWNKazZSbkREbHdlTloySE9SNFVVMjlxV1hiWGVBWUxaSlZqa1ANCmlJNWRMSDNPNEZhSlFTYzBmQVFzdlNiQlArcHlWMmxueDhra1Y2M21jaDJKL2QydXFqdTl6d1EvY002ajcvcEINCk1GNWVjejZ0SkpIbTZsUGxXNXlSeThYa2FrTllEUmkzdGVwVUxuSFR2ODhCL2NVQVR2cUxOZkx3VHVRRnFLUjENCkwwM29QTS9ydll3WHE0SVg5L0tOQzBGZUFrek9JZWlSWGI1MzdPTzVRVVp6bmNjR2NlRzlzTlhSZDlTQTlGMkkNCjhPbGJWTWFINDUveDZ3M3gxdUNKL1FmOVE5d0hhVXpEYmc3eC9qbkUzNGdOdCtaTFRSWkZSazhkM1Bsdm5iOGMNClBtdHp1d05XT1I1d1pCMU1MTmZYSUsyek10NHpxMnZ4ZGo4Vks5UVpnY2pMUFFHcDlZUGVXY3JWOGhXTlBneUwNCk5kQXRqdlBKT0QvTjB3NlpQU3NrZVVlS3psVVUxdnlJdUt1VWN3MXBZRTJ5Qkc0NDRWWGNWaE9XSHB0enRrQlYNClV5aE5UV1VEZ1ZQN1NsTDdTTXRwOHFBZk1yWmdFUno0N21oNEVYT3ZjS1J0aGo4TFcydjFxOG1lMUlpMjZMTGMNCkU1NEUwQWJFWWplT1U3YldJMTAyTUVMSW4xRTBIcHBUNzM0aTkwNkEvZGw5cjNBM1ZNTDRMbS9vQnk2TkFORlgNCjJoZEhQQ1BZbTBreWdNRCtVcmJFNVFzOCt6dEgySFcyTXpvRFJxZVpTWk0xcWk0VVRnc21NTFljRnFwK3dwY2cNCm1ybElsODVTRkl1cTQvZmZWK2FsNmdLZ0wrYi9LYmt2L01hUTRSTUoxTUxvR1RjN2FLWG5NeU8xYkpBc3o3UVoNCjU0em1BVyt3UlIycA0KPTJKdkUNCi0tLS0tRU5EIFBHUCBNRVNTQUdFLS0tLS0NCg=="; 
            paymentStatus.paymentEnquiryBase64 = paymentEnquiryBase64;

            string jsonUserString = Newtonsoft.Json.JsonConvert.SerializeObject(paymentStatus);
            var content = new StringContent(jsonUserString, Encoding.UTF8, "application/json");
            client.Timeout = TimeSpan.FromMinutes(10);
            HttpResponseMessage response = client.PostAsync(ApiPath, content).Result;
            var Json = response.Content.ReadAsStringAsync().Result;
            if (response.StatusCode == HttpStatusCode.OK || (response.StatusCode == HttpStatusCode.BadRequest && Regex.Match(Json, "referenceId").Success))
            {

                paymentStatusResponce = Newtonsoft.Json.JsonConvert.DeserializeObject<PaymentStatusResponce>(Json);
            }
            else if (response.StatusCode == HttpStatusCode.BadRequest)
            {
                ErrorResponse error = Newtonsoft.Json.JsonConvert.DeserializeObject<ErrorResponse>(Json);
                paymentStatusResponce.responseBase64 = Json;
                paymentStatusResponce.statusCode = error.Code;
                log.InfoFormat("Status API Responce:" + Json.ToString());
            }
            else
            {
                log.InfoFormat("Status API Responce:" + Json.ToString());
                paymentStatusResponce = Newtonsoft.Json.JsonConvert.DeserializeObject<PaymentStatusResponce>(Json);
            }

            log.InfoFormat("Status API Call ended");
            return paymentStatusResponce;
        }

        public PaymentStatusResponce CheckStatusFasterPayment(string x_reference_id)
        {
            log.InfoFormat("Status API Call started");
            PaymentStatusResponce paymentStatusResponce = new PaymentStatusResponce();
            HttpClient client = new HttpClient();
            var hsbcheader = DBRepository.GetAPIHeaderDetails(env);
            client.DefaultRequestHeaders.Add("x-hsbc-client-id", hsbcheader.Where(a => a.Key == "x-hsbc-client-id").FirstOrDefault().Value);// [HttpRequestHeader.ContentType] = "application/json";
            client.DefaultRequestHeaders.Add("x-hsbc-client-secret", hsbcheader.Where(a => a.Key == "x-hsbc-client-secret").FirstOrDefault().Value);
            client.DefaultRequestHeaders.Add("x-hsbc-profile-id", hsbcheader.Where(a => a.Key == "x-hsbc-profile-id").FirstOrDefault().Value);
            client.DefaultRequestHeaders.Add("x-hsbc-payment-type", hsbcheader.Where(a => a.Key == "x-hsbc-payment-type").FirstOrDefault().Value);
            client.DefaultRequestHeaders.Add("x-hsbc-country-code", hsbcheader.Where(a => a.Key == "x-hsbc-country-code").FirstOrDefault().Value);
            client.DefaultRequestHeaders.Add("x-reference-id", x_reference_id);
            string ApiPath = ConfigurationManager.AppSettings["statusEnq"];

            //PaymentStatusEnq paymentStatus = new PaymentStatusEnq();            
            //paymentStatus.paymentEnquiryBase64 = paymentEnquiryBase64;
            //string jsonUserString = Newtonsoft.Json.JsonConvert.SerializeObject(paymentStatus);

            //var content = new StringContent(jsonUserString, Encoding.UTF8, "application/json");
            client.Timeout = TimeSpan.FromMinutes(10);
            HttpResponseMessage response = client.GetAsync(ApiPath).Result;
            var Json = response.Content.ReadAsStringAsync().Result;
            if(Regex.Matches(Json,"}").Count>1)
            {
                Json = Json.Substring(0, Json.IndexOf("}")+1);
            }
            if (response.StatusCode == HttpStatusCode.OK || (response.StatusCode == HttpStatusCode.BadRequest && Regex.Match(Json, "referenceId").Success))
            {
                log.InfoFormat("Status API Responce:" + Json.ToString());
                paymentStatusResponce = Newtonsoft.Json.JsonConvert.DeserializeObject<PaymentStatusResponce>(Json);
            }
            else if (response.StatusCode == HttpStatusCode.BadRequest)
            {
                log.InfoFormat("Status API Responce:" + Json.ToString());
                ErrorResponse error = Newtonsoft.Json.JsonConvert.DeserializeObject<ErrorResponse>(Json);
                paymentStatusResponce.responseBase64 = Json;
                paymentStatusResponce.statusCode = error.Code;
            }
            else
            {

                paymentStatusResponce = Newtonsoft.Json.JsonConvert.DeserializeObject<PaymentStatusResponce>(Json);
            }
            log.InfoFormat("Status API Call ended");
            return paymentStatusResponce;
        }


        public PaymentStatusResponce PostDataToHSBC(string paymentEnquiryBase64, Boolean isfaster = false)
        {
            PaymentStatusResponce paymentStatusResponce = new PaymentStatusResponce();
            var hsbcheader = DBRepository.GetAPIHeaderDetails(env);
            HttpClient client = new HttpClient();
            log.InfoFormat("Payment API Call started");
            client.DefaultRequestHeaders.Add("x-hsbc-client-id", hsbcheader.Where(a => a.Key == "x-hsbc-client-id").FirstOrDefault().Value);// [HttpRequestHeader.ContentType] = "application/json";
            client.DefaultRequestHeaders.Add("x-hsbc-client-secret", hsbcheader.Where(a => a.Key == "x-hsbc-client-secret").FirstOrDefault().Value);
            client.DefaultRequestHeaders.Add("x-hsbc-profile-id", hsbcheader.Where(a => a.Key == "x-hsbc-profile-id").FirstOrDefault().Value);
            client.DefaultRequestHeaders.Add("x-payload-type", hsbcheader.Where(a => a.Key == "x-payload-type").FirstOrDefault().Value);
            //string ApiPath = "https://devcluster.api.p2g.netd2.hsbc.com.hk/cmb-connect-payments-pa-payment-cert-proxy/v1/bulk-payments/instant-receipt";
            string ApiPath = ConfigurationManager.AppSettings["instant-receipt"];
            if (isfaster)
            {
                client.DefaultRequestHeaders.Add("x-hsbc-payment-type", hsbcheader.Where(a => a.Key == "x-hsbc-payment-type").FirstOrDefault().Value);
                client.DefaultRequestHeaders.Add("x-hsbc-country-code", hsbcheader.Where(a => a.Key == "x-hsbc-country-code").FirstOrDefault().Value);
                // ApiPath = "https://devcluster.api.p2g.netd2.hsbc.com.hk/cmb-connect-payments-pa-payment-cert-proxy/v1/payments/instant-settlement";
                ApiPath = ConfigurationManager.AppSettings["instant-settlement"];
            }

            HSBC paymentStatus = new HSBC();
            //paymentEnquiryBase64 = "LS0tLS1CRUdJTiBQR1AgTUVTU0FHRS0tLS0tDQpWZXJzaW9uOiBCQ1BHIEMjIHYxLjguOC4wDQoNCmhRSU1BOHh4ZG5rQTd1OW9BUS85SGZ3a1Z3SDFqNnRVYmZpSGlvaHdsdDdlcUV6YSsrWFpSWHk1dmEzODRXdjINCktJRGp6bzVOY0d5STYzNDJISE9XR012N1JHVGUxamxPSXFoT3JRQzNQZ0MzSXhnSUd1MTk1bThHTlVxSFJsT2cNClVIUjM1YWo5dWhlYnNyZm0yRVo4UkwrR0M1YVZFSTVqWFh2MkZyLzkybVJFR1FyaXVZelBwZFdqRFBJZW40UDgNCmxYUTBidDFDRDVOUVpNOTBFSEFWOVlUdDNRVmJjOE5jbUZKZ1E4R2l5d3NzeDBhZldDbldTY3NyTFdETllzVE4NCmZsK1VjbGZLdndURWRJNjhlYVFReTNkWlUzYVRmR0dja09sN25RdzV5M05SU0pmK2NKNURPeDdTZDZYM2hYRzQNCktiakVnb3NYUEI3QzhXRytXemg4bHVmQTU3QkVMVlBibllxTHRIYU51VDQ5U2ZHcEpiVHg5cmkzNXp5WHpUQzcNCkt4MEZmWk5YYlAzUk1oM3VHS3NRYTMrTnpIcTE2VGhYS2RzTmlPYlpKb1pCUVNGRkV4WEF4c3FocTNCOVFTYWwNCm45WjFtckEvbzFWQnI3b3c3bHhtTjR0Yk1Rb1c0dTlENVNCOTNmM3NpWnI4eDVFV0xQZitNSW1sRVZzRFgxNG4NCk5wSDIydFkyaXZzeHVTV1JzNEZMRk1ZM1N5bndiaXB0TmdYVW5LQmhxRks5SDVyT2dqQ3R5d0dTTFd0aXJsZWENClFxcDlBZG1wV0paRFZMSFZtK0tMNytualJhNmNuUGw3RlJMWDVPS3Q0RXpiM2oxOGlRMi9LNlBOVU16V2lqcnkNCnB2S0Y5ZVUrbStINk5JK3owa3JtVVF6eFRsUEk2djFCbFZUK3FGL3FoYS9SUCtkTHUrQmRLVllKR3RFYmZ5clMNCndZY0JFeGlacFh5bmRaRnF2TnZwc1A4RkhXcldoeTc3dWdrRXZ6OHkzcktQck5pTXJqU3VEZERremlTRjJyRVYNCmlhMnluR0x5cTJKSDFxSWMrWnZwejN3TEpZcWNKazZSbkREbHdlTloySE9SNFVVMjlxV1hiWGVBWUxaSlZqa1ANCmlJNWRMSDNPNEZhSlFTYzBmQVFzdlNiQlArcHlWMmxueDhra1Y2M21jaDJKL2QydXFqdTl6d1EvY002ajcvcEINCk1GNWVjejZ0SkpIbTZsUGxXNXlSeThYa2FrTllEUmkzdGVwVUxuSFR2ODhCL2NVQVR2cUxOZkx3VHVRRnFLUjENCkwwM29QTS9ydll3WHE0SVg5L0tOQzBGZUFrek9JZWlSWGI1MzdPTzVRVVp6bmNjR2NlRzlzTlhSZDlTQTlGMkkNCjhPbGJWTWFINDUveDZ3M3gxdUNKL1FmOVE5d0hhVXpEYmc3eC9qbkUzNGdOdCtaTFRSWkZSazhkM1Bsdm5iOGMNClBtdHp1d05XT1I1d1pCMU1MTmZYSUsyek10NHpxMnZ4ZGo4Vks5UVpnY2pMUFFHcDlZUGVXY3JWOGhXTlBneUwNCk5kQXRqdlBKT0QvTjB3NlpQU3NrZVVlS3psVVUxdnlJdUt1VWN3MXBZRTJ5Qkc0NDRWWGNWaE9XSHB0enRrQlYNClV5aE5UV1VEZ1ZQN1NsTDdTTXRwOHFBZk1yWmdFUno0N21oNEVYT3ZjS1J0aGo4TFcydjFxOG1lMUlpMjZMTGMNCkU1NEUwQWJFWWplT1U3YldJMTAyTUVMSW4xRTBIcHBUNzM0aTkwNkEvZGw5cjNBM1ZNTDRMbS9vQnk2TkFORlgNCjJoZEhQQ1BZbTBreWdNRCtVcmJFNVFzOCt6dEgySFcyTXpvRFJxZVpTWk0xcWk0VVRnc21NTFljRnFwK3dwY2cNCm1ybElsODVTRkl1cTQvZmZWK2FsNmdLZ0wrYi9LYmt2L01hUTRSTUoxTUxvR1RjN2FLWG5NeU8xYkpBc3o3UVoNCjU0em1BVyt3UlIycA0KPTJKdkUNCi0tLS0tRU5EIFBHUCBNRVNTQUdFLS0tLS0NCg=="; 
            paymentStatus.paymentBase64 = paymentEnquiryBase64;

            string jsonUserString = Newtonsoft.Json.JsonConvert.SerializeObject(paymentStatus);
            var content = new StringContent(jsonUserString, Encoding.UTF8, "application/json");
            client.Timeout = TimeSpan.FromMinutes(10);
            HttpResponseMessage response = client.PostAsync(ApiPath, content).Result;

            var Json = response.Content.ReadAsStringAsync().Result;

            if (response.StatusCode == HttpStatusCode.OK || (response.StatusCode == HttpStatusCode.BadRequest && Regex.Match(Json, "referenceId").Success))
            {
                paymentStatusResponce = Newtonsoft.Json.JsonConvert.DeserializeObject<PaymentStatusResponce>(Json);
            }
            else if (response.StatusCode == HttpStatusCode.BadRequest)
            {
                ErrorResponse error = Newtonsoft.Json.JsonConvert.DeserializeObject<ErrorResponse>(Json);
                paymentStatusResponce.responseBase64 = Json;
                paymentStatusResponce.statusCode = error.Code;
                log.InfoFormat("Payment API Responce:" + Json.ToString());
            }
            else
            {
                log.InfoFormat("Payment API Responce:" + Json.ToString());
                paymentStatusResponce = Newtonsoft.Json.JsonConvert.DeserializeObject<PaymentStatusResponce>(Json);
            }
            log.InfoFormat("Payment API Call ended");
            return paymentStatusResponce;
        }

    }
}
