﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSBC_Payment
{
    public class DBRepository
    {
        public static IEnumerable<DebtorAccountDeatils> GetDebtorAccountDetails()
        {
            return CommonResource.ToCollection<DebtorAccountDeatils>(DbContext.DbUser.ExecuteDataSet("GetDebtorAccountDeatils").Tables[0]);
        }

        public static IEnumerable<TransactionDetails> GetTransactionDetails(DebtorAccountDeatils _debtorAccountDetails, string status,int IsFasterPayment)
        {
            return CommonResource.ToCollection<TransactionDetails>(DbContext.DbUser.ExecuteDataSet("GetTransactionDetails", _debtorAccountDetails.ProjectCode, _debtorAccountDetails.PaymentTypeId, status, IsFasterPayment).Tables[0]);
        }

        public static IEnumerable<HSBCKeyValue> GetAPIHeaderDetails(string env)
        {
            return CommonResource.ToCollection<HSBCKeyValue>(DbContext.DbUser.ExecuteDataSet("GetAPIHeaderDetails", env).Tables[0]);
        }

        public static int InsertXMLDetails(int TranscationID, string XML)
        {
            return Convert.ToInt32(DbContext.DbUser.ExecuteScalar("InsertXMLDetails", TranscationID, XML));
        }


        public static int InsertPaymentReponse(int TranscationID, PaymentStatusResponce responce)
        {
            return Convert.ToInt32(DbContext.DbUser.ExecuteScalar("InsertPaymentReponse", TranscationID, responce.statusCode, responce.responseBase64));
        }


        public static int InsertStatusReponse(int TranscationID, PaymentStatusResponce responce)
        {
            return Convert.ToInt32(DbContext.DbUser.ExecuteScalar("InsertStatusReponse", TranscationID, responce.responseBase64));
        }

        public static int UpdateHSBCTranscationMasterResponse(int TranscationID, PaymentStatusResponce responce, string ProjectCode)
        {
            return Convert.ToInt32(DbContext.DbUser.ExecuteScalar("UpdateHSBCTranscationMasterResponse", TranscationID, responce.referenceId, responce.statusCode, responce.statusDesc, ProjectCode));
        }

        public static int UpdateTransactionDetailsStatus(PaymentStatusResponce statusresponce, TransactionDetails invoice, string status)
        {
            return Convert.ToInt32(DbContext.DbUser.ExecuteScalar("UpdateTransactionDetailsStatus", invoice.TransactionDetailsId, statusresponce.referenceId, statusresponce.statusCode, statusresponce.statusDesc, status));
        }

        public static IEnumerable<TransactionDetails> GetTransactionDetailsByStatus(string status)
        {
            return CommonResource.ToCollection<TransactionDetails>(DbContext.DbUser.ExecuteDataSet("GetTransactionDetailsByStatus", status).Tables[0]);
        }

        public static int UpdateStatus(IEnumerable<TransactionDetails> transactionDetailsList, string status)
        {
            string ids = string.Join(",", transactionDetailsList.Select(a => a.TransactionDetailsId));
            return Convert.ToInt32(DbContext.DbUser.ExecuteScalar("UpdateTransactionDetailStatus", ids, status));
        }

        public static int UpdateInstrId( string InstrId,int TransactionDetailsId)
        {           
            return DbContext.DbUser.ExecuteNonQuery("UpdateInstrId", InstrId, TransactionDetailsId);
        }
        public static int UpdateEndToEndId(string EndToEndId, int TransactionDetailsId)
        {
            return DbContext.DbUser.ExecuteNonQuery("UpdateEndToEndId", EndToEndId, TransactionDetailsId);
        }
    }
}
