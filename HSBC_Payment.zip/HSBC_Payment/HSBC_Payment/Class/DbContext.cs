﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HSBC_Payment
{
    public static class DbContext
    {
        public static string connStr = ConfigurationManager.ConnectionStrings["Connstr"].ConnectionString;
        private static readonly DatabaseProviderFactory databaseProviderFactory = new DatabaseProviderFactory();
        public static Database DbUser = new SqlDatabase(connStr);
    }
}
