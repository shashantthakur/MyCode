﻿using System;

namespace ESPro.Infrastructure
{
    public class Class1
    {
    }
}
