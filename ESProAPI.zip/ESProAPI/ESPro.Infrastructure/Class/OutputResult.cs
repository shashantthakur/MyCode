﻿namespace ESPro.Infrastructure.Class
{
    public class OutputResult
    {
        public string status { get; set; }
        public string message { get; set; }
    }
}