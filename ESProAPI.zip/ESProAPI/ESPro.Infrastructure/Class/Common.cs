﻿using ESPro.Core.Entity;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;

namespace ESPro.Infrastructure.Class
{
    public class Common
    {

        public Common(IConfiguration configuration, IHostingEnvironment hostingEnvironment)
        {
            CommonResource.ConString = configuration["DBConnection:ConString"];
            CommonResource.SecretKey = configuration["JwtToken:SecretKey"];
            CommonResource.myIssuer = configuration["JwtToken:myIssuer"];
            CommonResource.myAudience = configuration["JwtToken:myAudience"];
            CommonResource.TokenExpiredInMin = Convert.ToInt32(configuration["JwtToken:TokenExpiredInMin"]);
            CommonResource.MailTemplatePath = Path.Combine(hostingEnvironment.ContentRootPath, "MailTemplate");
            CommonResource.ExcelTemplatePath = Path.Combine(hostingEnvironment.ContentRootPath, "ExcelTemplate");
            CommonResource.BaseUrl = configuration["BaseUrl"];
            CommonResource.SecurutyKey = configuration["SecurutyKey"];
            CommonResource.ResumePath = configuration["ResumePath"];
            CommonResource.TrainingMaterialPath = configuration["TrainingMaterialPath"];
            CommonResource.MEFPath = configuration["MEFPath"];
            CommonResource.SamplePath = configuration["SamplePath"];
            CommonResource.ImagePath = configuration["ImagePath"];
            CommonResource.UiUrl = configuration["UiUrl"];
            //CommonResource.ResumePathUrl = configuration["ResumePathUrl"];
            //CommonResource.SamplePathUrl = configuration["SamplePathUrl"];
            CommonResource.ImagePathUrl = configuration["ImagePathUrl"];
            CommonResource.ContractPath = configuration["ContractPath"];
            CommonResource.ExcerptPath = configuration["ExcerptPath"];
            CommonResource.MailRegards = configuration["MailRegards"];
            //CommonResource.ApiURL = configuration["AwardAPI"];
            //CommonResource.APIToken = configuration["AwardToken"];
            CommonResource.IConnectApiURL = configuration["IConnectApiURL"];
            CommonResource.Phase2Test = configuration["Phase2Test"];
            CommonResource.Phase2TestUserUpload = configuration["Phase2TestUserUpload"];

            CommonResource.HSBCConString = configuration["HSBC:ConString"];

            CommonResource.SendMail = configuration["SendMail"];

        }

    }



    public enum userRole
    {
        AGENCY,
        FREELANCER,
        LUMINAOTHERS,
        PROJECTMANAGER,
        ADMIN,
        SUPERADMIN,
        QUALITYMANAGER,
        CLIENT,
        CLIENTADMIN,
        HUMANRESOURCE,
        FLPROJECTMANAGER,
        LUMINASUPERVISOR
    }

    public static class CommonResource
    {

        public static string HSBCConString { get; set; }
        public static string ConString { get; set; }
        public static string SecretKey { get; set; }
        public static string myIssuer { get; set; }
        public static string myAudience { get; set; }
        public static int TokenExpiredInMin { get; set; }

        public static string MailTemplatePath { get; set; }
        public static string ExcelTemplatePath { get; set; }
        public static string BaseUrl { get; set; }

        public static string SecurutyKey { get; set; }

        public static string TrainingMaterialPath { get; set; }

        public static string MEFPath { get; set; }
        public static string ResumePath { get; set; }
        public static string SamplePath { get; set; }
        public static string ImagePath { get; set; }

        public static string ImagePathUrl { get; set; }

        public static string UiUrl { get; set; }

        public static string ApiURL { get; set; }
        public static string IConnectApiURL { get; set; }
        public static string APIToken { get; set; }

        //public static string ResumePathUrl { get; set; }
        //public static string SamplePathUrl { get; set; }
        public static string ContractPath { get; set; }
        public static string ExcerptPath { get; set; }
        public static string MailRegards { get; set; }
        public static string Phase2Test { get; set; }
        public static string Phase2TestUserUpload { get; set; }
        public static string SendMail { get; set; }

        public static List<T> ToCollection<T>(this DataTable dt)
        {
            //if (dt.Rows.Count > 0)
            //{
            //    string js = Newtonsoft.Json.JsonConvert.SerializeObject(dt);
            //    List<T> lst = Newtonsoft.Json.JsonConvert.DeserializeObject<List<T>>(js);
            //    return lst;
            //}
            //else
            //{
            //    List<T> lst = new System.Collections.Generic.List<T>();
            //    return lst;
            //}

            if (dt.Rows.Count > 0)
            {
                var settings = new JsonSerializerSettings
                {
                    NullValueHandling = NullValueHandling.Ignore,
                    MissingMemberHandling = MissingMemberHandling.Ignore
                };
                string js = Newtonsoft.Json.JsonConvert.SerializeObject(dt);
                List<T> lst = Newtonsoft.Json.JsonConvert.DeserializeObject<List<T>>(js, settings);
                return lst;
            }
            else
            {
                List<T> lst = new System.Collections.Generic.List<T>();
                return lst;
            }
        }

        public static string ToObject(Object foo, DataTable dt)
        {
            foreach (var prop in foo.GetType().GetProperties())
            {
                Console.WriteLine("{0}={1}", prop.Name, prop.GetValue(foo, null));
            }
            return "";
        }

        public static IEnumerable<List<T>> SplitList<T>(List<T> locations, int nSize = 30)
        {
            for (int i = 0; i < locations.Count; i += nSize)
            {
                yield return locations.GetRange(i, Math.Min(nSize, locations.Count - i));
            }
        }

        public static int GenerateRandomNo()
        {
            int _min = 1000;
            int _max = 9999;
            Random _rdm = new Random();
            return _rdm.Next(_min, _max);
        }



        private const string urlPattern = "https://data.fixer.io/api/latest?access_key=337862b3d4090bb8550eebc3bd0b9c34&base={0}&symbols={1}";
        //private const string urlPattern = "https://data.fixer.io/api/convert?access_key=337862b3d4090bb8550eebc3bd0b9c34&from={0}&to={1}&amount={2}";
        public static string CurrencyConversion(decimal amount, string fromCurrency, string toCurrency, out string exchange_Rate)
        {
            //string url = string.Format(urlPattern, fromCurrency, toCurrency, amount);
            string url = string.Format(urlPattern, fromCurrency, toCurrency);
            using (var wc = new WebClient())
            {
                var json = wc.DownloadString(url);
                Newtonsoft.Json.Linq.JToken token = Newtonsoft.Json.Linq.JObject.Parse(json);
                decimal exchangeRate = Convert.ToDecimal(token.Last.Last.Last.Last.ToString());
                exchange_Rate = exchangeRate.ToString();
                return (amount * exchangeRate).ToString();
            }
        }

        //private const string urlPattern = "http://rate-exchange-1.appspot.com/currency?from={0}&to={1}&q=1";
        //public static string CurrencyConversion(decimal amount, string fromCurrency, string toCurrency, out string exchange_Rate)
        //{
        //    string url = string.Format(urlPattern, fromCurrency, toCurrency);
        //    using (var wc = new WebClient())
        //    {
        //        var json = wc.DownloadString(url);
        //        Newtonsoft.Json.Linq.JToken token = Newtonsoft.Json.Linq.JObject.Parse(json);
        //        decimal exchangeRate = (decimal)token.SelectToken("rate");
        //        exchange_Rate = exchangeRate.ToString();
        //        return (amount * exchangeRate).ToString();
        //    }
        //}

        //public static string APIValidation()
        //{
        //    string ErrorMsg = string.Empty;
        //    if (string.IsNullOrEmpty(ApiURL))
        //    {
        //        ErrorMsg = "API url is missing.Please provide.";

        //    }
        //    if (string.IsNullOrEmpty(APIToken))
        //    {
        //        ErrorMsg = "API token is missing.Please provide.";
        //    }
        //    return ErrorMsg;
        //}


        public static string PostRequest<T>(string APIURL, T inputObject, string APIToken)
        {
            string Result = "";
            try
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(APIURL);
                    //HTTP POST
                    if (!string.IsNullOrEmpty(APIToken))
                        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", APIToken);
                    var postTask = client.PostAsJsonAsync<T>(APIURL, inputObject);

                    postTask.Wait();
                    var result = postTask.Result;
                    if (result.IsSuccessStatusCode && result.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        Result = result.Content.ReadAsStringAsync().Result;
                        return Result;
                    }
                    else
                    {
                        Result = result.ReasonPhrase;
                        return Result;
                    }
                }
            }
            catch (Exception ex)
            {
                Result = Convert.ToString(ex.InnerException);
                return Result;
            }
        }

        public static bool PostRequest<T>(string APIName, T inputObject, out string ErrorMsg)
        {
            ErrorMsg = string.Empty;
            //ErrorMsg = APIValidation();
            //if (!string.IsNullOrEmpty(ErrorMsg))
            //    return false;
            //try
            //{
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(ApiURL);
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", APIToken);
                var postTask = client.PostAsJsonAsync<T>(APIName, inputObject);

                postTask.Wait();
                var result = postTask.Result;
                if (result.IsSuccessStatusCode && result.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    if (APIName == "Transcation/UpdateUser")
                    {
                        var Json = result.Content.ReadAsStringAsync();
                        OutputResult results = JsonConvert.DeserializeObject<OutputResult>(Convert.ToString(Json.Result));
                        ErrorMsg = results.message;
                    }
                    return true;
                }
                else
                {
                    ErrorMsg = result.ReasonPhrase;
                    return false;
                }
            }
            //}
            //catch (Exception ex)
            //{
            //    ErrorMsg = Convert.ToString(ex.InnerException);
            //    return false;
            //}
        }

        public static bool InvoicePostRequestAsync<T>(string APIName, List<KeyValuePair<string, string>> postData, out string ErrorMsg, out string FullError)
        {
            ErrorMsg = string.Empty;
            FullError = String.Empty;
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/x-www-form-urlencoded"));
                    if (APIName == "DeleteFreelancerProfile" || APIName == "UpdateVendorEmail")
                        IConnectApiURL = Regex.Replace(IConnectApiURL, "Webservice.asmx/(.*)", "Webservice.asmx/" + APIName, RegexOptions.IgnoreCase);
                    HttpResponseMessage response = client.PostAsync(IConnectApiURL, new FormUrlEncodedContent(postData)).Result;
                    var Json = response.Content.ReadAsStringAsync().Result;
                    var Result = JsonConvert.DeserializeObject<RootObject>(Json);
                    if (Result != null)
                    {
                        var Result1 = Result.Response.FirstOrDefault();
                        if (Result1 != null)
                            if (Result1.statusCode == 200 || Result1.data == "Email not available in our database" || Result1.data.StartsWith("Existing Email Id is not exist for vendor"))
                            {
                                ErrorMsg = Result1.data;
                                return true;
                            }
                            else
                            {
                                ErrorMsg = Result1.data;
                                FullError = "Data: " + Result1.data + " \r\n Status: " + Result1.status + " Response Json: " + Json;
                            }

                    }
                    else
                        ErrorMsg = "Data: Unable to DeserializeObject" + "\r\n Status: 500";
                    return false;
                }
            }
            catch (Exception ex)
            {
                ErrorMsg = Convert.ToString(ex.Message);
                return false;
            }
        }

        public static DataTable ClassToDataTable<T>(IEnumerable<T> obj)
        {
            string json = Newtonsoft.Json.JsonConvert.SerializeObject(obj);
            DataTable dt = new DataTable();
            dt = Newtonsoft.Json.JsonConvert.DeserializeObject<DataTable>(json);
            return dt;
        }


        public static Object TableResponce<T>(IEnumerable<T> Data, string sort, string dir, int currentpage, int pageSize)
        {
            if (!string.IsNullOrEmpty(sort))
            {
                var param = sort;
                var propertyInfo = typeof(T).GetProperty(param);
                if (dir == "desc")
                {
                    Data = Data.OrderByDescending(x => propertyInfo.GetValue(x, null));
                }
                else
                {
                    Data = Data.OrderBy(x => propertyInfo.GetValue(x, null));
                }

            }

            var subdata = SplitList(Data.ToList(), pageSize);
            var response = new
            {
                Lastpage = subdata.Count(),
                data = subdata.Count() > 0 ? subdata.ElementAt(currentpage) : Data,
                TotalRecords = Data.Count()
            };
            return response;
        }

        public static List<string> ProhibitedCharsList()
        {
            List<string> AllowedChars = new List<string>();
            AllowedChars.Add("32"); //space
            //AllowedChars.Add("33"); //!
            //AllowedChars.Add("34"); //"
            //AllowedChars.Add("35"); //#
            //AllowedChars.Add("36"); //$
            //AllowedChars.Add("37"); //%
            //AllowedChars.Add("38"); //&
            AllowedChars.Add("39"); //'
            AllowedChars.Add("40"); //(
            AllowedChars.Add("41"); //)
            //AllowedChars.Add("42"); //*
            AllowedChars.Add("43"); //+
            AllowedChars.Add("44"); //,
            AllowedChars.Add("45"); //-
            AllowedChars.Add("46"); //.
            AllowedChars.Add("47"); ///
            AllowedChars.Add("48"); //0
            AllowedChars.Add("49"); //1
            AllowedChars.Add("50"); //2
            AllowedChars.Add("51"); //3
            AllowedChars.Add("52"); //4
            AllowedChars.Add("53"); //5
            AllowedChars.Add("54"); //6
            AllowedChars.Add("55"); //7
            AllowedChars.Add("56"); //8
            AllowedChars.Add("57"); //9
            //AllowedChars.Add("58"); //:
            //AllowedChars.Add("59"); //;
            //AllowedChars.Add("60"); //<
            //AllowedChars.Add("61"); //=
            //AllowedChars.Add("62"); //>
            //AllowedChars.Add("63"); //?
            //AllowedChars.Add("64"); //@
            AllowedChars.Add("65"); //A
            AllowedChars.Add("66"); //B
            AllowedChars.Add("67"); //C
            AllowedChars.Add("68"); //D
            AllowedChars.Add("69"); //E
            AllowedChars.Add("70"); //F
            AllowedChars.Add("71"); //G
            AllowedChars.Add("72"); //H
            AllowedChars.Add("73"); //I
            AllowedChars.Add("74"); //J
            AllowedChars.Add("75"); //K
            AllowedChars.Add("76"); //L
            AllowedChars.Add("77"); //M
            AllowedChars.Add("78"); //N
            AllowedChars.Add("79"); //O
            AllowedChars.Add("80"); //P
            AllowedChars.Add("81"); //Q
            AllowedChars.Add("82"); //R
            AllowedChars.Add("83"); //S
            AllowedChars.Add("84"); //T
            AllowedChars.Add("85"); //U
            AllowedChars.Add("86"); //V
            AllowedChars.Add("87"); //W
            AllowedChars.Add("88"); //X
            AllowedChars.Add("89"); //Y
            AllowedChars.Add("90"); //Z
            //AllowedChars.Add("91"); //[
            //AllowedChars.Add("92"); //\
            //AllowedChars.Add("93"); //]
            //AllowedChars.Add("94"); //^
            //AllowedChars.Add("95"); //_
            //AllowedChars.Add("96"); //`
            AllowedChars.Add("97"); //a
            AllowedChars.Add("98"); //b
            AllowedChars.Add("99"); //c
            AllowedChars.Add("100");    //d
            AllowedChars.Add("101");    //e
            AllowedChars.Add("102");    //f
            AllowedChars.Add("103");    //g
            AllowedChars.Add("104");    //h
            AllowedChars.Add("105");    //i
            AllowedChars.Add("106");    //j
            AllowedChars.Add("107");    //k
            AllowedChars.Add("108");    //l
            AllowedChars.Add("109");    //m
            AllowedChars.Add("110");    //n
            AllowedChars.Add("111");    //o
            AllowedChars.Add("112");    //p
            AllowedChars.Add("113");    //q
            AllowedChars.Add("114");    //r
            AllowedChars.Add("115");    //s
            AllowedChars.Add("116");    //t
            AllowedChars.Add("117");    //u
            AllowedChars.Add("118");    //v
            AllowedChars.Add("119");    //w
            AllowedChars.Add("120");    //x
            AllowedChars.Add("121");    //y
            AllowedChars.Add("122");    //z
            //AllowedChars.Add("123");    //{
            //AllowedChars.Add("124");    //|
            //AllowedChars.Add("125");    //}
            //AllowedChars.Add("126");	//~
            return AllowedChars;
        }

        public static string FindProhibitedCharacters(string text, List<string> AllowedChars, string Field)
        {
            string error = "";
            if (string.IsNullOrEmpty(text))
                return error;
            char[] chars = text.ToCharArray();
            StringBuilder result = new StringBuilder(text.Length + (int)(text.Length * 0.1));
            int chk = 0;
            foreach (char c in chars)
            {
                chk++;
                int value = Convert.ToInt32(c);

                if (!AllowedChars.Contains(value.ToString()))
                    result.Append(c);
                //if (value > 127)
                //    result.AppendFormat("&#{0};", value);
                //else
                //    result.Append(c);
            }
            if (result.ToString() != "")
                error = "Invalid Character(" + result.ToString() + ") found in " + Field + ", ";
            return error;
        }
    }
}