﻿using System.Collections.Generic;

namespace ESPro.Infrastructure.Class
{
    internal class RootObject
    {
        public List<Response> Response { get; set; }
    }

    public class Response
    {
        public int statusCode { get; set; }
        public string status { get; set; }
        public string data { get; set; }
    }
}