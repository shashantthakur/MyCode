﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Net;
using System.Text;

namespace ESPro.Infrastructure.Class
{
    public class Utilities
    {
        public Utilities(IConfiguration configuration, IHostingEnvironment hostingEnvironment)
        {
            UtilitiesResource.ApiMethod = configuration["ApiMethod"];
            UtilitiesResource.ApiURL = configuration["ApiURL"];
            UtilitiesResource.apiKey = configuration["apiKey"];
        }
    }

    public static class UtilitiesResource
    {
        public static string ApiMethod { get; set; }
        public static string ApiURL { get; set; }
        public static string apiKey { get; set; }




        public static string FSResultAPICall(string writingComments)
        {
            //string result = string.Empty;
            try
            {
                //working code
                if (string.IsNullOrEmpty(writingComments))
                    throw new Exception("Write not can't be empty");

                System.Net.ServicePointManager.Expect100Continue = false;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
                ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => true;

                WebClient webClient = new WebClient();
                webClient.Headers["ContentType"] = "application/x-www-form-urlencoded";

                NameValueCollection formData = new NameValueCollection();
                formData["apiKey"] = apiKey;
                formData["text"] = writingComments.Replace("\r\n", " ").Replace('\n', ' ');

                byte[] responseBytes = webClient.UploadValues(ApiURL, "POST", formData);
                string resultAuthTicket = Encoding.UTF8.GetString(responseBytes);
                webClient.Dispose();

                var obj = JsonConvert.DeserializeObject<dynamic>(resultAuthTicket);
                if (obj.statusCode != "200")
                    throw new Exception(obj.message.ToString());

                if (!string.IsNullOrEmpty(resultAuthTicket))
                {
                    return resultAuthTicket;
                }
                else throw new Exception("Something went wrong in API");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
                //throw new Exception(ex.Message);
            }
        }
    }
}
