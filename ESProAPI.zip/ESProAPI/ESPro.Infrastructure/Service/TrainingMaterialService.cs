﻿using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.IO;
using System.Text.RegularExpressions;
using System.Net;

namespace ESPro.Infrastructure.Service
{
    public class TrainingMaterialService : ITrainingMaterial
    {
        string content = "";
        public List<VTT_TranScript> GetTrsanScriptText(string vttPath)
        {
            using (WebClient client = new WebClient())
            {
                ServicePointManager.Expect100Continue = false;
                client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
                System.Net.ServicePointManager.ServerCertificateValidationCallback += (send, certificate, chain, sslPolicyErrors) => { return true; };
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
                //content = client.DownloadString("http://rs2.luminad.com/ui.espro.document_stg/Documents/Training/2/U1L01_Purposes_of_Assessment.vtt");// + vttPath);
                content = client.DownloadString(vttPath);
            }
            List<VTT_TranScript> VTT_TranScriptList = new List<VTT_TranScript>();
            //string Buf = File.ReadAllText(vttPath);
            string[] arr = content.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
            int cnt = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                string LineText = arr[i];
                Match m = Regex.Match(LineText, "([0-9]+:[0-9]+:[0-9]+[.,][0-9]+) \\-\\-\\> ([0-9]+:[0-9]+:[0-9]+[.,][0-9]+)", RegexOptions.IgnoreCase);
                if (m.Success)
                {
                    cnt++;
                    VTT_TranScript vTT_TranScript = new VTT_TranScript();

                    vTT_TranScript.Id = cnt;
                    TimeSpan start_ts = TimeSpan.Parse(m.Groups[1].Value.Replace(",", "."));
                    vTT_TranScript.StartTime = start_ts.TotalSeconds;

                    TimeSpan end_ts = TimeSpan.Parse(m.Groups[2].Value.Replace(",", "."));
                    vTT_TranScript.EndTime = end_ts.TotalSeconds;
                    if (arr.Length > (i + 1))
                        vTT_TranScript.TrsanScriptText = arr[i + 1];

                    VTT_TranScriptList.Add(vTT_TranScript);
                }
            }
            return VTT_TranScriptList;
        }

        public List<TrainingVideoDescription> GetTrainingVideoDescription(int SubId, int Seconds)
        {
            List<TrainingVideoDescription> _trainingVideoDescription = CommonResource.ToCollection<TrainingVideoDescription>(DbContext.DbUser.ExecuteDataSet("GetTrainingVideoDescription", SubId, Seconds).Tables[0]);
            return _trainingVideoDescription;
        }

        public List<SearchTrainingDetails> GetTrainingMaterialListForExtendedSearch(int RoleId, int ClientId)
        {
            List<SearchTrainingDetails> _searchTrainingMaterialList = CommonResource.ToCollection<SearchTrainingDetails>(DbContext.DbUser.ExecuteDataSet("GetTrainingMaterialForExtendedSearch", RoleId, ClientId).Tables[0]);
            return _searchTrainingMaterialList;
        }

        public List<TrainingMaterialMenu> GetTrainingMaterialMenu(int RoleId, int ClientId)
        {
            List<TrainingMaterialMenu> _trainingMaterialMenu = CommonResource.ToCollection<TrainingMaterialMenu>(DbContext.DbUser.ExecuteDataSet("GetTrainingMaterialMenu", RoleId, ClientId).Tables[0]);
            return _trainingMaterialMenu;
        }

        public List<TrainingMaterialMenu> GetTrainingMaterialDetailsMenu(int RoleId, int ClientId, int MenuId)
        {
            //List<TrainingMaterialMenu> _trainingMaterialList = new List<TrainingMaterialMenu>();
            List<TrainingMaterialMenu> _trainingMaterial = CommonResource.ToCollection<TrainingMaterialMenu>(DbContext.DbUser.ExecuteDataSet("GetTrainingMaterialMenuUnit", RoleId, ClientId, MenuId).Tables[0]);
            List<TrainingDetails> _trainingDetails = CommonResource.ToCollection<TrainingDetails>(DbContext.DbUser.ExecuteDataSet("GetTrainingMaterialDetailsMenu", MenuId).Tables[0]);

            if(_trainingMaterial!=null && _trainingMaterial.Count > 0)
            {
                foreach (TrainingMaterialMenu trainingMaterial in _trainingMaterial)
                {
                    List<TrainingDetails> _CurrTrainingDetails = _trainingDetails.Where(p2 => p2.TrainingMenuId == trainingMaterial.TrainingMaterialMenuId).ToList();
                    foreach (TrainingDetails trainingDetails in _CurrTrainingDetails)
                    {
                        trainingDetails.FilePath = CommonResource.TrainingMaterialPath + "/" + trainingDetails.TrainingDetailsId + "/" + trainingDetails.FilePath;
                        trainingDetails.ThumbnailPath = CommonResource.TrainingMaterialPath + "/" + trainingDetails.TrainingDetailsId + "/" + trainingDetails.ThumbnailPath;
                        trainingDetails.SrtPath = Path.GetDirectoryName(trainingDetails.FilePath).Replace("\\", "/").Replace(":/", "://") + "/" + Path.GetFileNameWithoutExtension(trainingDetails.FilePath) + ".vtt";
                        trainingDetails.VttPath = Path.GetDirectoryName(trainingDetails.FilePath).Replace("\\", "/").Replace(":/", "://") + "/" + Path.GetFileNameWithoutExtension(trainingDetails.FilePath) + "-es.vtt";
                    }
                    trainingMaterial.TrainingDetailsList=_CurrTrainingDetails;
                }
                    
            }
            //foreach (TrainingMaterialMenu trainingMaterial in _trainingMaterial)
            //{
            //    List<TrainingDetails> _CurrTrainingDetails = _trainingDetails.Where(p2 => p2.TrainingMenuId == trainingMaterial.TrainingMaterialMenuId).ToList();
            //    if (_CurrTrainingDetails != null)
            //    {
            //        foreach (TrainingDetails trainingDetails in _CurrTrainingDetails)
            //        {
            //            trainingDetails.FilePath = CommonResource.TrainingMaterialPath + "/" + trainingDetails.TrainingDetailsId + "/" + trainingDetails.FilePath;
            //            trainingDetails.ThumbnailPath = CommonResource.TrainingMaterialPath + "/" + trainingDetails.TrainingDetailsId + "/" + trainingDetails.ThumbnailPath;
            //            trainingDetails.SrtPath = Path.GetDirectoryName(trainingDetails.FilePath).Replace("\\", "/").Replace(":/", "://") + "/" + Path.GetFileNameWithoutExtension(trainingDetails.FilePath) + ".vtt";
            //            trainingDetails.VttPath = Path.GetDirectoryName(trainingDetails.FilePath).Replace("\\", "/").Replace(":/", "://") + "/" + Path.GetFileNameWithoutExtension(trainingDetails.FilePath) + "-es.vtt";
            //        }
            //        TrainingMaterialList trainingMaterialList = new TrainingMaterialList();

            //        trainingMaterialList.TrainingMenuId = trainingMaterial.TrainingMaterialMenuId;
            //        trainingMaterialList.UnitTitle = trainingMaterial.UnitTitle;
            //        trainingMaterialList.UnitTitle1 = Convert.ToString("" + trainingMaterial.UnitTitle1);
            //        trainingMaterialList.bgColor = trainingMaterial.bgColor;
            //        trainingMaterialList.RoleId = trainingMaterial.RoleId;
            //        trainingMaterialList.TrainingDetailsList = _CurrTrainingDetails;

            //        _trainingMaterialList.Add(trainingMaterialList);
            //        //foreach (TrainingDetails trainingDetails in _CurrTrainingDetails)
            //        //{

            //        //}
            //    }
            //}
            return _trainingMaterial;
        }

        public List<TrainingMaterialList> GetTrainingMaterialList(int RoleId, int ClientId, int MenuId)
        {
            List<TrainingMaterialList> _trainingMaterialList = new List<TrainingMaterialList>();
            List<TrainingMaterial> _trainingMaterial = CommonResource.ToCollection<TrainingMaterial>(DbContext.DbUser.ExecuteDataSet("GetTrainingMaterial", RoleId, ClientId, MenuId).Tables[0]);
            List<TrainingDetails> _trainingDetails = CommonResource.ToCollection<TrainingDetails>(DbContext.DbUser.ExecuteDataSet("GetTrainingMaterialDetails", RoleId, ClientId).Tables[0]);



            foreach (TrainingMaterial trainingMaterial in _trainingMaterial.OrderBy(c => c.UnitSeq).ToList())
            {

                List<TrainingDetails> _CurrTrainingDetails = _trainingDetails.Where(p2 => p2.TrainingMasterId == trainingMaterial.TrainingMaterialId).ToList();
                if (_CurrTrainingDetails != null)
                {
                    foreach (TrainingDetails trainingDetails in _CurrTrainingDetails)
                    {
                        trainingDetails.FilePath = CommonResource.TrainingMaterialPath + "/" + trainingDetails.TrainingDetailsId + "/" + trainingDetails.FilePath;
                        trainingDetails.ThumbnailPath = CommonResource.TrainingMaterialPath + "/" + trainingDetails.TrainingDetailsId + "/" + trainingDetails.ThumbnailPath;
                        trainingDetails.SrtPath = Path.GetDirectoryName(trainingDetails.FilePath).Replace("\\", "/").Replace(":/", "://") + "/" + Path.GetFileNameWithoutExtension(trainingDetails.FilePath) + ".vtt";
                        trainingDetails.VttPath = Path.GetDirectoryName(trainingDetails.FilePath).Replace("\\", "/").Replace(":/", "://") + "/" + Path.GetFileNameWithoutExtension(trainingDetails.FilePath) + "-es.vtt";
                    }
                    TrainingMaterialList trainingMaterialList = new TrainingMaterialList();

                    trainingMaterialList.TrainingMaterialId = trainingMaterial.TrainingMaterialId;
                    trainingMaterialList.UnitTitle = trainingMaterial.UnitTitle;
                    trainingMaterialList.UnitTitle1 = Convert.ToString("" + trainingMaterial.UnitTitle1);
                    trainingMaterialList.bgColor = trainingMaterial.bgColor;
                    trainingMaterialList.RoleId = trainingMaterial.RoleId;
                    trainingMaterialList.TrainingDetailsList = _CurrTrainingDetails;

                    _trainingMaterialList.Add(trainingMaterialList);
                    //foreach (TrainingDetails trainingDetails in _CurrTrainingDetails)
                    //{

                    //}
                }
            }
            // _subDisciplines.Where(p => !_subjectExpertise.Any(p2 => p2.ExpertiseId == p.ExpertiseId));
            return _trainingMaterialList;
        }

        public int UpdateTrainingViews(UpdateTrainingViewsCount updateTrainingViewsCount)
        {
            int count = DbContext.DbUser.ExecuteNonQuery("usp_UpdateTrainingViewsCount", updateTrainingViewsCount.UserID, updateTrainingViewsCount.UserEmailID, updateTrainingViewsCount.TrainingDetailsId, updateTrainingViewsCount.VideoViews);
            return count;
        }

        public int InsertLikeDislikeFlagCount(InsertLikeDislikeFlagCountParameters datas)
        {
            int count = 0;

            if (datas.LikeDislikeFlag == "Mail")
            {
                count = Convert.ToInt32(DbContext.DbUser.ExecuteScalar("usp_InsertLikeDislikeFlagCount", datas.UserID, datas.TrainingDetailsId, datas.LikeDislikeFlag, datas.VideoIssues, datas.AudioIssues, datas.SubtitlesIssues, datas.ContentRecommendations, datas.FlagOffensiveContent, datas.Type, datas.Anonymous));
            }
            else
            {
                count = DbContext.DbUser.ExecuteNonQuery("usp_InsertLikeDislikeFlagCount", datas.UserID, datas.TrainingDetailsId, datas.LikeDislikeFlag, datas.VideoIssues, datas.AudioIssues, datas.SubtitlesIssues, datas.ContentRecommendations, datas.FlagOffensiveContent, datas.Type, datas.Anonymous);
            }
            return count;
        }

        public LikeDislikeFlagCount GetInsertLikeDislikeFlagCount(InsertLikeDislikeFlagCountParameters datas)
        {
            List<LikeDislikeFlagCount> getInsertLikeDislikeFlagCount = CommonResource.ToCollection<LikeDislikeFlagCount>(DbContext.DbUser.ExecuteDataSet("usp_GetLikeDislikeFlagCount", datas.UserID, datas.TrainingDetailsId, datas.Type).Tables[0]);
            return getInsertLikeDislikeFlagCount[0];
        }

        public List<TrainingVideoReport> GetTrainingVideoProblemReport(string StartDate, string EndDate)
        {
            return CommonResource.ToCollection<TrainingVideoReport>(DbContext.DbUser.ExecuteDataSet("usp_GetTrainingVideoProblemReport", StartDate, EndDate).Tables[2]);
        }
        //List<TrainingMaterialList> ITrainingMaterial.GetTrainingMaterialList(int RoleId, int ClientId)
        //{
        //    throw new NotImplementedException();
        //}

        //int ITrainingMaterial.UpdateTrainingViews(UpdateTrainingViewsCount updateTrainingViewsCount)
        //{
        //    throw new NotImplementedException();
        //}
    }
}
