﻿using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace ESPro.Infrastructure.Service
{
    public class RatingService : IRating
    {

        public IEnumerable<RatingJobNoDetails> GetRatingJobNoDetails(int JobId)
        {
            var abc = CommonResource.ToCollection<RatingJobNoDetails>(DbContext.DbUser.ExecuteDataSet("usp_GetRatingJobNoDetails", JobId).Tables[0]);
            return abc;
        }

        public IEnumerable<RatingUsers> GetRatingUsersList(int UsersId, int currentuserid, string currentrole)
        {
            var abc = CommonResource.ToCollection<RatingUsers>(DbContext.DbUser.ExecuteDataSet("usp_GetUsersListForRatingHistory", UsersId, currentuserid, currentrole).Tables[0]);
            return abc;
        }

        public IEnumerable<RatingDetails> GetRatingHistory(int UsersId, int currentuserid, string currentuserrole)
        {
            var abc = CommonResource.ToCollection<RatingDetails>(DbContext.DbUser.ExecuteDataSet("usp_GetUsersRatingDetails", UsersId, currentuserid, currentuserrole).Tables[0]);

            if (currentuserrole == "FREELANCER")
            {
                List<RatingDetails> remodel = new List<RatingDetails>();
                foreach (var item in abc)
                {
                    RatingDetails M = new RatingDetails();
                    M = item;
                    if (! string.IsNullOrEmpty(item.AgencyUserEmailID))
                    {
                        M.InvApproverName = "REDACTED";
                        M.InvApproverEmail = "REDACTED";
                        M.InvApproverName2 = "REDACTED";
                        M.InvApproverEmail2 = "REDACTED";
                        M.ProjectManagerEmail = "REDACTED";

                    }
                    remodel.Add(M);
                }
            }
                return abc;
        }

        public IEnumerable<RatingComments> GetRatingComments(int JobId)
        {
            var abc = CommonResource.ToCollection<RatingComments>(DbContext.DbUser.ExecuteDataSet("usp_GetRatingComments", JobId).Tables[0]);
            return abc;
        }

        public IEnumerable<ProjectSpecificCategoryModel> GetProjectSpecificCategoryDetails(int? usersid, int? jobID)
        {
            return CommonResource.ToCollection<ProjectSpecificCategoryModel>(DbContext.DbUser.ExecuteDataSet("usp_Get_ProjectSpecificRatingDetails", usersid == null ? 0 : usersid, jobID).Tables[0]);
        }

        public IEnumerable<CategorySpecificModel> GetCategorySpecificCategoryDetails(int? usersid)
        {
            return CommonResource.ToCollection<CategorySpecificModel>(DbContext.DbUser.ExecuteDataSet("usp_Get_CategorySpecificRatingDetails", usersid).Tables[0]);
        }

        public IEnumerable<CategorySpecificModel> GetCategorySpecificCategoryDetailsForNonFreelancer(int? usersid)
        {
            return CommonResource.ToCollection<CategorySpecificModel>(DbContext.DbUser.ExecuteDataSet("usp_Get_CategorySpecificRatingDetailsForNonFreelancer", usersid).Tables[0]);
        }

        public IEnumerable<SkillSpecificRatingModel> GetSkillSpecificCategoryDetails(int? usersid)
        {
            return CommonResource.ToCollection<SkillSpecificRatingModel>(DbContext.DbUser.ExecuteDataSet("usp_Get_SkillSpecificRatingDetails", usersid).Tables[0]);
        }

        public IEnumerable<SkillSpecificRatingModel> GetSkillSpecificCategoryDetailsForNonFreelancer(int? usersid, string skill)
        {
            return CommonResource.ToCollection<SkillSpecificRatingModel>(DbContext.DbUser.ExecuteDataSet("usp_Get_SkillSpecificRatingDetailsForNonFreelancer", usersid, skill).Tables[0]);
        }

        public int SaveRatingDetails(RatingSave ratingDetails)
        {
            var OverallJobRating = String.Format("{0:0.00}", decimal.Round((decimal)(ratingDetails.OverallQualityRating + ratingDetails.AdherenceToScheduleRating + ratingDetails.CommunicationRating) / (decimal)3.00), 2);
            string Time = "";
            int cnt = 0;
            //try
            //{
                SqlConnection con = new SqlConnection(CommonResource.ConString);
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "usp_SaveRatingDetails";
                cmd.Parameters.AddWithValue("@RatingId", ratingDetails.RatingId);
                cmd.Parameters.AddWithValue("@JobId", ratingDetails.JobId);
                cmd.Parameters.AddWithValue("@OverallQualityOfWork", ratingDetails.OverallQualityRating);
                cmd.Parameters.AddWithValue("@AdherenceToSchedule", ratingDetails.AdherenceToScheduleRating);
                cmd.Parameters.AddWithValue("@Communication", ratingDetails.CommunicationRating);
                cmd.Parameters.AddWithValue("@OverallJobRating", OverallJobRating);
                cmd.Parameters.AddWithValue("@RatedByUsersId", ratingDetails.RatedBy);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 120;
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                if (con.State == ConnectionState.Closed)
                    con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

   //             Time += DateTime.Now;
   //             cnt = DbContext.DbUser.ExecuteNonQuery("usp_SaveRatingDetails", ratingDetails.RatingId, ratingDetails.JobId,
   //ratingDetails.OverallQualityRating, ratingDetails.AdherenceToScheduleRating, ratingDetails.CommunicationRating, OverallJobRating, ratingDetails.RatedBy);
   //             Time += "\r\n" + DateTime.Now;
   //         }
   //         catch (Exception ax)
   //         {
   //             Time += "\r\n" + DateTime.Now + " "+ax.StackTrace.ToString();
   //         }


            cnt = DbContext.DbUser.ExecuteNonQuery("usp_SaveRatingCommemts", ratingDetails.OverallQualityCommentId, ratingDetails.JobId, ratingDetails.OverallQualityCatagoryId, ratingDetails.OverallQualityComment);
            cnt = DbContext.DbUser.ExecuteNonQuery("usp_SaveRatingCommemts", ratingDetails.AdherenceToScheduleCommentId, ratingDetails.JobId, ratingDetails.AdherenceToScheduleCatagoryId, ratingDetails.AdherenceToScheduleComment);
            cnt = DbContext.DbUser.ExecuteNonQuery("usp_SaveRatingCommemts", ratingDetails.CommunicationCommentId, ratingDetails.JobId, ratingDetails.CommunicationCatagoryId, ratingDetails.CommunicationComment);

            return cnt;
        }

        public string GetRatedPM(int? jobID)
        {
            DataSet ds = DbContext.DbUser.ExecuteDataSet("usp_GetRatedPM", jobID);
            return ds.Tables[0].Rows[0][0].ToString();
        }
    }
}
