﻿using ESPro.Core.Interface;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using System.Linq;
using System.Security.Claims;
using ESPro.Infrastructure.Class;
using ESPro.Core.Entity;
using System.Data;
using System.IO;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using ESPro.Core.Entity.Search;
using System.Net.Http;
using System.Net;

namespace ESPro.Infrastructure.Service
{
    public class RegiService : IRegi
    {
        public IConfiguration _Configuration { get; }
        public string GenerateToken(int userId)
        {

            var mySecret = CommonResource.SecretKey;
            var mySecurityKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(mySecret));

            var myIssuer = CommonResource.myIssuer;
            var myAudience = CommonResource.myAudience;

            var tokenHandler = new JwtSecurityTokenHandler();
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
            new Claim(ClaimTypes.Name, userId.ToString()),
              //new Claim("FirstName", "Ravi")


                }),
                Expires = DateTime.UtcNow.AddDays(7),
                Issuer = myIssuer,
                Audience = myAudience,
                SigningCredentials = new SigningCredentials(mySecurityKey, SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }



        public string GenerateTokenAndSendMail(int userId, string EmailId, string FullName)
        {
            var mySecret = CommonResource.SecretKey;
            var mySecurityKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(mySecret));

            var myIssuer = CommonResource.myIssuer;
            var myAudience = CommonResource.myAudience;

            var tokenHandler = new JwtSecurityTokenHandler();
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
            new Claim(ClaimTypes.Name, userId.ToString()),
              //new Claim("FirstName", "Ravi")
                }),
                Expires = DateTime.UtcNow.AddHours(24),
                Issuer = myIssuer,
                Audience = myAudience,
                SigningCredentials = new SigningCredentials(mySecurityKey, SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            string TokenString = tokenHandler.WriteToken(token);

            MailService objMail = new MailService();
            string Url = CommonResource.BaseUrl + "/regi/link.validate?token=" + TokenString;


            var path = Path.Combine(CommonResource.MailTemplatePath, "AccountActivation.html");
            //var str2 = env.WebRootPath; // Null, both doesn't give any result

            StringBuilder sbMailBody = new StringBuilder(System.IO.File.ReadAllText(path));

            sbMailBody.Replace("[UserName]", FullName);
            sbMailBody.Replace("[ActvationLink]", Url);
            //sbMailBody.Replace("[RegistrationLink]", Url);


            return objMail.SendMail(sbMailBody.ToString(), "ESPro Account Verification Link", EmailId, "");
        }

        public string GenerateForgetTokenAndSendMail(int userId, string EmailId, string FullName, string Subject = "ESPro Reset Password")
        {

            var mySecret = CommonResource.SecretKey;
            var mySecurityKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(mySecret));

            var myIssuer = CommonResource.myIssuer;
            var myAudience = CommonResource.myAudience;

            var tokenHandler = new JwtSecurityTokenHandler();
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
            new Claim(ClaimTypes.Name, userId.ToString()),
              //new Claim("FirstName", "Ravi")
                }),
                Expires = DateTime.UtcNow.AddHours(24),
                Issuer = myIssuer,
                Audience = myAudience,
                SigningCredentials = new SigningCredentials(mySecurityKey, SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            string TokenString = tokenHandler.WriteToken(token);

            MailService objMail = new MailService();
            string Url = CommonResource.BaseUrl + "/regi/link.validateToken?token=" + TokenString;


            var path = Path.Combine(CommonResource.MailTemplatePath, "ForgotPassword.html");
            //var str2 = env.WebRootPath; // Null, both doesn't give any result

            StringBuilder sbMailBody = new StringBuilder(System.IO.File.ReadAllText(path));

            sbMailBody.Replace("[UserName]", FullName);
            sbMailBody.Replace("[ActvationLink]", Url);
            //sbMailBody.Replace("[RegistrationLink]", Url);


            return objMail.SendMail(sbMailBody.ToString(), Subject, EmailId, "");
        }


        public object OtpMailSend(string usersid)
        {
            string OTP = "";
            string OTPMail = "";
            try
            {

                OTP = Convert.ToString(CommonResource.GenerateRandomNo());
                MailService objMail = new MailService();
                UserDetailsService _userDetails = new UserDetailsService(_Configuration);
                var ud = _userDetails.getUser(usersid);
                var udd = _userDetails.GetUserUsersId(ud.UserName).FirstOrDefault();
                var dt = GetAuth(usersid);
                OTPMail = dt.OTPMail;
                string MailSubject = "OTP for ESPro";
                var path = Path.Combine(CommonResource.MailTemplatePath, "OTPMailTemplate.html");
                StringBuilder sbMailBody = new StringBuilder(System.IO.File.ReadAllText(path));
                sbMailBody.Replace("{UserName}", udd.Name);
                sbMailBody.Replace("{OTP}", OTP);
                sbMailBody.Replace("{Regards}", "Expert Source Pro Team.");
                //new MailSending().SendEmailAsyn(ProjectResources.strDefaultMailFromName, EmailID, "", MailSubject, sbMailBody.ToString(), 0, 0);
                objMail.SendMail(sbMailBody.ToString(), MailSubject, dt.OTPMail, "");
                var Datas = new
                {
                    OTP = OTP,
                    Email = dt.OTPMail
                };
                return Datas;
            }
            catch
            { }
            var Data = new
            {
                OTP = OTP,
                Email = OTPMail
            };
            return Data;
        }

        public string ValidateToken(string token, out string ActivationID)
        {
            ActivationID = "0";
            var mySecret = CommonResource.SecretKey;
            var mySecurityKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(mySecret));
            int pk_id = 0;
            var myIssuer = CommonResource.myIssuer;
            var myAudience = CommonResource.myAudience;

            var tokenHandler = new JwtSecurityTokenHandler();
            try
            {
                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidIssuer = myIssuer,
                    ValidAudience = myAudience,

                    LifetimeValidator = this.LifetimeValidator,
                    IssuerSigningKey = mySecurityKey

                }, out SecurityToken validatedToken);

                // tokenHandler.Claims.Where(z => z.Type.Equals("unique_name")).FirstOrDefault().Value, out pk_id),

                //var handler = new JwtSecurityTokenHandler();
                var jsonToken = tokenHandler.ReadToken(token);
                var tokenS = tokenHandler.ReadToken(token) as JwtSecurityToken;
                // var jti = tokenS.Claims.First(claim => claim.Type == "unique_name").Value;
                var UserActivationId = tokenS.Claims.First(claim => claim.Type == "unique_name").Value;

                ActivationID = UserActivationId;
                DataTable DT = DbContext.DbUser.ExecuteDataSet("usp_ValidateAndCreateUser", UserActivationId).Tables[0];
                return DT.Rows[0][0].ToString();
                //if(DT.Rows[0][0].ToString()== "true")
                //{
                //    return true;
                //}
                //else
                //{
                //    return false;
                //}                

            }
            catch (Exception ex)
            {
                return "0";
            }

        }


        public string ValidateResetPaswordToken(string token, out string ActivationID)
        {
            ActivationID = "0";
            var mySecret = CommonResource.SecretKey;
            var mySecurityKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(mySecret));
            int pk_id = 0;
            var myIssuer = CommonResource.myIssuer;
            var myAudience = CommonResource.myAudience;

            var tokenHandler = new JwtSecurityTokenHandler();
            try
            {
                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidIssuer = myIssuer,
                    ValidAudience = myAudience,

                    LifetimeValidator = this.LifetimeValidator,
                    IssuerSigningKey = mySecurityKey

                }, out SecurityToken validatedToken);

                // tokenHandler.Claims.Where(z => z.Type.Equals("unique_name")).FirstOrDefault().Value, out pk_id),

                //var handler = new JwtSecurityTokenHandler();
                var jsonToken = tokenHandler.ReadToken(token);
                var tokenS = tokenHandler.ReadToken(token) as JwtSecurityToken;
                // var jti = tokenS.Claims.First(claim => claim.Type == "unique_name").Value;
                var UserActivationId = tokenS.Claims.First(claim => claim.Type == "unique_name").Value;

                ActivationID = UserActivationId;
                DataTable DT = DbContext.DbUser.ExecuteDataSet("usp_ValidateForgotToken", UserActivationId).Tables[0];
                return DT.Rows[0][0].ToString();
                //if(DT.Rows[0][0].ToString()== "true")
                //{
                //    return true;
                //}
                //else
                //{
                //    return false;
                //}                

            }
            catch (Exception ex)
            {
                return "0";
            }

        }
        public bool LifetimeValidator(DateTime? notBefore, DateTime? expires, SecurityToken securityToken, TokenValidationParameters validationParameters)
        {
            if (expires != null)
            {
                if (DateTime.UtcNow < expires) return true;
            }
            return false;
        }

        public string InsertUserForActivation(RegiModel _userRegistrationModel)
        {
            DataTable DT = DbContext.DbUser.ExecuteDataSet("usp_InsertUserForActivation", _userRegistrationModel.EmailId, _userRegistrationModel.FullName, _userRegistrationModel.ContactNumber, _userRegistrationModel.Password).Tables[0];

            return DT.Rows[0][0].ToString();

        }
        public string ResendUserActivationLink(RegiModel _userRegistrationModel)
        {
            DataTable DT = DbContext.DbUser.ExecuteDataSet("usp_ResendUserActivationLink", _userRegistrationModel.EmailId, _userRegistrationModel.FullName, _userRegistrationModel.ContactNumber, _userRegistrationModel.Password).Tables[0];

            return DT.Rows[0][0].ToString();

        }

        public string ResendUserForotLink(string EmailId)
        {
            DataTable DT = DbContext.DbUser.ExecuteDataSet("usp_UserForgotLink", EmailId).Tables[0];

            return DT.Rows[0][0].ToString();

        }

        public string EmailValidate(string EmailId)
        {
            DataTable DT = DbContext.DbUser.ExecuteDataSet("usp_ValidateEmailId", EmailId).Tables[0];
            return DT.Rows[0][0].ToString();

        }

        public string ResetPassword(ResetPassword resetPassword)
        {
            var DT = DbContext.DbUser.ExecuteNonQuery("usp_ResetPassword", resetPassword.UsersId, resetPassword.Password);
            return DT.ToString();
        }

        public UserStatus UserLogin(Login login)
        {
            return CommonResource.ToCollection<UserStatus>(DbContext.DbUser.ExecuteDataSet("usp_Login", login.UserName, login.Password).Tables[0]).FirstOrDefault();
        }

        public UserStatus RegisterOrLoginExternalUser(ExternalResponse login)
        {
            return CommonResource.ToCollection<UserStatus>(DbContext.DbUser.ExecuteDataSet("usp_RegisterOrLoginGoogleUser", login.name, login.username, login.Picture, login.AuthenticationFrom).Tables[0]).FirstOrDefault();
        }

        public UserStatus SwitchUser(SwitchUser switchUser)
        {
            return CommonResource.ToCollection<UserStatus>(DbContext.DbUser.ExecuteDataSet("usp_SwitchUser", switchUser.UserName, switchUser.RoleId).Tables[0]).FirstOrDefault();

        }

        public int UpdateStatusOfRequestMail(int? JobID, string comments)
        {
            return DbContext.DbUser.ExecuteNonQuery("usp_Update_Status_RequestMaillProjectSF", JobID, comments);
        }

        public AuthModel GetAuth(string uid)
        {
            return CommonResource.ToCollection<AuthModel>(DbContext.DbUser.ExecuteDataSet("usp_getF2Auth", uid).Tables[0]).FirstOrDefault();
        }

        public string ManageActiveDeactive(string status, int? usersid, int? currentUserId, string comments = "")
        {
            int statusId = 1;
            if (status == "Inactive")
            {
                statusId = 0;
            }
            else if (status == "Active")
            {
                statusId = 1;
            }
            int cnt = DbContext.DbUser.ExecuteNonQuery("sp_ActiveDeactiveUser", usersid, statusId, comments, currentUserId);
            if (cnt > 0 && status == "Inactive")
            {

            }
            else if (cnt > 0 && status == "Active")
            {

            }
            return "";
        }

        public int UpdateAuth(AuthModel data)
        {
            int count = DbContext.DbUser.ExecuteNonQuery("usp_Update2FA", data.Id, data.OTPMail, data.F2Auth);
            return count;
        }

        public int SaveWorkAsDetails(WorkAsSave workAsSave)
        {
            int count = DbContext.DbUser.ExecuteNonQuery("usp_UpdateWorkAs", workAsSave.UserID, workAsSave.UserEmailID, workAsSave.WorkAs);
            return count;
        }

        public List<FreelancerTabModelAward> GetStylesheetForCopyEditingSkill(string UserID)
        {
            var abc = CommonResource.ToCollection<FreelancerTabModelAward>(DbContext.DbUser.ExecuteDataSet("usp_GetStylesheetForCopyEditingSkill", Convert.ToInt64(UserID)).Tables[0]);
            return abc;
        }

        public string LoginToES2(IConfiguration _Configuration)
        {
            ES2User eS2User = new ES2User();
            eS2User.user_id = _Configuration["ES2:user_id"].ToString();
            eS2User.password = _Configuration["ES2:password"].ToString();
            string ApiPath = _Configuration["ES2:api"].ToString() + "/LoginPage/GenrateLoginLink";

            string jsonUserString = Newtonsoft.Json.JsonConvert.SerializeObject(eS2User);
            var content = new StringContent(jsonUserString, Encoding.UTF8, "application/json");

            HttpClient client = new HttpClient();
            client.Timeout = TimeSpan.FromMinutes(10);
            HttpResponseMessage response = client.PostAsync(ApiPath, content).Result;
            var Json = response.Content.ReadAsStringAsync().Result;


            if (response.StatusCode == HttpStatusCode.OK)
            {

                return Json.ToString();
            }
            else
            {
                return "";
            }

        }

        public int InsertHireFreelancerExpertReq(HireFreelancerExpertReq hireFreelancerExpertReq)
        {
            int cnt = Convert.ToInt32(DbContext.DbUser.ExecuteScalar("usp_InsertHireFreelancerExpertReq", hireFreelancerExpertReq.ProjectName, hireFreelancerExpertReq.ProjectDescription, hireFreelancerExpertReq.FullName, hireFreelancerExpertReq.EmailId, hireFreelancerExpertReq.ContactNumber));
            return cnt;
        }

        public int GenerateOTP(GenerateOtp generateOtp)
        {
            string OTP = "";
            string OTPMail = "";
            try
            {

                OTP = Convert.ToString(CommonResource.GenerateRandomNo());
                int cnt = Convert.ToInt32(DbContext.DbUser.ExecuteScalar("usp_InsertOtp", generateOtp.UsersId, OTP, generateOtp.OtpType));

                MailService objMail = new MailService();
                UserDetailsService _userDetails = new UserDetailsService(_Configuration);
                var ud = _userDetails.getUser(generateOtp.UsersId.ToString());
                var udd = _userDetails.GetUserUsersId(ud.UserName).FirstOrDefault();
               // var dt = GetAuth(generateOtp.UsersId.ToString());
                OTPMail = ud.UserName;// dt.OTPMail;
                string MailSubject = "ESPro: Profile OTP";
                var path = Path.Combine(CommonResource.MailTemplatePath, "OTPMailTemplate.html");
                StringBuilder sbMailBody = new StringBuilder(System.IO.File.ReadAllText(path));
                sbMailBody.Replace("{UserName}", udd.Name);
                sbMailBody.Replace("{OTP}", OTP);
                sbMailBody.Replace("{Regards}", "Expert Source Pro Team.");
                //new MailSending().SendEmailAsyn(ProjectResources.strDefaultMailFromName, EmailID, "", MailSubject, sbMailBody.ToString(), 0, 0);
                objMail.SendMail(sbMailBody.ToString(), MailSubject, OTPMail, "");
                //var Datas = new
                //{
                //    OTP = OTP,
                //    Email = dt.OTPMail
                //};
                return cnt;
            }
            catch
            {
                return 0;
            }


        }
        public bool ValidateOTP(GenerateOtp generateOtp)
        {
            GetOtp getOtp = CommonResource.ToCollection<GetOtp>(DbContext.DbUser.ExecuteDataSet("usp_GetOtp", generateOtp.UsersId, generateOtp.OtpType).Tables[0]).FirstOrDefault();

            if(getOtp!=null && !string.IsNullOrEmpty( getOtp.Otp))
            {
                if(getOtp.Otp==generateOtp.Otp)
                {
                    return true;
                }else
                {
                    return false;
                }
            }else
            {
                return false;
            }
        }
    }
}
