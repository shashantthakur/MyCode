﻿using System;
using System.Collections.Generic;
using System.Text;
using ESPro.Core.Interface;
using System.Data.Common;
using ESPro.Infrastructure.Class;
using ESPro.Core.Entity;
using System.Linq;

namespace ESPro.Infrastructure.Service
{
    public class PredectiveService : IPredective
    {
        public PredictiveResult GetFsResult(int userdid)
        {
            return CommonResource.ToCollection<PredictiveResult>(DbContext.DbUser.ExecuteDataSet("usp_GetFSResult", userdid).Tables[0]).FirstOrDefault();
        }

        public bool UpSertWritingSample(PredictiveData data, string Result)
        {
            bool success = true;
            try
            {
                DbContext.DbUser.ExecuteNonQuery("usp_UpSertWritingSample", data.WritingNotes, data.UsersID, Result, null);
            }
            catch (Exception ex)
            {
                success = false;
            }
            return success;
        }
    }
}