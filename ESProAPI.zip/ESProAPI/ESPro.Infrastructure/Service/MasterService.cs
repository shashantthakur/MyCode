﻿using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESPro.Infrastructure.Service
{
    public class MasterService : IMaster
    {
        public List<Clients> GetClients()
        {
            return CommonResource.ToCollection<Clients>(DbContext.DbUser.ExecuteDataSet("usp_GetClients").Tables[0]);
        }

        public List<Currency> GetCurrency()
        {
            return CommonResource.ToCollection<Currency>(DbContext.DbUser.ExecuteDataSet("usp_GetCurrency").Tables[0]);
        }
        public List<MasterRateUnit> GetRateUnit()
        {
            return CommonResource.ToCollection<MasterRateUnit>(DbContext.DbUser.ExecuteDataSet("usp_GetRateUnit").Tables[0]);
        }

        
        public List<Locations> GetLocations()
        {
            //await Task.Delay(5000);
            //getwait(5);
            return CommonResource.ToCollection<Locations>(DbContext.DbUser.ExecuteDataSet("usp_GetLocations").Tables[0]);
        }

        public List<Languages> GetLanguages()
        {
            //await Task.Delay(5000);
            //getwait(5);
            return CommonResource.ToCollection<Languages>(DbContext.DbUser.ExecuteDataSet("usp_GetLanguages").Tables[0]);
        }

        public List<Skills> GetSkills()
        {
            return CommonResource.ToCollection<Skills>(DbContext.DbUser.ExecuteDataSet("usp_GetSkills").Tables[0]);
        }

        public List<Stylesheets> GetStylesheets()
        {
            return CommonResource.ToCollection<Stylesheets>(DbContext.DbUser.ExecuteDataSet("usp_GetStylesheets").Tables[0]);
        }

        public List<SystemFamilarity> GetSystemFamilarity()
        {
            return CommonResource.ToCollection<SystemFamilarity>(DbContext.DbUser.ExecuteDataSet("usp_GetSystemFamilarity").Tables[0]);
        }

        public IEnumerable<Qualifications> GetQualifications()
        {
            var result = CommonResource.ToCollection<Qualifications>(DbContext.DbUser.ExecuteDataSet("GetQualification").Tables[0]);
            return result;
        }

        public List<SubjectMatterExpertise> GetSubjectMatterExpertise()
        {
            List<SubjectMatterExpertise> subjectMatterExpertisesList = new List<SubjectMatterExpertise>();
            List<SubjectExpertise> _subjectExpertise = CommonResource.ToCollection<SubjectExpertise>(DbContext.DbUser.ExecuteDataSet("usp_GetSubjectMatterExpertise").Tables[0]);
            List<SubDisciplines> _subDisciplines = CommonResource.ToCollection<SubDisciplines>(DbContext.DbUser.ExecuteDataSet("usp_GetSubDisciplines").Tables[0]);

            foreach (SubjectExpertise SEitem in _subjectExpertise)
            {
                SubjectMatterExpertise _subjectMatterExpertise = new SubjectMatterExpertise();
                _subjectMatterExpertise.subjectExpertise = SEitem;
                // _subjectMatterExpertise.subDisciplines = _subDisciplines.Where(p => !_subjectExpertise.Any(p2 => p2.ExpertiseId == p.ExpertiseId)).ToList();
                _subjectMatterExpertise.subDisciplines = _subDisciplines.Where(p2 => p2.ExpertiseId == SEitem.ExpertiseId).ToList();
                subjectMatterExpertisesList.Add(_subjectMatterExpertise);
            }
            string jsn = Newtonsoft.Json.JsonConvert.SerializeObject(subjectMatterExpertisesList);
            // _subDisciplines.Where(p => !_subjectExpertise.Any(p2 => p2.ExpertiseId == p.ExpertiseId));
            return subjectMatterExpertisesList;
        }

        public List<SubjectMatterExpertiseGroup> GetSubjectMatterExpertiseGroup()
        {
            List<SubjectMatterExpertiseGroup> subjectMatterExpertisesList = new List<SubjectMatterExpertiseGroup>();
            List<SubjectExpertise> _subjectExpertise = CommonResource.ToCollection<SubjectExpertise>(DbContext.DbUser.ExecuteDataSet("usp_GetSubjectMatterExpertise").Tables[0]);
            List<SubDisciplines> _subDisciplines = CommonResource.ToCollection<SubDisciplines>(DbContext.DbUser.ExecuteDataSet("usp_GetSubDisciplines").Tables[0]);

            foreach (SubjectExpertise SEitem in _subjectExpertise)
            {

                List<SubDisciplines> _CurrensubDisciplines= _subDisciplines.Where(p2 => p2.ExpertiseId == SEitem.ExpertiseId).ToList();
                if (_CurrensubDisciplines != null)
                {
                    foreach (SubDisciplines subDisciplines in _CurrensubDisciplines)
                    {
                        SubjectMatterExpertiseGroup _subjectMatterExpertise = new SubjectMatterExpertiseGroup();
                        _subjectMatterExpertise.ExpertiseId = SEitem.ExpertiseId;
                        _subjectMatterExpertise.ExpertiseArea = SEitem.ExpertiseArea;
                        _subjectMatterExpertise.SubDisciplinesId = subDisciplines.SubDisciplinesId;
                        _subjectMatterExpertise.SubDiscipline = subDisciplines.SubDiscipline;
                        subjectMatterExpertisesList.Add(_subjectMatterExpertise);
                    }
                }
            }
            // _subDisciplines.Where(p => !_subjectExpertise.Any(p2 => p2.ExpertiseId == p.ExpertiseId));
            return subjectMatterExpertisesList;
        }
        public async Task<AllMaster> GetAllMaster()
        {

            AllMaster allMaster = new AllMaster();

            var taskLocations = Task.Run(() => GetLocations());
            var taskLanguages = Task.Run(() => GetLanguages());
            var taskSkills = Task.Run(() => GetSkills());
            var taskSystemFamilarity = Task.Run(() => GetSystemFamilarity());

            await Task.WhenAll(taskLocations, taskLanguages, taskSkills, taskSystemFamilarity);

            allMaster.Locations = taskLocations.Result;
            allMaster.Languages = taskLanguages.Result;
            allMaster.Skills = taskSkills.Result;
            allMaster.SystemFamilarity = taskSystemFamilarity.Result;

            return allMaster;
        }

        public void getwait(int min)
        {
            DateTime CurTime = DateTime.Now.AddSeconds(min);
            while (DateTime.Now < CurTime)
            {

            }
        }

        public List<Rating> GetRating()
        {
            return CommonResource.ToCollection<Rating>(DbContext.DbUser.ExecuteDataSet("usp_GetRating").Tables[0]);
        }

        public List<RatingCategories> GetRatingCategories()
        {
            return CommonResource.ToCollection<RatingCategories>(DbContext.DbUser.ExecuteDataSet("usp_GetRatingCategories").Tables[0]);
        }

        public List<Roles> GetRoles(string RolesFrom)
        {
            return CommonResource.ToCollection<Roles>(DbContext.DbUser.ExecuteDataSet("usp_GetRoles", RolesFrom).Tables[0]);
        }

        public List<AgencyMaster> GetAgency()
        {
            return CommonResource.ToCollection<AgencyMaster>(DbContext.DbUser.ExecuteDataSet("usp_GetAgency").Tables[0]);
        }


        public List<SelectList> GetDistinctJobs()
        {
            return CommonResource.ToCollection<SelectList>(DbContext.DbUser.ExecuteDataSet("usp_GetDistinctJobs").Tables[0]);
        }

        public List<SelectList> GetDistinctAuthors()
        {
            return CommonResource.ToCollection<SelectList>(DbContext.DbUser.ExecuteDataSet("usp_GetDistinctAuthors").Tables[0]);
        }

        public List<SelectList> GetDistinctUsers(string UserRole)
        {
            return CommonResource.ToCollection<SelectList>(DbContext.DbUser.ExecuteDataSet("usp_GetDistinctUsers", UserRole).Tables[0]);
        }
    }
}
