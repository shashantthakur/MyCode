﻿using ESPro.Core.Entity;
using ESPro.Core.Entity.Freelancer;
using ESPro.Core.Entity.HSBC;
using ESPro.Core.Entity.Invoice;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;

namespace ESPro.Infrastructure.Service
{
    public class InvoiceService : IInvoice
    {
        CryptoService cryptoService = new CryptoService();
        public IConfiguration _Configuration { get; }

        public InvoiceService(IConfiguration configuration)
        {
            _Configuration = configuration;
        }
        public InvoiceService()
        {

        }
        public List<PrefundingClient> PrefundingClients()
        {
            List<PrefundingClient> result = new List<PrefundingClient>();
            result = CommonResource.ToCollection<PrefundingClient>(DbContext.DbUser.ExecuteDataSet("GetPrefundingClient").Tables[0]);
            return result;
        }
        public List<InvoiceRatingStatus> InvoiceRatedbyPM(string JobNo, string FreelancerEmailID, int InvoiceSummaryID)
        {
            var abc = CommonResource.ToCollection<InvoiceRatingStatus>(DbContext.DbUser.ExecuteDataSet("usp_InvoiceRatedbyPM", JobNo, FreelancerEmailID, InvoiceSummaryID).Tables[0]);
            return abc;
        }

        public List<AllUsers> GetAllUsers(string Role)
        {
            var abc = CommonResource.ToCollection<AllUsers>(DbContext.DbUser.ExecuteDataSet("usp_GetAllUsers", Role).Tables[0]);
            return abc;
        }

        public IEnumerable<InvoiceStatus> GeInvoicesStatusList(string UserRole)
        {
            var abc = CommonResource.ToCollection<InvoiceStatus>(DbContext.DbUser.ExecuteDataSet("usp_GetInvoicesStatus", UserRole).Tables[0]);
            return abc;
        }

        public IEnumerable<FinanceMatrix> GetFinanceMatrix()
        {
            var abc = CommonResource.ToCollection<FinanceMatrix>(DbContext.DbUser.ExecuteDataSet("usp_GetFinanceMatrix").Tables[0]);
            return abc;
        }

        public IEnumerable<SendMailTo> GetSendMailDetails(string MailType, int clientid = 0)
        {
            var abc = CommonResource.ToCollection<SendMailTo>(DbContext.DbUser.ExecuteDataSet("usp_GetSendMailDetails", MailType, clientid).Tables[0]);
            return abc;
        }

        public List<WileyPrefundingDetails> GePrefundingDetails(WileyPrefundingDetailsSearchParameters wileyPrefundingDetailsSearchParameters)
        {
            var abc = CommonResource.ToCollection<WileyPrefundingDetails>(DbContext.DbUser.ExecuteDataSet("usp_GetPrefundingDetails", wileyPrefundingDetailsSearchParameters.Currency, wileyPrefundingDetailsSearchParameters.PrefundingFlag, wileyPrefundingDetailsSearchParameters.Client).Tables[0]);
            //var abc = CommonResource.ToCollection<WileyPrefundingDetails>(DbContext.DbUser.ExecuteDataSet("usp_GetPrefundingDetails", wileyPrefundingDetailsSearchParameters.PrefundingFlag).Tables[0]);
            return abc;
        }

        public List<Invoice> GeInvoicesforAPApproval(string InvoiceSummaryIDs)
        {
            var abc = CommonResource.ToCollection<Invoice>(DbContext.DbUser.ExecuteDataSet("usp_GetInvoices", "", "", "", "", "", "", "", "", "", InvoiceSummaryIDs).Tables[0]);
            for (int i = 0; i < abc.Count; i++)
            {
                abc[i].ProfileWireFee = cryptoService.Decrypt(abc[i].ProfileWireFee) == "" ? "0.00" : cryptoService.Decrypt(abc[i].ProfileWireFee);
            }
            return abc;
        }

        public List<Invoice> GetInvoicesList(string StartDate, string EndDate, string Status, string ContractType, string ProfileCurrency, string ContractCurrency, string Role, string UserEmailID, string DateColumn, int currentPage, int pagesize, string sort, string dir,
            out int totalcount, out List<string> Jobs, out List<string> Freelancers, out List<string> InvoiceNames, out List<string> InvApprovers,

            List<string> JobFilter, List<string> FreelancerFilter, List<string> InvoiceNameFilter, List<string> InvApproverFilter, string InvoiceDateType = "", string flag = "A")
        {

            if (JobFilter == null)
                JobFilter = new List<string>();
            if (FreelancerFilter == null)
                FreelancerFilter = new List<string>();
            if (InvoiceNameFilter == null)
                InvoiceNameFilter = new List<string>();
            if (InvApproverFilter == null)
                InvApproverFilter = new List<string>();


            var abc = new List<Invoice>();
            DataTable djf = CommonResource.ClassToDataTable(JobFilter.Select(a => new { filter = a }).Where(b => !string.IsNullOrEmpty(b.filter)).ToList());
            if (djf.Rows.Count == 1 && Convert.ToString(djf.Rows[0][0]) == "0")
            {
                djf = new DataTable();
            }
            if (djf.Columns.Count == 0)
            {
                djf.Columns.Add("filter");
            }

            DataTable dff = CommonResource.ClassToDataTable(FreelancerFilter.Select(a => new { filter = a }).Where(b => !string.IsNullOrEmpty(b.filter)).ToList());
            if (dff.Rows.Count == 1 && Convert.ToString(dff.Rows[0][0]) == "0")
            {
                dff = new DataTable();
            }
            if (dff.Columns.Count == 0)
            {
                dff.Columns.Add("filter");
            }

            DataTable dinf = CommonResource.ClassToDataTable(InvoiceNameFilter.Select(a => new { filter = a }).Where(b => !string.IsNullOrEmpty(b.filter)).ToList());
            if (dinf.Rows.Count == 1 && Convert.ToString(dinf.Rows[0][0]) == "0")
            {
                dinf = new DataTable();
            }
            if (dinf.Columns.Count == 0)
            {
                dinf.Columns.Add("filter");
            }

            DataTable diaf = CommonResource.ClassToDataTable(InvApproverFilter.Select(a => new { filter = a }).Where(b => !string.IsNullOrEmpty(b.filter)).ToList());
            if (diaf.Rows.Count == 1 && Convert.ToString(diaf.Rows[0][0]) == "0")
            {
                diaf = new DataTable();
            }
            if (diaf.Columns.Count == 0)
            {
                diaf.Columns.Add("filter");
            }

            if (Status == "PAIDINVOICES")
            {
                //abc = CommonResource.ToCollection<Invoice>(DbContext.DbUser.ExecuteDataSet("usp_GetInvoicesPaidThruWallet", StartDate, EndDate, UserEmailID, currentPage, pagesize, sort, dir, flag).Tables[1]);
                SqlConnection con = new SqlConnection(CommonResource.ConString);
                SqlCommand cmd = new SqlCommand();
                DataTable dt = new DataTable();
                cmd.Connection = con;
                cmd.CommandText = "usp_GetInvoicesPaidThruWalletNew";
                cmd.Parameters.AddWithValue("@StartDate", StartDate);
                cmd.Parameters.AddWithValue("@EndDate", EndDate);
                cmd.Parameters.AddWithValue("@UserEmailID", UserEmailID);
                cmd.Parameters.AddWithValue("@currentPage", currentPage);
                cmd.Parameters.AddWithValue("@pagesize", pagesize);
                cmd.Parameters.AddWithValue("@sort", sort == "" ? null : sort);
                cmd.Parameters.AddWithValue("@dir", dir == "" ? null : dir);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 60000;
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                if (con.State == ConnectionState.Closed)
                    con.Open();
                DataSet dtds = new DataSet();
                adp.Fill(dtds);
                con.Close();
                totalcount = Convert.ToInt32(dtds.Tables[0].Rows[0][0]);
                Jobs = dtds.Tables[1].Rows.Cast<DataRow>().Select(a => Convert.ToString(a[0])).ToList();
                Freelancers = (dtds.Tables[2].Rows.Cast<DataRow>().Select(a => Convert.ToString(a[0])).ToList());
                InvoiceNames = (dtds.Tables[3].Rows.Cast<DataRow>().Select(a => Convert.ToString(a[0])).ToList());
                InvApprovers = (dtds.Tables[4].Rows.Cast<DataRow>().Select(a => Convert.ToString(a[0])).ToList());
                return CommonResource.ToCollection<Invoice>(dtds.Tables[5]);
            }
            else
            {
                //abc = CommonResource.ToCollection<Invoice>(DbContext.DbUser.ExecuteDataSet("usp_GetInvoices", StartDate, EndDate, Status, ContractType, ProfileCurrency, ContractCurrency, Role, UserEmailID, InvoiceDateType, "", currentPage, pagesize, sort, dir, flag, djf, dff, dinf, diaf).Tables[1]);
                SqlConnection con = new SqlConnection(CommonResource.ConString);
                SqlCommand cmd = new SqlCommand();
                DataTable dt = new DataTable();
                cmd.Connection = con;
                cmd.CommandText = "usp_GetInvoicesNew";
                cmd.Parameters.AddWithValue("@StartDate", StartDate);
                cmd.Parameters.AddWithValue("@EndDate", EndDate);
                cmd.Parameters.AddWithValue("@Status", Status);
                cmd.Parameters.AddWithValue("@ContractType", ContractType);
                cmd.Parameters.AddWithValue("@ProfileCurrency", ProfileCurrency);
                cmd.Parameters.AddWithValue("@ContractCurrency", ContractCurrency);
                cmd.Parameters.AddWithValue("@Role", Role);
                cmd.Parameters.AddWithValue("@UserEmailID", UserEmailID);
                cmd.Parameters.AddWithValue("@InvoiceDateType", InvoiceDateType);
                cmd.Parameters.AddWithValue("@InvoiceSummaryIDs", "");
                cmd.Parameters.AddWithValue("@currentPage", currentPage);
                cmd.Parameters.AddWithValue("@pagesize", pagesize);
                cmd.Parameters.AddWithValue("@sort", sort);
                cmd.Parameters.AddWithValue("@dir", dir);
                cmd.Parameters.AddWithValue("@flag", flag);
                cmd.Parameters.AddWithValue("@djf", djf);
                cmd.Parameters.AddWithValue("@dff", dff);
                cmd.Parameters.AddWithValue("@dinf", dinf);
                cmd.Parameters.AddWithValue("@diaf", diaf);
                cmd.Parameters.AddWithValue("@DateColumn", DateColumn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 60000;
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                if (con.State == ConnectionState.Closed)
                    con.Open();
                DataSet dtds = new DataSet();
                adp.Fill(dtds);
                con.Close();
                totalcount = Convert.ToInt32(dtds.Tables[0].Rows[0][0]);
                Jobs = dtds.Tables[1].Rows.Cast<DataRow>().Select(a => Convert.ToString(a[0])).ToList();
                Freelancers = (dtds.Tables[2].Rows.Cast<DataRow>().Select(a => Convert.ToString(a[0])).ToList());
                InvoiceNames = (dtds.Tables[3].Rows.Cast<DataRow>().Select(a => Convert.ToString(a[0])).ToList());
                InvApprovers = (dtds.Tables[4].Rows.Cast<DataRow>().Select(a => Convert.ToString(a[0])).ToList());
                return CommonResource.ToCollection<Invoice>(dtds.Tables[5]);
            }
        }

        public List<Invoice> GetInvoicesListNotSendToConnect()
        {
            var abc = CommonResource.ToCollection<Invoice>(DbContext.DbUser.ExecuteDataSet("GetInvoicesListNotSendToConnect").Tables[0]);
            return abc;
        }

        public List<Invoice> CheckFinalInvoiceRaisedorNot(int JobID, string FreelancerEmailID)
        {
            return CommonResource.ToCollection<Invoice>(DbContext.DbUser.ExecuteDataSet("CheckFinalInvoiceRaisedorNot", Convert.ToString("" + JobID), FreelancerEmailID).Tables[0]);
        }

        public List<InvoiceDetails> GetInvoiceDetails(int InvoiceSummaryID)
        {

            List<InvoiceDetails> invoiceDetailsList = CommonResource.ToCollection<InvoiceDetails>(DbContext.DbUser.ExecuteDataSet("usp_GetInvoiceDetails", InvoiceSummaryID).Tables[0]);
            for (int i = 0; i < invoiceDetailsList.Count; i++)
            {
                if (!string.IsNullOrEmpty(invoiceDetailsList[0].AccountNumber))
                {
                    invoiceDetailsList[i].AccountNumber = cryptoService.Decrypt(invoiceDetailsList[i].AccountNumber);
                    invoiceDetailsList[i].AccountNumber = MaskAllButLast(invoiceDetailsList[i].AccountNumber, 4);
                }
            }
            //cmt
            return invoiceDetailsList;
        }
        public string MaskAllButLast(string input, int charsToDisplay, char maskingChar = 'X')
        {
            int charsToMask = input.Length - charsToDisplay;
            return charsToMask > 0 ? $"{new string(maskingChar, charsToMask)}{input.Substring(charsToMask)}" : input;
        }

        public int UpdatePrefundingBalance(WileyPrefundingDetails wileyPrefundingDetails)
        {
            int cnt = DbContext.DbUser.ExecuteNonQuery("usp_GetClientBalancePerCurrency", wileyPrefundingDetails.StartDate, Convert.ToDateTime(wileyPrefundingDetails.PrefundingDate).ToString("yyyy-MM-dd"), wileyPrefundingDetails.PrefundingClient, wileyPrefundingDetails.PrefundingCurrency, "");
            return cnt;
        }

        public int SaveWileyPrefunding(WileyPrefundingDetails wileyPrefundingDetails)
        {
            int cnt = DbContext.DbUser.ExecuteNonQuery("usp_InsertUpdateWileyPrefundingAmount", wileyPrefundingDetails.PrefundingAmount, Convert.ToDateTime(wileyPrefundingDetails.PrefundingDate), wileyPrefundingDetails.PrefundingCurrency, wileyPrefundingDetails.PrefundingClient, wileyPrefundingDetails.EnteredBy);
            return cnt;
        }

        public int SaveInvoiceDetails(InvoiceSave saveInvoice)
        {
            string ApprovalLevel = "Inv2";
            if (Convert.ToString("" + saveInvoice.InvApproverEmail).Trim().ToUpper() == Convert.ToString("" + saveInvoice.UserEmailID).Trim().ToUpper())
                ApprovalLevel = "Inv1";

            int cnt = DbContext.DbUser.ExecuteNonQuery("usp_SaveInvoiceStatus", saveInvoice.InvoiceSummaryID, saveInvoice.RejectionComments, saveInvoice.UsersId, saveInvoice.UserRole, saveInvoice.Status, ApprovalLevel, saveInvoice.PaymentTypeId, saveInvoice.ContractCurrency, saveInvoice.WireFee);
            return cnt;
        }

        public int UpdateInvoiceDetails(InvoiceDetailsSave invoiceDetailsSave)
        {
            int cnt = DbContext.DbUser.ExecuteNonQuery("usp_UpdateInvoiceType", invoiceDetailsSave.InvoiceDetailsID, invoiceDetailsSave.OldInvoiceType, invoiceDetailsSave.NewInvoiceType, invoiceDetailsSave.UsersId);
            return cnt;
        }

        public int CreateInvoice(List<FreelancerDashboardSummary> invoiceModels, int UsersId)
        {
            CryptoService cryptoService = new CryptoService();
            string Query = "";

            decimal totalAmount = 0;
            string exchangeRate = "";
            string ConversionCurrency = "";
            string BankingCharges = "0.00";
            string BankingChargesInUSD = "0.00";
            for (int i = 0; i < invoiceModels.Count; i++)
            {

                //if (i == 0 && invoiceModels[i].JobNo.StartsWith("CLJ-"))
                if (i == 0)
                {
                    var abc = CommonResource.ToCollection<BankInfo>(DbContext.DbUser.ExecuteDataSet("usp_GetFreelancerBankInfo", UsersId, invoiceModels[0].FLBankInfoId).Tables[0]);
                    if (abc[0].WireFeeReq == 1)
                    {
                        //if (abc[0].Currency == "CAD" && invoiceModels[i].Contracted_Currency == "CAD")
                        //    BankingCharges = "0.00";
                        //else
                        //{
                        BankingCharges = cryptoService.Decrypt(abc[0].WireFee);

                        DataTable dataWire = DbContext.DbUser.ExecuteDataSet("usp_Calculate_WileyExchange", invoiceModels[i].JobID, 0, cryptoService.Decrypt(abc[0].WireFee), invoiceModels[i].Contracted_Currency).Tables[0];

                        BankingChargesInUSD = Convert.ToString("" + dataWire.Rows[0][0]);
                        //}

                        if (BankingChargesInUSD == "0000" || BankingChargesInUSD == "")
                            BankingChargesInUSD = CommonResource.CurrencyConversion(Convert.ToDecimal(cryptoService.Decrypt(abc[0].WireFee)), invoiceModels[i].Contracted_Currency, "USD", out exchangeRate);
                    }
                }

                totalAmount += Convert.ToDecimal(Convert.ToDecimal(invoiceModels[i].RaisedUnit) * Convert.ToDecimal(invoiceModels[i].RatePerUnit));
                invoiceModels[i].RatePerUnit = Convert.ToDecimal(invoiceModels[i].RatePerUnit);
                invoiceModels[i].SubTotal = Convert.ToDecimal(Convert.ToDecimal(invoiceModels[i].RaisedUnit) * Convert.ToDecimal(invoiceModels[i].RatePerUnit)).ToString("0.00");

                //invoiceModels[i].AmountInUSD = DbContext.DbUser.ExecuteScalar("usp_Calculate_WileyExchange", invoiceModels[i].JobID, 0, invoiceModels[i].SubTotal, invoiceModels[i].Contracted_Currency).ToString();
                DataTable dataTable = DbContext.DbUser.ExecuteDataSet("usp_Calculate_WileyExchange", invoiceModels[i].JobID, 0, invoiceModels[i].SubTotal, invoiceModels[i].Contracted_Currency).Tables[0];
                invoiceModels[i].AmountInUSD = Convert.ToString("" + dataTable.Rows[0][0]);
                invoiceModels[i].ConversionRateinUSD = exchangeRate = Convert.ToString("" + dataTable.Rows[0][1]);
                invoiceModels[i].ConversionCurrency = Convert.ToString("" + dataTable.Rows[0][2]);

                if (invoiceModels[i].AmountInUSD == "0000" || invoiceModels[i].AmountInUSD == "")
                {
                    invoiceModels[i].AmountInUSD = CommonResource.CurrencyConversion(Convert.ToDecimal(invoiceModels[i].SubTotal), invoiceModels[i].Contracted_Currency, "USD", out exchangeRate);
                    invoiceModels[i].ConversionRateinUSD = exchangeRate;
                }
            }

            Query = GenerateInvoiceDetails(invoiceModels);
            object cnt = DbContext.DbUser.ExecuteScalar("usp_CreateInvoice", UsersId, invoiceModels.Count, "APPLIED", Convert.ToDecimal(totalAmount).ToString("0.00"), Convert.ToDecimal(BankingCharges).ToString("0.00"), Convert.ToDecimal(BankingChargesInUSD).ToString("0.00"), invoiceModels[0].JobNo, Convert.ToString(invoiceModels[0].FLBankInfoId), Query);

            InvoiceNotification(Convert.ToInt32(cnt));
            return Convert.ToInt32(cnt);
        }

        public string GenerateInvoiceDetails(List<FreelancerDashboardSummary> invoiceModels)
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("INSERT INTO InvoiceDetails ([InvoiceSummaryId], [JobId], [NoOfUnit], [SumAmount], [RatePerUnit], [Invoicetype], [InvoiceComments], [AmountinUSD], [ConversionCurrencyRate], [ConversionCurrency]) Values ");
                for (int i = 0; i < invoiceModels.Count; i++)
                {
                    sb.AppendFormat("(-99, '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}') ,",
                        invoiceModels[i].JobID,
                        invoiceModels[i].RaisedUnit,
                        invoiceModels[i].SubTotal,
                        invoiceModels[i].RatePerUnit,
                        invoiceModels[i].InvoiceType,
                        ChangeSingleQouteToDoubleQoute(invoiceModels[i].FreelancerInvoiceComments),
                        invoiceModels[i].AmountInUSD,
                        invoiceModels[i].ConversionRateinUSD,
                        invoiceModels[i].ConversionCurrency.Trim() == "" ? "USD" : invoiceModels[i].ConversionCurrency
                        );
                }


                return sb.ToString().TrimEnd(',');
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public string ChangeSingleQouteToDoubleQoute(string data)
        {
            if (!String.IsNullOrEmpty(data))
            {
                return data.Replace("'", "''");
            }
            return data;

        }
        //public static void InvoiceNotification(string FreelancerEmailId, string FreelancerName, string PMEmailID, string AssignmentType, string JobNo, string Invoiceno, string PMname, string CompletionDate, string InvApproverEmail, string InvApproverName, string Author, string Title, string Task, string TotalAmount, string TotalUnits, string InvoiceComments)
        public void InvoiceNotification(int InvoiceSummaryID)
        {
            var inv = GetInvoiceDetails(InvoiceSummaryID);
            string MailSubject = "ESPro: Invoice notification for job: " + inv[0].JobNo;
            StringBuilder sbMailBody = new StringBuilder(File.ReadAllText(Path.Combine(CommonResource.MailTemplatePath, "InvoiceNotification.html")));

            if (inv[0].InvApproverName == "")
                sbMailBody.Replace("{InvApproverName}", Convert.ToString("" + inv[0].PM_Name));
            else
                sbMailBody.Replace("{InvApproverName}", Convert.ToString("" + inv[0].InvApproverName));

            sbMailBody.Replace("{Freelancer}", Convert.ToString("" + inv[0].FreelancerName));
            sbMailBody.Replace("{LuminaJobNumber}", Convert.ToString("" + inv[0].JobNo));
            sbMailBody.Replace("{Author}", Convert.ToString("" + inv[0].Author));
            sbMailBody.Replace("{Title}", Convert.ToString("" + inv[0].Title));
            sbMailBody.Replace("{Task}", Convert.ToString("" + inv[0].Task));
            sbMailBody.Replace("{InvoiceNumber}", Convert.ToString("" + inv[0].Name));
            sbMailBody.Replace("{InvoicValue}", Convert.ToString("" + inv[0].TotalAmount));
            sbMailBody.Replace("{Units}", Convert.ToString("" + inv[0].TotalUnitsApplied));
            sbMailBody.Replace("{Comments}", Convert.ToString("" + inv[0].InvoiceComments));
            sbMailBody.Replace("{SubmissionDate}", Convert.ToDateTime(inv[0].InvoiceDate).ToString("dd-MMM-yyyy"));
            sbMailBody.Replace("{Regards}", CommonResource.MailRegards);

            var SendMailTo = GetSendMailDetails("APPRaiseInvoice").ToList();

            string ToMail = inv[0].InvApproverEmail + "; " + SendMailTo[0].ToMailList;
            string CCMail = inv[0].JobPM + "; " + inv[0].FreelancerEmailID + "; " + SendMailTo[0].CCMailList;
            string BCCMail = SendMailTo[0].BCCMailList;
            MailService objMail = new MailService();
            objMail.SendMail(sbMailBody.ToString(), MailSubject, ToMail, CCMail, BCCMail);
            // new MailSending().SendEmailAsyn(ProjectResources.strDefaultMailFromName, InvApproverEmail, PMEmailID + "; " + MySessionData.User_Id, MailSubject, sbMailBody.ToString(), 0, 0);
        }

        public bool PushDataToIConnect(InvoiceSave invoiceSave, out string ErrorMsg, out string FullError, out string JsonData)
        {
            //var invoiceModelData = GetInvoiceDetails(invoiceSave.InvoiceSummaryID);
            //var json = new JavaScriptSerializer().Serialize(invoiceModelData);
            var invoiceModelData = GetInvoicebyId(invoiceSave.InvoiceSummaryID);
            var json = Newtonsoft.Json.JsonConvert.SerializeObject(invoiceModelData);
            JsonData = json;
            List<KeyValuePair<string, string>> keyValuePair = new List<KeyValuePair<string, string>>();
            keyValuePair.Add(new KeyValuePair<string, string>("Token", Convert.ToString(_Configuration["InvToken"])));
            keyValuePair.Add(new KeyValuePair<string, string>("Json", json));
            bool result = CommonResource.InvoicePostRequestAsync<InvoiceModelData>("Invoicedetails", keyValuePair, out ErrorMsg, out FullError);
            return result;
        }

        public static InvoiceModelData GetInvoicebyId(int invoicesummaryId)
        {
            InvoiceModelData invoiceModelData = new InvoiceModelData();
            DataSet ds = DbContext.DbUser.ExecuteDataSet("IconnectAPI_GetInvoiceDetailsbyId", invoicesummaryId);
            if (ds != null && ds.Tables.Count > 0)
            {
                invoiceModelData = CommonResource.ToCollection<InvoiceModelData>(ds.Tables[0]).FirstOrDefault();
                invoiceModelData.invoiceDetails = CommonResource.ToCollection<FreelancerInvoiceCost>(ds.Tables[1]).ToList();
            }
            return invoiceModelData;
        }

        public int InsertInvoiceLog(int InvoiceId, string ApiType, bool Status, string Error = "", string JsonData = "")
        {
            List<object> parameters = new List<object>() { InvoiceId, ApiType, Status, Error, JsonData };
            return DbContext.DbUser.ExecuteNonQuery("usp_InsertInvoiceLog", parameters.ToArray());
        }

        public int AddInvoiceLog(string methodName, string processPoint, string freelanceEmailId, bool isInvoiceGenerated, string invoiceName = "")
        {
            return DbContext.DbUser.ExecuteNonQuery("Save_ErrorLogInvoice", new List<object>() { methodName, processPoint, freelanceEmailId, isInvoiceGenerated, invoiceName }.ToArray());
            //return 0;
        }

        public int SaveWireFeeDetails(WireFeeSave wireFeeSave)
        {
            int count = DbContext.DbUser.ExecuteNonQuery("usp_UpdateWireFee", wireFeeSave.UserID, wireFeeSave.UserEmailID, wireFeeSave.WireFee);
            return count;
        }

        public List<DateFilterTypes> GetFilterDateType(string status)
        {
            var abc = CommonResource.ToCollection<DateFilterTypes>(DbContext.DbUser.ExecuteDataSet("GetFilterDateType", status).Tables[0]);
            return abc;
        }

        public SaveInvoiceResult SaveInvoiceDetails(InvoiceSave[] saveInvoice, string RequestUrl)
        {

            SaveInvoiceResult CommonResult = new SaveInvoiceResult();

            List<SendMailTo> SendMailToMain = new List<SendMailTo>();
            StringBuilder sbMailBodyMain = new StringBuilder();
            if (saveInvoice[0].UserRole == "FINANCEMANAGER" && saveInvoice[0].Status == "APPROVEDBYAP")
            {
                SendMailToMain = GetSendMailDetails("APPApprovedByAP").ToList();
                string TemplateName = "FinanceManagerApproveInvoiceTemplate.html";
                sbMailBodyMain = new StringBuilder(System.IO.File.ReadAllText(Path.Combine(CommonResource.MailTemplatePath, TemplateName)));
            }

            var results = saveInvoice.AsParallel().Select(filename => SaveInvDeails(filename, RequestUrl, SendMailToMain, sbMailBodyMain.ToString())).ToArray();

            if (results.Where(a => a.Status == "Success").Count() > 0 && results.Where(a => a.Status == "fail").Count() == 0)
            {
                CommonResult.Status = "Success";
                CommonResult.ErrorMessage = "";
            }
            else if (results.Where(a => a.Status == "fail").Count() > 0)
            {
                CommonResult.Status = "fail";
                CommonResult.ErrorMessage = results.Where(a => a.Status == "fail").FirstOrDefault().ErrorMessage;
            }
            else
            {
                CommonResult.Status = "fail";
                CommonResult.ErrorMessage = "";
            }
            return CommonResult;
        }
        public SaveInvoiceResult SaveInvDeails(InvoiceSave saveInvoice, string RequestUrl, List<SendMailTo> SendMailToMain, string sbMailBodyMain)
        {
            HSBC.HSBCService _hSBC = new HSBC.HSBCService();
            SaveInvoiceResult CommonResult = new SaveInvoiceResult();
            if (saveInvoice.IsRePayment == true)
            {
                AddInvoiceLog("", "Repayment Start Invoice : " + saveInvoice.InvoiceSummaryID + " and Status: " + saveInvoice.Status, saveInvoice.FreelancerEmailID, false, "");
                InvoiceInfo invoiceInfo = new InvoiceInfo();
                invoiceInfo.BankAccountId = saveInvoice.BankAccountId;
                invoiceInfo.PaymentTypeId = saveInvoice.PaymentTypeId;
                invoiceInfo.UsersId = saveInvoice.FreelancerID;
                invoiceInfo.InvoiceSummaryId = saveInvoice.InvoiceSummaryID;
                invoiceInfo.InvoiceName = saveInvoice.InvoiceName;
                invoiceInfo.InvoiceDate = Convert.ToDateTime(saveInvoice.InvoiceDate);
                invoiceInfo.ApproveDate = DateTime.Now;
                invoiceInfo.PaymentDate = Convert.ToDateTime(saveInvoice.PaymentDate);
                invoiceInfo.ProfileCurrency = saveInvoice.ProfileCurrency;
                invoiceInfo.ContractCurrency = saveInvoice.ContractCurrency;
                //invoiceInfo.TotalAmount = float.Parse(saveInvoice.TotalAmount, CultureInfo.InvariantCulture.NumberFormat);
                invoiceInfo.TotalAmount = Convert.ToDecimal(saveInvoice.TotalAmount).ToString("0.00");
                invoiceInfo.WireFee = Convert.ToDecimal(saveInvoice.WireFee).ToString("0.00");
                invoiceInfo.ProjectCode = "ESPRO";
                invoiceInfo.IsRePayment = saveInvoice.IsRePayment;
                invoiceInfo.TransactionDetailsId = saveInvoice.TransactionDetailsId;
                invoiceInfo.Status = "YTS";
                invoiceInfo.DeActiveComment = "";
                invoiceInfo.IsActive = 1;
                Boolean flag = _hSBC.InsertInvoiceInfo(invoiceInfo);
                if (flag)
                {
                    saveInvoice.Status = "Repayment";
                    SaveInvoiceDetails(saveInvoice);

                    AddInvoiceLog("", "Repayment End Successfully Invoice : " + saveInvoice.InvoiceSummaryID + " and Status: " + saveInvoice.Status, saveInvoice.FreelancerEmailID, false, "");
                    CommonResult.Status = "Success";
                }
                else
                {
                    AddInvoiceLog("", "Repayment End with error Invoice : " + saveInvoice.InvoiceSummaryID + " and Status: " + saveInvoice.Status, saveInvoice.FreelancerEmailID, false, "");
                    CommonResult.Status = "Error";
                    CommonResult.ErrorMessage = "Update transaction for banking failed, please try again.";
                }

            }
            else
            {
                AddInvoiceLog("", "Invoice : " + saveInvoice.InvoiceSummaryID + " and Status: " + saveInvoice.Status, saveInvoice.FreelancerEmailID, false, "");
                string Error;
                bool ratingStatus = false;
                if (saveInvoice.Status == "APPROVED")
                {
                    //if (Convert.ToString("" + saveInvoice.CustomerName).ToUpper().Trim() == "MACMILLAN LEARNING" && Convert.ToString("" + saveInvoice.JobCategory).ToUpper().Trim() == "COPES")
                    //    ratingStatus = true;
                    //else
                    //{
                    var ratingDetails = InvoiceRatedbyPM(saveInvoice.JobNo, saveInvoice.FreelancerEmailID, saveInvoice.InvoiceSummaryID).ToList();
                    if (Convert.ToString("" + ratingDetails[0].RatingStatus) == "TRUE")
                        ratingStatus = true;
                    else
                    {
                        ratingStatus = false;
                        saveInvoice.JobID = Convert.ToInt32("" + ratingDetails[0].JobID);
                    }
                    //}
                }
                else
                    ratingStatus = true;

                Error = String.Empty;
                string FullError = string.Empty;
                bool resultStatus = true;
                if (ratingStatus)
                {
                    if (!saveInvoice.JobNo.StartsWith("CLJ", StringComparison.OrdinalIgnoreCase) && saveInvoice.Status == "APPROVED" && (RequestUrl.Contains("www.expertsourcepro.com")))
                    {
                        if (Convert.ToString("" + saveInvoice.InvApproverEmail2) == "" || saveInvoice.InvApproverEmail2 == saveInvoice.UserEmailID)
                        {
                            AddInvoiceLog("", "Invoice : " + saveInvoice.InvoiceSummaryID + " and Status: " + saveInvoice.Status + " for iConnect Integration Start(Job No.: " + saveInvoice.JobNo + ")", saveInvoice.FreelancerEmailID, false, "");
                            string jsonData = String.Empty;
                            bool result = PushDataToIConnect(saveInvoice, out Error, out FullError, out jsonData);

                            string Err = "";
                            if (!string.IsNullOrEmpty(FullError))
                            {
                                Err = FullError + " : " + Error;
                            }
                            else
                            {
                                Err = Error;
                            }
                            if (!result)
                            {

                                AddInvoiceLog("", "Invoice : " + saveInvoice.InvoiceSummaryID + " and Status: " + saveInvoice.Status + " for iConnect Integration Error(" + Err + ")", saveInvoice.FreelancerEmailID, false, "");

                                InsertInvoiceLog(saveInvoice.InvoiceSummaryID, "iConnect", false, Err, jsonData);

                                CommonResult.Status = "fail";
                                CommonResult.ErrorMessage = "Error: Something went wrong. Please try again. Description: Error from I-connect API: " + Err;
                                resultStatus = false;
                            }
                            else
                                InsertInvoiceLog(saveInvoice.InvoiceSummaryID, "iConnect", true, Err, jsonData);
                        }
                    }

                    //if (resultStatus || saveInvoice.Status != "APPROVED")
                    if (resultStatus)
                    {
                        //AddInvoiceLog("", "Invoice : " + saveInvoice.InvoiceSummaryID + " and Status: " + saveInvoice.Status + " for saving info start", saveInvoice.FreelancerEmailID, false, "");
                        if (SaveInvoiceDetails(saveInvoice) > 0)
                        {
                            AddInvoiceLog("", "Invoice : " + saveInvoice.InvoiceSummaryID + " and Status: " + saveInvoice.Status + " for saving info success", saveInvoice.FreelancerEmailID, true, "");
                            var inv = GetInvoiceDetails(saveInvoice.InvoiceSummaryID);
                            StringBuilder sbMailBody = null;
                            string TemplateName = String.Empty;
                            string MailSubject = "";
                            string ToMail = "";
                            string CCMail = "";
                            string BCCMail = "";
                            //AddInvoiceLog("", "Invoice : " + saveInvoice.InvoiceSummaryID + " and Status: " + saveInvoice.Status + " for mail send start", saveInvoice.FreelancerEmailID, false, "");
                            if (saveInvoice.UserRole == "FREELANCER")
                            {
                                var SendMailTo = GetSendMailDetails("APPCancelInvoice").ToList();
                                TemplateName = "InvoiceFreelancerCancelNotification.html";
                                MailSubject = "ESPro: Freelancer Cancel Invoice: " + inv[0].Name;
                                ToMail = inv[0].InvApproverEmail + "; " + SendMailTo[0].ToMailList;
                                CCMail = inv[0].JobPM + "; " + inv[0].FreelancerEmailID + "; " + SendMailTo[0].CCMailList;
                                BCCMail = SendMailTo[0].BCCMailList;
                                sbMailBody = new StringBuilder(System.IO.File.ReadAllText(Path.Combine(CommonResource.MailTemplatePath, TemplateName)));

                                sbMailBody.Replace("[InvApproverName]", inv[0].InvApproverName);
                                sbMailBody.Replace("[FreelancerName]", inv[0].FreelancerName);
                                sbMailBody.Replace("[InvoiceNo]", inv[0].Name);
                                sbMailBody.Replace("[Jobno]", inv[0].JobNo);
                                sbMailBody.Replace("[title]", inv[0].Title);
                                sbMailBody.Replace("[author]", inv[0].Author);
                                sbMailBody.Replace("[TotalAmount]", inv[0].TotalAmount);
                                sbMailBody.Replace("[InvoiceDate]", inv[0].InvoiceDate);
                                sbMailBody.Replace("[Remark]", saveInvoice.RejectionComments);
                            }
                            else if (saveInvoice.UserRole == "FINANCEMANAGER" && saveInvoice.Status == "APPROVEDBYAP")
                            {
                                var SendMailTo = SendMailToMain;// GetSendMailDetails("APPApprovedByAP").ToList();
                                //TemplateName = "FinanceManagerApproveInvoiceTemplate.html";
                                MailSubject = "ESPro: Finance Manager Approved: " + inv[0].Name + "";
                                ToMail = inv[0].FreelancerEmailID + "; " + SendMailTo[0].ToMailList;
                                CCMail = inv[0].JobPM + "; " + inv[0].InvApproverEmail + "; " + SendMailTo[0].CCMailList;
                                BCCMail = SendMailTo[0].BCCMailList;
                                //sbMailBody = new StringBuilder(System.IO.File.ReadAllText(Path.Combine(CommonResource.MailTemplatePath, TemplateName)));
                                sbMailBody = new StringBuilder(sbMailBodyMain);
                                sbMailBody.Replace("[ApproverName]", saveInvoice.UserName);
                                sbMailBody.Replace("[HelloName]", inv[0].FreelancerName);
                                sbMailBody.Replace("[Jobno]", inv[0].JobNo);
                                sbMailBody.Replace("[InvoiceNo]", inv[0].Name);
                                sbMailBody.Replace("[title]", inv[0].Title);
                                sbMailBody.Replace("[author]", inv[0].Author);
                                sbMailBody.Replace("[task]", inv[0].Task);
                                sbMailBody.Replace("[PMName]", inv[0].PM_Name);
                                sbMailBody.Replace("[InvoiceDate]", inv[0].InvoiceDate);
                                sbMailBody.Replace("[InvApproverName]", inv[0].InvApproverName);
                                sbMailBody.Replace("[Approveddate]", inv[0].ApprovedDate);
                                sbMailBody.Replace("[TotalAmount]", inv[0].TotalAmount);
                                sbMailBody.Replace("[APApproveddate]", inv[0].APActionDate);
                            }
                            else if (saveInvoice.UserRole == "FINANCEMANAGER" && saveInvoice.Status == "REJECTEDBYAP")
                            {
                                var SendMailTo = GetSendMailDetails("APPRejectedByAP").ToList();
                                TemplateName = "APRejectionInvoiceTemplate.html";
                                MailSubject = "ESPro: Finance Manager Rejected: " + inv[0].Name + "";
                                ToMail = inv[0].FreelancerEmailID + "; " + SendMailTo[0].ToMailList;
                                CCMail = inv[0].JobPM + "; " + inv[0].InvApproverEmail + "; " + saveInvoice.UserEmailID + "; " + SendMailTo[0].CCMailList;
                                BCCMail = SendMailTo[0].BCCMailList;
                                sbMailBody = new StringBuilder(System.IO.File.ReadAllText(Path.Combine(CommonResource.MailTemplatePath, TemplateName)));
                                sbMailBody.Replace("[HelloName]", inv[0].FreelancerName);
                                sbMailBody.Replace("[InvoiceNo]", inv[0].Name);
                                sbMailBody.Replace("[TotalAmount]", inv[0].TotalAmount);
                                sbMailBody.Replace("[InvoiceDate]", inv[0].InvoiceDate);
                                sbMailBody.Replace("[RejectionComment]", saveInvoice.RejectionComments);
                            }
                            else if (saveInvoice.Status == "APPROVED")
                            {
                                var SendMailTo = GetSendMailDetails("APPApprovedByPM").ToList();
                                if ((saveInvoice.InvApproverEmail2 == "" || saveInvoice.InvApproverEmail2 is null) || saveInvoice.InvApproverEmail2 == saveInvoice.UserEmailID)
                                {
                                    TemplateName = "ApproveInvoiceTemplate.html";
                                    MailSubject = "ESPro: Approved by PM: " + inv[0].Name + "";
                                    ToMail = inv[0].FreelancerEmailID;

                                    CCMail = inv[0].JobPM + "; " + inv[0].InvApproverEmail + "; " + saveInvoice.UserEmailID + "; " + SendMailTo[0].CCMailList + "; " + inv[0].InvApproverEmail2;
                                    BCCMail = SendMailTo[0].BCCMailList;

                                    sbMailBody = new StringBuilder(System.IO.File.ReadAllText(Path.Combine(CommonResource.MailTemplatePath, TemplateName)));
                                }
                                else
                                {
                                    TemplateName = "InvoiceNotificationToInv2.html";
                                    MailSubject = "ESPro: Approved by Invoice Approver: " + inv[0].Name + "";
                                    ToMail = inv[0].InvApproverEmail2;

                                    CCMail = inv[0].JobPM + "; " + inv[0].InvApproverEmail + "; " + saveInvoice.UserEmailID + "; " + SendMailTo[0].CCMailList + "; " + inv[0].InvApproverEmail2;
                                    BCCMail = SendMailTo[0].BCCMailList;

                                    sbMailBody = new StringBuilder(System.IO.File.ReadAllText(Path.Combine(CommonResource.MailTemplatePath, TemplateName)));
                                    sbMailBody.Replace("[InvApproverName2]", inv[0].InvApproverName2);
                                    sbMailBody.Replace("[ProjectManager]", inv[0].InvApproverName);
                                }

                                sbMailBody.Replace("[FreelancerName]", inv[0].FreelancerName);
                                sbMailBody.Replace("[Jobno]", inv[0].JobNo);
                                sbMailBody.Replace("[InvoiceNo]", inv[0].Name);
                                sbMailBody.Replace("[title]", inv[0].Title);
                                sbMailBody.Replace("[author]", inv[0].Author);
                                sbMailBody.Replace("[task]", inv[0].Task);
                                sbMailBody.Replace("[PMName]", inv[0].PM_Name);
                                sbMailBody.Replace("[InvoiceDate]", inv[0].InvoiceDate);
                                //sbMailBody.Replace("[InvApproverName]", inv[0].InvApproverName);
                                sbMailBody.Replace("[InvApproverName]", saveInvoice.UserName);
                                sbMailBody.Replace("[Approveddate]", inv[0].ApprovedDate);
                                sbMailBody.Replace("[TotalAmount]", inv[0].TotalAmount);
                            }
                            else if (saveInvoice.Status == "REJECTED")
                            {
                                var SendMailTo = GetSendMailDetails("APPRejectedByPM").ToList();
                                TemplateName = "RejectionInvoiceTemplate.html";
                                MailSubject = "ESPro: Rejected by PM: " + inv[0].Name + "";
                                ToMail = inv[0].FreelancerEmailID + "; " + SendMailTo[0].ToMailList;
                                CCMail = inv[0].JobPM + "; " + inv[0].InvApproverEmail + "; " + saveInvoice.UserEmailID + "; " + SendMailTo[0].CCMailList;
                                BCCMail = SendMailTo[0].BCCMailList;
                                sbMailBody = new StringBuilder(System.IO.File.ReadAllText(Path.Combine(CommonResource.MailTemplatePath, TemplateName)));
                                sbMailBody.Replace("[HelloName]", inv[0].FreelancerName);
                                sbMailBody.Replace("[InvoiceNo]", inv[0].Name);
                                sbMailBody.Replace("[TotalAmount]", inv[0].TotalAmount);
                                sbMailBody.Replace("[InvoiceDate]", inv[0].InvoiceDate);
                                //sbMailBody.Replace("[InvApproverName]", inv[0].InvApproverName);
                                sbMailBody.Replace("[InvApproverName]", saveInvoice.UserName);
                                sbMailBody.Replace("[RejectionComment]", saveInvoice.RejectionComments);
                            }

                            sbMailBody.Replace("[Regards]", CommonResource.MailRegards);

                            int mailsendflag = 0;
                            if (saveInvoice.Status == "APPROVEDBYAP")
                            {
                                CommonResult.Status = "Approved By AP and Mail sent to user";

                                InvoiceInfo invoiceInfo = new InvoiceInfo();
                                invoiceInfo.BankAccountId = saveInvoice.BankAccountId;
                                invoiceInfo.PaymentTypeId = saveInvoice.PaymentTypeId;
                                invoiceInfo.UsersId = saveInvoice.FreelancerID;
                                invoiceInfo.InvoiceSummaryId = saveInvoice.InvoiceSummaryID;
                                invoiceInfo.InvoiceName = saveInvoice.InvoiceName;
                                invoiceInfo.InvoiceDate = Convert.ToDateTime(saveInvoice.InvoiceDate);
                                invoiceInfo.ApproveDate = DateTime.Now;
                                invoiceInfo.PaymentDate = Convert.ToDateTime(saveInvoice.PaymentDate);
                                invoiceInfo.ProfileCurrency = saveInvoice.ProfileCurrency;
                                invoiceInfo.ContractCurrency = saveInvoice.ContractCurrency;
                                //invoiceInfo.TotalAmount = float.Parse(saveInvoice.TotalAmount, CultureInfo.InvariantCulture.NumberFormat);
                                invoiceInfo.TotalAmount = Convert.ToDecimal(saveInvoice.TotalAmount).ToString("0.00");
                                invoiceInfo.WireFee = Convert.ToDecimal(saveInvoice.WireFee).ToString("0.00");
                                invoiceInfo.ProjectCode = "ESPRO";
                                invoiceInfo.IsRePayment = saveInvoice.IsRePayment;
                                invoiceInfo.TransactionDetailsId = saveInvoice.TransactionDetailsId;
                                //if (inv[0].LocationId == 4)
                                //{
                                //    invoiceInfo.Status = "MANUAL";
                                //    invoiceInfo.DeActiveComment = "Due to wire fee issue for Canada Freelancer, we sent manual payment";
                                //    invoiceInfo.IsActive = 0;
                                //}
                                //else
                                //{
                                if (!string.IsNullOrEmpty(saveInvoice.HSBC_Status))
                                {
                                    invoiceInfo.Status = "MANUAL";
                                    invoiceInfo.DeActiveComment = saveInvoice.RejectionComments;
                                    invoiceInfo.IsActive = 0;
                                }
                                else
                                {
                                    invoiceInfo.Status = "YTS";
                                    invoiceInfo.DeActiveComment = "";
                                    invoiceInfo.IsActive = 1;
                                }


                                //}

                                AddInvoiceLog("", "Invoice : " + saveInvoice.InvoiceSummaryID + " and Status: " + saveInvoice.Status + " for hsbc sync start", saveInvoice.FreelancerEmailID, false, "");
                                Boolean flag = _hSBC.InsertInvoiceInfo(invoiceInfo);
                                if (flag)
                                {
                                    mailsendflag = 1;
                                    CommonResult.Status = "Success";
                                    AddInvoiceLog("", "Invoice : " + saveInvoice.InvoiceSummaryID + " and Status: " + saveInvoice.Status + " for hsbc sync success", saveInvoice.FreelancerEmailID, false, "");
                                }
                                else
                                {
                                    List<BankTransactionHistory> lstBankTransactionHistory = new List<BankTransactionHistory>();
                                    lstBankTransactionHistory = _hSBC.GetInvoiceDetails("ESPRO", saveInvoice.InvoiceSummaryID);
                                    if (lstBankTransactionHistory.Count == 0)
                                    {
                                        saveInvoice.Status = "APPROVED";
                                        SaveInvoiceDetails(saveInvoice);
                                        CommonResult.Status = "Error";
                                        CommonResult.ErrorMessage = "Update transaction for banking failed, please try again.";
                                        AddInvoiceLog("", "Invoice : " + saveInvoice.InvoiceSummaryID + " and Status: " + saveInvoice.Status + " for Update Transaction for banking failed.", saveInvoice.FreelancerEmailID, true, "");
                                    }
                                    //CommonResult.Status = "fail";
                                    //AddInvoiceLog("", "Invoice : " + saveInvoice.InvoiceSummaryID + " and Status: " + saveInvoice.Status + " for hsbc sync fail", saveInvoice.FreelancerEmailID, false, "");
                                }
                            }
                            else
                            {
                                mailsendflag = 1;
                                CommonResult.Status = "Success";
                                CommonResult.ErrorMessage = "";
                                //AddInvoiceLog("", "Invoice : " + saveInvoice.InvoiceSummaryID + " and Status: " + saveInvoice.Status + " for mail send end", saveInvoice.FreelancerEmailID, true, "");
                            }

                            if (mailsendflag == 1)
                            {
                                if (CommonResource.ToCollection<MailDetails>(DbContext.DbUser.ExecuteDataSet("CheckMailAlreadySent", MailSubject).Tables[0]).ToList().Count() == 0)
                                {
                                    MailService objMail = new MailService();
                                    objMail.SendMail(sbMailBody.ToString(), MailSubject, ToMail, CCMail, BCCMail);
                                    AddInvoiceLog("", "Invoice : " + saveInvoice.InvoiceSummaryID + " and Status: " + saveInvoice.Status + " for mail send end", saveInvoice.FreelancerEmailID, false, "");
                                }
                            }
                        }
                        else
                        {
                            AddInvoiceLog("", "Invoice : " + saveInvoice.InvoiceSummaryID + " and Status: " + saveInvoice.Status + " for saving info fail", saveInvoice.FreelancerEmailID, false, "");
                            CommonResult.Status = "fail";
                            CommonResult.ErrorMessage = "";
                        }
                    }
                }
                else
                {
                    CommonResult.Status = "fail";
                    CommonResult.ErrorMessage = "Please rate the job before approving the invoice!####" + saveInvoice.JobID;
                    AddInvoiceLog("", "Invoice : " + saveInvoice.InvoiceSummaryID + " and Status: " + saveInvoice.Status + "(" + CommonResult.ErrorMessage + ")", saveInvoice.FreelancerEmailID, false, "");
                }

            }
            return CommonResult;
        }


    }


}