﻿using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;

namespace ESPro.Infrastructure.Service
{
    public class MailService : IMails
    {
        //public string SendMail(string MsgBody, string Subject, string ToMail, string CCMail, string BccMail = "", string astrAttatchment = "")
        //{


        //    DataTable EmailDT = DbContext.DbUser.ExecuteDataSet("GetMailDetails").Tables[0];


        //    string MailFrom = EmailDT.Rows[0]["MailFrom"].ToString();
        //    string MailPWD = EmailDT.Rows[0]["MailPWD"].ToString();
        //    string SMTPIP = EmailDT.Rows[0]["SMTPIP"].ToString();



        //    string result = SendMail(MsgBody, Subject, ToMail, CCMail, MailFrom, "ESPro", MailPWD, SMTPIP, astrAttatchment, BccMail);
        //    //string err = objConn.SendMail(Body, "Welcome to Lumina Datamatics’ new Expert Source Pro! ", email, "", MailFrom, "Lumina Datamatics Team", MailPWD, SMTPIP, Attachment);
        //    return result;
        //}
        public string SendMail(string BodyStr, string SubjectStr, string toAddress, string CCAddress, string BCCAddress = "", string FromMail_UserName = "", string astrAttatchment = "", string ReplTo = "")
        {
            string ErrorMsg = "";
            string MailSuccess = "Y";
            string CSS = ".r11 {background-color: #B9C9FE;} .r21 {background-color: #E8EDFF;} #child td {padding-left: 5px;}";
            if (SubjectStr.Trim() == "")
            {
                Regex regex = new Regex("<title>([^<]+)</title>");
                Match match = regex.Match(BodyStr.ToString());
                if (match.Success)
                {
                    SubjectStr = match.Groups[1].Value;
                }
            }
            BodyStr = BodyStr.ToString().Replace("[CSSData]", CSS);

            DataTable EmailDT = DbContext.DbUser.ExecuteDataSet("GetMailDetails").Tables[0];
            string ProjectCode = EmailDT.Rows[0]["ProjectCode"].ToString();
            string MailFrom = EmailDT.Rows[0]["MailFrom"].ToString();
            string MailPWD = EmailDT.Rows[0]["MailPWD"].ToString();
            string SMTPIP = EmailDT.Rows[0]["SMTPIP"].ToString();

            if (FromMail_UserName.Trim() == "")
            {
                FromMail_UserName = "ESPro";
            }

            if (MailFrom.Trim() == "")
            {
                ErrorMsg = ErrorMsg + "\nMail not sent, FromMailId is blank, please check!!!";
            }
            if (MailPWD.Trim() == "")
            {
                ErrorMsg = ErrorMsg + "\nMail not sent, FromMailPassword is blank, please check!!!";
            }
            if (BodyStr.Trim() == "")
            {
                ErrorMsg = ErrorMsg + "Mail not sent, MailBody is blank, please check!!!";
            }
            if (SubjectStr.Trim() == "")
            {
                ErrorMsg = ErrorMsg + "\nMail not sent, MailSubject is blank, please check!!!";
            }
            if (SMTPIP.Trim() == "")
            {
                ErrorMsg = ErrorMsg + "\nMail not sent, SMTP_IP is blank, please check!!!";
            }
            if (Convert.ToString(ErrorMsg).Trim() == "")
            {
                SmtpClient objSmtpServer = new SmtpClient(SMTPIP, 587);
                MailMessage message = new MailMessage();

                try
                {
                    message.From = new MailAddress(MailFrom, FromMail_UserName);


                    string[] TO = Regex.Replace(toAddress, "([ ]*)", "").Replace(",", ";").ToString().Trim().Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);
                    TO = TO.Distinct().ToArray();
                    for (int k = 0; k < TO.Length; k++)
                    {
                        if (TO[k].Trim() != "")
                            message.To.Add(TO[k].ToString().Trim());
                    }

                    string[] CC = Regex.Replace(CCAddress, "([ ]*)", "").Replace(",", ";").ToString().Trim().Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);
                    CC = CC.Distinct().ToArray();
                    for (int k = 0; k < CC.Length; k++)
                    {
                        if (CC[k].Trim() != "")
                        {
                            if (!toAddress.Contains(CC[k].ToString().Trim()))
                            {
                                MailAddress mailAddress = new MailAddress(CC[k].ToString().Trim());
                                if (!message.CC.Contains(mailAddress))
                                    message.CC.Add(CC[k].ToString().Trim());
                            }
                        }
                    }

                    string[] BCC = Regex.Replace(BCCAddress, "([ ]*)", "").Replace(",", ";").ToString().Trim().Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);
                    BCC = BCC.Distinct().ToArray();
                    for (int k = 0; k < BCC.Length; k++)
                    {
                        if (BCC[k].Trim() != "")
                            message.Bcc.Add(BCC[k].ToString().Trim());
                    }

                    string[] ReTo = Regex.Replace(ReplTo, "([ ]*)", "").Replace(",", ";").ToString().Trim().Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);
                    ReTo = ReTo.Distinct().ToArray();
                    for (int k = 0; k < ReTo.Length; k++)
                    {
                        if (ReTo[k].Trim() != "")
                            message.ReplyTo = new MailAddress(ReTo[k].ToString().Trim());
                    }

                    message.Subject = SubjectStr;
                    message.IsBodyHtml = true;
                    message.Body = BodyStr;
                    objSmtpServer.EnableSsl = true;
                    if ((astrAttatchment != null))
                    {
                        for (int i = 0; i <= astrAttatchment.ToString().Split(';').Length - 2; i++)
                        {
                            message.Attachments.Add(new Attachment(astrAttatchment.ToString().Split(';')[i].ToString()));
                        }
                    }

                    objSmtpServer.Credentials = new System.Net.NetworkCredential(MailFrom, MailPWD);
                    //objSmtpServer.Credentials = new System.Net.NetworkCredential();

                    int milliseconds = 600;
                    System.Threading.Thread.Sleep(milliseconds);
                    //delay(100);
                    //await Task.Delay(200);
                    if (CommonResource.SendMail == "Y")
                        objSmtpServer.Send(message);
                    else
                        ErrorMsg = "skipped";
                }
                catch (Exception ex)
                {
                    ErrorMsg = ex.Message.ToString();
                    MailSuccess = "N";
                }
                finally
                {
                    message.Dispose();
                    message = null;
                    objSmtpServer = null;
                }
            }
            int cnt = DbContext.DbUser.ExecuteNonQuery("usp_InsertMailHistory", SubjectStr, toAddress, CCAddress, BCCAddress, BodyStr, ErrorMsg, MailSuccess, FromMail_UserName, SMTPIP, ReplTo, MailFrom, MailPWD);

            return ErrorMsg;
        }
    }
}
