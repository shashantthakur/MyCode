﻿using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ESPro.Infrastructure.Service
{
    public class JobsService : IJobs
    {
        public IEnumerable<JobSummaryModel> getFreelancerDetails(int userID, string FromWhere)
        {
            return CommonResource.ToCollection<JobSummaryModel>(DbContext.DbUser.ExecuteDataSet("sp_getFreelancerJobDetails", userID, FromWhere).Tables[0]);
        }

        public IEnumerable<JobModel> GetJobDetailsWithFileter(string JobNo, string ISBN, string AuthorName, string Title, string SelectdLocation, string SelectdSkill)
        {
            return CommonResource.ToCollection<JobModel>(DbContext.DbUser.ExecuteDataSet("usp_getJobDtls", JobNo, ISBN, AuthorName, Title, SelectdLocation, SelectdSkill).Tables[0]);
        }

        public IEnumerable<JobSearchModel> GetJobSearch(string SearchField,string SearchText)
        {
            List<JobSearchModel> jobSearchModels = CommonResource.ToCollection<JobSearchModel>(DbContext.DbUser.ExecuteDataSet("usp_JobSearch", SearchField, SearchText).Tables[0]);
            List<JobInvoiceSearchModel> jobInvoiceSearchData = CommonResource.ToCollection<JobInvoiceSearchModel>(DbContext.DbUser.ExecuteDataSet("usp_JobInvoiceSearch", SearchField, SearchText).Tables[0]);

            for (int i = 0; i < jobSearchModels.Count(); i++)
            {
                jobSearchModels[i].jobInvoiceSearchData = jobInvoiceSearchData.FindAll(c => c.JobID == jobSearchModels[i].JobID);
            }
            

            return jobSearchModels;
        }
        
    }
}
