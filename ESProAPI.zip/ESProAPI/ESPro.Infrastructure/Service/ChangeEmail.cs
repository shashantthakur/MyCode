﻿namespace ESPro.Infrastructure.Service
{
    public class ChangeEmail
    {
        public string oldEmail { get; set; }
        public string newEmail { get; set; }
        public bool isDeleted { get; set; }
    }
}