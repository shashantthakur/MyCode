﻿using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using ESPro.Core.Entity;
using System.Linq;
namespace ESPro.Infrastructure.Service
{
   public class AuthService : IAuth
    {
        public string GenerateToken(UserStatus userStatus)
        {

            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(CommonResource.SecretKey));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
            var claims = new[] {
                     
                     new Claim(JwtRegisteredClaimNames.Email, "espro.customersupport@luminad.com"),
                     new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                     //new Claim(JwtRegisteredClaimNames.Aud,FullName),
                     new Claim(JwtRegisteredClaimNames.UniqueName,userStatus.UsersId.ToString()),
                     new Claim(JwtRegisteredClaimNames.Sub, userStatus.UserName),//Eamil Id
                    
                     };
            var token = new JwtSecurityToken(CommonResource.myIssuer,
            CommonResource.myAudience,
            claims,
            expires: DateTime.Now.AddMinutes(CommonResource.TokenExpiredInMin),
            
            signingCredentials: credentials);
     
            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        public string ReGenerateToken(string token)
        {
            UserStatus userStatus = new UserStatus();
            var mySecret = CommonResource.SecretKey;
            var mySecurityKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(mySecret));
            var myIssuer = CommonResource.myIssuer;
            var myAudience = CommonResource.myAudience;

            var tokenHandler = new JwtSecurityTokenHandler();
            try
            {
                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidIssuer = myIssuer,
                    ValidAudience = myAudience,

                    LifetimeValidator = this.LifetimeValidator,
                    IssuerSigningKey = mySecurityKey

                }, out SecurityToken validatedToken);

                // tokenHandler.Claims.Where(z => z.Type.Equals("unique_name")).FirstOrDefault().Value, out pk_id),

                //var handler = new JwtSecurityTokenHandler();
                var jsonToken = tokenHandler.ReadToken(token);
                var tokenS = tokenHandler.ReadToken(token) as JwtSecurityToken;
                // var jti = tokenS.Claims.First(claim => claim.Type == "unique_name").Value;
                userStatus.UsersId = Convert.ToInt32(tokenS.Claims.First(claim => claim.Type == "unique_name").Value);
                userStatus.UserName = tokenS.Claims.First(claim => claim.Type == "sub").Value;
                //if(DT.Rows[0][0].ToString()== "true")
                //{
                //    return true;
                //}
                //else
                //{
                //    return false;
                //}                

            }
            catch (Exception ex)
            {
                
            }
            return GenerateToken(userStatus);
        }

       public ClientLogin ApiClientLogin(ClientLogin clientLogin)
        {
            return CommonResource.ToCollection<ClientLogin>(DbContext.DbUser.ExecuteDataSet("usp_ApiClientLogin", clientLogin.Client, clientLogin.UserName, clientLogin.Password).Tables[0]).FirstOrDefault();
        }
        public Boolean ValidateToken(string token)
        {
           
            var mySecret = CommonResource.SecretKey;
            var mySecurityKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(mySecret));            
            var myIssuer = CommonResource.myIssuer;
            var myAudience = CommonResource.myAudience;

            var tokenHandler = new JwtSecurityTokenHandler();
            try
            {
                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidIssuer = myIssuer,
                    ValidAudience = myAudience,

                    LifetimeValidator = this.LifetimeValidator,
                    IssuerSigningKey = mySecurityKey

                }, out SecurityToken validatedToken);

                // tokenHandler.Claims.Where(z => z.Type.Equals("unique_name")).FirstOrDefault().Value, out pk_id),

                //var handler = new JwtSecurityTokenHandler();
                var jsonToken = tokenHandler.ReadToken(token);
                var tokenS = tokenHandler.ReadToken(token) as JwtSecurityToken;
                // var jti = tokenS.Claims.First(claim => claim.Type == "unique_name").Value;
                var UserActivationId = tokenS.Claims.First(claim => claim.Type == "unique_name").Value;

                return true;
                //if(DT.Rows[0][0].ToString()== "true")
                //{
                //    return true;
                //}
                //else
                //{
                //    return false;
                //}                

            }
            catch (Exception ex)
            {
                return false;
            }

        }
        public bool LifetimeValidator(DateTime? notBefore, DateTime? expires, SecurityToken securityToken, TokenValidationParameters validationParameters)
        {
            if (expires != null)
            {
                if (DateTime.UtcNow < expires) return true;
            }
            return false;
        }
    }
}
