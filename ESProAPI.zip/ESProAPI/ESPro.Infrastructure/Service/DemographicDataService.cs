﻿using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;

namespace ESPro.Infrastructure.Service
{
    public class DemographicDataService : IDemographicData
    {
        public async Task<MasterDemographicData> GetDemographicDataMaster()
        {

            MasterDemographicData _masterDemographicData = new MasterDemographicData();

            var taskRaceEthnicity = Task.Run(() => GetRaceEthnicity());
            var taskEthnicity = Task.Run(() => GetEthnicity());
            var taskGender = Task.Run(() => GetGender());
            var taskAgeBracke = Task.Run(() => GetAgeBracket());
            var taskDisability = Task.Run(() => GetDisability());
            var taskMilitary = Task.Run(() => GetMilitary());
            var taskBusinessClassification = Task.Run(() => GetBusinessClassification());
            var taskDemographicAgencies = Task.Run(() => GetDemographicAgencies());
            var taskAboutESPro = Task.Run(() => GetAboutESPro());

            await Task.WhenAll(taskEthnicity, taskGender, taskAgeBracke, taskDisability, taskMilitary, taskBusinessClassification, taskDemographicAgencies, taskAboutESPro);

            _masterDemographicData.RaceEthnicityList = taskRaceEthnicity.Result;
            _masterDemographicData.EthnicityList = taskEthnicity.Result;
            _masterDemographicData.GenderList = taskGender.Result;
            _masterDemographicData.AgeBracketList = taskAgeBracke.Result;
            _masterDemographicData.DisabilityList = taskDisability.Result;
            _masterDemographicData.MilitaryList = taskMilitary.Result;
            _masterDemographicData.BusinessClassificationList = taskBusinessClassification.Result;
            _masterDemographicData.DemographicAgenciesList = taskDemographicAgencies.Result;
            _masterDemographicData.AboutESProList = taskAboutESPro.Result;

            return _masterDemographicData;
        }
        public void getwait(int min)
        {
            DateTime CurTime = DateTime.Now.AddSeconds(min);
            while (DateTime.Now < CurTime)
            {

            }
        }

        public List<MasterEthnicity> GetRaceEthnicity()
        {
            List<MasterEthnicity> masterEthnicity = CommonResource.ToCollection<MasterEthnicity>(DbContext.DbUser.ExecuteDataSet("usp_GetRaceEthnicity").Tables[0]);

            CryptoService cryptoService = new CryptoService();

            foreach (var _masterEthnicity in masterEthnicity)
            {
                _masterEthnicity.Ethnicity = cryptoService.Decrypt(_masterEthnicity.Ethnicity);
            }
            return masterEthnicity;
        }

        public List<MasterAboutESPro> GetAboutESPro()
        {
            List<MasterAboutESPro> masterAboutESPro = CommonResource.ToCollection<MasterAboutESPro>(DbContext.DbUser.ExecuteDataSet("usp_GetAboutESPro").Tables[0]);

            CryptoService cryptoService = new CryptoService();
            foreach (var _masterAboutESPro in masterAboutESPro)
            {
                _masterAboutESPro.AboutESPro = cryptoService.Decrypt(_masterAboutESPro.AboutESPro);
            }
            return masterAboutESPro;
        }

        public List<MasterEthnicity> GetEthnicity()
        {
            List<MasterEthnicity> masterEthnicity = CommonResource.ToCollection<MasterEthnicity>(DbContext.DbUser.ExecuteDataSet("usp_GetEthnicity").Tables[0]);

            CryptoService cryptoService = new CryptoService();

            foreach (var _masterEthnicity in masterEthnicity)
            {
                _masterEthnicity.Ethnicity = cryptoService.Decrypt(_masterEthnicity.Ethnicity);
            }
            return masterEthnicity;
        }
        public List<MasterGender> GetGender()
        {
            List<MasterGender> masterGenders = CommonResource.ToCollection<MasterGender>(DbContext.DbUser.ExecuteDataSet("usp_GetGender").Tables[0]);

            CryptoService cryptoService = new CryptoService();

            foreach (var _masterGenders in masterGenders)
            {
                _masterGenders.Gender = cryptoService.Decrypt(_masterGenders.Gender);
            }
            return masterGenders;
        }
        public List<MasterAgeBracket> GetAgeBracket()
        {
            List<MasterAgeBracket> masterAgeBrackets = CommonResource.ToCollection<MasterAgeBracket>(DbContext.DbUser.ExecuteDataSet("usp_GetAgeBracket").Tables[0]);

            CryptoService cryptoService = new CryptoService();

            foreach (var _masterAgeBrackets in masterAgeBrackets)
            {
                _masterAgeBrackets.AgeBracket = cryptoService.Decrypt(_masterAgeBrackets.AgeBracket);
            }
            return masterAgeBrackets;
        }

        public List<MasterDisability> GetDisability()
        {
            List<MasterDisability> masterDisabilities = CommonResource.ToCollection<MasterDisability>(DbContext.DbUser.ExecuteDataSet("usp_GetDisability").Tables[0]);

            CryptoService cryptoService = new CryptoService();

            foreach (var _masterDisabilities in masterDisabilities)
            {
                _masterDisabilities.Disability = cryptoService.Decrypt(_masterDisabilities.Disability);
            }
            return masterDisabilities;
        }
        public List<MasterMilitary> GetMilitary()
        {
            List<MasterMilitary> masterMilitaries = CommonResource.ToCollection<MasterMilitary>(DbContext.DbUser.ExecuteDataSet("usp_GetMilitary").Tables[0]);

            CryptoService cryptoService = new CryptoService();

            foreach (var _masterMilitaries in masterMilitaries)
            {
                _masterMilitaries.Military = cryptoService.Decrypt(_masterMilitaries.Military);
            }
            return masterMilitaries;
        }
        public List<MasterBusinessClassification> GetBusinessClassification()
        {
            List<MasterBusinessClassification> masterBusinessClassifications = CommonResource.ToCollection<MasterBusinessClassification>(DbContext.DbUser.ExecuteDataSet("usp_GetBusinessClassification").Tables[0]);

            CryptoService cryptoService = new CryptoService();

            foreach (var _masterBusinessClassifications in masterBusinessClassifications)
            {
                _masterBusinessClassifications.BusinessClassification = cryptoService.Decrypt(_masterBusinessClassifications.BusinessClassification);
            }
            return masterBusinessClassifications;
        }
        public List<MasterDemographicAgencies> GetDemographicAgencies()
        {
            List<MasterDemographicAgencies> masterDemographicAgencies = CommonResource.ToCollection<MasterDemographicAgencies>(DbContext.DbUser.ExecuteDataSet("usp_GetDemographicAgencies").Tables[0]);

            CryptoService cryptoService = new CryptoService();

            foreach (var _masterDemographicAgencies in masterDemographicAgencies)
            {
                _masterDemographicAgencies.DemographicAgencies = cryptoService.Decrypt(_masterDemographicAgencies.DemographicAgencies);
            }
            return masterDemographicAgencies;
        }
        public UserDemographicData GetDemographicData(int UsersId)
        {
            UserDemographicData userDemographicData = new UserDemographicData();
            DemographicAdditionalInfo demographicAdditionalInfo = CommonResource.ToCollection<DemographicAdditionalInfo>(DbContext.DbUser.ExecuteDataSet("GetDemographicAdditionalInfo", UsersId).Tables[0]).FirstOrDefault();
            if (demographicAdditionalInfo != null)
            {
                userDemographicData.IsOwnBusiness = demographicAdditionalInfo.OwnBusiness;
                userDemographicData.AgencyName = demographicAdditionalInfo.AgencyName;
                userDemographicData.AboutESProOther = demographicAdditionalInfo.AboutESProOther;
            }
            userDemographicData.Race = CommonResource.ToCollection<UserSelectedSkills>(DbContext.DbUser.ExecuteDataSet("usp_GetUserDemographicMapping", UsersId, "MasterRaceEthnicity").Tables[0]).Select(p2 => p2.FieldId).FirstOrDefault();
            userDemographicData.Gender = CommonResource.ToCollection<UserSelectedSkills>(DbContext.DbUser.ExecuteDataSet("usp_GetUserDemographicMapping", UsersId, "MasterGender").Tables[0]).Select(p2 => p2.FieldId).FirstOrDefault();
            userDemographicData.AgeBracket = CommonResource.ToCollection<UserSelectedSkills>(DbContext.DbUser.ExecuteDataSet("usp_GetUserDemographicMapping", UsersId, "MasterAgeBracket").Tables[0]).Select(p2 => p2.FieldId).FirstOrDefault();
            userDemographicData.Disability = CommonResource.ToCollection<UserSelectedSkills>(DbContext.DbUser.ExecuteDataSet("usp_GetUserDemographicMapping", UsersId, "MasterDisability").Tables[0]).Select(p2 => p2.FieldId).FirstOrDefault();
            userDemographicData.VeteranStatus = CommonResource.ToCollection<UserSelectedSkills>(DbContext.DbUser.ExecuteDataSet("usp_GetUserDemographicMapping", UsersId, "MasterMilitary").Tables[0]).Select(p2 => p2.FieldId).FirstOrDefault();

            userDemographicData.BusinessClassification = CommonResource.ToCollection<UserSelectedSkills>(DbContext.DbUser.ExecuteDataSet("usp_GetUserDemographicMapping", UsersId, "MasterBusinessClassification").Tables[0]).Select(p2 => p2.FieldId).ToList();
            userDemographicData.Agency = CommonResource.ToCollection<UserSelectedSkills>(DbContext.DbUser.ExecuteDataSet("usp_GetUserDemographicMapping", UsersId, "MasterDemographicAgencies").Tables[0]).Select(p2 => p2.FieldId).ToList();
            userDemographicData.Ethnicity = CommonResource.ToCollection<UserSelectedSkills>(DbContext.DbUser.ExecuteDataSet("usp_GetUserDemographicMapping", UsersId, "MasterEthnicity").Tables[0]).Select(p2 => p2.FieldId).FirstOrDefault();
            userDemographicData.AboutESPro = CommonResource.ToCollection<UserSelectedSkills>(DbContext.DbUser.ExecuteDataSet("usp_GetUserDemographicMapping", UsersId, "MasterAboutESPro").Tables[0]).Select(p2 => p2.FieldId).FirstOrDefault();
            return userDemographicData;
        }
        public DemographicAdditionalInfo GetDemographicAdditionalInfo(int UsersId)
        {
         return CommonResource.ToCollection<DemographicAdditionalInfo>(DbContext.DbUser.ExecuteDataSet("GetDemographicAdditionalInfo", UsersId).Tables[0]).FirstOrDefault();
        }

        public int UpdateDemographicData(UserDemographicData userData)
        {
            int cnt = 0;

            DbContext.DbUser.ExecuteNonQuery("usp_UpSertDemographicAdditionalInfo", userData.UsersId, userData.IsOwnBusiness==null? false: userData.IsOwnBusiness, userData.AgencyName, userData.AboutESProOther);

            cnt += DbContext.DbUser.ExecuteNonQuery("usp_UpSertDemographicDataMapping", userData.UsersId, userData.Race, "MasterRaceEthnicity");
            cnt += DbContext.DbUser.ExecuteNonQuery("usp_UpSertDemographicDataMapping", userData.UsersId, userData.Gender, "MasterGender");
            cnt += DbContext.DbUser.ExecuteNonQuery("usp_UpSertDemographicDataMapping", userData.UsersId, userData.AgeBracket, "MasterAgeBracket");
            cnt += DbContext.DbUser.ExecuteNonQuery("usp_UpSertDemographicDataMapping", userData.UsersId, userData.Disability, "MasterDisability");
            cnt += DbContext.DbUser.ExecuteNonQuery("usp_UpSertDemographicDataMapping", userData.UsersId, userData.VeteranStatus, "MasterMilitary");

            DbContext.DbUser.ExecuteNonQuery("usp_DeleteDemographicDataMapping", userData.UsersId, "MasterBusinessClassification");
            if (userData.BusinessClassification != null)
                foreach (int id in userData.BusinessClassification)
                {
                    cnt += InsertDemographicData(userData.UsersId, id, "MasterBusinessClassification");
                }

            DbContext.DbUser.ExecuteNonQuery("usp_DeleteDemographicDataMapping", userData.UsersId, "MasterDemographicAgencies");
            if (userData.Agency != null)
                foreach (int id in userData.Agency)
                {
                    cnt += InsertDemographicData(userData.UsersId, id, "MasterDemographicAgencies");
                }

            //DbContext.DbUser.ExecuteNonQuery("usp_DeleteDemographicDataMapping", userData.UsersId, "MasterAboutESPro");
            //if (userData.AboutESPro != null)
            //    foreach (int id in userData.AboutESPro)
            //    {
            //        cnt += InsertDemographicData(userData.UsersId, id, "MasterAboutESPro");
            //    }

            cnt += DbContext.DbUser.ExecuteNonQuery("usp_UpSertDemographicDataMapping", userData.UsersId, userData.AboutESPro, "MasterAboutESPro");

            DbContext.DbUser.ExecuteNonQuery("usp_DeleteDemographicDataMapping", userData.UsersId, "MasterEthnicity");
            if(userData.Ethnicity!=null)
            cnt += InsertDemographicData(userData.UsersId, userData.Ethnicity, "MasterEthnicity");
            return cnt;
        }

        public int InsertDemographicData(int? UsersId, int? SkillId, string TableName)
        {
            return DbContext.DbUser.ExecuteNonQuery("usp_InsertDemographicDataMapping", UsersId, SkillId, TableName);
        }


       public List<DemographicDataReport> GenerateDemographicDataReport(DemographicDataReportParam demographicDataReportParam)
       {
            //string clients = "";
            //for (int i = 0; i < demographicDataReportParam.Clients.Length; i++)
            //{
            //    if(i==0)
            //    {
            //        clients += "'" + demographicDataReportParam.Clients[i].ToString() + "'";
            //    }
            //    else
            //    {
            //        clients += ",'" + demographicDataReportParam.Clients[i].ToString() + "'";
            //    }
            //}
            //List<DemographicDataReport>  demographicDataReportList= CommonResource.ToCollection<DemographicDataReport>(DbContext.DbUser.ExecuteDataSet("usp_DemographicDataReport", clients).Tables[0]);
            List<DemographicDataReport> demographicDataReportList = CommonResource.ToCollection<DemographicDataReport>(DbContext.DbUser.ExecuteDataSet("usp_DemographicDataReport", demographicDataReportParam.Customers).Tables[0]);
            demographicDataReportList = demographicDataReportList.Where(a => a.ProjectRatedCount != 0).ToList();
            int cnt = 0;
            foreach (var item in demographicDataReportList)
            {
                cnt++;
                item.SRNO = cnt;
                item.RaceEthnicity = DecryptData(item.RaceEthnicity);
                item.Gender = DecryptData(item.Gender);
                item.AgeBracket = DecryptData(item.AgeBracket);
                item.Disability = DecryptData(item.Disability);
                item.MilitaryStatus = DecryptData(item.MilitaryStatus);
                item.BusinessClassification = DecryptData(item.BusinessClassification);
                item.DemographicAgencies = DecryptData(item.DemographicAgencies);
                item.BusinessEthnicity = DecryptData(item.BusinessEthnicity);
            }
           
            return demographicDataReportList;
        }

        public string DecryptData(string EncryptString)
        {
            if (string.IsNullOrEmpty(EncryptString))
                return EncryptString;
            CryptoService cryptoService = new CryptoService();

          string[] arr=  EncryptString.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i]= cryptoService.Decrypt(arr[i]);
            }
          

           return String.Join(", ", arr);

        }
    }
}
