using ESPro.Core.Entity.Client;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using iText.Html2pdf;

using iText.Kernel.Pdf;
using iText.StyledXmlParser.Css.Media;
//using iTextSharp.text;
//using iTextSharp.text.html.simpleparser;
//using iTextSharp.text.pdf;
//using iTextSharp.tool.xml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace ESPro.Infrastructure.Service
{
    public class ClientService : IClient
    {
        public IEnumerable<ClientJobDetailsModel> GetClientDashboard(int UsersId, string UserRole, string UserEmailID)
        {
            ClientUser userClient = new ClientUser();
            IEnumerable<ClientJobDetailsModel> clientJobDetailsModel = null;
            //if (UserRole.Trim().ToUpper() == "AGENCY")
            //{
            //    userClient.ClientName = UserRole;
            //    userClient.UserName = UserEmailID;
            //}
            //else
                userClient = GetUserClientName(UsersId);
            
            if (userClient != null)
            {
                clientJobDetailsModel = CommonResource.ToCollection<ClientJobDetailsModel>(DbContext.DbUser.ExecuteDataSet("sp_GetClientJobDetails", userClient.ClientName, userClient.UserName, UserRole).Tables[0]);
            }
            return clientJobDetailsModel;
        }

        public ClientJobDetailsModel GetJobDetailsFromID(int JobId)
        {
            return CommonResource.ToCollection<ClientJobDetailsModel>(DbContext.DbUser.ExecuteDataSet("usp_GetJobDetailsFromId", JobId).Tables[0]).FirstOrDefault();

        }
        public ClientUser GetUserClientName(int UsersId)
        {
            ClientUser userClient = new ClientUser();
            userClient = CommonResource.ToCollection<ClientUser>(DbContext.DbUser.ExecuteDataSet("usp_GetUserClientName", UsersId).Tables[0]).FirstOrDefault();
            return userClient;

        }

        public string CreateClientJob(ClientJobDetailsModel model)
        {

            var Jobmodel = CommonResource.ToCollection<ReturnJobDetails>(DbContext.DbUser.ExecuteDataSet("usp_ClientCreateJob", model.Customer, model.Author,
                            model.Title, model.Edition, model.Unit, model.Skill, model.ISBN13, model.NoOfUnits,
                            model.ClientBudget, (model.ContractedRate * model.NoOfUnits), model.FreelancerName, model.FreelancerEmailID,
                           model.IsManualRecord,
                            Convert.ToDateTime(model.ExpectedCompletionDate), model.JobPM, model.PM_Name,
                            model.Contracted_Currency, model.Budget_Currency, model.Notes, model.Discipline, model.SubDiscipline, model.RequestComment, Convert.ToString("" + model.WireFee),model.JobPrefix).Tables[0]).FirstOrDefault(); 


            

            model.JobID = Convert.ToInt32(Jobmodel.JobID);
            model.JobNo = Jobmodel.JobNo;

            //return Convert.ToInt32(JobId);
            return RaiseContract(model, true);
        }
        public string UpdateClientJob(ClientJobDetailsModel model)
        {
            if (model.AgencyEmail != "")
            {
                var cnt = DbContext.DbUser.ExecuteNonQuery("Upsert_FLAgencyJobMapping", model.AgencyId, model.AgencyUserId, model.FreelancerUsersId, model.JobID);
                SendMailToFreelancerContract(model, false, "AssignFreelancer");
                return "Freelancer Assigned Successfully.";
            }
            else
            {
                if (model.JobID == null || model.JobID == 0)
                {
                    return "fail";
                }
                var cnt = DbContext.DbUser.ExecuteNonQuery("usp_ClientUpdateJob", model.JobID, model.Customer, model.Author,
               model.Title, model.Edition, model.Unit, model.Skill, model.ISBN13, model.NoOfUnits, model.ClientBudget,
               (model.ContractedRate * model.NoOfUnits), model.Contracted_Currency, model.Budget_Currency, model.FreelancerName,
               model.FreelancerEmailID, model.IsManualRecord, Convert.ToDateTime(model.ExpectedCompletionDate), model.Notes,
               model.RequestComment, model.SubDiscipline, model.Discipline, Convert.ToString("" + model.WireFee));
               return RaiseContract(model, false);
            }
        }
        public int DeleteClientJob(ClientJobDetailsModel clientJobDetailsModel)
        {
            int cnt = DbContext.DbUser.ExecuteNonQuery("usp_ClientDeleteJob", clientJobDetailsModel.JobID);
            if(clientJobDetailsModel.ContractStatus == "ACCEPTED" && cnt > 0)
            {
                SendMailToFreelancerContract(clientJobDetailsModel, false, "DeleteJob");
            }
            return cnt;
        }

        public string RaiseContract(ClientJobDetailsModel jdmodel, bool NewJob)
        {
            bool ContractRaised = false;
            if (NewJob == true && Convert.ToString("" + jdmodel.FreelancerName) != "")
                ContractRaised = true;
            else if (jdmodel.ContractStatus == "REJECTED" && Convert.ToString("" + jdmodel.FreelancerName) != "")
                ContractRaised = true;
            else if (Convert.ToString("" + jdmodel.FreelancerName) != "" && Convert.ToString("" + jdmodel.ContractStatus) != "ACCEPTED")
                ContractRaised = true;

            if (ContractRaised)
            {
                try
                {
                    int Client_code = jdmodel.ClientId.Value;
                    //jdmodel.JobPM = MySessionData.User_Id;
                    //int.TryParse(MySessionData.Client_code, out Client_code);
                    bool IsContractRequired = jdmodel.ContractRequired;
                    if (IsContractRequired && !String.IsNullOrEmpty(jdmodel.FreelancerEmailID))
                    {
                        DateTime DueDate = Convert.ToDateTime(jdmodel.ExpectedCompletionDate);
                        ContractModel contractModel = new ContractModel()
                        {
                            JobNo = jdmodel.JobNo,
                            ContractorName = jdmodel.FreelancerName,
                            WileyContact = jdmodel.PM_Name,
                            ClientName = jdmodel.Customer,
                            Author = jdmodel.Author,
                            Title = jdmodel.Title,
                            Edition = jdmodel.Edition,
                            ISBN = jdmodel.ISBN13,
                            WorkDescription = jdmodel.Skill,
                            DueDate = DueDate.ToString("yyyy-MM-dd"), //jdmodel.ExpectedCompletionDate,
                            TypeofUnit = jdmodel.Unit,
                            NumberofUnits = jdmodel.NoOfUnits,
                            ContractedRateperUnit = jdmodel.ContractedRate,
                            ContractedCurrency = jdmodel.Contracted_Currency,
                            TotalValueofAssignment = Convert.ToString(jdmodel.NoOfUnits * jdmodel.ContractedRate),
                            EffectiveDate = DateTime.Now.ToString("yyyy-MM-dd")
                        };
                        string Error = String.Empty;
                        String FileName = String.Format("Contract_{0}_{1}.pdf", jdmodel.JobNo, DateTime.Now.ToString("ddMMyyyyhhmmss"));
                        string HtmlFileName = String.Format("Contract_{0}_{1}.html", jdmodel.JobNo, DateTime.Now.ToString("ddMMyyyyhhmmss"));
                        string FolderPath = Path.Combine(CommonResource.ContractPath, Client_code.ToString(), DateTime.Now.ToString("dd_MM_yyyy_hh_mm_ss"));

                        var path = Path.Combine(CommonResource.MailTemplatePath, "Freelancer_Contract.html");
                        //var str2 = env.WebRootPath; // Null, both doesn't give any result



                        string FilePath = Path.Combine(FolderPath, FileName);
                        if (!Directory.Exists(FolderPath))
                            Directory.CreateDirectory(FolderPath);
                        string HtmlStringData = System.IO.File.ReadAllText(path);
                        string UpdatedHtmlString = GetHtmlString(HtmlStringData, contractModel, out Error);
                        bool result = ConvertHTMLToPDF(FolderPath, UpdatedHtmlString, FileName, "", out Error);
                        if (result)
                        {
                            string FilePathNew = FilePath.Replace(CommonResource.ContractPath, "");
                            UpsertContractInfo(Convert.ToInt32(jdmodel.JobID), "APPLIED", FilePathNew, jdmodel.FreelancerUsersId.Value, String.Empty, 0);
                            //string FileEncoded = EncodeOrDecode.Encrypt(FilePath);
                            if (NewJob == true)
                            {
                                SendMailToFreelancerContract(jdmodel);
                            }else
                            {
                                SendMailToFreelancerContract(jdmodel,false, "UPDATED");
                                return "Contract Updated successfully.";
                            }
                           
                        }
                        //TempData["JobUpdateMsg"] = "Contract Raised successfully!";
                        return "Contract Raised successfully.";


                    }else
                    {
                        if (NewJob == true)
                        {
                            return "Job Created Successfully.";
                        }
                        else
                        {
                            return "Job Updated Successfully.";
                        }
                    }
                }
                catch (Exception ex)
                {
                    return "fail";
                    //TempData["JobUpdateMsg"] = ex.Message.ToString();
                }
            }
            else
            {
                if (NewJob == true)
                {
                    return "Job Created Successfully.";
                }
                else
                {
                    return "Job Updated Successfully.";
                }
            }
        }

        internal static bool UpsertContractInfo(int jobID, string Status, string filePath, int FreelancerUsersId, string UserComment = "", int ContractId = 0, string Intitals = "")
        {
            return Convert.ToInt32(DbContext.DbUser.ExecuteScalar("usp_UpsertContractInfo", jobID, Status, filePath, FreelancerUsersId, Convert.ToString("" + UserComment), ContractId, Intitals)) > 0 ? true : false;
        }
        private string GetHtmlString(string htmlStringData, ContractModel contractModel, out string Error)
        {
            try
            {
                htmlStringData = htmlStringData.Replace("[JobNo]", contractModel.JobNo);
                htmlStringData = htmlStringData.Replace("[ContractorName]", contractModel.ContractorName);
                htmlStringData = htmlStringData.Replace("[WileyContact]", contractModel.WileyContact);
                htmlStringData = htmlStringData.Replace("[ClientName]", contractModel.ClientName);
               
                htmlStringData = htmlStringData.Replace("[Author]", contractModel.Author);
                htmlStringData = htmlStringData.Replace("[Title]", contractModel.Title);
                htmlStringData = htmlStringData.Replace("[Edition]", contractModel.Edition);
                htmlStringData = htmlStringData.Replace("[ISBN]", contractModel.ISBN);
                htmlStringData = htmlStringData.Replace("[WorkDescription]", contractModel.WorkDescription);
                htmlStringData = htmlStringData.Replace("[DueDate]", contractModel.DueDate);
                htmlStringData = htmlStringData.Replace("[TypeofUnit]", contractModel.TypeofUnit);
                htmlStringData = htmlStringData.Replace("[NumberofUnits]", Convert.ToString(contractModel.NumberofUnits));
                htmlStringData = htmlStringData.Replace("[ContractedRateperUnit]", Convert.ToString(contractModel.ContractedRateperUnit));
                htmlStringData = htmlStringData.Replace("[ContractedCurrency]", contractModel.ContractedCurrency);
                htmlStringData = htmlStringData.Replace("[TotalValueofAssignment]", contractModel.TotalValueofAssignment);
                htmlStringData = htmlStringData.Replace("[EffectiveDate]", contractModel.EffectiveDate);
                Error = String.Empty;
            }
            catch (Exception ex)
            {
                Error = ex.Message.ToString();
            }
            return htmlStringData;
        }

       public string getPdf()
        {
            try
            {
                string HtmlFilePath = @"F:\Applications\T1.html";
                string PdfFilePath = @"F:\Applications\T1.pdf";
                string HTMLString = File.ReadAllText(HtmlFilePath, Encoding.UTF8);
                //using (MemoryStream stream = new System.IO.MemoryStream())
                //{
                //    StringReader reader = new StringReader(HTMLString);
                //    //Document PdfFile = new Document(PageSize.A4);
                //    //Document PdfFile = new Document(new iTextSharp.text.Rectangle(680f, 900f), 20, 2, 70, 0);
                //    Document PdfFile = new Document(PageSize.A4.Rotate(), 30f, 30f, 30f, 30f);
                //    PdfWriter writer = PdfWriter.GetInstance(PdfFile, stream);
                //    PdfFile.Open();
                //    XMLWorkerHelper.GetInstance().ParseXHtml(writer, PdfFile, reader);
                //    //HTMLWorker htmlparser = new HTMLWorker(PdfFile);
                //    //htmlparser.Parse(reader);    
                //    PdfFile.Close();
                //    File.WriteAllBytes(PdfFilePath, stream.ToArray());
                //}


                //StringReader sr = new StringReader(HTMLString);
                //// Document pdfDoc = new Document(PageSize.A4, 10f, 10f, 10f, 0f);
                //Document pdfDoc = new Document(PageSize.A4.Rotate(), 30f, 30f, 30f, 30f);
                //HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
                //using (MemoryStream memoryStream = new MemoryStream())
                //{

                //    PdfWriter writer = PdfWriter.GetInstance(pdfDoc, memoryStream);
                //    pdfDoc.Open();

                PdfWriter writer = new PdfWriter(PdfFilePath);
                PdfDocument pdf = new PdfDocument(writer);
                pdf.SetTagged();
                iText.Kernel.Geom.PageSize pageSize = iText.Kernel.Geom.PageSize.A4;
                pdf.SetDefaultPageSize(pageSize);
                ConverterProperties properties = new ConverterProperties();
                //properties.SetBaseUri(baseUri);
                MediaDeviceDescription mediaDeviceDescription
                    = new MediaDeviceDescription(MediaType.SCREEN);
                mediaDeviceDescription.SetWidth(pageSize.GetWidth());
                properties.SetMediaDeviceDescription(mediaDeviceDescription);
                HtmlConverter.ConvertToPdf(HTMLString, pdf, properties);

                //    htmlparser.Parse(sr);

                //    pdfDoc.Close();

                //    //byte[] bytes = memoryStream.ToArray();
                //    File.WriteAllBytes(PdfFilePath, memoryStream.ToArray());
                //    memoryStream.Close();
                //}
                return "success";
            }
            catch (Exception ex)
            {

                return ex.Message.ToString();
            }
        }
        public bool ConvertHTMLToPDF(string FilePath, string HTMLString, string PDFName, string HTMLCSS, out string Error)
        {
            try
            {               
                using (FileStream pdfDest = File.Open(System.IO.Path.Combine(FilePath, PDFName), FileMode.OpenOrCreate))
                {
                    ConverterProperties converterProperties = new ConverterProperties();
                    HtmlConverter.ConvertToPdf(HTMLString, pdfDest, converterProperties);
                }    

                string HtmlFile = Path.Combine(FilePath, PDFName.Replace(".pdf", ".html"));
                File.WriteAllText(HtmlFile, HTMLString);
                Error = String.Empty;
                return true;
            }
            catch (Exception ex)
            {
                Error = ex.Message;
                return false;
            }

        }

       public void SendMailToFreelancerContract(ClientJobDetailsModel jdmodel, bool isSigned = false, string MailType = "", string RejectionComments = "")
        {
            StringBuilder sbMailBody = null;
            string TemplateName = String.Empty;
            string MailSubject = "";
            if (MailType == "DeleteJob")
            {
                TemplateName = "ContractDeleted.html";
                MailSubject = "Contract Deleted for " + jdmodel.Skill + " for " + jdmodel.Author + ", " + jdmodel.Title + ", " + jdmodel.Edition + "";
            }
            else if (MailType == "AssignFreelancer")
            {
                TemplateName = "AssignFreelancer.html";
                MailSubject = "Agency assigned the job for " + jdmodel.Skill + " for " + jdmodel.Author + ", " + jdmodel.Title + ", " + jdmodel.Edition + "";
            }
            else if (MailType == "REJECTED")
            {
                TemplateName = "ContractRejected.html";
                MailSubject = "Contract Rejected for " + jdmodel.Skill + " for " + jdmodel.Author + ", " + jdmodel.Title + ", " + jdmodel.Edition + "";
            }
            else if (MailType == "UPDATED")
            {
                TemplateName = "ContractCreateMail.html";
                MailSubject = "Contract Updated for " + jdmodel.Skill + " for " + jdmodel.Author + ", " + jdmodel.Title + ", " + jdmodel.Edition + "";
            }
            else if (isSigned)
            {
                TemplateName = "ContractSignMail.html";
                MailSubject = "Signed Contract for " + jdmodel.Skill + " for " + jdmodel.Author + ", " + jdmodel.Title + ", " + jdmodel.Edition + "";
            }
            else
            {
                TemplateName = "ContractCreateMail.html";
                MailSubject = "Contract Raised for " + jdmodel.Skill + " for " + jdmodel.Author + ", " + jdmodel.Title + ", " + jdmodel.Edition + "";
            }
            sbMailBody = new StringBuilder(System.IO.File.ReadAllText(CommonResource.MailTemplatePath + "\\" + TemplateName));
            sbMailBody.Replace("[JobNo]", jdmodel.JobNo);
            //sbMailBody.Replace("[Freelancer]", jdmodel.FreelancerName);
            sbMailBody.Replace("[Freelancer]", jdmodel.FreelancerName);
            sbMailBody.Replace("[ClietName]", jdmodel.PM_Name);
            sbMailBody.Replace("[JobNo]", jdmodel.JobNo);
            sbMailBody.Replace("[Author]", jdmodel.Author);
            sbMailBody.Replace("[Title]", jdmodel.Title);
            sbMailBody.Replace("[Skill]", jdmodel.Skill);
            sbMailBody.Replace("[ISBN]", jdmodel.ISBN13);
            sbMailBody.Replace("[RejectedReason]", RejectionComments);
            sbMailBody.Replace("[LogninLink]", CommonResource.UiUrl);
            sbMailBody.Replace("[Regards]", "Expert Source Mailer");
            sbMailBody.Replace("[Expert_Source]", "ESPro");
            string Freelancer_EmailID = jdmodel.FreelancerEmailID;
            MailService objMail = new MailService();
            if (MailType == "DeleteJob")
                objMail.SendMail(sbMailBody.ToString(), MailSubject, jdmodel.FreelancerEmailID, jdmodel.InvApproverEmail);
            else if (MailType == "AssignFreelancer")
                objMail.SendMail(sbMailBody.ToString(), MailSubject, Freelancer_EmailID, jdmodel.AgencyEmail + "," + jdmodel.JobPM + "," + jdmodel.InvApproverEmail);
            else if (isSigned || MailType == "REJECTED")
                objMail.SendMail(sbMailBody.ToString(), MailSubject, jdmodel.JobPM, Freelancer_EmailID);
            else
                objMail.SendMail(sbMailBody.ToString(), MailSubject, Freelancer_EmailID, jdmodel.JobPM);
        }

        public List<ClientUser> GetAllClientUsers(int ClientCode)
        {
            List<ClientUser> allClientUsers = new List<ClientUser>();
            allClientUsers = CommonResource.ToCollection<ClientUser>(DbContext.DbUser.ExecuteDataSet("usp_GetAllClientUsers", ClientCode).Tables[0]);
            return allClientUsers;
        }

        public string UpdatePMName(ReassignedJobs reassignedJobs)
        {
            var cnt = DbContext.DbUser.ExecuteNonQuery("usp_UpdatePMName", reassignedJobs.JobID, reassignedJobs.OldPMName, reassignedJobs.OldPMEmailId, reassignedJobs.NewPMName, reassignedJobs.NewPMEmailId, reassignedJobs.ReassignedUsersId);
            SendJobReassignedMail(reassignedJobs);
            return "success";
        }

        public void SendJobReassignedMail(ReassignedJobs reassignedJobs)
        {
            StringBuilder sbMailBody = null;
            string TemplateName = String.Empty;
            string MailSubject = "";
            TemplateName = "ReassignPM.html";
            MailSubject = "ESPro: Re-assigned Job: " + reassignedJobs.JobNo;

            sbMailBody = new StringBuilder(System.IO.File.ReadAllText(CommonResource.MailTemplatePath + "\\" + TemplateName));
            sbMailBody.Replace("[JobNo]", reassignedJobs.JobNo);
            sbMailBody.Replace("[OldPMName]", reassignedJobs.OldPMName);
            sbMailBody.Replace("[OldPMEmailId]", reassignedJobs.OldPMEmailId);
            sbMailBody.Replace("[NewPMName]", reassignedJobs.NewPMName);
            sbMailBody.Replace("[NewPMEmailId]", reassignedJobs.NewPMEmailId);
            sbMailBody.Replace("[UserName]", reassignedJobs.ReassignedBy);
            sbMailBody.Replace("[Regards]", "Expert Source Mailer");
            sbMailBody.Replace("[Expert_Source]", "ESPro");
            MailService objMail = new MailService();
            objMail.SendMail(sbMailBody.ToString(), MailSubject, reassignedJobs.NewPMEmailId, reassignedJobs.OldPMEmailId + "; " + reassignedJobs.ReassignedEmailId);
        }
    }
}
