﻿using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Microsoft.AspNetCore.Hosting;

namespace ESPro.Infrastructure.Service
{
    public class TestService : ITestInterface
    {
      

        private IHostingEnvironment _hostingEnvironment;

        public TestService(Microsoft.AspNetCore.Hosting.IHostingEnvironment environment)
        {
            _hostingEnvironment = environment;
        }
        public TestService()
        {

        }
        public string GetData()
        {
            return "Ravi";
        }
        public string MapPath(string path)
        {
            var filePath = Path.Combine(_hostingEnvironment.ContentRootPath, path);
            return filePath;
        }
        public List<FSConfigModel> GetFSConfig()
        {
           // DbContext.DbUser.ExecuteDataSet("GetFSConfig")
           return CommonResource.ToCollection<FSConfigModel>(DbContext.DbUser.ExecuteDataSet("GetFSConfig").Tables[0]);
            //return DbContext.DbUser.ExecuteSprocAccessor<FSConfigModel>("GetFSConfig").ToList();
        }
    }
}
