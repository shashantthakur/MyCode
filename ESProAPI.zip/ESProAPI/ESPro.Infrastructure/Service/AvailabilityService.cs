﻿using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Infrastructure.Service
{
    public class AvailabilityService : IAvailability
    {
        public int ApplyLeave(Availability availability)
        {
            if(availability.WeekOffDays==null)
            {
                availability.WeekOffDays = "";
            }
           
            int cnt = DbContext.DbUser.ExecuteNonQuery("usp_UpSertAvailabilityMaster", availability.AvailabilityId, availability.UsersId,
                availability.EventTypeId, availability.StartDate, availability.EndDate, availability.Year, availability.Month, availability.EventTitle, availability.Description, availability.WeekOffDays);
            return cnt;
        }

        public int DeleteAvailability(int AvailabilityId)
        {
            int cnt = DbContext.DbUser.ExecuteNonQuery("usp_DeleteAvailability", AvailabilityId);
            return cnt;
        }

        
        public List<Availability> CheckAvailability(int UsersId, DateTime StartDate, DateTime EndDate,int AvailabilityId)
        {
            return CommonResource.ToCollection<Availability>(DbContext.DbUser.ExecuteDataSet("usp_CheckAvailability", UsersId, StartDate, EndDate, AvailabilityId).Tables[0]);
        }

        public List<AvailabilityList> GetAvailability(int UsersId,  int Month, int Year, int AvailabilityId)
        {
            return CommonResource.ToCollection<AvailabilityList>(DbContext.DbUser.ExecuteDataSet("usp_GetAvailability", UsersId, Month, Year, AvailabilityId).Tables[0]);
        }
        
    }
    

}
