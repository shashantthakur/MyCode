﻿using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ESPro.Infrastructure.Service
{
    public class SmartAssessorService : ISmartAssessor
    {

        public bool AddCommentToQuestion(AddCommentToQuestionParameter addCommentToQuestionParameter)
        {
            Boolean flag = false;
            try
            {
                int cnt = DbContext.DbUser.ExecuteNonQuery("usp_InsertSAReportProblemToQuestion", addCommentToQuestionParameter.SATestRegistrationID, addCommentToQuestionParameter.QuestionID, addCommentToQuestionParameter.UserID, addCommentToQuestionParameter.Comment);
                if (cnt > 0)
                    flag = true;
            }
            catch (Exception ex)
            {

            }
            return flag;
        }

        public int TestFailCount(int UserID, string TestType)
        {
            int FailCount = 0;
            var xyz = CommonResource.ToCollection<SmartAssessorTest>(DbContext.DbUser.ExecuteDataSet("usp_GetSmartAssessorGivenTestDetails", UserID, TestType).Tables[0]);
            for (int i = 0; i < xyz.Count; i++)
            {
                if (xyz[i].Status == 1)
                    break;
                FailCount++;
            }
            return FailCount;
        }

        public List<SmartAssessorTest> GetSmartAssessorTestDetailsEnrolledUser(SmartAssessorTestParamaters smartAssessorTestParamaters)
        {
            var abc = CommonResource.ToCollection<SmartAssessorTest>(DbContext.DbUser.ExecuteDataSet("usp_GetSmartAssessorTestDetailsEnrolledUser", smartAssessorTestParamaters.FromWhere).Tables[0]);
            return abc;
        }

        public List<SmartAssessorTest> GetSmartAssessorAllTestList(int UserID)
        {
            var abc = CommonResource.ToCollection<SmartAssessorTest>(DbContext.DbUser.ExecuteDataSet("usp_GetSmartAssessorGivenAllTestDetails", UserID).Tables[0]);
            return abc;
        }

        public List<CertificatePassedOnDetails> GetCertificatePassedOn(int UserID, string CertificateType)
        {
            var abc = CommonResource.ToCollection<CertificatePassedOnDetails>(DbContext.DbUser.ExecuteDataSet("STP_GetCertificatePassedOn", UserID, CertificateType).Tables[0]);
            return abc;
        }

        public List<SmartAssessorTest> GetSmartAssessorTestList(SmartAssessorTestParamaters smartAssessorTestParamaters)
        {
            int FailCount = TestFailCount(smartAssessorTestParamaters.UserId, smartAssessorTestParamaters.TestType);
            var abc = CommonResource.ToCollection<SmartAssessorTest>(DbContext.DbUser.ExecuteDataSet("usp_GetSmartAssessorTestDetails", smartAssessorTestParamaters.UserId, smartAssessorTestParamaters.TestType, FailCount).Tables[0]);
            for (int i = 0; i < abc.Count; i++)
            {
                abc[i].ExcerptFile = CommonResource.ExcerptPath + "\\" + abc[i].SmartAssessorTestID + "\\" + abc[i].ExcerptFile;
            }
            return abc;
        }

        public int SmartAssessorReActiveTest(int UserID, string TestType)
        {
            object cnt = DbContext.DbUser.ExecuteScalar("STP_UpdateSmartAssessorReActiveTest", UserID, TestType);
            return Convert.ToInt32(cnt);
        }

        public int AllocateTest(AllocateTest allocateTest)
        {
            object cnt = DbContext.DbUser.ExecuteScalar("STP_InsertUpdateSmartAssessorTestRegistration", allocateTest.TestRegistrationID, allocateTest.UsersId, allocateTest.TestID, allocateTest.CRUDAction);
            return Convert.ToInt32(cnt);
        }

        public SkillQuestion GetQuestionsOnSmartAssessor(int UsesId, int TestID, int TestRegistrationId)
        {
            SkillQuestion skillQuestion = CommonResource.ToCollection<SkillQuestion>(DbContext.DbUser.ExecuteDataSet("STP_GetSmartAssessorQuestionForUser", UsesId, TestID, TestRegistrationId).Tables[0]).FirstOrDefault();

            if (skillQuestion != null)
            {
                IEnumerable<SkillQuestionOption> _skillQuestionOption = CommonResource.ToCollection<SkillQuestionOption>(DbContext.DbUser.ExecuteDataSet("STP_GetSmartAssessorQuestionOption", skillQuestion.QuestionMasterID).Tables[0]);
                skillQuestion.Options = _skillQuestionOption;
            }
            return skillQuestion;
        }

        public TestResult SaveTest(QuestionOptionModel questionOptionModel)
        {
            try
            {
                int IsRight = 1;
                var abc = CommonResource.ToCollection<SkillQuestionOption>(DbContext.DbUser.ExecuteDataSet("STP_GetSmartAssessorRightAnswers", questionOptionModel.QuestionID).Tables[0]);
                if (abc[0].OptionID != questionOptionModel.OptionID)
                    IsRight = 0;

                TestResult testResult = CommonResource.ToCollection<TestResult>(DbContext.DbUser.ExecuteDataSet("STP_SmartAssessorSaveAnswer", questionOptionModel.QuestionID, questionOptionModel.UserID, questionOptionModel.TestID, questionOptionModel.TestRegistrationID, questionOptionModel.OptionID, questionOptionModel.CrudAction, IsRight).Tables[0]).FirstOrDefault();
                int FailCount = TestFailCount(questionOptionModel.UserID, questionOptionModel.TestType);
                if (FailCount == 3)
                {
                    CommonResource.ToCollection<TestResult>(DbContext.DbUser.ExecuteDataSet("STP_InsertUpdateSmartAssessorReActiveTest", questionOptionModel.UserID, questionOptionModel.TestType).Tables[0]).FirstOrDefault();
                }
                if (testResult.ErrorCode == "000")
                {
                    testResult.ErrorCode = "success";

                }
                else if (testResult.ErrorCode == "111")
                {
                    testResult.ErrorCode = "pass";

                }
                else if (testResult.ErrorCode == "1111")
                {
                    testResult.ErrorCode = "passf";

                }
                else if (testResult.ErrorCode == "222")
                {
                    testResult.ErrorCode = "fail";
                }
                else if (testResult.ErrorCode.Equals("2222"))
                {
                    testResult.ErrorCode = "failf";
                }
                else
                {
                    testResult.ErrorCode = "error";
                }
                return testResult;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public List<SmartAssessorTestResult> GetSmartAssessorTestResult(int UsesId, int TestRegistrationId)
        {
            List<SmartAssessorTestResult> SmartAssessorTestResult = CommonResource.ToCollection<SmartAssessorTestResult>(DbContext.DbUser.ExecuteDataSet("usp_GetSmartAssessorTestResult", UsesId, TestRegistrationId).Tables[0]).ToList();
            return SmartAssessorTestResult;
        }


        public SkillQuestion GetFeedbackQuestionsOnSmartAssessor(int UsesId, int TestRegistrationId)
        {
            SkillQuestion skillQuestion = CommonResource.ToCollection<SkillQuestion>(DbContext.DbUser.ExecuteDataSet("STP_GetSmartAssessorFeedbackQuestionForUser", UsesId, TestRegistrationId).Tables[0]).FirstOrDefault();

            if (skillQuestion != null)
            {
                IEnumerable<SkillQuestionOption> _skillQuestionOption = CommonResource.ToCollection<SkillQuestionOption>(DbContext.DbUser.ExecuteDataSet("STP_GetSmartAssessorFeedbackQuestionOption", skillQuestion.QuestionMasterID).Tables[0]);
                skillQuestion.Options = _skillQuestionOption;
            }
            return skillQuestion;
        }

        public TestResult SaveFeedback1Answer(QuestionOptionModel questionOptionModel)
        {
            try
            {
                TestResult testResult = CommonResource.ToCollection<TestResult>(DbContext.DbUser.ExecuteDataSet("STP_SmartAssessorFeedback1SaveAnswer", questionOptionModel.QuestionID, questionOptionModel.UserID, questionOptionModel.TestRegistrationID, questionOptionModel.OptionID, questionOptionModel.CrudAction).Tables[0]).FirstOrDefault();

                if (testResult.ErrorCode == "000")
                {
                    testResult.ErrorCode = "success";

                }
                else
                {
                    testResult.ErrorCode = "error";
                }
                return testResult;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public SkillQuestion GetFeedbackDescQuestionsOnSmartAssessor(int UsesId, int TestRegistrationId, int FeedbackQuestionMasterID)
        {
            SkillQuestion skillQuestion = CommonResource.ToCollection<SkillQuestion>(DbContext.DbUser.ExecuteDataSet("STP_GetFeedbackDescQuestionsOnSmartAssessor", UsesId, TestRegistrationId, FeedbackQuestionMasterID).Tables[0]).FirstOrDefault();
            return skillQuestion;
        }

        public TestResult SaveFeedback2Answer(QuestionOptionModel questionOptionModel)
        {
            try
            {
                TestResult testResult = CommonResource.ToCollection<TestResult>(DbContext.DbUser.ExecuteDataSet("STP_SmartAssessorFeedback2SaveAnswer", questionOptionModel.QuestionID, questionOptionModel.UserID, questionOptionModel.TestRegistrationID, questionOptionModel.DescAns, questionOptionModel.CrudAction).Tables[0]).FirstOrDefault();

                if (testResult.ErrorCode == "000")
                {
                    testResult.ErrorCode = "success";
                }
                else
                {
                    testResult.ErrorCode = "error";
                }
                return testResult;
            }
            catch (Exception ex)
            {
                throw;
            }
        }


    }
}
