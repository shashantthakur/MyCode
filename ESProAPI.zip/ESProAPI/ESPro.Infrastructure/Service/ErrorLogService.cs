﻿using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Infrastructure.Service
{
   public class ErrorLogService: IErrorLog
    {
        public int InsertErrorLog(ErrorLog errorLog)
        {
            return DbContext.DbUser.ExecuteNonQuery("usp_ErrorLog", errorLog.RequestUri, errorLog.Host, errorLog.UsersId, errorLog.UserName, errorLog.StatusCode, errorLog.Type, errorLog.Message);
           
        }
    }
}
