﻿using ESPro.Core.Entity;
using ESPro.Core.Entity.JobPost;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ESPro.Infrastructure.Service
{
    public class JobPostService : IJobPost
    {
        public List<UserMaster> GetJobPostedBy()
        {
            List<UserMaster> lstJobPostedBy = CommonResource.ToCollection<UserMaster>(DbContext.DbUser.ExecuteDataSet("usp_GetPostJobByList").Tables[0]);
            return lstJobPostedBy;
        }

        public List<JobPost> GetPostJobList(SearchJobPostParameters data)
        {
            List<JobPost> lstJobPost = CommonResource.ToCollection<JobPost>(DbContext.DbUser.ExecuteDataSet("usp_GetPostJobList", Convert.ToInt32(0 + data.PostJobId),  data.UserId, Convert.ToString("" + data.UserRole), Convert.ToString("" + data.Type), data.PostedFrom, data.PostedTo, data.ProjectStartDate, data.ProjectEndDate, data.SearchJobType, data.SearchJobPostedBy).Tables[0]);


            if (!string.IsNullOrEmpty(data.country))
            {
                List<JobPost> temp = new List<JobPost>();
                string[] dis = data.country.Split(',');
                foreach (JobPost item in lstJobPost)
                {
                    string[] itemArray = item.Country.Split(',');
                    var intersect = itemArray.Intersect(dis);
                    if (intersect.Count() > 0)
                    {
                        temp.Add(item);
                    }
                }
                lstJobPost = temp;
            }


            if (!string.IsNullOrEmpty( data.SubDiscipline))
            {
                List<JobPost> temp = new List<JobPost>();
                string[] dis = data.SubDiscipline.Split(',');
                foreach (JobPost item in lstJobPost)
                {
                    string[] FieldArray = item.Field.Split(',');
                    var intersect = FieldArray.Intersect(dis);
                    if(intersect.Count()>0)
                    {
                        temp.Add(item);
                    }
                }
                lstJobPost = temp;
            }

            if (!string.IsNullOrEmpty(data.Skills))
            {
                List<JobPost> temp = new List<JobPost>();
                string[] dis = data.Skills.Split(',');
                foreach (JobPost item in lstJobPost)
                {
                    string[] itemArray = item.Skills.Split(',');
                    var intersect = itemArray.Intersect(dis);
                    if (intersect.Count() > 0)
                    {
                        temp.Add(item);
                    }
                }
                lstJobPost = temp;
            }

            return lstJobPost;
        }

        public List<JobPostUserInfo> GetPostJobUsersInfoList(SearchJobPostParameters data)
        {
            if (data.LikeDislikeType == "MailReplied" || data.LikeDislikeType == "MailNotReplied")
            {
                List<JobPostUserInfo> lstJobPostUserInfo = CommonResource.ToCollection<JobPostUserInfo>(DbContext.DbUser.ExecuteDataSet("usp_GetPostJobUsersMailInfo", data.PostJobId, data.LikeDislikeType, data.Type).Tables[0]);
                return lstJobPostUserInfo;
            }
            else
            {
                List<JobPostUserInfo> lstJobPostUserInfo = CommonResource.ToCollection<JobPostUserInfo>(DbContext.DbUser.ExecuteDataSet("usp_GetPostJobUsersInfo", data.PostJobId, data.LikeDislikeType, data.Type).Tables[0]);
                return lstJobPostUserInfo;
            }
            
        }

        public int SaveJobPostInfo(JobPost jobPost)
        {
            int cnt = 0;
            if (jobPost.Type == "Insert" || jobPost.Type == "Update")
                cnt = DbContext.DbUser.ExecuteNonQuery("usp_InsertUpdateJobPost", jobPost.Id, jobPost.Title, jobPost.Description, jobPost.Field, jobPost.SystemFamilarity, jobPost.Skills, jobPost.Stylesheets, jobPost.Languages, jobPost.Country, jobPost.BudgetCurrency, jobPost.BudgetAmount, jobPost.StartDate, jobPost.EndDate, jobPost.InsertedBy, jobPost.Type,jobPost.IsHighPriority);
            else
                cnt = DbContext.DbUser.ExecuteNonQuery("usp_ExpireUnExpireJobPost", jobPost.Id, jobPost.Type);
            return cnt;
        }

        public int SaveJobPostUsersInfo(JobPost jobPost)
        {
            int cnt = DbContext.DbUser.ExecuteNonQuery("usp_InsertUsersJobPost", jobPost.Id, jobPost.MoreInfo, jobPost.InsertedBy, jobPost.TrainingLikeDisLikeFlagDetailsId);
            return cnt;
        }

        public int MarkAsRepliedUsersJobPostMail(JobPostUserInfo jobPost)
        {
            int cnt = DbContext.DbUser.ExecuteNonQuery("usp_MarkAsRepliedUsersJobPostMail", jobPost.JobPostInfoId, jobPost.JobPostUsersInfoId, jobPost.JobPostedByUsersId);
            return cnt;
        }

        
    }
}
