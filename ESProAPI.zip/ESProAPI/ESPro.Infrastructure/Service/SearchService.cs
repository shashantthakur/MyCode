﻿using ESPro.Core.Interface;
using System;
using System.Collections.Generic;
using System.Text;
using ESPro.Infrastructure.Class;
using ESPro.Core.Entity.Search;
using System.Linq;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Configuration;
using ESPro.Core.Entity.Client;
using ESPro.Core.Entity;
using System.Data.SqlClient;
using System.Data;

namespace ESPro.Infrastructure.Service
{
    public class SearchService : ISearch
    {
        public IConfiguration _Configuration { get; }
        public AgencyService _agency = new AgencyService();

        public List<SaveSearch> GetUserWiseSaveSearch(UserWiseSaveSearchParameters datas)
        {
            var abc = CommonResource.ToCollection<SaveSearch>(DbContext.DbUser.ExecuteDataSet("usp_GetSaveSearch", datas.UserID, datas.SaveSearchID).Tables[0]);
            return abc;
        }

        public List<userResult> GetFreelancersFromFilter(FilterSearch search, out int totalcount, bool extra = false)
        {
            List<string> str = new List<string>();
            UserWiseSaveSearchParameters searchdatas = new UserWiseSaveSearchParameters { SaveSearchID = search.filterid };
            SaveSearch lst = GetUserWiseSaveSearch(searchdatas).FirstOrDefault();
            SearchParameters datas = new SearchParameters();
            datas.Agency = lst.Agency;
            datas.currentpage = 1;
            datas.DDLPreferedFLVal = lst.PreferedFreelancer;
            datas.Freelancer = lst.FreelancerNameID;
            datas.Stylesheets = lst.Stylesheet;
            datas.Skill = lst.Skills;
            datas.Keywords = lst.Keywords;
            datas.Language = lst.Languages;
            datas.Location = lst.Country;
            datas.Familiarity = lst.LevelOfSystemFamilarity;
            datas.System = lst.SystemPlatformFamilarity;
            datas.IsPreferedFL = lst.PreferredFreelancerBoolean == "Yes" ? true : false;
            datas.IsLuminaCertFL = lst.LuminaCertification == "Yes" ? true : false;
            datas.Discipline = lst.Field;
            datas.Qualification = lst.LevelOfField;
            datas.pageSize = 5;
            datas.currentusersid = lst.UserID;
            UserDetailsService _userDetails = new UserDetailsService(_Configuration);
            var ud = _userDetails.GetUserProfile(lst.UserID);
            datas.currentuseremailid = ud.UserName;
            datas.currentuserrole = ud.UserRole;
            datas.sort = "";
            datas.dir = "";
            datas.Statuses = "";
            datas.Rating = "";
            datas.RatingVal = "";
            datas.isStaffSearch = "false";
            datas.Client_code = search.Client_code;
            totalcount = 0;
            //SearchParameters datas = CommonResource.ToCollection<FreelancerTabModel>(DbContext.DbUser.ExecuteDataSet("usp_FreelancerList", Role, userid, CurrentUserRole, Client_code, keyword).Tables[0]).ToList();
            var dt = GetFreelancerData(datas, out totalcount, extra).Select(a => new userResult { UserEmailId = a.User_id, UsersId = a.ID, UserName = a.Username, UserRole = a.User_role }).ToList();
            return dt;
        }

        public List<FilterList> GetFilterList(int UsersId)
        {
            var abc = CommonResource.ToCollection<FilterList>(DbContext.DbUser.ExecuteDataSet("usp_GetSaveSearch", UsersId, 0).Tables[0]);
            return abc;
        }

        public List<FreelancerTabModelAward> GetFreelancerData(SearchParameters datas, out int totalcount, bool extra = false)
        {
            bool IsPM;
            bool IsStaff;
            List<FreelancerTabModelAward> lstFreelancerTabModelAward = new List<FreelancerTabModelAward>();
            bool.TryParse(datas.IsPMRole, out IsPM);
            IsPM = CheckIsValidForPMView(datas.currentuserrole, IsPM);
            bool.TryParse(datas.isStaffSearch, out IsStaff);
            IsStaff = CheckIsValidForPMView(datas.currentuserrole, IsStaff);
            List<FreelancerTabModel> result = new List<FreelancerTabModel>();

            if (IsPM)
                result = GetFreelancerTabDetailsQM(datas.currentusersid, datas.currentuserrole, datas.Client_code, out totalcount, Convert.ToString(userRole.QUALITYMANAGER), datas.Keywords, datas, IsPM, IsStaff, extra);
            else if (IsStaff)
                result = GetFreelancerTabDetailsQM(datas.currentusersid, datas.currentuserrole, datas.Client_code, out totalcount, Convert.ToString(userRole.LUMINAOTHERS), datas.Keywords, datas, IsPM, IsStaff, extra);
            else
                result = GetFreelancerTabDetailsQM(datas.currentusersid, datas.currentuserrole, datas.Client_code, out totalcount, Convert.ToString(userRole.FREELANCER), datas.Keywords, datas, IsPM, IsStaff, extra);
            SaveSearch srch = new SaveSearch();
            if (datas.flag != 0)
            {
                srch = GetUserWiseSaveSearch(new UserWiseSaveSearchParameters { SaveSearchID = datas.flag, UserID = 0 }).FirstOrDefault();
                if (datas.from != "table")
                    updateFreelancerFilterDate(datas.flag);
            }

            foreach (FreelancerTabModel Item in result.OrderByDescending(a => a.LastUpdatedDate))
            {
                FreelancerTabModelAward temp = new FreelancerTabModelAward();
                temp.ID = Item.ID;
                temp.CertificationName = Item.CertificationName;
                temp.Location = Item.Location;
                temp.Rating = Item.Rating;
                temp.user_status = Item.user_status;
                temp.Username = Item.Username;
                temp.User_id = Item.User_id;
                temp.Agency = Item.Agency;
                temp.User_role = Item.User_role;
                temp.IsTestCompleted = Item.IsTestCompleted;
                temp.ClientName = Item.ClientName;
                temp.PreferredFreelancer = Item.PreferredFreelancer;
                temp.Comments = Item.Comments;
                temp.LastUpdatedDate = Item.LastUpdatedDate;
                if (datas.from != "table")
                    temp.IsNew = ((Item.LastUpdatedDate > srch.LastAccessedOn) && srch.LastAccessedOn.GetValueOrDefault().Year != 1) ? 1 : 0;
                else
                    temp.IsNew = ((Item.LastUpdatedDate > srch.PreviousSearchDate) && srch.LastAccessedOn.GetValueOrDefault().Year != 1) ? 1 : 0;
                temp.ExpertArea = Item.ExpertArea;
                temp.SystemName = Item.SystemName;
                temp.Stylesheets = Item.Stylesheets;
                temp.Skills = Item.Skills;
                temp.Language = Item.Language;
                lstFreelancerTabModelAward.Add(temp);
            }
            return lstFreelancerTabModelAward;
        }
        public bool CheckIsValidForPMView(string currentRole, bool isPMSearch)
        {
            if (isPMSearch)
            {
                if (currentRole.Equals(Convert.ToString(userRole.SUPERADMIN)) || currentRole.Equals(Convert.ToString(userRole.ADMIN)) || currentRole.Equals(Convert.ToString(userRole.CLIENT)) || currentRole.Equals(Convert.ToString(userRole.CLIENTADMIN)) || currentRole.Equals(Convert.ToString(userRole.LUMINASUPERVISOR)))
                    isPMSearch = true;
                else
                    isPMSearch = false;
            }
            return isPMSearch;
        }



        public List<FreelancerTabModel> GetFreelancerTabDetailsQM(int userid, string CurrentUserRole, string Client_code, out int totalcount, string Role = "FREELANCER", string keyword = "", SearchParameters datavariables = null, bool isPM = false, bool IsStaff = false, bool extra = false)
        {
            if (datavariables == null)
            {
                datavariables = new SearchParameters();
            }
            totalcount = 0;
            string qualification = "";
            string Familiarity = "";
            if (Role.Equals(Convert.ToString(userRole.FREELANCER)))
            {
                Role = "FREELANCER,AGENCY";
            }
            else if (Role.Equals(Convert.ToString(userRole.LUMINAOTHERS)))
            {
                Role = "PROJECTMANAGER,LUMINAOTHERS,ADMIN,HUMANRESOURCE,FINANCEMANAGER";
            }
            if (!string.IsNullOrEmpty(keyword) && !string.IsNullOrWhiteSpace(keyword))
            {
                List<string> lst = keyword.Split(',').Select(b => @"""" + b + @"""").ToList();
                keyword = string.Join(" or ", lst);
            }
            if (!string.IsNullOrEmpty(datavariables.Familiarity))
            {
                List<string> lst = datavariables.Familiarity.Split(',').Select(b => b.Trim() + @"= 1 ").ToList();
                Familiarity = string.Join(" and ", lst);
                if (!string.IsNullOrEmpty(Familiarity))
                {
                    Familiarity = " and " + Familiarity;
                }
            }
            if (!string.IsNullOrEmpty(datavariables.Qualification))
            {
                List<string> lst = datavariables.Qualification.Split(',').Select(b => b.Trim() + @" = 1").ToList();
                qualification = string.Join(" and ", lst);
                if (!string.IsNullOrEmpty(qualification))
                {
                    qualification = " and " + qualification;
                }
            }
            if (String.IsNullOrEmpty(Client_code))
                Client_code = "0";
            //List<FreelancerTabModel> result = CommonResource.ToCollection<FreelancerTabModel>(DbContext.DbUser.ExecuteDataSet("usp_FreelancerList", Role, userid, CurrentUserRole, Client_code, keyword).Tables[0]).ToList();

            DataSet ds = new DataSet();



            DataTable dts = new DataTable();





            if (string.IsNullOrEmpty(datavariables.Freelancer))
                datavariables.Freelancer = "";
            var vs = datavariables.Freelancer.Split(',').Select(b => new { filter = b }).Where(a => !string.IsNullOrEmpty(a.filter)).ToList();
            if (vs.Count > 0)
            {
                var json = Newtonsoft.Json.JsonConvert.SerializeObject(vs);
                dts = Newtonsoft.Json.JsonConvert.DeserializeObject<DataTable>(json);
            }
            else
            {
                dts = new DataTable();
                dts.Columns.Add("filter");
            }
            ds.Tables.Add(dts);
            if (string.IsNullOrEmpty(datavariables.Qualification))
                datavariables.Qualification = "";
            vs = (datavariables.Qualification.Split(',').Select(b => new { filter = b })).Where(a => !string.IsNullOrEmpty(a.filter)).ToList();
            if (vs.Count > 0)
            {
                var json = Newtonsoft.Json.JsonConvert.SerializeObject(vs);
                dts = Newtonsoft.Json.JsonConvert.DeserializeObject<DataTable>(json);
            }
            else
            {
                dts = new DataTable();
                dts.Columns.Add("filter");
            }
            ds.Tables.Add(dts);
            if (string.IsNullOrEmpty(datavariables.Discipline))
                datavariables.Discipline = "";
            vs = (datavariables.Discipline.Split(',').Select(b => new { filter = b })).Where(a => !string.IsNullOrEmpty(a.filter)).ToList();
            if (vs.Count > 0)
            {
                var json = Newtonsoft.Json.JsonConvert.SerializeObject(vs);
                dts = Newtonsoft.Json.JsonConvert.DeserializeObject<DataTable>(json);
            }
            else
            {
                dts = new DataTable();
                dts.Columns.Add("filter");
            }
            ds.Tables.Add(dts);
            if (string.IsNullOrEmpty(datavariables.Familiarity))
                datavariables.Familiarity = "";
            vs = datavariables.Familiarity.Split(',').ToList().Select(b => new { filter = b }).Where(a => !string.IsNullOrEmpty(a.filter)).ToList();
            if (vs.Count > 0)
            {
                var json = Newtonsoft.Json.JsonConvert.SerializeObject(vs);
                dts = Newtonsoft.Json.JsonConvert.DeserializeObject<DataTable>(json);
            }
            else
            {
                dts = new DataTable();
                dts.Columns.Add("filter");
            }
            ds.Tables.Add(dts);
            if (string.IsNullOrEmpty(datavariables.System))
                datavariables.System = "";
            vs = (datavariables.System.Split(',').Select(b => new { filter = b })).Where(a => !string.IsNullOrEmpty(a.filter)).ToList();
            if (vs.Count > 0)
            {
                var json = Newtonsoft.Json.JsonConvert.SerializeObject(vs);
                dts = Newtonsoft.Json.JsonConvert.DeserializeObject<DataTable>(json);
            }
            else
            {
                dts = new DataTable();
                dts.Columns.Add("filter");
            }
            ds.Tables.Add(dts);
            if (string.IsNullOrEmpty(datavariables.Skill))
                datavariables.Skill = "";
            vs = (datavariables.Skill.Split(',').Select(b => new { filter = b })).Where(a => !string.IsNullOrEmpty(a.filter)).ToList();
            if (vs.Count > 0)
            {
                var json = Newtonsoft.Json.JsonConvert.SerializeObject(vs);
                dts = Newtonsoft.Json.JsonConvert.DeserializeObject<DataTable>(json);
            }
            else
            {
                dts = new DataTable();
                dts.Columns.Add("filter");
            }
            ds.Tables.Add(dts);
            if (string.IsNullOrEmpty(datavariables.Stylesheets))
                datavariables.Stylesheets = "";
            vs = (datavariables.Stylesheets.Split(',').Select(b => new { filter = b })).Where(a => !string.IsNullOrEmpty(a.filter)).ToList();
            if (vs.Count > 0)
            {
                var json = Newtonsoft.Json.JsonConvert.SerializeObject(vs);
                dts = Newtonsoft.Json.JsonConvert.DeserializeObject<DataTable>(json);
            }
            else
            {
                dts = new DataTable();
                dts.Columns.Add("filter");
            }
            ds.Tables.Add(dts);
            if (string.IsNullOrEmpty(datavariables.Statuses))
                datavariables.Statuses = "";
            vs = (datavariables.Statuses.Split(',').Select(b => new { filter = b })).Where(a => !string.IsNullOrEmpty(a.filter)).ToList();
            if (vs.Count > 0)
            {
                var json = Newtonsoft.Json.JsonConvert.SerializeObject(vs);
                dts = Newtonsoft.Json.JsonConvert.DeserializeObject<DataTable>(json);
            }
            else
            {
                dts = new DataTable();
                dts.Columns.Add("filter");
            }
            ds.Tables.Add(dts);
            if (string.IsNullOrEmpty(datavariables.Language))
                datavariables.Language = "";
            vs = (datavariables.Language.Split(',').Select(b => new { filter = b })).Where(a => !string.IsNullOrEmpty(a.filter)).ToList();
            if (vs.Count > 0)
            {
                var json = Newtonsoft.Json.JsonConvert.SerializeObject(vs);
                dts = Newtonsoft.Json.JsonConvert.DeserializeObject<DataTable>(json);
            }
            else
            {
                dts = new DataTable();
                dts.Columns.Add("filter");
            }
            ds.Tables.Add(dts);
            if (string.IsNullOrEmpty(datavariables.Agency))
                datavariables.Agency = "";
            vs = (datavariables.Agency.Split(',').Select(b => new { filter = b })).Where(a => !string.IsNullOrEmpty(a.filter)).ToList();
            if (vs.Count > 0)
            {
                var json = Newtonsoft.Json.JsonConvert.SerializeObject(vs);
                dts = Newtonsoft.Json.JsonConvert.DeserializeObject<DataTable>(json);
            }
            else
            {
                dts = new DataTable();
                dts.Columns.Add("filter");
            }
            ds.Tables.Add(dts);
            if (string.IsNullOrEmpty(datavariables.Location))
                datavariables.Location = "";
            vs = (datavariables.Location.Split(',').Select(b => new { filter = b })).Where(a => !string.IsNullOrEmpty(a.filter)).ToList();
            if (vs.Count > 0)
            {
                var json = Newtonsoft.Json.JsonConvert.SerializeObject(vs);
                dts = Newtonsoft.Json.JsonConvert.DeserializeObject<DataTable>(json);
            }
            else
            {
                dts = new DataTable();
                dts.Columns.Add("filter");
            }
            ds.Tables.Add(dts);
            vs = (Role.Split(',').Select(b => new { filter = b })).Where(a => !string.IsNullOrEmpty(a.filter)).ToList();
            if (vs.Count > 0)
            {
                var json = Newtonsoft.Json.JsonConvert.SerializeObject(vs);
                dts = Newtonsoft.Json.JsonConvert.DeserializeObject<DataTable>(json);
            }
            else
            {
                dts = new DataTable();
                dts.Columns.Add("filter");
            }
            ds.Tables.Add(dts);
            if (string.IsNullOrEmpty(datavariables.DDLPreferedFLVal))
                datavariables.DDLPreferedFLVal = "";
            vs = (datavariables.DDLPreferedFLVal.Split(',').Select(b => new { filter = b })).Where(a => !string.IsNullOrEmpty(a.filter)).ToList();
            if (vs.Count > 0)
            {
                var json = Newtonsoft.Json.JsonConvert.SerializeObject(vs);
                dts = Newtonsoft.Json.JsonConvert.DeserializeObject<DataTable>(json);
            }
            else
            {
                dts = new DataTable();
                dts.Columns.Add("filter");
            }
            ds.Tables.Add(dts);
            SqlConnection con = new SqlConnection(CommonResource.ConString);
            SqlCommand cmd = new SqlCommand();
            DataTable dt = new DataTable();
            cmd.Connection = con;
            if (!extra)
                cmd.CommandText = "usp_FreelancerListNew";
            else
                cmd.CommandText = "usp_FreelancerListNewExtra";
            cmd.Parameters.AddWithValue("@UserId", userid);
            cmd.Parameters.AddWithValue("@UserRole", CurrentUserRole);
            cmd.Parameters.AddWithValue("@ClientCode", Client_code);
            cmd.Parameters.AddWithValue("@Keyword", keyword != null ? keyword : @"");
            cmd.Parameters.AddWithValue("@freelancers", ds.Tables[0]);
            cmd.Parameters.AddWithValue("@qualification", qualification);
            cmd.Parameters.AddWithValue("@discipline", ds.Tables[2]);
            cmd.Parameters.AddWithValue("@system", ds.Tables[4]);
            cmd.Parameters.AddWithValue("@Familiarity", Familiarity);
            cmd.Parameters.AddWithValue("@skill", ds.Tables[5]);
            cmd.Parameters.AddWithValue("@stylesheets", ds.Tables[6]);
            cmd.Parameters.AddWithValue("@statuses", ds.Tables[7]);
            cmd.Parameters.AddWithValue("@language", ds.Tables[8]);
            cmd.Parameters.AddWithValue("@agency", ds.Tables[9]);
            cmd.Parameters.AddWithValue("@location", ds.Tables[10]);
            cmd.Parameters.AddWithValue("@Role", ds.Tables[11]);
            cmd.Parameters.AddWithValue("@DDLPreferedFLVal", ds.Tables[12]);
            cmd.Parameters.AddWithValue("@Rating", datavariables.Rating);
            decimal? ratingVal = null;
            if (!string.IsNullOrEmpty(datavariables.RatingVal))
            {
                ratingVal = Convert.ToDecimal(datavariables.RatingVal);
            }
            cmd.Parameters.AddWithValue("@RatingVal", ratingVal);
            cmd.Parameters.AddWithValue("@IsPM", isPM);
            cmd.Parameters.AddWithValue("@IsStaff", IsStaff);
            cmd.Parameters.AddWithValue("@isPreferedFL", datavariables.IsPreferedFL);
            cmd.Parameters.AddWithValue("@isLuminaCertFL", datavariables.IsLuminaCertFL);
            cmd.Parameters.AddWithValue("@currentPage", datavariables.currentpage);
            cmd.Parameters.AddWithValue("@pagesize", datavariables.pageSize);
            cmd.Parameters.AddWithValue("@sort", datavariables.sort == "" ? null : datavariables.sort);
            cmd.Parameters.AddWithValue("@dir", datavariables.dir == "" ? null : datavariables.dir);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 60000;
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            if (con.State == ConnectionState.Closed)
                con.Open();
            DataSet dtds = new DataSet();
            adp.Fill(dtds);
            con.Close();
            totalcount = Convert.ToInt32(dtds.Tables[0].Rows[0][0]);
            return CommonResource.ToCollection<FreelancerTabModel>(dtds.Tables[1]);

        }


        public List<FreelancerTabSearchModel> GetFreelancerTabSearchDetailsQM(int userid, string CurrentUserRole, string Client_code, string Role = "FREELANCER", string keyword = "")
        {
            if (Role.Equals(Convert.ToString(userRole.FREELANCER)))
            {
                Role = "FREELANCER,AGENCY";
            }
            else if (Role.Equals(Convert.ToString(userRole.LUMINAOTHERS)))
            {
                Role = "PROJECTMANAGER,LUMINAOTHERS,ADMIN,HUMANRESOURCE,FINANCEMANAGER";
            }
            if (!string.IsNullOrEmpty(keyword) && !string.IsNullOrWhiteSpace(keyword))
            {
                List<string> lst = keyword.Split(',').Select(b => @"""" + b + @"""").ToList();
                keyword = string.Join(" or ", lst);
            }
            if (String.IsNullOrEmpty(Client_code))
                Client_code = "0";
            //List<FreelancerTabModel> result = CommonResource.ToCollection<FreelancerTabModel>(DbContext.DbUser.ExecuteDataSet("usp_FreelancerList", Role, userid, CurrentUserRole, Client_code, keyword).Tables[0]).ToList();


            SqlConnection con = new SqlConnection(CommonResource.ConString);
            SqlCommand cmd = new SqlCommand();
            DataTable dt = new DataTable();
            cmd.Connection = con;
            cmd.CommandText = "usp_FreelancerListSearch";
            cmd.Parameters.AddWithValue("@Role", Role);
            cmd.Parameters.AddWithValue("@UserId", userid);
            cmd.Parameters.AddWithValue("@UserRole", CurrentUserRole);
            cmd.Parameters.AddWithValue("@ClientCode", Client_code);
            cmd.Parameters.AddWithValue("@Keyword", keyword != null ? keyword : "");
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 60000;
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            if (con.State == ConnectionState.Closed)
                con.Open();
            adp.Fill(dt);
            con.Close();
            return CommonResource.ToCollection<FreelancerTabSearchModel>(dt);

        }

        public void updateFreelancerFilterDate(int saveid)
        {
            DbContext.DbUser.ExecuteScalar("uspUpdateFreelancerFilterDate", saveid);
        }

        public List<FSCompResult> GetFSCompMatching(int UsersId)
        {
            return CommonResource.ToCollection<FSCompResult>(DbContext.DbUser.ExecuteDataSet("FSResultCompareNew", UsersId).Tables[0]).ToList();
        }

        public List<ExistingRecord> GetSelectedSkillFreelancer(string selectedSkill, int userid)
        {
            return CommonResource.ToCollection<ExistingRecord>(DbContext.DbUser.ExecuteDataSet("sp_selectedSkills_freelancer", selectedSkill, userid).Tables[0]).ToList();
        }

        public string InsertUpdateDeleteSaveSearch(SaveSearch saveSearch)
        {
            try
            {
                var Jobmodel = CommonResource.ToCollection<SaveSearch>(DbContext.DbUser.ExecuteDataSet("usp_InsertUpdateDeleteSaveSearch", Convert.ToInt32("0" + saveSearch.SaveSearchID), saveSearch.SaveSearchName, saveSearch.Field, saveSearch.LevelOfField, saveSearch.Languages, saveSearch.Keywords, saveSearch.SystemPlatformFamilarity, saveSearch.LevelOfSystemFamilarity, saveSearch.Country, saveSearch.Agency, saveSearch.FreelancerName, saveSearch.Skills, saveSearch.Stylesheet, saveSearch.PreferedFreelancer, Convert.ToBoolean(saveSearch.PreferredFreelancerBoolean) == true ? 1 : 0, Convert.ToBoolean(saveSearch.LuminaCertification) == true ? 1 : 0, saveSearch.UserID, saveSearch.Action).Tables[0]).FirstOrDefault();
                return "Success";

            }
            catch (Exception ex)
            {
                return ex.Message.ToString();
                //throw;
            }
        }

        public List<SearchTermsAccepted> GetSearchTermsAcceptedDetails(int UsersID)
        {
            var abc = CommonResource.ToCollection<SearchTermsAccepted>(DbContext.DbUser.ExecuteDataSet("usp_GetSearchTerms", UsersID).Tables[0]);
            return abc;
        }

        public int SaveSearchTerms(int UserID)
        {
            int count = DbContext.DbUser.ExecuteNonQuery("usp_SaveSearchTerms", UserID);
            return count;
        }

        public int SaveUsersComment(UsersComment usersComment)
        {
            int count = DbContext.DbUser.ExecuteNonQuery("usp_UpSertUsersComment", usersComment.UsersId, usersComment.CommenterId, usersComment.Comment);
            return count;
        }

        public int DeleteUsersComment(UsersComment usersComment)
        {
            int count = DbContext.DbUser.ExecuteNonQuery("usp_DeleteUsersComment", usersComment.UsersId, usersComment.CommenterId);
            return count;
        }

        public UsersComment GetUsersComment(UsersComment usersComment)
        {
            var abc = CommonResource.ToCollection<UsersComment>(DbContext.DbUser.ExecuteDataSet("usp_GetUsersComment", usersComment.UsersId, usersComment.CommenterId).Tables[0]).FirstOrDefault();
            return abc;
        }

    }
}
