﻿using ESPro.Core.Entity.Report;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using Newtonsoft.Json;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Text;

namespace ESPro.Infrastructure.Service
{
    public class ReportService : IReport
    {

        public List<TestCompletedUsers> GetTestCompletedUsers(string UserRole, int ReportID)
        {
            var abc = new List<TestCompletedUsers>();
            if (ReportID == 28)
                abc = CommonResource.ToCollection<TestCompletedUsers>(DbContext.DbUser.ExecuteDataSet("usp_GetSmartAssessorTestCompletedUsers").Tables[0]);
            else
                abc = CommonResource.ToCollection<TestCompletedUsers>(DbContext.DbUser.ExecuteDataSet("usp_GetTestCompletedUsers", UserRole).Tables[0]);
            return abc;
        }

        public List<CustomeRoles> GetAllCustomeRoles(int ClientCode)
        {
            //List<CustomeRoles> customeRoles = new List<CustomeRoles>();
            //customeRoles.Add(new CustomeRoles { ID = 1, RoleName = "Freelancer" });
            //customeRoles.Add(new CustomeRoles { ID = 2, RoleName = "Lumina Staff" });
            //customeRoles.Add(new CustomeRoles { ID = 2, RoleName = "Project Manager" });
            //customeRoles.Add(new CustomeRoles { ID = 2, RoleName = "Client" });
            //customeRoles.Add(new CustomeRoles { ID = 2, RoleName = "All" });
            //return customeRoles;
            var abc = CommonResource.ToCollection<CustomeRoles>(DbContext.DbUser.ExecuteDataSet("usp_GetCustomeRoles", Convert.ToString(ClientCode)).Tables[0]);
            return abc;
        }

        //public List<ExistingRecord> GetSelectedSkillFreelancer(string selectedSkills, string UserEmailID)
        //{
        //    List<object> parameters = new List<object>() { selectedSkills, Convert.ToInt16(UserEmailID) };
        //    return CommonResource.ToCollection<ExistingRecord>(DbContext.DbUser.ExecuteDataSet("sp_selectedSkills_freelancer", parameters.ToArray()).Tables[0]);
        //}

        public List<ReportType> GetReportTypes(string UserRole, int ClientId)
        {
            var abc = CommonResource.ToCollection<ReportType>(DbContext.DbUser.ExecuteDataSet("usp_GetReportName", UserRole, ClientId).Tables[0]);
            return abc;
        }
        public List<CustomerWorked> GetCustomerWorked()
        {
            var abc = CommonResource.ToCollection<CustomerWorked>(DbContext.DbUser.ExecuteDataSet("usp_GetCustomerWorked").Tables[0]);
            return abc;
        }

        public List<MasterOverdueReports> GetOverdueReportTypes(string UserRole)
        {
            var abc = CommonResource.ToCollection<MasterOverdueReports>(DbContext.DbUser.ExecuteDataSet("usp_GetOverdueReportName", UserRole).Tables[0]);
            return abc;
        }

        public List<MasterRatingCompositeReport> GetRatingCompositeReportTypes(string UserRole)
        {
            var abc = CommonResource.ToCollection<MasterRatingCompositeReport>(DbContext.DbUser.ExecuteDataSet("usp_GetRatingCompositeReportName", UserRole).Tables[0]);
            return abc;
        }

        public List<ServiceReport> GetServiceReportList(string StartDate, string EndDate, string Role, string UserEmailID, int ClientCode)
        {
            var abc = CommonResource.ToCollection<ServiceReport>(DbContext.DbUser.ExecuteDataSet("usp_GetServiceReport", Role, StartDate, EndDate, UserEmailID, ClientCode).Tables[0]);
            return abc;
        }

        public List<RatingReport> GetRatingReportList(string UserEmailID, string Role, string Skill)
        {
            var abc = CommonResource.ToCollection<RatingReport>(DbContext.DbUser.ExecuteDataSet("usp_GetRatingReport", UserEmailID, Role, Skill).Tables[0]);
            return abc;
        }

        public List<SubDisciplineRatingReport> GetSubDisciplineRatingReportList(string UserEmailID, string Role, string Skill)
        {
            var abc = CommonResource.ToCollection<SubDisciplineRatingReport>(DbContext.DbUser.ExecuteDataSet("usp_GetSubDisciplineRatingReport", UserEmailID, Role, Skill).Tables[0]);
            return abc;
        }
        

        public List<OverDueReport> GetOverDueReportList(string UserEmailID, string UserRole, int ClientCode, int OverdueReportID)
        {
            var abc = CommonResource.ToCollection<OverDueReport>(DbContext.DbUser.ExecuteDataSet("usp_GetOverDueReport", UserEmailID, UserRole, ClientCode, OverdueReportID).Tables[0]);
            return abc;
        }

        public List<OverDueReport> GetOverDueEndDateReportList()
        {
            var abc = CommonResource.ToCollection<OverDueReport>(DbContext.DbUser.ExecuteDataSet("Service_Overdue_End_Date_Report").Tables[2]);
            return abc;
        }

        public List<PersonalInsights> GetPersonalInsightsList(string Role)
        {
            var abc = CommonResource.ToCollection<PersonalInsights>(DbContext.DbUser.ExecuteDataSet("usp_GetPersonalInsightsReport", Role).Tables[0]);
            return abc;
        }

        public DataTable GetPredictiveTestingList(string Role)
        {
            //var abc = CommonResource.ToCollection<PredictiveTestingReport>(DbContext.DbUser.ExecuteDataSet("usp_GetPredictiveTestingReport", Role).Tables[0]);
            //return abc;

            SqlConnection con = new SqlConnection(CommonResource.ConString);
            SqlCommand cmd = new SqlCommand();
            DataTable dt = new DataTable();
            cmd.Connection = con;
            cmd.CommandText = "usp_GetPredictiveTestingReport";
            cmd.Parameters.AddWithValue("@UserRole", Role);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 60000;
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            if (con.State == ConnectionState.Closed)
                con.Open();
            adp.Fill(dt);
            con.Close();
            return dt;
        }

        public List<RatingCompositeReport> GetRatingCompositeReports(int ClientCode, string CustomeRoles, string Role, int RatingCompositeReportID)
        {
            var abc = CommonResource.ToCollection<RatingCompositeReport>(DbContext.DbUser.ExecuteDataSet("usp_GetRatingCompositeReport", ClientCode, CustomeRoles, Role, RatingCompositeReportID).Tables[0]);
            return abc;
        }

        public List<FLInvoicesPendingPMApprovalReport> GetFLInvoicesPendingPMApprovalReports(string ReportType)
        {
            var abc = new List<FLInvoicesPendingPMApprovalReport>();
            string para = null;
            if (ReportType == "Wiley")
                abc = CommonResource.ToCollection<FLInvoicesPendingPMApprovalReport>(DbContext.DbUser.ExecuteDataSet("usp_GetWileyFLInvoicesPendingPMApprovalReport", para).Tables[2]);
            else
                abc = CommonResource.ToCollection<FLInvoicesPendingPMApprovalReport>(DbContext.DbUser.ExecuteDataSet("usp_GetLuminaFLInvoicesPendingPMApprovalReport").Tables[2]);
            return abc;
        }

        public List<RatingHistoryReport> GetRatingHistoryReports(string UserEmailID, string FreelancerEmailID, int ClientCode, string Role)
        {
            var abc = CommonResource.ToCollection<RatingHistoryReport>(DbContext.DbUser.ExecuteDataSet("usp_GetRatingHistoryReport", UserEmailID, FreelancerEmailID, ClientCode, Role).Tables[0]);
            return abc;
        }

        public List<LuminaFreelancerCost> GetLuminaFreelancerCosts(string StartDate, string EndDate, int ClientCode)
        {
            var abc = CommonResource.ToCollection<LuminaFreelancerCost>(DbContext.DbUser.ExecuteDataSet("usp_GetLuminaFreelanceCostReport", StartDate, EndDate, ClientCode).Tables[0]);
            return abc;
        }

        public List<WileyFreelancerCost> GetWileyFreelancerCost(string StartDate, string EndDate, int ClientCode, string Currency, string Limit)
        {
            var abc = CommonResource.ToCollection<WileyFreelancerCost>(DbContext.DbUser.ExecuteDataSet("usp_GetWileyFreelanceCostReport", StartDate, EndDate, ClientCode, Currency, Limit).Tables[0]);
            return abc;
        }
        public List<TaskReport> GetTaskReport(string UserEmailID, string UserRole, string Skills, int ClientCode)
        {
            var abc = CommonResource.ToCollection<TaskReport>(DbContext.DbUser.ExecuteDataSet("usp_GetTaskReport", UserEmailID, UserRole, Skills, ClientCode).Tables[0]);
            return abc;
        }
        public List<FreelancerRollOff> GetFreelancerRollOff()
        {
            var abc = CommonResource.ToCollection<FreelancerRollOff>(DbContext.DbUser.ExecuteDataSet("Service_Freelancer_Roll_Off").Tables[2]);
            return abc;
        }

        public List<AdHocMLReport> GetAdHocMLReport()
        {
            var abc = CommonResource.ToCollection<AdHocMLReport>(DbContext.DbUser.ExecuteDataSet("usp_GetMLAdhocReport").Tables[0]);
            return abc;
        }

        public List<MacMillanFreelancerDetails> GetMacMillanFreelancerDetails()
        {
            var abc = CommonResource.ToCollection<MacMillanFreelancerDetails>(DbContext.DbUser.ExecuteDataSet("Service_Macmilan_Report").Tables[2]);
            return abc;
        }

        public List<MacMillanCompletedJobs> GetMacMillanCompletedJobs()
        {
            var abc = CommonResource.ToCollection<MacMillanCompletedJobs>(DbContext.DbUser.ExecuteDataSet("Service_Macmilan_Report").Tables[3]);
            return abc;
        }

        public List<MacMillanPendingJobs> GetMacMillanPendingJobs()
        {
            var abc = CommonResource.ToCollection<MacMillanPendingJobs>(DbContext.DbUser.ExecuteDataSet("Service_Macmilan_Report").Tables[4]);
            return abc;
        }

        public DataTable SmartAssessorReportPerTest(string UserID, int TestID)
        {
            DataTable dataTable = new DataTable();
            SqlConnection con = new SqlConnection(CommonResource.ConString);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "usp_GetSmartAssessorReport";
            cmd.Parameters.AddWithValue("@UserID", UserID);
            cmd.Parameters.AddWithValue("@TestID", TestID);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 120;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            if (con.State == ConnectionState.Closed)
                con.Open();
            da.Fill(dataTable);
            con.Close();
            return dataTable;
        }

        public DataTable PersonalInsightsInfo(DataTable dt)
        {
            DataSet ds = new DataSet();
            DataTable exportDataTable = new DataTable();
            Console.ForegroundColor = ConsoleColor.Green;
            string displaysresult = string.Empty;
            exportDataTable.Columns.Add("UserId", typeof(string));
            exportDataTable.Columns.Add("User_Name", typeof(string));
            exportDataTable.Columns.Add("Agency_Name", typeof(string));
            exportDataTable.Columns.Add("User_Role", typeof(string));
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                dynamic objectProperty = JsonConvert.DeserializeObject<dynamic>(Convert.ToString(dt.Rows[i]["Result"]));
                if (objectProperty == null)
                    continue;
                if (string.IsNullOrEmpty(Convert.ToString(objectProperty.data)))
                    continue;
                var dict = JsonConvert.DeserializeObject<Dictionary<string, string>>(objectProperty.data.ToString());
                string value = string.Empty;
                DataRow dr = exportDataTable.NewRow();
                dr["UserId"] = (Convert.ToString(dt.Rows[i]["EmailId"]));
                dr["Agency_Name"] = (Convert.ToString(dt.Rows[i]["AgencyName"]));
                dr["User_Role"] = Convert.ToString(dt.Rows[i]["user_role"]);
                dr["User_Name"] = Convert.ToString(dt.Rows[i]["username"]);
                exportDataTable.Rows.Add(dr);
                foreach (var item in dict)
                {

                    if (!string.IsNullOrEmpty(item.Value))
                    {
                        double actulResult = Convert.ToDouble(item.Value) * 100;
                        value = Convert.ToString(Math.Round(actulResult, 1));
                        value += "%";
                    }
                    DataRow dynamicDataRow = exportDataTable.NewRow();

                    DataColumnCollection columns = exportDataTable.Columns;
                    if (!columns.Contains(item.Key))
                    {
                        exportDataTable.Columns.Add(item.Key, typeof(string));
                    }
                    dr[item.Key] = value;
                }
            }

            // fill the dataset to
            return exportDataTable;
        }

        public DataTable DTRatingCompositeReport(DataTable dt)
        {
            DataTable exportDataTable = new DataTable();
            DataSet ds = new DataSet();
            Console.ForegroundColor = ConsoleColor.Green;
            string displaysresult = string.Empty;
            exportDataTable.Columns.Add("UserId", typeof(string));
            exportDataTable.Columns.Add("UserName", typeof(string));
            exportDataTable.Columns.Add("AgencyName", typeof(string));
            exportDataTable.Columns.Add("Client", typeof(string));
            exportDataTable.Columns.Add("OverAllRating", typeof(string));
            exportDataTable.Columns.Add("AdherenceToSchedule", typeof(string));
            exportDataTable.Columns.Add("Communication", typeof(string));
            exportDataTable.Columns.Add("OverallQualityOfWork", typeof(string));
            exportDataTable.Columns.Add("OfProjectRated", typeof(string));
            exportDataTable.Columns.Add("Country", typeof(string));
            exportDataTable.Columns.Add("user_Role", typeof(string));
            exportDataTable.Columns.Add("Tasks", typeof(string));
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow dr = exportDataTable.NewRow();
                dr["UserId"] = (Convert.ToString(dt.Rows[i]["UserId"]));
                dr["UserName"] = (Convert.ToString(dt.Rows[i]["Name"]));
                dr["AgencyName"] = (Convert.ToString(dt.Rows[i]["AgencyName"]));
                dr["Client"] = (Convert.ToString(dt.Rows[i]["Clients"]));
                dr["OverAllRating"] = (Convert.ToString(dt.Rows[i]["OverAllRating"]));
                dr["AdherenceToSchedule"] = (Convert.ToString(dt.Rows[i]["AdherenceToSchedule"]));
                dr["Communication"] = (Convert.ToString(dt.Rows[i]["Communication"]));
                dr["OverallQualityOfWork"] = (Convert.ToString(dt.Rows[i]["OverallQualityOfWork"]));
                dr["OfProjectRated"] = (Convert.ToString(dt.Rows[i]["OfProjectRated"]));
                dr["Country"] = (Convert.ToString(dt.Rows[i]["Location"]));
                dr["user_Role"] = (Convert.ToString(dt.Rows[i]["userRole"]));
                dr["Tasks"] = (Convert.ToString(dt.Rows[i]["Skills"]));
                exportDataTable.Rows.Add(dr);
                if (!string.IsNullOrEmpty(Convert.ToString(dt.Rows[i]["Result"])))
                {
                    dynamic objectProperty = JsonConvert.DeserializeObject<dynamic>(Convert.ToString(dt.Rows[i]["Result"]));
                    if (objectProperty == null && string.IsNullOrEmpty(Convert.ToString(objectProperty.data)))
                        continue;

                    var dict = JsonConvert.DeserializeObject<Dictionary<string, string>>(objectProperty.data.ToString());
                    string value = string.Empty;
                    foreach (var item in dict)
                    {
                        if (!string.IsNullOrEmpty(item.Value))
                        {
                            double actulResult = Convert.ToDouble(item.Value) * 100;
                            value = Convert.ToString(Math.Round(actulResult, 1));
                            value += "%";
                        }
                        DataRow dynamicDataRow = exportDataTable.NewRow();

                        DataColumnCollection columns = exportDataTable.Columns;
                        if (!columns.Contains(item.Key))
                        {
                            exportDataTable.Columns.Add(item.Key, typeof(string));
                        }
                        dr[item.Key] = value;
                    }
                }
            }
            return exportDataTable;
        }

        public string CheckMarkValues(string DBVal)
        {
            string checkmark = "";
            if (DBVal == "Yes")
                checkmark = "=CHAR(252)";
            //else if (DBVal == "No")
            //    checkmark = "=CHAR(251)";
            else
                checkmark = "";
            return checkmark;
        }

        public byte[] DownloadReport(DataTable dtToExport, int ReportID, int ClientCode, string TemplateFile, string ExportFileName, string FromRows, string ToRows, int HeaderLength, DataTable dtToExport1, DataTable dtToExport2)
        {
            using (var pck = new OfficeOpenXml.ExcelPackage())
            {
                using (var stream = System.IO.File.OpenRead(TemplateFile))
                {
                    pck.Load(stream);
                }

                if (dtToExport.Rows.Count > 0)
                {
                    string modelRange = "";

                    var ws = pck.Workbook.Worksheets[1];

                    if (ReportID == 1)
                    {
                        ws.Column(4).Style.Numberformat.Format = "dd-MMM-yyyy";
                        ws.Column(5).Style.Numberformat.Format = "dd-MMM-yyyy";
                    }
                    else if (ReportID == 4)
                    {
                        ws.Column(5).Style.Numberformat.Format = "dd-MMM-yyyy";
                        if (ExportFileName.StartsWith("Lumina_Overdue_Ratings") || ExportFileName.StartsWith("Wiley_Overdue_Ratings"))
                        {
                            ws.DeleteColumn(20);
                            ws.DeleteColumn(20);
                            ws.DeleteColumn(20);
                        }
                        else
                            ws.DeleteColumn(22);
                    }
                    else if (ExportFileName.StartsWith("Task_Report") && ClientCode != 0)
                    {
                        ws.DeleteColumn(12);
                        ws.DeleteColumn(12);
                        ws.DeleteColumn(12);
                        ws.DeleteColumn(12);
                        ToRows = "N";
                    }
                    else if (ReportID == 20 || ReportID == 26 || ReportID == 27)
                    {
                        string CurrencySymbol = "$";
                        if (ReportID == 26)
                        {
                            CurrencySymbol = "£";
                            ws.Cells["B3"].Style.Numberformat.Format = "£ ###,###,##0.00";
                            ws.Cells["F3"].Value = "When prefunding reaches £50k, the topup of prefunding is required";
                            ws.Cells["J2"].Value = "Please use a new version of this upon each new prefunding payment of £200k";
                            ws.Cells["L4"].Value = "Invoice Amount (GBP)";
                            ws.Cells["M4"].Value = "Banking charge for local currency (GBP)";
                            ws.Cells["R4"].Value = "Amount (GBP)";
                        }

                        ws.Column(3).Style.Numberformat.Format = "dd-MMM-yyyy";
                        ws.Column(4).Style.Numberformat.Format = "dd-MMM-yyyy";
                        ws.Column(11).Style.Numberformat.Format = "###,###,##0.00";
                        ws.Column(12).Style.Numberformat.Format = CurrencySymbol + " ###,###,##0.00";
                        ws.Column(13).Style.Numberformat.Format = CurrencySymbol + " ###,###,##0.00";
                        ws.Column(14).Style.Numberformat.Format = CurrencySymbol + " ###,###,##0.00";
                        ws.Column(15).Style.Numberformat.Format = CurrencySymbol + " ###,###,##0.00";
                        //ws.Column(19).Style.Numberformat.Format = "$ ###,###,##0.00";
                        ws.Column(19).Style.Numberformat.Format = "dd-MMM-yyyy";

                        ws.Column(22).Style.Numberformat.Format = CurrencySymbol + " ###,###,##0.00";
                        ws.Column(24).Style.Numberformat.Format = "dd-MMM-yyyy";

                        Decimal TotalAmount = Convert.ToDecimal(ws.Cells["B3"].Value);

                        for (int i = 0; i < dtToExport.Rows.Count; i++)
                        {
                            if (dtToExport.Rows[i]["isbn13"].ToString().Length == 6)
                            {
                                ws.Cells["H" + (i + 5) + ""].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                ws.Cells["H" + (i + 5) + ""].Style.Fill.BackgroundColor.SetColor(Color.Yellow);
                            }
                            ws.Cells["N" + (i + 5) + ""].Formula = "=L" + (i + 5) + "+M" + (i + 5) + ""; ;
                            if (i == 0)
                                ws.Cells["O" + (i + 5) + ""].Formula = "=B3-N" + (i + 5) + "";
                            else
                                ws.Cells["O" + (i + 5) + ""].Formula = "=O" + (i + 4) + "-N" + (i + 5) + "";
                        }
                    }
                    else if (ReportID == 21)
                    {
                        ws.Column(5).Style.Numberformat.Format = "dd-MMM-yyyy";
                        ws.Column(22).Style.Numberformat.Format = "dd-MMM-yyyy";
                    }
                    else if (ReportID == 23)
                    {
                        dtToExport.Columns.Remove("select");
                        dtToExport.Columns.Remove("ID");
                        dtToExport.Columns.Remove("NoOfJobs");
                        dtToExport.Columns.Remove("FreelancerID");
                        dtToExport.Columns.Remove("DueInDays");
                        dtToExport.Columns.Remove("FLBankInfoId");
                        dtToExport.AcceptChanges();

                        ws.DeleteColumn(1);
                        ws.DeleteColumn(3);
                        ws.DeleteColumn(18);

                        ws.Column(14).Style.Numberformat.Format = "dd-MMM-yyyy";
                        ws.Column(15).Style.Numberformat.Format = "dd-MMM-yyyy";
                        ws.Column(16).Style.Numberformat.Format = "dd-MMM-yyyy";
                        ws.Column(17).Style.Numberformat.Format = "dd-MMM-yyyy";
                        ws.Column(18).Style.Numberformat.Format = "dd-MMM-yyyy";
                    }
                    else if (ReportID == 25)
                    {
                        FromRows = "A2";
                        ToRows = "M";
                        int FromMergeRows = 0, From_MergeRows = 0;
                        int ToMergeRows = 0;
                        Color colFromHex = System.Drawing.ColorTranslator.FromHtml("#98FB98");
                        int OddRows = 0;
                        //ws.Cells[FromRows].LoadFromDataTable(FreelancerProfile, false);
                        for (int i = 0; i < dtToExport.Rows.Count; i++)
                        {
                            try
                            {
                                ws.Cells["A" + (i + 2) + ""].Value = Convert.ToString(dtToExport.Rows[i][0]);
                                ws.Cells["B" + (i + 2) + ""].Value = Convert.ToString(dtToExport.Rows[i][1]);
                                ws.Cells["C" + (i + 2) + ""].Value = Convert.ToString(dtToExport.Rows[i][2]);
                                ws.Cells["D" + (i + 2) + ""].Value = Convert.ToString(dtToExport.Rows[i][3]);
                                ws.Cells["E" + (i + 2) + ""].Formula = CheckMarkValues(Convert.ToString(dtToExport.Rows[i][4]));
                                ws.Cells["E" + (i + 2) + ""].Style.Font.SetFromFont(new Font("Wingdings", 10));
                                ws.Cells["F" + (i + 2) + ""].Formula = CheckMarkValues(Convert.ToString(dtToExport.Rows[i][5]));
                                ws.Cells["F" + (i + 2) + ""].Style.Font.SetFromFont(new Font("Wingdings", 10));
                                ws.Cells["G" + (i + 2) + ""].Formula = CheckMarkValues(Convert.ToString(dtToExport.Rows[i][6]));
                                ws.Cells["G" + (i + 2) + ""].Style.Font.SetFromFont(new Font("Wingdings", 10));
                                ws.Cells["H" + (i + 2) + ""].Formula = CheckMarkValues(Convert.ToString(dtToExport.Rows[i][7]));
                                ws.Cells["H" + (i + 2) + ""].Style.Font.SetFromFont(new Font("Wingdings", 10));
                                ws.Cells["I" + (i + 2) + ""].Formula = CheckMarkValues(Convert.ToString(dtToExport.Rows[i][8]));
                                ws.Cells["I" + (i + 2) + ""].Style.Font.SetFromFont(new Font("Wingdings", 10));
                                ws.Cells["J" + (i + 2) + ""].Value = Convert.ToString(dtToExport.Rows[i][9]);
                                ws.Cells["K" + (i + 2) + ""].Value = Convert.ToString(dtToExport.Rows[i][10]);
                                ws.Cells["L" + (i + 2) + ""].Value = Convert.ToString(dtToExport.Rows[i][11]);
                                ws.Cells["M" + (i + 2) + ""].Value = Convert.ToString(dtToExport.Rows[i][12]);
                                int merge_flag = 0;
                                if (i == 0)
                                    ToMergeRows = FromMergeRows = i + 2;
                                else if (i == (dtToExport.Rows.Count - 1))
                                {
                                    ToMergeRows = i + 2;
                                    merge_flag = 1;
                                }
                                else
                                {
                                    if (Convert.ToString(dtToExport.Rows[i][0]).ToUpper().Trim() == Convert.ToString(dtToExport.Rows[i - 1][0]).ToUpper().Trim())
                                        ToMergeRows = i + 2;
                                    else
                                    {
                                        ToMergeRows = i + 1;
                                        merge_flag = 1;
                                        From_MergeRows = i + 2;
                                    }
                                }
                                if (merge_flag == 1)
                                {
                                    OddRows++;
                                    ws.Cells["A" + FromMergeRows + ":A" + ToMergeRows + ""].Merge = true;
                                    ws.Cells["B" + FromMergeRows + ":B" + ToMergeRows + ""].Merge = true;
                                    ws.Cells["C" + FromMergeRows + ":C" + ToMergeRows + ""].Merge = true;
                                    ws.Cells["J" + FromMergeRows + ":J" + ToMergeRows + ""].Merge = true;
                                    ws.Cells["K" + FromMergeRows + ":K" + ToMergeRows + ""].Merge = true;
                                    ws.Cells["L" + FromMergeRows + ":L" + ToMergeRows + ""].Merge = true;
                                    ws.Cells["M" + FromMergeRows + ":M" + ToMergeRows + ""].Merge = true;

                                    if (OddRows % 2 == 1)
                                    {
                                        ws.Cells["D" + FromMergeRows + ":L" + ToMergeRows.ToString() + ""].Style.Fill.PatternType = ExcelFillStyle.Solid;
                                        ws.Cells["D" + FromMergeRows + ":L" + ToMergeRows.ToString() + ""].Style.Fill.BackgroundColor.SetColor(colFromHex);
                                    }
                                    merge_flag = 0;
                                    FromMergeRows = From_MergeRows;
                                }
                            }
                            catch (Exception ex)
                            {
                                //throw;
                            }
                        }
                    }
                    ws.Cells[FromRows].LoadFromDataTable(dtToExport, false);

                    var modelCells = ws.Cells[FromRows];
                    var modelRows = dtToExport.Rows.Count + HeaderLength;
                    modelRange = FromRows + ":" + ToRows.ToString() + modelRows.ToString();
                    ws.Cells[FromRows + ":" + ToRows.ToString() + modelRows.ToString()].Style.Font.SetFromFont(new Font("Calibri", 10));
                    if (ReportID == 29)
                    {
                        // ws.Cells[FromRows + ":" + ToRows.ToString() + modelRows.ToString()].AutoFitColumns();
                        ws.Cells.AutoFitColumns();
                    }
                    var modelTable = ws.Cells[modelRange];
                    // Assign borders
                    modelTable.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    modelTable.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    modelTable.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    modelTable.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;

                    if (ReportID == 25)
                    {
                        ToRows = "O";
                        ws = pck.Workbook.Worksheets[2];

                        ws.Cells[FromRows].LoadFromDataTable(dtToExport1, false);

                        modelCells = ws.Cells[FromRows];
                        modelRows = dtToExport1.Rows.Count + 1;
                        modelRange = FromRows + ":" + ToRows.ToString() + modelRows.ToString();

                        ws.Column(2).Style.WrapText = true;
                        ws.Column(3).Style.WrapText = true;
                        ws.Column(4).Style.WrapText = true;
                        ws.Column(5).Style.WrapText = true;
                        ws.Column(6).Style.WrapText = true;
                        ws.Column(7).Style.WrapText = true;
                        ws.Column(8).Style.WrapText = true;
                        ws.Column(9).Style.WrapText = true;
                        ws.Column(10).Style.WrapText = true;
                        ws.Column(11).Style.WrapText = true;
                        ws.Column(12).Style.WrapText = true;
                        ws.Column(13).Style.WrapText = true;
                        ws.Column(14).Style.WrapText = true;

                        ws.Cells[FromRows + ":" + ToRows.ToString() + modelRows.ToString()].Style.Font.SetFromFont(new Font("Calibri", 10));
                        modelTable = ws.Cells[modelRange];
                        // Assign borders
                        modelTable.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                        modelTable.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                        modelTable.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                        modelTable.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;


                        //Inprogress Jobs
                        ToRows = "J";
                        ws = pck.Workbook.Worksheets[3];

                        ws.Cells[FromRows].LoadFromDataTable(dtToExport2, false);

                        modelCells = ws.Cells[FromRows];
                        modelRows = dtToExport2.Rows.Count + 1;
                        modelRange = FromRows + ":" + ToRows.ToString() + modelRows.ToString();

                        ws.Column(9).Style.Numberformat.Format = "mm/dd/yyyy";
                        ws.Column(10).Style.Numberformat.Format = "mm/dd/yyyy";

                        ws.Cells[FromRows + ":" + ToRows.ToString() + modelRows.ToString()].Style.Font.SetFromFont(new Font("Calibri", 10));
                        modelTable = ws.Cells[modelRange];
                        // Assign borders
                        modelTable.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                        modelTable.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                        modelTable.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                        modelTable.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    }

                }
                //pck.SaveAs(new System.IO.FileInfo(@"C:\Users\Test\Desktop\New folder\New folder\\DisciplineRatingReport.xlsx"));
                return pck.GetAsByteArray();
            }
        }

        public void FinanceReport()
        {
            string Query = " select EINSSN, pd.FullName,  Street1, City1, state1, PostalCode1,'United States of America',   AccountNumber, UserName,jd.Contracted_Currency, sum(cast(coalesce(SumAmount, '0.00') as float)) TotalAmountInvoice, sum(cast(coalesce(AmountinUSD, '0.00') as float)) AmountInUSDGBP from Users U join personaldetails pd on pd.usersid = u.id Join Addressdetails ad on ad.usersid = u.id join flbankinfo fb on fb.usersid = u.id left join jobdetails jd on U.username = jd.freelanceremailid left join invoicedetails id on jd.jobid = id.jobid left join invoicesummary iis on iis.id = id.invoicesummaryId and year(apactiondate) = 2021 where LocationsId1 = 1 and iis.Status = 'APPROVEDBYAP' and year(apactiondate) = 2021 group by  pd.FullName, fb.FullName, Street1, City1, state1, PostalCode1, UserName, EINSSN, AccountNumber, jd.Contracted_Currency order by UserName";

            string Query_all = "select EINSSN, pd.FullName,  Street1, City1, state1, PostalCode1,Location,  AccountNumber, UserName,jd.Contracted_Currency, sum(cast(coalesce(SumAmount, '0.00') as float)) TotalAmountInvoice, sum(cast(coalesce(AmountinUSD, '0.00') as float)) AmountInUSDGBP from Users U join personaldetails pd on pd.usersid = u.id Join Addressdetails ad on ad.usersid = u.id join flbankinfo fb on fb.usersid = u.id left join jobdetails jd on U.username = jd.freelanceremailid left join invoicedetails id on jd.jobid = id.jobid left join invoicesummary iis on iis.id = id.invoicesummaryId and year(apactiondate)= 2021 join MasterLocations ml on ml.id = ad.LocationsId1 where iis.Status = 'APPROVEDBYAP' and year(apactiondate)= 2021 group by  pd.FullName,fb.FullName ,Street1,City1,state1,PostalCode1,UserName,EINSSN,AccountNumber,jd.Contracted_Currency,Location order by UserName";
            DataTable dt = DbContext.DbUser.ExecuteDataSet(CommandType.Text, Query_all).Tables[0];
            CryptoService cryptoService = new CryptoService();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                dt.Rows[i]["EINSSN"] = cryptoService.Decrypt(dt.Rows[i]["EINSSN"].ToString());
                dt.Rows[i]["AccountNumber"] = cryptoService.Decrypt(dt.Rows[i]["AccountNumber"].ToString());
            }
            DataSetToExcel(dt, "ESPro");
        }
        private void DataSetToExcel(DataTable _dataTable, string fileName)
        {
            string FilePath = "D:\\Report";
            if (File.Exists(FilePath + "\\" + fileName + ".xlsx"))
                File.Delete(FilePath + "\\" + fileName + ".xlsx");
            using (ExcelPackage pck = new ExcelPackage())
            {
                ExcelWorksheet workSheet = pck.Workbook.Worksheets.Add(_dataTable.TableName);
                workSheet.Cells["A1"].LoadFromDataTable(_dataTable, true);

                pck.SaveAs(new FileInfo(FilePath + "\\" + fileName + ".xlsx"));
            }
        }
    }

}
