﻿namespace ESPro.Infrastructure.Service
{
    internal class CommonFunctions
    {
    }
}