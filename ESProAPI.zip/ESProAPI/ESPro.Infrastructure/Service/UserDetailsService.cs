﻿using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ESPro.Infrastructure.Class;
using Microsoft.Extensions.Configuration;
using System.Data;

namespace ESPro.Infrastructure.Service
{

    public class UserDetailsService : IUserDetails
    {
        public IConfiguration _Configuration { get; }

        public UserDetailsService(IConfiguration configuration)
        {
            _Configuration = configuration;
        }
        public List<ComponentPermission> GetComponentPermission(int UsersId, int RoleId, int ClientsId)
        {
            return CommonResource.ToCollection<ComponentPermission>(DbContext.DbUser.ExecuteDataSet("usp_GetComponentPermission", UsersId, RoleId, ClientsId).Tables[0]);
        }

        public int UpdateProfilePic(string image, int usersid)
        {
            int cnt = DbContext.DbUser.ExecuteNonQuery("usp_UpdateProfilePic", image, usersid);
            return cnt;
        }

        public string ForgotUserPassword(UsersDetailsModel ud)
        {
            try
            {
                CryptoService crypt = new CryptoService();
                MailService objMail = new MailService();

                var path = Path.Combine(CommonResource.MailTemplatePath, "ForgotPassword.html");
                StringBuilder sbMailBody = new StringBuilder(System.IO.File.ReadAllText(path));
                sbMailBody.Replace("[Expert_Source]", "ESPro");
                sbMailBody.Replace("[HelloName]", ud.Name.ToLower());
                sbMailBody.Replace("[YourPassword]", crypt.Decrypt(ud.Password));
                sbMailBody.Replace("[LogninLink]", CommonResource.UiUrl);
                sbMailBody.Replace("[Regards]", "Expert Source Mailer");
                //new MailSending().SendEmailAsyn(ProjectResources.strDefaultMailFromName, ud.user_email_id, "", MailSubject, sbMailBody.ToString(), 0, 0);
                return objMail.SendMail(sbMailBody.ToString(), "ESPro: Account Password", ud.UserName, "");
            }
            catch
            { }
            return "";
        }


        public Users getUser(string UsersId)
        {
            return CommonResource.ToCollection<Users>(DbContext.DbUser.ExecuteDataSet("usp_GetUsers", UsersId).Tables[0]).FirstOrDefault();
        }
        public AddressDetails GetAddressDetails(string UsersId)
        {
            return CommonResource.ToCollection<AddressDetails>(DbContext.DbUser.ExecuteDataSet("usp_GetAddressDetails", UsersId).Tables[0]).FirstOrDefault();
        }
        public PersonalDetails GetPersonalDetails(string UsersId)
        {
            return CommonResource.ToCollection<PersonalDetails>(DbContext.DbUser.ExecuteDataSet("usp_GetPersonalDetails", UsersId).Tables[0]).FirstOrDefault();
        }

        public UsersDetails GetUsersDetails(string UsersId)
        {

            UsersDetails usersDetails = new UsersDetails();
            usersDetails.users = getUser(UsersId);
            usersDetails.addressDetails = GetAddressDetails(UsersId);
            usersDetails.personalDetails = GetPersonalDetails(UsersId);


            return usersDetails;
        }



        public int UpdateAddressDetails(AddressDetails addressDetails)
        {

            int cnt = DbContext.DbUser.ExecuteNonQuery("usp_UpdateAddressDetails", addressDetails.UsersId, addressDetails.Street1, addressDetails.City1, addressDetails.State1, addressDetails.PostalCode1, addressDetails.Street2, addressDetails.City2, addressDetails.State2, addressDetails.PostalCode2, addressDetails.LocationsId1, addressDetails.LocationsId2);

            return cnt;
        }
        public int UpdatePersonalDetails(PersonalDetails personalDetails)
        {
            int cnt = DbContext.DbUser.ExecuteNonQuery("usp_UpdatePersonalDetails", personalDetails.UsersId, personalDetails.FullName, personalDetails.Currency, personalDetails.TargetHourlyRate, personalDetails.WireFee, personalDetails.ContactNumber, personalDetails.AlternateContactNumber, personalDetails.Fax, personalDetails.PrimaryContact);
            //Update profile completeness

            return cnt;
        }


        public int UpdateUserSkills(UserSkills userSkills)
        {

            int cnt = 0;


            DbContext.DbUser.ExecuteNonQuery("usp_UpdateUserSkills", userSkills.UsersId, userSkills.WorkTime, userSkills.DigitalContentExperience, userSkills.CompanyName);

            DbContext.DbUser.ExecuteNonQuery("usp_DeleteUserSkillsMapping", userSkills.UsersId, "MasterLanguages");

            foreach (int id in userSkills.Languages)
            {
                cnt += InsertSkills(userSkills.UsersId, id, "MasterLanguages");
            }
            DbContext.DbUser.ExecuteNonQuery("usp_DeleteUserSkillsMapping", userSkills.UsersId, "MasterSkills");
            foreach (int id in userSkills.Skills)
            {
                cnt += InsertSkills(userSkills.UsersId, id, "MasterSkills");
            }

            DbContext.DbUser.ExecuteNonQuery("usp_DeleteUserSkillsMapping", userSkills.UsersId, "MasterStylesheet");
            foreach (int id in userSkills.Stylesheets)
            {
                cnt += InsertSkills(userSkills.UsersId, id, "MasterStylesheet");
            }

            DbContext.DbUser.ExecuteNonQuery("usp_DeleteUserSkillsMapping", userSkills.UsersId, "MasterSubDisciplines");
            foreach (int id in userSkills.SubDisciplines)
            {
                cnt += InsertSkills(userSkills.UsersId, id, "MasterSubDisciplines");
            }
            DbContext.DbUser.ExecuteNonQuery("usp_DeleteUserSkillsMapping", userSkills.UsersId, "MasterSystemFamilarity");
            foreach (int id in userSkills.SystemFamilarity)
            {
                cnt += InsertSkills(userSkills.UsersId, id, "MasterSystemFamilarity");
            }

            //DisciplineEducationLevel
            DbContext.DbUser.ExecuteNonQuery("usp_DeleteDisciplineEducationLevel", userSkills.UsersId);

            foreach (UserDisciplineEducationLevel userDiscEduLevel in userSkills.userDisciplineEducationLevels)
            {
                cnt += DbContext.DbUser.ExecuteNonQuery("usp_InsertDisciplineEducationLevel", userDiscEduLevel.UsersId, userDiscEduLevel.SubDisciplinesId, userDiscEduLevel.WorkingKnowledgeOnly, userDiscEduLevel.CollegeDegree, userDiscEduLevel.MasterDegree, userDiscEduLevel.PhD, userDiscEduLevel.TeachingExperience);
            }

            //SystemExperienceLevel
            DbContext.DbUser.ExecuteNonQuery("usp_DeleteSystemExperienceLevel", userSkills.UsersId);

            foreach (UserSystemExperienceLevel userSysExpLevel in userSkills.userSystemExperienceLevels)
            {
                cnt += DbContext.DbUser.ExecuteNonQuery("usp_InsertSystemExperienceLevel", userSysExpLevel.UsersId, userSysExpLevel.SystemFamilarityId, userSysExpLevel.Beginner, userSysExpLevel.Experienced, userSysExpLevel.Advanced);
            }

            //Update profile completeness



            return cnt;
        }

        public int InsertSkills(int? UsersId, int? SkillId, string TableName)
        {
            return DbContext.DbUser.ExecuteNonQuery("usp_InsertUserSkillsMapping", UsersId, SkillId, TableName);
        }

        public List<FreelancerList> GetFreelancer()
        {
            return CommonResource.ToCollection<FreelancerList>(DbContext.DbUser.ExecuteDataSet("usp_GetFreelancers").Tables[0]);
        }

        public UserSkills GetUserSkills(int UsersId)
        {
            UserSkills userSkills = new UserSkills();
            UserSkillsSingle userSkillsSingle = CommonResource.ToCollection<UserSkillsSingle>(DbContext.DbUser.ExecuteDataSet("usp_GetUserSkills", UsersId).Tables[0]).FirstOrDefault();

            if (userSkillsSingle != null)
            {
                userSkills.CompanyName = userSkillsSingle.CompanyName;
                userSkills.DigitalContentExperience = userSkillsSingle.DigitalContentExperience;
                userSkills.WorkTime = userSkillsSingle.WorkTime;
            }

            //List<UserSelectedSkills> UserSelectedSkills = CommonResource.ToCollection<UserSelectedSkills>(DbContext.DbUser.ExecuteDataSet("usp_GetUserSkillsMapping", UsersId).Tables[0]);

            //userSkills.Languages = UserSelectedSkills.Where(p2 => p2.TableName == "MasterLanguages").Select(p2 => p2.FieldId).ToList();
            //userSkills.Skills = UserSelectedSkills.Where(p2 => p2.TableName == "MasterSkills").Select(p2 => p2.FieldId).ToList();
            //userSkills.SubDisciplines = UserSelectedSkills.Where(p2 => p2.TableName == "MasterSubDisciplines").Select(p2 => p2.FieldId).ToList();
            //userSkills.SystemFamilarity = UserSelectedSkills.Where(p2 => p2.TableName == "MasterSystemFamilarity").Select(p2 => p2.FieldId).ToList();

                  userSkills.Languages = CommonResource.ToCollection<UserSelectedSkills>(DbContext.DbUser.ExecuteDataSet("usp_GetUserSkillsMapping", UsersId, "MasterLanguages").Tables[0]).Select(p2 => p2.FieldId).ToList();
            userSkills.Skills = CommonResource.ToCollection<UserSelectedSkills>(DbContext.DbUser.ExecuteDataSet("usp_GetUserSkillsMapping", UsersId, "MasterSkills").Tables[0]).Select(p2 => p2.FieldId).ToList();
            userSkills.Stylesheets = CommonResource.ToCollection<UserSelectedSkills>(DbContext.DbUser.ExecuteDataSet("usp_GetUserSkillsMapping", UsersId, "MasterStylesheet").Tables[0]).Select(p2 => p2.FieldId).ToList();
            userSkills.SubDisciplines = CommonResource.ToCollection<UserSelectedSkills>(DbContext.DbUser.ExecuteDataSet("usp_GetUserSkillsMapping", UsersId, "MasterSubDisciplines").Tables[0]).Select(p2 => p2.FieldId).ToList(); 

            userSkills.SystemFamilarity = CommonResource.ToCollection<UserSelectedSkills>(DbContext.DbUser.ExecuteDataSet("usp_GetUserSkillsMapping", UsersId, "MasterSystemFamilarity").Tables[0]).Select(p2 => p2.FieldId).ToList();


            userSkills.userDisciplineEducationLevels = CommonResource.ToCollection<UserDisciplineEducationLevel>(DbContext.DbUser.ExecuteDataSet("usp_GetDisciplineEducationLevel", UsersId).Tables[0]);
            userSkills.userSystemExperienceLevels = CommonResource.ToCollection<UserSystemExperienceLevel>(DbContext.DbUser.ExecuteDataSet("usp_GetSystemExperienceLevel", UsersId).Tables[0]);

            return userSkills;
        }
        //public WritingSample GetUserWritingSample(int UsersId)
        //{
        //    WritingSample writingSample = new WritingSample();
        //    writingSample= CommonResource.ToCollection<WritingSample>(DbContext.DbUser.ExecuteDataSet("usp_GetUserWrittingSample", UsersId).Tables[0]).FirstOrDefault();
        //    List<UserSelectedClients> userSelectedClients = CommonResource.ToCollection<UserSelectedClients>(DbContext.DbUser.ExecuteDataSet("usp_GetUserClientMapping", UsersId).Tables[0]);

        //    writingSample.ClientId= userSelectedClients.Select(p2 => p2.ClientsId.Value).ToList();
        //    return writingSample;
        //}
        //public int UpdateUserWritingSample(WritingSample writingSample)
        //{
        //    int cnt = DbContext.DbUser.ExecuteNonQuery("usp_UpdateUserWrittingSample", writingSample.UsersId, writingSample.Headline, writingSample.WrittingSample);

        //    DbContext.DbUser.ExecuteNonQuery("usp_DeleteUserClientMapping", writingSample.UsersId);

        //    foreach (int ClientId in writingSample.ClientId)
        //    {
        //        cnt += DbContext.DbUser.ExecuteNonQuery("usp_InsertUserClientMapping", writingSample.UsersId, ClientId);
        //    }

        //    return cnt;
        //}

        public UserFLComments GetUserFLComments(int UsersId, string UserRole, int ClientId)
        {

            UserFLComments userFLComments = new UserFLComments();
            userFLComments = CommonResource.ToCollection<UserFLComments>(DbContext.DbUser.ExecuteDataSet("usp_GetFLComments", UsersId).Tables[0]).FirstOrDefault();

            //if (UserRole == "CLIENT")
            if (UserRole == "CLIENT" && userFLComments != null)
            {
                DataTable dataTable = DbContext.DbUser.ExecuteDataSet("usp_GetFLClientComments", UsersId, ClientId).Tables[0];
                //userFLComments.ClientComment = (dataTable == null || dataTable.Rows.Count == 0) ? "" : Convert.ToString("" + dataTable.Rows[0][0]);
                userFLComments.ClientComment = "";
                if(dataTable.Rows.Count > 0)
                    userFLComments.ClientComment = Convert.ToString("" + dataTable.Rows[0][0]);
            }
            var ds = DbContext.DbUser.ExecuteDataSet("usp_GetUserClientMapping", UsersId);
            List<UserSelectedClients> userSelectedClients = CommonResource.ToCollection<UserSelectedClients>(ds.Tables[0]);
            List<UserSelectedClients> userSelectedPreferredClients = CommonResource.ToCollection<UserSelectedClients>(ds.Tables[1]);

            if (userFLComments != null)
            {
                userFLComments.ClientId = userSelectedClients.Select(p2 => p2.ClientsId.Value).ToList();
                userFLComments.PreferredId = userSelectedPreferredClients.Select(p2 => p2.ClientsId.Value).ToList();
            }
            return userFLComments;
        }
        public int UpdateFLComments(UserFLComments writingSample)
        {
            int cnt = DbContext.DbUser.ExecuteNonQuery("usp_UpdateFLComments", writingSample.UsersId, writingSample.Headline, writingSample.FLComments);

            DbContext.DbUser.ExecuteNonQuery("usp_DeleteUserClientMapping", writingSample.UsersId);
            if (writingSample.ClientId != null)
            {
                foreach (int ClientId in writingSample.ClientId)
                {
                    Boolean preferred = writingSample.PreferredId.Where(b => b == ClientId).Count() > 0 ? true : false;
                    cnt += DbContext.DbUser.ExecuteNonQuery("usp_InsertUserClientMapping", writingSample.UsersId, ClientId, preferred);
                }
            }
            return cnt;
        }

        public UserProfile GetUserProfile(int UsersId)
        {
            return CommonResource.ToCollection<UserProfile>(DbContext.DbUser.ExecuteDataSet("usp_GetUserProfile", UsersId).Tables[0]).FirstOrDefault();
        }

        public int UpdateResumeSample(int UsersId, string ResumeFilePath, string SampleFilePath, string LinkToOnlineProfile)
        {
            int cnt = DbContext.DbUser.ExecuteNonQuery("usp_UpdateResumeSample", UsersId, ResumeFilePath, SampleFilePath, LinkToOnlineProfile);


            return cnt;
        }

        public UserResumeSample GetUserResumeSample(int UsersId)
        {
            UserResumeSample userResumeSample = new UserResumeSample();
            userResumeSample = CommonResource.ToCollection<UserResumeSample>(DbContext.DbUser.ExecuteDataSet("usp_GetUserResumeSample", UsersId).Tables[0]).FirstOrDefault();

            if (userResumeSample != null)
            {
                //if (userResumeSample.ResumeFilePath != null)
                //    userResumeSample.ResumeFilePath = CommonResource.ResumePathUrl + "/" + userResumeSample.ResumeFilePath.Replace("\\", "/");
                //if (userResumeSample.SampleFilePath != null)
                //    userResumeSample.SampleFilePath = CommonResource.SamplePathUrl + "/" + userResumeSample.SampleFilePath.Replace("\\", "/");
            }

            return userResumeSample;
        }


        public async Task SaveFile(string path, IFormFile file, string fileName)
        {
            try
            {
                if (file != null && file.Length > 0)
                {
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }
                    var filePath = Path.Combine(path, fileName);

                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        await file.CopyToAsync(fileStream);
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }


        public int SaveGeneralComments(AdminComments data)
        {
            int cnt = DbContext.DbUser.ExecuteNonQuery("sp_upsertComments", data.usersid, data.GenComment.Replace("'", "''"), data.CurrentUserRole, data.CurrentClientcode, data.CurrentUsersId, data.ClientComments.Replace("'", "''"));
            //SqlConnection con = (SqlConnection)dbUser.CreateConnection();
            //SqlCommand cmd = new SqlCommand();
            //cmd.Connection = con;
            //cmd.CommandText = @"update UserOtherInfo set GenComments = '" + data.GenComment.Replace("'", "''") + "' where user_id = '" + emailid + "'";
            //con.Open();
            //SqlDataAdapter adp = new SqlDataAdapter(cmd);
            //DataTable dt = new DataTable();
            //adp.Fill(dt);

            //if (MySessionData.User_Role == "CLIENT")
            //{
            //    cmd.CommandText = @"insert into FLClientCommentsMapping (UserID, ClientProjectID, ClientUserID, LastUpdated, ClientComments) values ( (select pk_id from user_details where user_id='" + emailid + "'), " + MySessionData.Client_code + ", " + MySessionData.MyUserID + ", getdate(), '" + ClientComments.Replace("'", "''") + "')";
            //    adp = new SqlDataAdapter(cmd);
            //    adp.Fill(dt);
            //}
            //con.Close();
            return cnt;
        }



        public List<UserRoles> GetUserRoles(int UsersId, string CurrentRole)
        {
            var abc = CommonResource.ToCollection<UserRoles>(DbContext.DbUser.ExecuteDataSet("usp_GetUserRoles", UsersId, CurrentRole).Tables[0]);
            return abc;
        }

        public UserProfileCompleteness getUserProfileCompleteness(int UsersId, int RoleId)
        {
            return CommonResource.ToCollection<UserProfileCompleteness>(DbContext.DbUser.ExecuteDataSet("GetUserProfileCompletness", UsersId, RoleId).Tables[0]).FirstOrDefault();
        }

        public int DeleteProfile(int UsersId, int RoleId)
        {
            int cnt = DbContext.DbUser.ExecuteNonQuery("DeleteAccount", UsersId, RoleId);
            return cnt;
        }

        public List<UsersDetailsModel> GetUserUsersId(string EmailID)
        {
            var cnt = CommonResource.ToCollection<UsersDetailsModel>(DbContext.DbUser.ExecuteDataSet("usp_GetUsersId", EmailID).Tables[0]);
            return cnt;
        }

        public bool DeleteProfileFromConnect(string UserEmailId)
        {
            string ErrorMsg = "", FullError = "";
            List<KeyValuePair<string, string>> keyValuePair = new List<KeyValuePair<string, string>>();
            keyValuePair.Add(new KeyValuePair<string, string>("Token", Convert.ToString(_Configuration["InvToken"])));
            keyValuePair.Add(new KeyValuePair<string, string>("Email", UserEmailId));
            bool result = CommonResource.InvoicePostRequestAsync<InvoiceModelData>("DeleteFreelancerProfile", keyValuePair, out ErrorMsg, out FullError);
            return result;
        }

        public Boolean CallApiForChangeEmail(string OldEmail, string NewEmail, string Type)
        {
            bool result = false;
            try
            {
                ChangeEmail changeEmail = new ChangeEmail();
                changeEmail.oldEmail = OldEmail;
                if (Type == "Change")
                {
                    changeEmail.newEmail = NewEmail;
                    changeEmail.isDeleted = false;
                }
                else
                {
                    changeEmail.newEmail = "";
                    changeEmail.isDeleted = true;
                }
                result = CommonResource.PostRequest<ChangeEmail>("Transcation/UpdateUser", changeEmail, out string ErrorMsg);
                if (ErrorMsg == "Data Updated." || ErrorMsg == "Email Deleted")
                    result = true;
                else
                    result = false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

        public string GetUserProfilePic(int usersId)
        {
            string pic = Convert.ToString(DbContext.DbUser.ExecuteDataSet("usop_GetProfilePic", usersId).Tables[0].Rows[0][0]);
            return pic;
        }

        public void loginStatus(string userName, string iP, string status, string From, string Data)
        {
            DbContext.DbUser.ExecuteScalar("usp_LoginStatus", userName, iP, status, From, Data);
        }

        public List<MEFLearningPath> GetMEFLearningPath(int FreelancerID, int UserID)
        {
            return CommonResource.ToCollection<MEFLearningPath>(DbContext.DbUser.ExecuteDataSet("usp_GetMEFLearningPath", FreelancerID, UserID).Tables[0]);
        }

        public int UpdateMEFLearningPaths(MEFLearningPath mEFLearningPath)
        {
            int cnt = 0;
            string[] paths = mEFLearningPath.MEFLearningPaths.Split(',');
            for (int i = 0; i < paths.Length; i++)
            {
                cnt += DbContext.DbUser.ExecuteNonQuery("usp_UpdateMEFLearningPath", mEFLearningPath.FreelancerID, mEFLearningPath.UserID, Convert.ToInt16(paths[i].ToString().Trim()), i);
            }
            return cnt;
        }
    }
}
