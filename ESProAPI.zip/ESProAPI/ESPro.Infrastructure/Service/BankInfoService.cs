﻿using ESPro.Core.Entity;
using ESPro.Core.Entity.Freelancer;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.IO;
using System.Data;
using ESPro.Core.Entity.Invoice;

namespace ESPro.Infrastructure.Service
{
    public class BankInfoService : IBankInfo
    {
        public List<Invoice> GetInvoicesList(SearchFreelancerInvoices datas)
        {
            var abc = CommonResource.ToCollection<Invoice>(DbContext.DbUser.ExecuteDataSet("usp_GetInvoicesByFLBankInfoId", datas.UserEmailID, datas.FLBankInfoId).Tables[0]);
            return abc;
        }

        public BankInfo GetFreelancerBankingInfo(int UserID,int FLBankInfoId)
        {
            if (FLBankInfoId == null)
                FLBankInfoId = 0;
            CryptoService cryptoService = new CryptoService();
            BankInfo bankInfo = CommonResource.ToCollection<BankInfo>(DbContext.DbUser.ExecuteDataSet("usp_GetFreelancerBankInfo", UserID, FLBankInfoId).Tables[0]).FirstOrDefault();
            if (bankInfo!=null)
            {
                bankInfo.RoutingID = cryptoService.Decrypt(bankInfo.RoutingID);
                bankInfo.SwiftCode = cryptoService.Decrypt(bankInfo.SwiftCode);
                bankInfo.IBANNumber = cryptoService.Decrypt(bankInfo.IBANNumber);
                bankInfo.BankName = cryptoService.Decrypt(bankInfo.BankName);
                bankInfo.BankAddress = cryptoService.Decrypt(bankInfo.BankAddress);
                bankInfo.AccountNumber = cryptoService.Decrypt(bankInfo.AccountNumber);
                bankInfo.WireFee = cryptoService.Decrypt(bankInfo.WireFee);
                bankInfo.TaxID = cryptoService.Decrypt(bankInfo.TaxID);
            }
            return bankInfo;
        }

        public IEnumerable<BankInfo> GetFreelancerAllBankingInfo(int UserID)
        {
            CryptoService cryptoService = new CryptoService();
            IEnumerable<BankInfo> bankInfoList  = CommonResource.ToCollection<BankInfo>(DbContext.DbUser.ExecuteDataSet("[usp_GetFreelancerAllBankInfo]", UserID).Tables[0]);

            foreach (var bankInfo in bankInfoList)
            {
                bankInfo.RoutingID = cryptoService.Decrypt(bankInfo.RoutingID);
                bankInfo.SwiftCode = cryptoService.Decrypt(bankInfo.SwiftCode);
                bankInfo.IBANNumber = cryptoService.Decrypt(bankInfo.IBANNumber);
                bankInfo.BankName = cryptoService.Decrypt(bankInfo.BankName);
                bankInfo.BankAddress = cryptoService.Decrypt(bankInfo.BankAddress);
                bankInfo.AccountNumber = cryptoService.Decrypt(bankInfo.AccountNumber);
                bankInfo.WireFee = cryptoService.Decrypt(bankInfo.WireFee);
                bankInfo.TaxID = cryptoService.Decrypt(bankInfo.TaxID);
            }           
            return bankInfoList;
        }
        public List<FreelancerBankDashboard> GetFreelancerBankDashboard(int UserID)
        {
            CryptoService cryptoService = new CryptoService();
            List<FreelancerBankDashboard> _freelancerBankDashboard = CommonResource.ToCollection<FreelancerBankDashboard>(DbContext.DbUser.ExecuteDataSet("usp_GetFreelancerBankDashboard", UserID).Tables[0]);
            for (int i = 0; i < _freelancerBankDashboard.Count(); i++)
            {
                _freelancerBankDashboard[i].BankName = cryptoService.Decrypt(_freelancerBankDashboard[i].BankName);
                _freelancerBankDashboard[i].AccountNumber = cryptoService.Decrypt(_freelancerBankDashboard[i].AccountNumber);
                _freelancerBankDashboard[i].WireFee = cryptoService.Decrypt(_freelancerBankDashboard[i].WireFee);
                if (!string.IsNullOrEmpty(_freelancerBankDashboard[i].AccountNumber))
                _freelancerBankDashboard[i].AccountNumber = MaskAllButLast(_freelancerBankDashboard[i].AccountNumber, 4);
            }
           
            return _freelancerBankDashboard;
        }

        public string MaskAllButLast(string input, int charsToDisplay, char maskingChar = 'X')
        {
            int charsToMask = input.Length - charsToDisplay;
            return charsToMask > 0 ? $"{new string(maskingChar, charsToMask)}{input.Substring(charsToMask)}" : input;
        }

        public int DeleteFreelancerBankInfo( int FLBankInfoId)
        {
            int cnt = DbContext.DbUser.ExecuteNonQuery("usp_DeleteFreelancerBankInfo", FLBankInfoId);
            return cnt;
        }
        //public int SetDefaultFreelancerBankInfo(int FLBankInfoId)
        //{
        //    int cnt = DbContext.DbUser.ExecuteNonQuery("usp_SetDefaultFreelancerBankInfo", FLBankInfoId);
        //    return cnt;
        //}

        public string InsertUpdateBankingInfo(BankInfo bankInfo)
        {
            try
            {
                CryptoService cryptoService = new CryptoService();
               
               DataTable rec_id= DbContext.DbUser.ExecuteDataSet("usp_InsertUpdateBankInfo",
                    bankInfo.UsersID,
                    bankInfo.UpdatedBy,
                    Convert.ToInt32("0" + bankInfo.ID),
                    bankInfo.BankCountry,
                    bankInfo.RoutingID == null ? bankInfo.RoutingID : cryptoService.Encrypt(bankInfo.RoutingID),
                    bankInfo.SwiftCode == null ? bankInfo.SwiftCode : cryptoService.Encrypt(bankInfo.SwiftCode),
                    bankInfo.IBANNumber == null ? bankInfo.IBANNumber : cryptoService.Encrypt(bankInfo.IBANNumber),
                    bankInfo.WireFee == null ? bankInfo.WireFee : cryptoService.Encrypt(bankInfo.WireFee),
                    cryptoService.Encrypt(bankInfo.BankName),
                    cryptoService.Encrypt(bankInfo.BankAddress),
                    cryptoService.Encrypt(bankInfo.AccountNumber),
                    bankInfo.TaxID == null ? bankInfo.TaxID : cryptoService.Encrypt(bankInfo.TaxID),
                    bankInfo.AccountName, bankInfo.Currency, bankInfo.BeneficiaryType, bankInfo.IsDefault).Tables[0];

                string MailSubject = "";
                string ToMailID = "";
                string CcMailID = "";
                StringBuilder sbMailBody = new StringBuilder();
                if (bankInfo.UpdatedUserRole == "FINANCEMANAGER")
                {
                    MailSubject = "ESPro: Bank Detail Updated For: " + bankInfo.FLUserName;
                    sbMailBody = new StringBuilder(System.IO.File.ReadAllText(Path.Combine(CommonResource.MailTemplatePath, "FLBankInfo.html")));
                    sbMailBody.Replace("[FreelancerName]", bankInfo.FLUserName);
                    sbMailBody.Replace("[FinanceManager]", bankInfo.FinanceUserName);
                    sbMailBody.Replace("[Regards]", CommonResource.MailRegards);
                    ToMailID = bankInfo.FLUserEmailID;
                    CcMailID = bankInfo.FinanceEmailID;
                }
                else
                {
                    sbMailBody = new StringBuilder(System.IO.File.ReadAllText(Path.Combine(CommonResource.MailTemplatePath, "FLBankInfoAdded.html")));
                    if (bankInfo.ID == 0)
                    {
                        MailSubject = "ESPro: Bank Detail Added By: " + bankInfo.FinanceUserName;
                        sbMailBody.Replace("[Added]", "added");
                    }
                    else
                    {
                        MailSubject = "ESPro: Bank Detail Updated By: " + bankInfo.FinanceUserName;
                        sbMailBody.Replace("[Added]", "updated");
                    }
                    sbMailBody.Replace("[FreelancerName]", bankInfo.FinanceUserName);
                    sbMailBody.Replace("[Regards]", CommonResource.MailRegards);
                    sbMailBody.Replace("[LogninLink]", CommonResource.UiUrl);

                     InvoiceService _invoice = new InvoiceService();
                     var financeUsers = _invoice.GetAllUsers("FINANCEMANAGER");
                    ToMailID = String.Join(",", financeUsers.ToList().Select(a => a.EmailID));
                    CcMailID = bankInfo.FinanceEmailID;
                }

                MailService objMail = new MailService();
                objMail.SendMail(sbMailBody.ToString(), MailSubject, ToMailID, CcMailID);


                //if (bankInfo.ID == 0)
                //    return "Bank Info added successfully";
                //else
                //    return "Bank Info updated successfully";
                if(rec_id!=null && rec_id.Rows.Count>0)
                {
                    return rec_id.Rows[0]["ID"].ToString();
                }
                else
                {
                    return 0.ToString();
                }
               
            }
            catch (Exception ex)
            {

                return "fail";
            }

        }
        public List<FreelancerBankDetails> GetFreelancersAccountDetails(string UserIDs,string FLBankInfoIds )
        {
            //var abc = CommonResource.ToCollection<FreelancerBankDetails>(DbContext.DbUser.ExecuteDataSet("usp_GetFreelancerAccountDetails", UserIDs).Tables[0]);
            //return abc;get.invoicesforAPApproval
            if (string.IsNullOrEmpty(FLBankInfoIds))
            {
                FLBankInfoIds = "0";
            }
            CryptoService cryptoService = new CryptoService();
            List<FreelancerBankDetails> freelancerBankDetails = CommonResource.ToCollection<FreelancerBankDetails>(DbContext.DbUser.ExecuteDataSet("usp_GetFreelancerAccountDetails", UserIDs, FLBankInfoIds).Tables[0]);
            for (int i = 0; i < freelancerBankDetails.Count; i++)
            {
                freelancerBankDetails[i].RoutingID = cryptoService.Decrypt(freelancerBankDetails[i].RoutingID == null ? "" : freelancerBankDetails[i].RoutingID);
                freelancerBankDetails[i].SwiftCode = cryptoService.Decrypt(freelancerBankDetails[i].SwiftCode == null ? "" : freelancerBankDetails[i].SwiftCode);
                freelancerBankDetails[i].IBANNumber = cryptoService.Decrypt(freelancerBankDetails[i].IBANNumber == null ? "" : freelancerBankDetails[i].IBANNumber);
                freelancerBankDetails[i].BankName = cryptoService.Decrypt(freelancerBankDetails[i].BankName == null ? "" : freelancerBankDetails[i].BankName);
                freelancerBankDetails[i].BankAddress = cryptoService.Decrypt(freelancerBankDetails[i].BankAddress == null ? "" : freelancerBankDetails[i].BankAddress);
                freelancerBankDetails[i].AccountNumber = cryptoService.Decrypt(freelancerBankDetails[i].AccountNumber == null ? "" : freelancerBankDetails[i].AccountNumber);
                freelancerBankDetails[i].WireFee = cryptoService.Decrypt(freelancerBankDetails[i].WireFee == null ? "" : freelancerBankDetails[i].WireFee);
                freelancerBankDetails[i].TaxID = cryptoService.Decrypt(freelancerBankDetails[i].TaxID == null ? "" : freelancerBankDetails[i].TaxID);
            }
            return freelancerBankDetails;
        }
    }
}
