﻿using System;
using System.Collections.Generic;
using System.Text;
using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.Common;
using Newtonsoft;

namespace ESPro.Infrastructure.Service
{
    public class AgencyService : IAgency
    {
        public IEnumerable<AgenciesModel> GetAgencies()
        {
            IEnumerable<AgenciesModel>  agenciesModels= CommonResource.ToCollection<AgenciesModel>(DbContext.DbUser.ExecuteDataSet("usp_GetAllAgencies").Tables[0]);
            return agenciesModels;
        }


        public IEnumerable<AgenciesDetailsModel> GetAgenciesDetaiils(int Agencyid)
        {
            DataTable dt = DbContext.DbUser.ExecuteDataSet("GetAgencyDetailsByAgencyID", Agencyid).Tables[0];

            string js = Newtonsoft.Json.JsonConvert.SerializeObject(dt);
            IEnumerable<AgenciesDetailsModel> tst = Newtonsoft.Json.JsonConvert.DeserializeObject<List<AgenciesDetailsModel>>(js);
            return tst;
            //return CommonResource.ToCollection<AgenciesDetailsModel>(DbContext.DbUser.ExecuteDataSet("GetAgencyDetailsByAgencyID", Agencyid).Tables[0]);
        }

        public IEnumerable<AgenciesDetailsModel> GetUsersAgenciesDetaiils(int Userid)
        {
            //DataTable dt = DbContext.DbUser.ExecuteDataSet("GetAgencyDetailsByUserId", Userid).Tables[0];

            //string js = Newtonsoft.Json.JsonConvert.SerializeObject(dt);
            //IEnumerable<AgenciesDetailsModel> tst = Newtonsoft.Json.JsonConvert.DeserializeObject<List<AgenciesDetailsModel>>(js);
            //return tst;
            return CommonResource.ToCollection<AgenciesDetailsModel>(DbContext.DbUser.ExecuteDataSet("GetAgencyDetailsByUserId", Userid).Tables[0]);
        }


        public bool InsertAgency(AgencyViewModel agency)
        {
            bool suceess = true;
            try
            {
                if (agency._agencydetails.Count > 0)
                {
                    foreach (var _agencydetail in agency._agencydetails)
                    {
                        DbContext.DbUser.ExecuteNonQuery("usp_upsertAgencyDetails", agency.UsersId, agency.AgencyId,agency.AgencyExclusiveID, agency.AgencyNames, agency.URL, agency.Address, _agencydetail.AgencyUserInfoID, _agencydetail.AgencyUserName, _agencydetail.ContactNumber, _agencydetail.Fax, _agencydetail.skypeid, _agencydetail.EmailId);
                    }
                }
                else
                {
                    DbContext.DbUser.ExecuteNonQuery("usp_upsertAgencyDetails", agency.UsersId, agency.AgencyId, agency.AgencyExclusiveID, agency.AgencyNames, agency.URL, agency.Address, null, null, null, null, null, null);
                }

               
            }
            catch (Exception ex)
            {
                suceess = false;
            }
            return suceess;
        }
    }
}
