﻿using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace ESPro.Infrastructure.Service
{
    public class BulkMailService : IBulkMail
    {
        public bool SendBulkMail(BulkMail bulkMail)
        {
            if (bulkMail.RolesId == null)
            {
                bulkMail.RolesId = new List<int>();
            }
           

                if (!string.IsNullOrEmpty(bulkMail.MailTo))
            {
                DataTable DT = DbContext.DbUser.ExecuteDataSet("usp_insertBulkMailMaster", bulkMail.UsersId, string.Join(",", bulkMail.RolesId), bulkMail.FilterId, bulkMail.MailSubject, bulkMail.MailBody, bulkMail.MailTo).Tables[0];
                string BulkMailMasterId = DT.Rows[0][0].ToString();

                string[] MailToList = Regex.Replace(bulkMail.MailTo, "([ ]*)", "").Replace(",", ";").ToString().Trim().Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);
                MailService objMail = new MailService();
                for (int k = 0; k < MailToList.Length; k++)
                {
                    UsersDetailsModel usersDetailsModel = CommonResource.ToCollection<UsersDetailsModel>(DbContext.DbUser.ExecuteDataSet("usp_GetUsersId", MailToList[k]).Tables[0]).FirstOrDefault();
                    string ErrorMsg = "";
                    int IsMailSend = 0;
                    if (usersDetailsModel != null)
                    {
                        string mailbody = Regex.Replace(bulkMail.MailBody, "{{Freelancer}}", usersDetailsModel.Name.Trim(), RegexOptions.IgnoreCase);
                        //ErrorMsg = objMail.SendMail(mailbody, bulkMail.MailSubject, MailToList[k], "", "", "Expert Source Team", "", "");
                        ErrorMsg = objMail.SendMail(mailbody, bulkMail.MailSubject, MailToList[k], "", "", bulkMail.FullName, "", bulkMail.UserName);
                        if (ErrorMsg == "")
                            IsMailSend = 1;

                        int cnt = DbContext.DbUser.ExecuteNonQuery("usp_insertBulkMailDetails", BulkMailMasterId, MailToList[k], IsMailSend, ErrorMsg);
                    }
                    else
                    {
                        string mailbody = Regex.Replace(bulkMail.MailBody, "{{Freelancer}}", "User", RegexOptions.IgnoreCase);

                        //ErrorMsg = objMail.SendMail(mailbody, bulkMail.MailSubject, MailToList[k], "", "", "Expert Source Team", "", "ravi.agrawal@luminad.com");
                        ErrorMsg = objMail.SendMail(mailbody, bulkMail.MailSubject, MailToList[k], "", "", bulkMail.FullName, "", bulkMail.UserName);
                        if (ErrorMsg == "")
                            IsMailSend = 1;

                        int cnt = DbContext.DbUser.ExecuteNonQuery("usp_insertBulkMailDetails", BulkMailMasterId, MailToList[k], IsMailSend, ErrorMsg);

                    }
                }
            }
            else if (bulkMail.RolesId != null && bulkMail.RolesId.Count > 0)
            {
                string ErrorMsg = "";
                int IsMailSend = 0;
                DataTable DT = DbContext.DbUser.ExecuteDataSet("usp_insertBulkMailMaster", bulkMail.UsersId, string.Join(",", bulkMail.RolesId), bulkMail.MailSubject, bulkMail.MailBody, bulkMail.MailTo).Tables[0];

                string BulkMailMasterId = DT.Rows[0][0].ToString();

                for (int i = 0; i < bulkMail.RolesId.Count; i++)
                {
                    List<RoleWiseUserList> _roleWiseUserList = CommonResource.ToCollection<RoleWiseUserList>(DbContext.DbUser.ExecuteDataSet("usp_GetRoleWiseUser", bulkMail.RolesId[i]).Tables[0]);

                    MailService objMail = new MailService();
                    for (int k = 0; k < _roleWiseUserList.Count(); k++)
                    {

                        string mailbody = Regex.Replace(bulkMail.MailBody, "{{Freelancer}}", _roleWiseUserList[k].FullName.Trim(), RegexOptions.IgnoreCase);


                        ErrorMsg = objMail.SendMail(mailbody, bulkMail.MailSubject, _roleWiseUserList[k].UserName, "", "", "Expert Source Team", "", "");
                        if (ErrorMsg == "")
                            IsMailSend = 1;

                        int cnt = DbContext.DbUser.ExecuteNonQuery("usp_insertBulkMailDetails", BulkMailMasterId, _roleWiseUserList[k].UserName, IsMailSend, ErrorMsg);
                    }

                }
            }

            return true;
        }
        public int SaveMailTemplate(MailTemplate mailTemplate )
        {
            if(mailTemplate.MailTemplateId==null)
            {
                mailTemplate.MailTemplateId = 0;
            }
            int count = DbContext.DbUser.ExecuteNonQuery("usp_UpSertMailTemplate", mailTemplate.MailTemplateId, mailTemplate.UsersId, mailTemplate.TemplateName, mailTemplate.MailSub, mailTemplate.MailBody);
            return count;
        }
        public int DeleteMailTemplate(MailTemplate mailTemplate)
        {
            if (mailTemplate.MailTemplateId == null)
            {
                mailTemplate.MailTemplateId = 0;
            }
            int count = DbContext.DbUser.ExecuteNonQuery("usp_DeleteMailTemplate", mailTemplate.MailTemplateId);
            return count;
        }
        public List<MailTemplate> GetUserMailTemplate(MailTemplate mailTemplate )
        {
            return CommonResource.ToCollection<MailTemplate>(DbContext.DbUser.ExecuteDataSet("usp_GetMailTemplate", mailTemplate.UsersId).Tables[0]);

        }


        
    }
}
