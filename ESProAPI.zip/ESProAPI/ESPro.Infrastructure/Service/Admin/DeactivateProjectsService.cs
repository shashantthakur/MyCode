﻿using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Infrastructure.Service
{
    public class DeactivateProjectsService : IDeactivateProjects
    {
        public IEnumerable<KillableJobs> GetKillableJobs(SearchKillableJobs searchKillableJobs)
        {
            var abc = CommonResource.ToCollection<KillableJobs>(DbContext.DbUser.ExecuteDataSet("usp_GetKillableJobs", searchKillableJobs.CompletionStartDate, searchKillableJobs.CompletionEndDate, searchKillableJobs.JobNos, searchKillableJobs.Authors).Tables[0]);
            return abc;
        }

        public int DeactivateProjects(KillJobs KillJobs)
        {
            int cnt = DbContext.DbUser.ExecuteNonQuery("usp_KillJobs", KillJobs.KillJobIds, KillJobs.UpdatedBy);
            return cnt;
        }
    }
}
