﻿using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Infrastructure.Service
{
    public class AdminDashboardService : IAdminDashboard
    {
        public IEnumerable<AdminDashboard> GetAdminDashboard(string UserName, string UserRole)
        {
            var abc = CommonResource.ToCollection<AdminDashboard>(DbContext.DbUser.ExecuteDataSet("usp_GetAdminDashboard", UserName, UserRole).Tables[0]);
            return abc;
        }
    }
}
