﻿using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Infrastructure.Service
{
    public class AdminManageService : IAdminManage
    {
        public IConfiguration _Configuration { get; }
        public AdminManageService(IConfiguration configuration)
        {
            _Configuration = configuration;
        }

        public IEnumerable<UserRoleList> GetUsersAndRoleList()
        {
            var abc = CommonResource.ToCollection<UserRoleList>(DbContext.DbUser.ExecuteDataSet("usp_GetUsersAndRole").Tables[0]);
            return abc;
        }

        public int UpdateEmailId(AdminManage updateEmailDetails)
        {
            int cnt = DbContext.DbUser.ExecuteNonQuery("usp_UpdateEmailId", updateEmailDetails.UsersId, updateEmailDetails.NewEmailId, updateEmailDetails.CurrentEmailId, updateEmailDetails.UpdatedBy);
            return cnt;
        }

        public int UpdateUsersDetails(AdminManageUsersDetails usersDetails)
        {
            DbContext.DbUser.ExecuteNonQuery("usp_DeleteUserRoleMapping", usersDetails.UsersId);

            int IsDefault = 1;
            int cnt = 0;
            for (int i = 0; i < usersDetails.RoleId.Length; i++)
            {
                 cnt += DbContext.DbUser.ExecuteNonQuery("usp_UpdateUsersDetails", usersDetails.UsersId, usersDetails.RoleId[i], usersDetails.ClientId, usersDetails.IsActive, usersDetails.UpdatedBy, IsDefault, usersDetails.IsRestricted == null ? 0 : usersDetails.IsRestricted);
                IsDefault = 0;
            }
            
            return cnt;
        }

        public int SaveNewUsersDetails(NewUser usersDetails)
        {
            int cnt = Convert.ToInt32(DbContext.DbUser.ExecuteScalar("usp_SaveNewUsersDetails", usersDetails.UsersName, usersDetails.EmailId, usersDetails.RoleId, usersDetails.ClientId, usersDetails.AgencyId, usersDetails.CreatedBy,usersDetails.IsRestricted==null?0: usersDetails.IsRestricted));
            return cnt;
        }

        public IEnumerable<UsersWithPreferredClient> GetUsersWithPreferredClient()
        {
            var abc = CommonResource.ToCollection<UsersWithPreferredClient>(DbContext.DbUser.ExecuteDataSet("usp_GetUsersWithPreferredClient").Tables[0]);
            return abc;
        }

        public int UpdateUsersWithPreferredClients(AdminManageUsersWithPreferredClients usersPreferredClientDetails)
        {
            DbContext.DbUser.ExecuteNonQuery("usp_DeleteUserPreferredClientMapping", usersPreferredClientDetails.UsersId);
            int cnt = 0;
            for (int i = 0; i < usersPreferredClientDetails.ClientId.Length; i++)
            {
                cnt += DbContext.DbUser.ExecuteNonQuery("usp_UpdatePreferredClient", usersPreferredClientDetails.UsersId, usersPreferredClientDetails.ClientId[i]);
            }

            return cnt;
        }
    }
}
