﻿using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Infrastructure.Service
{
    public class FSConfigService : IFSConfig
    {
        public IEnumerable<FSConfig> GetFSConfig()
        {
            var abc = CommonResource.ToCollection<FSConfig>(DbContext.DbUser.ExecuteDataSet("usp_GetFSConfig").Tables[0]);
            return abc;
        }

        public int UpdateFSConfig(FSConfig FSconfig)
        {
            int cnt = DbContext.DbUser.ExecuteNonQuery("usp_UpdateFSconfig", FSconfig.ConfigId, FSconfig.Discrepancy, FSconfig.Weightage, FSconfig.UpdatedBy);
            return cnt;
        }

    }
}
