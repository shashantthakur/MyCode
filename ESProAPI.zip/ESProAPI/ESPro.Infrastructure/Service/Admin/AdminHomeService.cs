﻿using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Infrastructure.Service
{    
    public class AdminHomeService : IAdminHome
    {
        public IEnumerable<AdminHome> GetAdminHome()
        {
            var abc = CommonResource.ToCollection<AdminHome>(DbContext.DbUser.ExecuteDataSet("usp_GetAdminHome").Tables[0]);
            return abc;
        }
    }
}
