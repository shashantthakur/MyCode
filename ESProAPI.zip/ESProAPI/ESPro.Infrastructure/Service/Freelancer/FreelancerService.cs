﻿using ESPro.Core.Entity;
using ESPro.Core.Entity.Freelancer;
using ESPro.Core.Entity.Invoice;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace ESPro.Infrastructure.Service
{
    public class FreelancerService : IFreelancer
    {
        public RegiService _IUserRegistration = new RegiService();
        public RatingService _rating = new RatingService();
        public InvoiceService _invoice = new InvoiceService();

        public List<WileyPreferredUsers> GetAllWileyPreferredUsers()
        {
            var abc = CommonResource.ToCollection<WileyPreferredUsers>(DbContext.DbUser.ExecuteDataSet("usp_GetAllWileyPreferredUsers").Tables[0]);
            return abc;
        }

        public List<FreelancerDashboardSummary> GetFreelancerRemoveJobList(int UserID, string UserEmailID, string UserRole)
        {
            var abc = CommonResource.ToCollection<FreelancerDashboardSummary>(DbContext.DbUser.ExecuteDataSet("usp_GetFreelancerDashboard", UserID, UserEmailID, UserRole, "ClOSED").Tables[0]);
            return abc;
        }

        public List<FreelancerDashboardSummary> GetFreelancerDashboardList(int UserID, string UserEmailID, string UserRole)
        {
            var abc = CommonResource.ToCollection<FreelancerDashboardSummary>(DbContext.DbUser.ExecuteDataSet("usp_GetFreelancerDashboard", UserID, UserEmailID, UserRole, "").Tables[0]);
            return abc;
        }

       

        public List<FreelancerCreditDebitDetails> GetFreelancerCreditDebitDetailsList(string StartDate, string EndDate, string CreditDebitType, string Role, string UserEmailID)
        {
            var abc = CommonResource.ToCollection<FreelancerCreditDebitDetails>(DbContext.DbUser.ExecuteDataSet("usp_GetCreditDebitDetails", StartDate, EndDate, CreditDebitType, Role, UserEmailID).Tables[0]);
            return abc;
        }

        

        public string EncryptBankDetails(BankInfo bankInfo)
        {
            try
            {
                var Jobmodel = CommonResource.ToCollection<BankInfo>(DbContext.DbUser.ExecuteDataSet("usp_EncryptBankInfo", bankInfo.UsersID, bankInfo.RoutingID, bankInfo.SwiftCode, bankInfo.IBANNumber, bankInfo.BankName, bankInfo.BankAddress, bankInfo.AccountNumber, bankInfo.TaxID).Tables[0]).FirstOrDefault();
            }
            catch (Exception ex)
            {

            }
            return "Bank Info added successfully";
        }

       

        public string InsertUpdateCreditDebitInfo(FreelancerCreditDebitDetails freelancerCreditDebitDetails)
        {
            try
            {
                string Template = "";
                if (freelancerCreditDebitDetails.Action == "Delete")
                    Template = "FLCreditDebitInfoDelete.html";
                else
                    Template = "FLCreditDebitInfo.html";
                var Jobmodel = CommonResource.ToCollection<FreelancerCreditDebitDetails>(DbContext.DbUser.ExecuteDataSet("usp_InsertUpdateCreditDebitInfo", freelancerCreditDebitDetails.UserID, Convert.ToInt32("0" + freelancerCreditDebitDetails.CreditDebitID), freelancerCreditDebitDetails.InvoiceSummaryID, freelancerCreditDebitDetails.Amount, freelancerCreditDebitDetails.CreditDebitType, freelancerCreditDebitDetails.Reason, freelancerCreditDebitDetails.Action).Tables[0]).FirstOrDefault();
                string MailSubject = "ESPro: " + freelancerCreditDebitDetails.CreditDebitType + " Detail " + freelancerCreditDebitDetails.Action + " For: " + freelancerCreditDebitDetails.FreelancerName;
                StringBuilder sbMailBody = new StringBuilder(System.IO.File.ReadAllText(Path.Combine(CommonResource.MailTemplatePath, Template)));
                sbMailBody.Replace("{FreelancerName}", freelancerCreditDebitDetails.FreelancerName);
                sbMailBody.Replace("{CreditDebitType}", freelancerCreditDebitDetails.CreditDebitType);
                sbMailBody.Replace("{FinanceManager}", freelancerCreditDebitDetails.UserName);
                sbMailBody.Replace("{InvoicName}", freelancerCreditDebitDetails.InvoiceName);
                sbMailBody.Replace("{LuminaJobNumber}", freelancerCreditDebitDetails.JobNo);
                sbMailBody.Replace("{Currency}", freelancerCreditDebitDetails.Currency);
                sbMailBody.Replace("{Amount}", freelancerCreditDebitDetails.Amount);
                sbMailBody.Replace("{Reason}", freelancerCreditDebitDetails.Reason);
                sbMailBody.Replace("{EnteredOn}", DateTime.Now.ToString("dd-MM-yyyy"));
                sbMailBody.Replace("{Regards}", CommonResource.MailRegards);
                MailService objMail = new MailService();
                objMail.SendMail(sbMailBody.ToString(), MailSubject, freelancerCreditDebitDetails.FreelancerEmailID, freelancerCreditDebitDetails.PMEmailID + ";" + freelancerCreditDebitDetails.InvApproverEmail + ";" + freelancerCreditDebitDetails.UserEmailID);

                return "Success";

            }
            catch (Exception ex)
            {
                return ex.Message.ToString();
                //throw;
            }
        }


        public List<FreelancerDashboardSummary> GetJobDetails(string JobIDs)
        {
            var abc = CommonResource.ToCollection<FreelancerDashboardSummary>(DbContext.DbUser.ExecuteDataSet("usp_GetJobDetails", JobIDs).Tables[0]);
            return abc;
        }

        public int RemoveJobFromInvoice(string JobIds, string Type)
        {
            int cnt = DbContext.DbUser.ExecuteNonQuery("usp_DeactiveJobForInvoice", JobIds, Type);
            return cnt;
        }

        public int SaveContract(ContractSave contractSave)
        {
            int cnt = DbContext.DbUser.ExecuteNonQuery("usp_UpsertContractInfo", 0, contractSave.Status, "", contractSave.UsersId, Convert.ToString("" + contractSave.RejectionComments), contractSave.ContractID, contractSave.Initials);
            return cnt;
        }

        public void FreelancerRequestDetailsOnMail(int? jobID, string comment)
        {
            IEnumerable<ProjectSpecificCategoryModel> modeldata = _rating.GetProjectSpecificCategoryDetails(null, jobID);
            IEnumerable<RatingComments> commentLst = _rating.GetRatingComments(jobID.Value);
            ProjectSpecificCategoryModel oProjectSpecificCategoryModel = modeldata.FirstOrDefault();
            RatingComments OverALLQualityofWork = commentLst.Where(a => a.RatingCategoryId == 1).FirstOrDefault();
            RatingComments AdheranceToSchedule = commentLst.Where(a => a.RatingCategoryId == 2).FirstOrDefault();
            RatingComments Communication = commentLst.Where(a => a.RatingCategoryId == 3).FirstOrDefault();
            StringBuilder sbMailBody = null;
            sbMailBody = new StringBuilder(System.IO.File.ReadAllText(CommonResource.MailTemplatePath + "\\" + "FreelancerRequestDetailsMailTemplate.html"));
            string Ratedpm = _rating.GetRatedPM(jobID);
            string toMailIds = string.IsNullOrEmpty(Ratedpm) ? oProjectSpecificCategoryModel.JobPM : Ratedpm;


            string MailSubject = "Request For Rating Details";
            sbMailBody.Replace("{UserName}", oProjectSpecificCategoryModel.FreelancerName);
            sbMailBody.Replace("{Lumina Job Number}", oProjectSpecificCategoryModel.JobNo);
            sbMailBody.Replace("{Client}", oProjectSpecificCategoryModel.Customer);
            sbMailBody.Replace("{Author}", oProjectSpecificCategoryModel.Author);
            sbMailBody.Replace("{Title}", oProjectSpecificCategoryModel.Title);
            sbMailBody.Replace("{Edition}", oProjectSpecificCategoryModel.Edition);
            sbMailBody.Replace("{Unit}", oProjectSpecificCategoryModel.Unit);
            sbMailBody.Replace("{No. of Units}", oProjectSpecificCategoryModel.NoOfUnits);
            sbMailBody.Replace("{Task}", oProjectSpecificCategoryModel.Skill);
            sbMailBody.Replace("{Client budget}", oProjectSpecificCategoryModel.ClientBudget);
            sbMailBody.Replace("{Contracted rate}", oProjectSpecificCategoryModel.ContractedRate);
            sbMailBody.Replace("{Overall Job Rating}", Convert.ToString(oProjectSpecificCategoryModel.OverallJobRating));
            sbMailBody.Replace("{ATSRating}", Convert.ToString(oProjectSpecificCategoryModel.AdherenceToSchedule));
            sbMailBody.Replace("{ATSComment}", AdheranceToSchedule != null ? AdheranceToSchedule.Comments : "");//
            sbMailBody.Replace("{OQWRating}", Convert.ToString(oProjectSpecificCategoryModel.OverallQualityOfWork));
            sbMailBody.Replace("{OQWComment}", OverALLQualityofWork != null ? OverALLQualityofWork.Comments : "");//
            sbMailBody.Replace("{CMRating}", Convert.ToString(oProjectSpecificCategoryModel.Communication));
            sbMailBody.Replace("{CMComment}", Communication != null ? Communication.Comments : "");//
            sbMailBody.Replace("{Freelancer comments}", comment);
            sbMailBody.Replace("{FreeLancer Name}", oProjectSpecificCategoryModel.FreelancerName);
            sbMailBody.Replace("{Freelancer Email Id}", oProjectSpecificCategoryModel.FreelancerEmailID);
            MailService objMail = new MailService();
            //new MailSending().SendEmailAsyn(ProjectResources.strDefaultMailFromName, toMailIds, "", MailSubject, sbMailBody.ToString(), 0, MySessionData.User_Id);
            objMail.SendMail(sbMailBody.ToString(), MailSubject, toMailIds, "", "", oProjectSpecificCategoryModel.FreelancerEmailID);

        }


    }
}
