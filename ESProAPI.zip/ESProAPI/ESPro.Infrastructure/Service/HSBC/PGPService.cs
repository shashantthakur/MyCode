﻿using ESPro.Core.Interface.HSBC;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Infrastructure.Service.HSBC
{
   public class PGPService : IPGP
    {
        public string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }
        public string Base64Decode(string base64EncodedData)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }
    }
}
