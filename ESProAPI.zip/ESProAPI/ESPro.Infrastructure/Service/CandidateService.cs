﻿using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Text;

namespace ESPro.Infrastructure.Service
{
    public class CandidateService : ICandidate
    {
        public int SaveCandidateList(CandidateList preferedUsers)
        {
           if( preferedUsers.CandidateListId==null)
            {
                preferedUsers.CandidateListId = 0;
            }
            int count = DbContext.DbUser.ExecuteNonQuery("[usp_UpSertCandidateList]", preferedUsers.CandidateListId, preferedUsers.OwnerId, preferedUsers.ListName, preferedUsers.IsActive);
            return count;
        }

        public int DeleteCandidateList(int CandidateListId)
        {
            int count = DbContext.DbUser.ExecuteNonQuery("usp_DeleteCandidateList", CandidateListId);
            return count;
        }

        public List<CandidateList> GetCandidateListDashboard(int OwnerId)
        {
            return CommonResource.ToCollection<CandidateList>(DbContext.DbUser.ExecuteDataSet("[usp_getCandidateListDashboard]", OwnerId).Tables[0]);

        }

        public List<CandidateListUsers> GetCandidateListUsers(int CandidateListId)
        {
            return CommonResource.ToCollection<CandidateListUsers>(DbContext.DbUser.ExecuteDataSet("uspGetCandidateListUsers", CandidateListId).Tables[0]);

        }
        public List<CandidateListShareUsers> GetCandidateListShareUsers(int CandidateListId)
        {
            return CommonResource.ToCollection<CandidateListShareUsers>(DbContext.DbUser.ExecuteDataSet("usp_GetCandidateListShareUsers", CandidateListId).Tables[0]);

        }
        public List<CandidateList> GetCandidateList(int OwnerId)
        {
            return CommonResource.ToCollection<CandidateList>(DbContext.DbUser.ExecuteDataSet("[usp_getCandidateList]", OwnerId).Tables[0]);

        }

        public int SaveCandidateListUser(CandidateListUserParam candidateListUserParam)
        {
            int count = 0;
            for (int i = 0; i < candidateListUserParam.CandidateListId.Count; i++)
            {
                count += DbContext.DbUser.ExecuteNonQuery("[usp_UpSertCandidateListUsers]", candidateListUserParam.UsersId, candidateListUserParam.CandidateListId[i], candidateListUserParam.OwnerId);
            }
            if (count <= 0)
            {
                count = 1;
            }
            return count;
        }

          public int DeleteCandidateListUser(int CandidateListUsersId)
        {
            int count = DbContext.DbUser.ExecuteNonQuery("usp_DeleteCandidateListUsers", CandidateListUsersId);
            return count;
        }
        
        public int UnshareCandidateList(int CandidateListShareId)
        {
            int count = DbContext.DbUser.ExecuteNonQuery("usp_UnShareCandidateList", CandidateListShareId);
            return count;
        }
        public List<ShareListUsers> GetShareListUsers(ShareListParam shareListParam)
        {
            return CommonResource.ToCollection<ShareListUsers>(DbContext.DbUser.ExecuteDataSet("GetUsersByRole", shareListParam.UsersId, shareListParam.UsersRoleId, shareListParam.ClientId).Tables[0]);

        }

        public int AcceptShareList(int CandidateShareListId)
        {
            int count = DbContext.DbUser.ExecuteNonQuery("usp_CandidateListShareAccepted", CandidateShareListId);
            return count;
        }


        public string GenerateMailShareCandidateList(ShareListMailParam shareListMailParam)
        {
            string Error = "";
            for (int i = 0; i < shareListMailParam.UsersEmail.Count; i++)
            {

                UsersDetailsModel usersDetailsModel = CommonResource.ToCollection<UsersDetailsModel>(DbContext.DbUser.ExecuteDataSet("usp_GetUsersId", shareListMailParam.UsersEmail[i]).Tables[0]).FirstOrDefault();
                if (usersDetailsModel != null)
                {
                    //int count = DbContext.DbUser.ExecuteNonQuery("usp_UpSertCandidateListShare", shareListMailParam.CandidateListId, usersDetailsModel.UsersId, "invited", 1);

                    DataTable DT = DbContext.DbUser.ExecuteDataSet("usp_UpSertCandidateListShare", shareListMailParam.CandidateListId, usersDetailsModel.UsersId, "invited", 1).Tables[0];                     

                    if (DT!=null && DT.Rows[0][0].ToString() != "0")
                    {
                        var mySecret = CommonResource.SecretKey;
                        var mySecurityKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(mySecret));

                        var myIssuer = CommonResource.myIssuer;
                        var myAudience = CommonResource.myAudience;

                        var tokenHandler = new JwtSecurityTokenHandler();
                        var tokenDescriptor = new SecurityTokenDescriptor
                        {
                            Subject = new ClaimsIdentity(new Claim[]
                            {
            new Claim(ClaimTypes.Name, DT.Rows[0][0].ToString()),
                                //new Claim("FirstName", "Ravi")
                            }),
                            Expires = DateTime.UtcNow.AddHours(24),
                            Issuer = myIssuer,
                            Audience = myAudience,
                            SigningCredentials = new SigningCredentials(mySecurityKey, SecurityAlgorithms.HmacSha256Signature)
                        };

                        var token = tokenHandler.CreateToken(tokenDescriptor);
                        string TokenString = tokenHandler.WriteToken(token);

                        MailService objMail = new MailService();
                        string Url = CommonResource.BaseUrl + "/Candidate/AcceptInvitation?token=" + TokenString;


                        var path = Path.Combine(CommonResource.MailTemplatePath, "InvitationCandidateList.html");
                        //var str2 = env.WebRootPath; // Null, both doesn't give any result

                        StringBuilder sbMailBody = new StringBuilder(System.IO.File.ReadAllText(path));

                        sbMailBody.Replace("[UserName]", usersDetailsModel.Name);
                        sbMailBody.Replace("[Sharedby]", shareListMailParam.FromFullName);
                        sbMailBody.Replace("[NameCandidateList]", shareListMailParam.ListName);
                        sbMailBody.Replace("[Description]", shareListMailParam.Comments);
                        sbMailBody.Replace("[ActvationLink]", Url);
                        //sbMailBody.Replace("[RegistrationLink]", Url);

                        string Subject = "Invitation to access candidate list";
                        string ccmail = "";
                        //string ccmail = "ravi.agrawal@luminad.com";
                        Error += objMail.SendMail(sbMailBody.ToString(), Subject, usersDetailsModel.UserName, ccmail, "", shareListMailParam.FromFullName, "", shareListMailParam.FromEmail);
                    }
                }
            }
            return Error;
        }

        public string ValidateToken(string token)
        {
           string ActivationID = "0";
            var mySecret = CommonResource.SecretKey;
            var mySecurityKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(mySecret));
            int pk_id = 0;
            var myIssuer = CommonResource.myIssuer;
            var myAudience = CommonResource.myAudience;

            var tokenHandler = new JwtSecurityTokenHandler();
            try
            {
                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidIssuer = myIssuer,
                    ValidAudience = myAudience,

                    LifetimeValidator = this.LifetimeValidator,
                    IssuerSigningKey = mySecurityKey

                }, out SecurityToken validatedToken);

                // tokenHandler.Claims.Where(z => z.Type.Equals("unique_name")).FirstOrDefault().Value, out pk_id),

                //var handler = new JwtSecurityTokenHandler();
                var jsonToken = tokenHandler.ReadToken(token);
                var tokenS = tokenHandler.ReadToken(token) as JwtSecurityToken;
                // var jti = tokenS.Claims.First(claim => claim.Type == "unique_name").Value;
                var UserActivationId = tokenS.Claims.First(claim => claim.Type == "unique_name").Value;

                ActivationID = UserActivationId;
              
                return ActivationID;
                //if(DT.Rows[0][0].ToString()== "true")
                //{
                //    return true;
                //}
                //else
                //{
                //    return false;
                //}                

            }
            catch (Exception ex)
            {
                return "0";
            }

        }
        public bool LifetimeValidator(DateTime? notBefore, DateTime? expires, SecurityToken securityToken, TokenValidationParameters validationParameters)
        {
            if (expires != null)
            {
                if (DateTime.UtcNow < expires) return true;
            }
            return false;
        }
    }

}
