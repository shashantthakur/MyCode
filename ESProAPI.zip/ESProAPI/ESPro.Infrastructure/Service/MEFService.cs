﻿using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Linq;
using System.Data;

namespace ESPro.Infrastructure.Service
{
    public class MEFService : IMEF
    {
        public bool CheckLearningPathAcess(int UsersId)
        {
            //  List<MEFLearnongPath> _MEFLearnongPathList = new List<MEFLearnongPath>();
            List<MEFLearnongPath> _trainingMaterial = CommonResource.ToCollection<MEFLearnongPath>(DbContext.DbUser.ExecuteDataSet("usp_MEFGetLearningPath", UsersId).Tables[0]);
            if (_trainingMaterial.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public List<MEFLearnongPath> GetLearningPath(int UsersId)
        {
            //  List<MEFLearnongPath> _MEFLearnongPathList = new List<MEFLearnongPath>();
            List<MEFLearnongPath> _trainingMaterial = CommonResource.ToCollection<MEFLearnongPath>(DbContext.DbUser.ExecuteDataSet("usp_MEFGetLearningPath", UsersId).Tables[0]);

            if (_trainingMaterial.Count > 0)
            {
                List<MEFVideoDetails> _trainingDetails = CommonResource.ToCollection<MEFVideoDetails>(DbContext.DbUser.ExecuteDataSet("usp_MEFGetVideos", UsersId, 0).Tables[0]);



                foreach (MEFLearnongPath trainingMaterial in _trainingMaterial)
                {


                    List<MEFVideoDetails> _CurrTrainingDetails = _trainingDetails.Where(p2 => p2.MEFLearningPathId == trainingMaterial.MEFLearningPathId).ToList();
                    if (_CurrTrainingDetails != null)
                    {
                        foreach (MEFVideoDetails trainingDetails in _CurrTrainingDetails)
                        {
                            trainingDetails.FilePath = CommonResource.MEFPath + "/" + trainingDetails.MEFVideosId + "/" + trainingDetails.FilePath;
                            trainingDetails.ThumbnailPath = CommonResource.MEFPath + "/" + trainingDetails.MEFVideosId + "/" + trainingDetails.ThumbnailPath;
                            //trainingDetails.SrtPath = Path.GetDirectoryName(trainingDetails.FilePath).Replace("\\", "/").Replace(":/", "://") + "/" + Path.GetFileNameWithoutExtension(trainingDetails.FilePath) + ".vtt";
                            //trainingDetails.VttPath = Path.GetDirectoryName(trainingDetails.FilePath).Replace("\\", "/").Replace(":/", "://") + "/" + Path.GetFileNameWithoutExtension(trainingDetails.FilePath) + "-es.vtt";
                        }
                        trainingMaterial.MEFVideoDetailsList = _CurrTrainingDetails;
                    }
                }
            }

            return _trainingMaterial;
        }

        public string UpdateVideoCompletelyView (int UsersId, int MEFVideosId)
        {
            DbContext.DbUser.ExecuteNonQuery("usp_MEFUpdateVideoCompletelyViewed", UsersId, MEFVideosId);
            return "";
        }

        public List<MEFVideoDetails> GetMEFVideos(int UsersId, int MEFLearningPathId)
        {
            List<MEFVideoDetails> _VideoDetails = CommonResource.ToCollection<MEFVideoDetails>(DbContext.DbUser.ExecuteDataSet("usp_MEFGetVideos", UsersId, MEFLearningPathId).Tables[0]);
            bool previousPassed = true;
            foreach (MEFVideoDetails _mefVideoDetail in _VideoDetails)
            {
                _mefVideoDetail.FilePath = CommonResource.MEFPath + "/" + _mefVideoDetail.MEFVideosId + "/" + _mefVideoDetail.FilePath;
                _mefVideoDetail.ThumbnailPath = CommonResource.MEFPath + "/" + _mefVideoDetail.MEFVideosId + "/" + _mefVideoDetail.ThumbnailPath;

                if (!previousPassed)
                {
                    _mefVideoDetail.Passed = "ViewPrevious";
                }
                if (string.IsNullOrEmpty(_mefVideoDetail.Passed) || _mefVideoDetail.Passed == "Failed")
                {
                    previousPassed = false;
                }
            }
            return _VideoDetails;
        }

        public List<MEFDashboard> GetMEFDashboard(int UsersId, string Role)
        {
            DataSet ds = DbContext.DbUser.ExecuteDataSet("MEF_GetDashboardData", Role, UsersId);
            List<MEFDashboard> _MEFDashboard = CommonResource.ToCollection<MEFDashboard>(ds.Tables[0]);
            return _MEFDashboard;
        }

        public List<MEFBadge> GetMEFBadge(int userid = 0)
        {
            DataSet ds = DbContext.DbUser.ExecuteDataSet("MEF_GetBadges", userid);
            List<MEFBadge> _MEFBadge = CommonResource.ToCollection<MEFBadge>(ds.Tables[0]);
            return _MEFBadge;
        }

        public int UpdateVideoViews(MEFParam _mEFParam)
        {
            int count = DbContext.DbUser.ExecuteNonQuery("usp_MEFUpdateVideoViewsCount", _mEFParam.UsersId, _mEFParam.MEFVideosId, _mEFParam.MEFLearningPathId);
            return count;
        }


        public int AllocateTest(MEFAllocateTest allocateTest)
        {
            object cnt = DbContext.DbUser.ExecuteScalar("MEF_InsertUpdateTestRegistration", allocateTest.TestRegistrationID, allocateTest.UsersId, allocateTest.TestID, allocateTest.Action);
            return Convert.ToInt32(cnt);
        }

        public MEFQuestion GetQuestionForUser(int UsesId, int TestID, int TestRegistrationId)
        {
            MEFQuestion _mefQuestion = CommonResource.ToCollection<MEFQuestion>(DbContext.DbUser.ExecuteDataSet("MEF_GetQuestionForUser", UsesId, TestID, TestRegistrationId).Tables[0]).FirstOrDefault();

            if (_mefQuestion != null)
            {
                IEnumerable<MEFQuestionOption> _skillQuestionOption = CommonResource.ToCollection<MEFQuestionOption>(DbContext.DbUser.ExecuteDataSet("MEF_GetQuestionOption", _mefQuestion.QuestionMasterID).Tables[0]);
                _mefQuestion.Options = _skillQuestionOption;
            }
            return _mefQuestion;
        }

        public MEFTestCode SaveTest(MEFQuestionOptionModel questionOptionModel)
        {
            try
            {
                int IsRight = 1;
                var abc = CommonResource.ToCollection<SkillQuestionOption>(DbContext.DbUser.ExecuteDataSet("MEF_GetRightAnswers", questionOptionModel.QuestionID).Tables[0]);
                if (abc[0].OptionID != questionOptionModel.OptionID)
                    IsRight = 0;

                MEFTestCode testResult = CommonResource.ToCollection<MEFTestCode>(DbContext.DbUser.ExecuteDataSet("MEF_SaveAnswer", questionOptionModel.QuestionID, questionOptionModel.UserID, questionOptionModel.TestID, questionOptionModel.TestRegistrationID, questionOptionModel.OptionID, questionOptionModel.CrudAction, IsRight).Tables[0]).FirstOrDefault();
                //int FailCount = TestFailCount(questionOptionModel.UserID, questionOptionModel.TestType);
                //if (FailCount == 3)
                //{
                //    CommonResource.ToCollection<TestResult>(DbContext.DbUser.ExecuteDataSet("STP_InsertUpdateSmartAssessorReActiveTest", questionOptionModel.UserID, questionOptionModel.TestType).Tables[0]).FirstOrDefault();
                //}
                if (testResult.ErrorCode == "000")
                {
                    testResult.ErrorCode = "success";

                }
                else if (testResult.ErrorCode == "111")
                {
                    testResult.ErrorCode = "pass";

                }
                else if (testResult.ErrorCode == "1111")
                {
                    testResult.ErrorCode = "passf";

                }
                else if (testResult.ErrorCode == "222")
                {
                    testResult.ErrorCode = "fail";
                }
                else if (testResult.ErrorCode.Equals("2222"))
                {
                    testResult.ErrorCode = "failf";
                }
                else
                {
                    testResult.ErrorCode = "error";
                }
                return testResult;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public MEFTestResult GetTestResult(int UsesId, int TestRegistrationId)
        {
            MEFTestResult SmartAssessorTestResult = CommonResource.ToCollection<MEFTestResult>(DbContext.DbUser.ExecuteDataSet("MEF_GetTestResult", UsesId, TestRegistrationId).Tables[0]).FirstOrDefault();
            return SmartAssessorTestResult;
        }

        public int SaveFeedbackData(TestResultFeedback testResultFeedback)
        {
            int cnt = DbContext.DbUser.ExecuteNonQuery("MEF_SaveFeedback", testResultFeedback.Feedback, testResultFeedback.TestRegistrationID);
            return cnt;
        }

    }
}
