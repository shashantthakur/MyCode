﻿using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESPro.Infrastructure.Service
{
    public class CertificationSevice : ICertification
    {

        public IEnumerable<UserTestInfo> GetUserTestInfo(int UsersId)
        {
            IEnumerable<UserTestInfo> _userTestInfon = CommonResource.ToCollection<UserTestInfo>(DbContext.DbUser.ExecuteDataSet("STP_GetCertificatebyUserId", UsersId).Tables[0]);
            return _userTestInfon;
        }

        public IEnumerable<Certificate> GetUnEnrolledCertificate(int UsersId)
        {
            return CommonResource.ToCollection<Certificate>(DbContext.DbUser.ExecuteDataSet("STP_UnEnrolledCertificateByUserId", UsersId).Tables[0]);
        }

        public AllocateTest GetTestDetails(int TestID)
        {
            return CommonResource.ToCollection<AllocateTest>(DbContext.DbUser.ExecuteDataSet("STP_GetSelectedTestDetails", TestID).Tables[0]).FirstOrDefault();
        }

        public AllocateTest GetSelectedTest(int UsersId, int TestID)
        {
            return CommonResource.ToCollection<AllocateTest>(DbContext.DbUser.ExecuteDataSet("STP_GetSelectedTest", UsersId, TestID).Tables[0]).FirstOrDefault();
        }

        public int AllocateTest(AllocateTest allocateTest)
        {
            AllocateTest _allocateTest = GetSelectedTest(allocateTest.UsersId.Value, allocateTest.TestID.Value);

            if (_allocateTest != null && _allocateTest.TestRegistrationID != 0)
            {
                return _allocateTest.TestRegistrationID.Value;
            }
            else
            {

                object cnt = DbContext.DbUser.ExecuteScalar("STP_InsertUpdateTestRegistration", allocateTest.TestRegistrationID, allocateTest.UsersId, allocateTest.TestID, allocateTest.CRUDAction);
                return Convert.ToInt32(cnt);
            }

        }

        public SkillQuestion GetQuestionsOnSkill(int UsesId, int TestID, int SkillID, int TestRegistrationId)
        {
            SkillQuestion skillQuestion = CommonResource.ToCollection<SkillQuestion>(DbContext.DbUser.ExecuteDataSet("STP_GetQuestionForUser", UsesId, SkillID, TestID, TestRegistrationId).Tables[0]).FirstOrDefault();

            if (skillQuestion != null)
            {
                IEnumerable<SkillQuestionOption> _skillQuestionOption = CommonResource.ToCollection<SkillQuestionOption>(DbContext.DbUser.ExecuteDataSet("STP_GetQuestionOption", skillQuestion.QuestionMasterID).Tables[0]);
                skillQuestion.Options = _skillQuestionOption;
            }
            return skillQuestion;
        }

        public TestResult SaveTest(QuestionOptionModel questionOptionModel)
        {
            try
            {
                int IsRight = 1;
                var abc = CommonResource.ToCollection<SkillQuestionOption>(DbContext.DbUser.ExecuteDataSet("STP_GetRightAnswers", questionOptionModel.QuestionID).Tables[0]);
                if (abc.Count() == questionOptionModel.checkArray.Count)
                {
                    for (int i = 0; i < questionOptionModel.checkArray.Count; i++)
                    {
                        if (abc.Where(a => Convert.ToString(a.OptionID) == Convert.ToString(questionOptionModel.checkArray[i])).ToList().Count() == 0)
                        {
                            IsRight = 0;
                            break;
                        }
                    }
                }
                else
                    IsRight = 0;

                //TestResult testResult = CommonResource.ToCollection<TestResult>(DbContext.DbUser.ExecuteDataSet("STP_SaveAnswer", questionOptionModel.QuestionID, questionOptionModel.UserID, questionOptionModel.TestID, questionOptionModel.TestRegistrationID, questionOptionModel.OptionID, questionOptionModel.CrudAction).Tables[0]).FirstOrDefault();

                TestResult testResult = CommonResource.ToCollection<TestResult>(DbContext.DbUser.ExecuteDataSet("STP_SaveAnswer", questionOptionModel.QuestionID, questionOptionModel.UserID, questionOptionModel.TestID, questionOptionModel.TestRegistrationID, String.Join(",", questionOptionModel.checkArray), questionOptionModel.CrudAction, IsRight).Tables[0]).FirstOrDefault();

                if (testResult.ErrorCode == "000")
                {
                    testResult.ErrorCode = "success";

                }
                else if (testResult.ErrorCode == "111")
                {
                    testResult.ErrorCode = "pass";

                }
                else if (testResult.ErrorCode == "1111")
                {
                    testResult.ErrorCode = "passf";

                }
                else if (testResult.ErrorCode == "222")
                {
                    testResult.ErrorCode = "fail";
                }
                else if (testResult.ErrorCode.Equals("2222"))
                {
                    testResult.ErrorCode = "failf";
                }
                else
                {
                    testResult.ErrorCode = "error";
                }
                return testResult;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public IEnumerable<TestAnalysis> GetTestAnalysis(int TestRegistrationId)
        {
            IEnumerable<TestAnalysis> testAnalysis = CommonResource.ToCollection<TestAnalysis>(DbContext.DbUser.ExecuteDataSet("STP_GetTestAnalysis", TestRegistrationId).Tables[0]);
            return testAnalysis;

        }

        public int SaveFeedbackData(TestResultFeedback testResultFeedback)
        {
            int cnt = DbContext.DbUser.ExecuteNonQuery("STP_SaveFeedback", testResultFeedback.Feedback, testResultFeedback.TestRegistrationID);
            return cnt;
        }

        public SkillPhase2Test GetPhase2Test(int SkillPhase2TestID)
        {
            SkillPhase2Test _skillPhase2Test = CommonResource.ToCollection<SkillPhase2Test>(DbContext.DbUser.ExecuteDataSet("STP_GetPhase2Test", SkillPhase2TestID).Tables[0]).FirstOrDefault();
            return _skillPhase2Test;

        }
        public int SavePhase2Registration(Phase2Registration _phase2)
        {
            int cnt = DbContext.DbUser.ExecuteNonQuery("STP_Phase2Registration_Save", _phase2.Phase2RegistrationID, _phase2.UserID, _phase2.SkillPhase2TestID, _phase2.FilePath, _phase2.Status, _phase2.TestScore, _phase2.IsPassed, _phase2.CheckedBy, _phase2.Type, _phase2.CrudAction);
            return cnt;
        }

        public async Task SaveFile(string path, IFormFile file, string fileName)
        {
            try
            {
                if (file != null && file.Length > 0)
                {
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }
                    var filePath = Path.Combine(path, fileName);

                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        await file.CopyToAsync(fileStream);
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }



        public IEnumerable<CertificateInfo> GetCertificate()
        {
            IEnumerable<CertificateInfo> _certificateInfo = CommonResource.ToCollection<CertificateInfo>(DbContext.DbUser.ExecuteDataSet("STP_GetCertificate").Tables[0]);
            return _certificateInfo;

        }



        public IEnumerable<SkillCertificateUser> GetCertificateUser(int TestRegistrationID, string CertificateType)
        {
            IEnumerable<SkillCertificateUser> _certificateInfo = null;
            if (CertificateType == "Certificate")
                _certificateInfo = CommonResource.ToCollection<SkillCertificateUser>(DbContext.DbUser.ExecuteDataSet("STP_GetCertificateUser", TestRegistrationID).Tables[0]);
            else
                _certificateInfo = CommonResource.ToCollection<SkillCertificateUser>(DbContext.DbUser.ExecuteDataSet("STP_GetSmartAssessorCertificateUser", TestRegistrationID, CertificateType).Tables[0]);
            return _certificateInfo;
        }

        public IEnumerable<Phase2Registration> GetPhase2Registration(int Status)
        {
            IEnumerable<Phase2Registration> Phase2Completed = CommonResource.ToCollection<Phase2Registration>(DbContext.DbUser.ExecuteDataSet("STP_Phase2Registration_Get", Status).Tables[0]);
            return Phase2Completed;

        }
        

    }
}
