﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    public class AdminManage
    {
        public Int64 UsersId { get; set; }
        public string FreelancerName { get; set; }
        public string CurrentEmailId { get; set; }
        public string NewEmailId { get; set; }
        public Int64 UpdatedBy { get; set; }
    }

    public class UpdateVendorEmail
    {
        public string Vendor { get; set; }
        public string existingemail { get; set; }
        public string newemail { get; set; }
    }

    public class AdminManageParameters
    {
        public int UsersId { get; set; }
        public string sort { get; set; }
        public string dir { get; set; }
        public int currentpage { get; set; }
        public int pageSize { get; set; }

        public List<string> UserNameFilter { get; set; }
        public List<string> RoleFilter { get; set; }
        public List<string> EmailFilter { get; set; }
        public AdminManageParameters()
        {
            UserNameFilter = new List<string>();
            RoleFilter = new List<string>();
            EmailFilter = new List<string>();
        }
    }
}
