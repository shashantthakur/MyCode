﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    public class AdminDashboard
    {
        //public Int64 JobId { get; set; }
        //public string JobNo { get; set; }
        //public string Client { get; set; }
        //public string ProjectManager { get; set; }
        //public string Author { get; set; }
        //public string Title { get; set; }
        //public string Edition { get; set; }
        //public string Skill { get; set; }
        //public string Freelancer { get; set; }
        //public string CompletionDate { get; set; }

        public int UniqueRecord { get; set; }
        public string JobNo { get; set; }
        public string Customer { get; set; }
        public string ISBN13 { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string Edition { get; set; }
        public string Skill { get; set; }
        public string FreelancerName { get; set; }
        public string PM_Name { get; set; }
        public string CompletionDate { get; set; }
        public string FreelancerEmailID { get; set; }
        public string JobID { get; set; }
        public string UserStatus { get; set; }
        public string UserName { get; set; }
        public string JobPM { get; set; }
        public string InvApproverName { get; set; }
        public string InvApproverEmail { get; set; }
        public string InvApproverName2 { get; set; }
        public string InvApproverEmail2 { get; set; }
    }

    public class AdminParameters
    {
        public string UserEmailID { get; set; }
        public string UserRole { get; set; }
        public string sort { get; set; }
        public string dir { get; set; }
        public int currentpage { get; set; }
        public int pageSize { get; set; }
        public List<string> JobFilter { get; set; }
        public List<string> FreelancerFilter { get; set; }
        public List<string> InvApproverFilter { get; set; }
        public AdminParameters()
        {
            JobFilter = new List<string>();
            FreelancerFilter = new List<string>();
            InvApproverFilter = new List<string>();
        }
    }
}
