﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    public class AdminHome
    {
        public Int64 TotalFreelancerProfiles { get; set; }
        public Int64 TotalProjectManagers { get; set; }
        public Int64 LuminaAdminUsers { get; set; }
        public Int64 TotalLuminaEmployeeProfiles { get; set; }
        public Int64 JobsPendingRatings { get; set; }
        public Int64 JobsPendingInvoices { get; set; }
        public Int64 ProfilesMissingWritingSamples { get; set; }
        public Int64 TotalNumberClients { get; set; }
        public Int64 FLProjectManagers { get; set; }
        public Int64 InvoicesPendingApproval { get; set; }
        public Int64 UserAppearedWritingSamples { get; set; }
    }
}
