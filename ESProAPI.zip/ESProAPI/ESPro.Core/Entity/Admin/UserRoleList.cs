﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    public class UserRoleList
    {
        public int? UsersId { get; set; }
        public string UsersName { get; set; }
        public string EmailId { get; set; }
        public int?[] RolesId { get; set; }
        public string RoleId { get; set; }
        public string UserRole { get; set; }
        public string RoleTitle { get; set; }
        public string ClientsId { get; set; }
        public string ClientName { get; set; }
        public int? IsActive { get; set; }
        public int? IsRestricted { get; set; }
    }

    public class UsersWithPreferredClient
    {
        public int? UserId { get; set; }
        public string UserName { get; set; }
        public string PreferredClient { get; set; }
        public string PreferredClientIDs { get; set; }
    }


}
