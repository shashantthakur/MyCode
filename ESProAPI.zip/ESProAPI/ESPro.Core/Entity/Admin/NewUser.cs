﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    public class NewUser
    {
        public string UsersName { get; set; }
        public string EmailId { get; set; }
        public int RoleId { get; set; }
        public int? ClientId { get; set; }
        public int? AgencyId { get; set; }
        public int CreatedBy { get; set; }
        public int? IsRestricted { get; set; }
    }
}
