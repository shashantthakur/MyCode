﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    public class FSConfig
    {
        public int ConfigId { get; set; }
        public string Field { get; set; }
        public int Discrepancy { get; set; }
        public int Weightage { get; set; }
        public int UpdatedBy { get; set; }
    }
}
