﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    public class AdminManageUsersDetails
    {
        public int UsersId { get; set; }
        public int[] RoleId { get; set; }
        public int ClientId { get; set; }
        public int IsActive { get; set; }
        public int UpdatedBy { get; set; }
        public int? IsRestricted { get; set; }
    }

    public class AdminManageUsersWithPreferredClients
    {
        public int UsersId { get; set; }
        public int[] ClientId { get; set; }
        public int UpdatedBy { get; set; }
    }
}
