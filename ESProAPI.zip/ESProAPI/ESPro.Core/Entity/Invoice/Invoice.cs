﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity.Invoice
{
    public class InvoiceStatus
    {
        public string Text { get; set; }
        public string Value { get; set; }
    }
    public class Invoice
    {
        public Boolean select { get; set; }
        public Int64 ID { get; set; }
        public string Name { get; set; }
        public string ContractType { get; set; }
        public Int64 NoOfJobs { get; set; }
        public int FreelancerID { get; set; }
        public string FLEsproCode { get; set; }
        public string FreelancerName { get; set; }
        public string FreelancerEmail { get; set; }
        public string PMName { get; set; }
        public string PMEmail { get; set; }
        public string InvApproverName { get; set; }
        public string InvApproverEmail { get; set; }
        public string InvApproverName2 { get; set; }
        public string InvApproverEmail2 { get; set; }
        public string APApprovedRejectedBy { get; set; }
        public string Status { get; set; }
        public DateTime? InvoiceDate { get; set; }
        public DateTime? InvApprovedRejectedDate { get; set; }
        public DateTime? Inv2ApprovedRejectedDate { get; set; }
        public DateTime? TargetAPProcessingDate { get; set; }
        public int DueInDays { get; set; }
        public DateTime? APApprovedRejectedDate { get; set; }
        public string RejectionComments { get; set; }
        public string ProfileCurrency { get; set; }
        public string ContractedCurrency { get; set; }
        public string ConversionCurrencyRate { get; set; }
        public string TotalAmount { get; set; }
        public string BankingCharges { get; set; }
        public string TotalAmountInUSD { get; set; }
        public string JobNo { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string Edition { get; set; }
        public string Skill { get; set; }
        public string Service { get; set; }
        public string Customer { get; set; }
        public string JobCategory { get; set; }
        public int? FLBankInfoId { get; set; }
        public string ProfileWireFee { get; set; }
    }
    public class InvoiceDetails
    {
        public Int64 InvoiceDetailsID { get; set; }
        public Int64 InvoiceSummaryID { get; set; }
        public string JobNo { get; set; }
        public Int64 JobID { get; set; }
        public string Name { get; set; }
        public string InvoiceDate { get; set; }
        public Int64 NoOfJobs { get; set; }
        public string Status { get; set; }
        public string RejectionComments { get; set; }
        public string RejectedBy { get; set; }
        public string TotalAmount { get; set; }
        public string FullName { get; set; }
        public string LastName { get; set; }
        public string AssignmentType { get; set; }
        public string PM_Name { get; set; }
        public string JobPM { get; set; }
        public string Service_Email { get; set; }
        public string PMemail { get; set; }
        public string ActionType { get; set; }
        public string ApprovedDate { get; set; }
        public float AppliedUnits { get; set; }
        public string SumAmount { get; set; }
        public string AmountInUSD { get; set; }
        public string Unit { get; set; }
        public string FreelancerName { get; set; }
        public string FreelancerEmailID { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string Task { get; set; }
        public string Edition { get; set; }
        public float RatePerUnit { get; set; }
        public string Service { get; set; }
        public string Notes { get; set; }
        public string SingleUnitTotalAmount { get; set; }
        public string Contracted_Currency { get; set; }
        public string CustomerName { get; set; }
        public string JobCategory { get; set; }
        public string InvApproverName { get; set; }
        public string InvApproverEmail { get; set; }
        public string InvApproverName2 { get; set; }
        public string InvApproverEmail2 { get; set; }
        public string InvoiceType { get; set; }
        public string InvoiceComments { get; set; }
        public string UnitsAssigned { get; set; }
        public string UnitsApplied { get; set; }
        public string TotalUnitsApplied { get; set; }
        public string APActionDate { get; set; }
        public string APRejectionComments { get; set; }
        public int? LocationId { get; set; }
        public string AccountNumber { get; set; }
        public string BankCurrency { get; set; }
        public string BankISOCode { get; set; }

    }

    public class InvoiceRatingStatus
    {
        public string RatingStatus { get; set; }
        public int JobID { get; set; }
    }

    public class FinanceMatrix
    {
        public int PendingPMApproval { get; set; }
        public int ApprovedByPM { get; set; }
        public int RejectedByPM { get; set; }
        public int ApprovedBYAP { get; set; }
        public int RejectedBYAP { get; set; }
        public int FundsAvailaible { get; set; }
        public int CashedOutofWallet { get; set; }
    }

    public class SendMailTo
    {
        public string ToMailList { get; set; }
        public string CCMailList { get; set; }
        public string BCCMailList { get; set; }
    }

    public class MailDetails
    {
        public string MailSubject { get; set; }
        public DateTime MailDate { get; set; }
    }

    public class DateFilterTypes
    {
        public string ColumnType { get; set; }
        public string ColumnName { get; set; }
    }

    public class InvoiceSave
    {
        public string JobNo { get; set; }
        public int JobID { get; set; }
        public int InvoiceSummaryID { get; set; }
        public string InvoiceName { get; set; }
        public string InvoiceDate { get; set; }
        public string InvApproverName { get; set; }
        public string InvApproverEmail { get; set; }
        public string InvApproverName2 { get; set; }
        public string InvApproverEmail2 { get; set; }
        public int FreelancerID { get; set; }
        public int UsersId { get; set; }
        public string UserName { get; set; }
        public string UserEmailID { get; set; }
        public string UserRole { get; set; }
        public string Status { get; set; }
        public string RejectionComments { get; set; }
        public string CustomerName { get; set; }
        public string JobCategory { get; set; }
        public string Service { get; set; }
        public string Skill { get; set; }
        public string FreelancerEmailID { get; set; }
        public int BankAccountId { get; set; }
        public int PaymentTypeId { get; set; }
        public string PaymentDate { get; set; }
        public string ProfileCurrency { get; set; }
        public string ContractCurrency { get; set; }
        public string TotalAmount { get; set; }
        public string WireFee { get; set; }
        public string BankingChargesInUSD { get; set; }
        public bool IsRePayment { get; set; }
        public int? TransactionDetailsId { get; set; }

        public string HSBC_Status { get; set; }
    }

    public class InvoiceDetailsSave
    {
        public int InvoiceSummaryID { get; set; }
        public int InvoiceDetailsID { get; set; }
        public string OldInvoiceType { get; set; }
        public string NewInvoiceType { get; set; }
        public int UsersId { get; set; }
        public string UserEmailID { get; set; }
    }

    public class AllUsers
    {
        public int UsersID { get; set; }
        public string UserName { get; set; }
        public string EmailID { get; set; }
        public string UserRole { get; set; }
    }

    public class WileyPrefundingDetails
    {
        public int? ID { get; set; }
        public string PrefundingAmount { get; set; }
        public DateTime PrefundingDate { get; set; }
        public string PrefundingBalance { get; set; }
        public string PrefundingCurrency { get; set; }
        public int PrefundingClient { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string UserName { get; set; }
        public string UserEmailID { get; set; }
        public int? EnteredBy { get; set; }
        public DateTime? EnteredOn { get; set; }
    }

    public class WileyPrefundingDetailsSearchParameters
    {
        public string Currency { get; set; }
        public int Client { get; set; }
        public int PrefundingFlag { get; set; }
        public string sort { get; set; }
        public string dir { get; set; }
        public int currentpage { get; set; }
        public int pageSize { get; set; }
    }

    public class UpdatePreFundingBalance
    {

    }

    public class filter
    {
        public List<string> JobFilter { get; set; }
        public List<string> InvoiceNameFilter { get; set; }
        public List<string> FreelancerFilter { get; set; }
        public List<string> InvApproverFilter { get; set; }
        public filter()
        {
            InvoiceNameFilter = new List<string>();
            JobFilter = new List<string>();
            FreelancerFilter = new List<string>();
            InvApproverFilter = new List<string>();
        }
    }

    public class SearchInvoiceParameters : filter
    {
        public int InvoiceSummaryID { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string Status { get; set; }
        public string ContractType { get; set; }
        public string ProfileCurrency { get; set; }
        public string ContractCurrency { get; set; }
        public string Role { get; set; }
        public string UserEmailID { get; set; }
        public string sort { get; set; }
        public string dir { get; set; }
        public int currentpage { get; set; }
        public int pageSize { get; set; }
        public string DateColumn { get; set; }
    }
    public class InvoiceDownload
    {
        public int InvoiceSummaryID { get; set; }
        public string FyleType { get; set; }

    }


    public class TransactionHistoryfilter
    {
        public List<string> InvoiceNameFilter { get; set; }
        public List<string> FreelancerFilter { get; set; }
        public TransactionHistoryfilter()
        {
            InvoiceNameFilter = new List<string>();
            FreelancerFilter = new List<string>();
        }
    }

    public class SearchCheckedInvoiceID
    {
        public string checkedID { get; set; }
    }

    public class SearchBankTransactionHistoryParameters : TransactionHistoryfilter
    {
        public string ProjectCode { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string Status { get; set; }
        public string Role { get; set; }
        public int UsersID { get; set; }
        public string ReportType { get; set; }
        public string sort { get; set; }
        public string dir { get; set; }
        public int currentpage { get; set; }
        public int pageSize { get; set; }
    }

    public class WireFeeSave
    {
        public int UserID { get; set; }
        public string UserEmailID { get; set; }
        public string WireFee { get; set; }
    }
    public class SaveInvoiceResult
    {
        public string Status { get; set; }
        public string ErrorMessage { get; set; }
    }
    public class PrefundingClient
    {
        public int? Id { get; set; }
        public string ClientName { get; set; }
        public string ClientCode { get; set; }
    }
}