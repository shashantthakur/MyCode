﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace ESPro.Core.Entity.Client
{
    public class JobDetailsModel
    {
        public int AgencyId { get; set; }
        public int? JobID { get; set; }

        public string JobNo { get; set; }

        public string Customer { get; set; }
        public string JobPrefix { get; set; }
        
        public string PM_Name { get; set; }

        public string Author { get; set; }
       // [Required(ErrorMessage = "Please enter title. ")]
        public string Title { get; set; }

        public string Edition { get; set; }
       // [Required(ErrorMessage = "Please enter ISBN13(13 digit) or Cost code number(6 digit).")]
       // [RegularExpression("[0-9]{6}([0-9]{7})?", ErrorMessage = "Please enter ISBN13(13 digit) or Cost code number(6 digit).")]
        public string ISBN13 { get; set; }


        public string Unit { get; set; }
       // [Required(ErrorMessage = "Please select a skill.")]
        public string Skill { get; set; }
       // [Required(ErrorMessage = "Please provide No of units.")]
       // [Range(0.001, double.MaxValue, ErrorMessage = "No of units must be greater than zero.")]
        public decimal? NoOfUnits { get; set; }
        //[RegularExpression(@"\d+(\.\d{1,2})?", ErrorMessage = "Enter decimal.")]
        //[Required(ErrorMessage = "Please provide Availaible Budget.")]
        //[Range(0.001, double.MaxValue, ErrorMessage = "Availaible Budget must be greater than zero.")]
        public decimal? ClientBudget { get; set; }
        //[RegularExpression(@"\d+(\.\d{1,2})?", ErrorMessage = "Enter decimal.")]
        //[Required(ErrorMessage = "Please provide Contracted Rate per unit.")]
       // [Range(0.001, double.MaxValue, ErrorMessage = "Contracted Rate must be greater than zero.")]
        public decimal? ContractedRate { get; set; }
        
        public int? FreelancerUsersId { get; set; }
        public string FreelancerName { get; set; }

        public string FreelancerEmailID { get; set; }
        public bool IsManualRecord { get; set; }
        public string AssignmentType { get; set; }
        //public string PM_Name { get; set; }
        public string JobPM { get; set; }
        public string Service_Email { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }

        public string RaisedCount { get; set; }
        public string LastStatus { get; set; }

        public string Service { get; set; }
        public string Notes { get; set; }
        public string RequestComment { get; set; }
       // [Required(ErrorMessage = "Please select Budget Currency.")]
        public string Budget_Currency { get; set; }
        //[Required(ErrorMessage = "Please select Contracted Currency.")]
        public string Contracted_Currency { get; set; }
        //[Required(ErrorMessage = "Please select Discipline.")]
        public string Discipline { get; set; }
        //[Required(ErrorMessage = "Please select SubDiscipline.")]
        public string SubDiscipline { get; set; }

        public string InvApproverName { get; set; }
        public string InvApproverEmail { get; set; }
        public string ContractStatus { get; set; }
        public bool isExpanded { get; set; }
        public string InvoiceType { get; set; }
        public string WireFee { get; set; }
        public string CompletionDate { get; set; }
    }

    public class ReturnJobDetails
    {
        public int JobID { get; set; }
        public string JobNo { get; set; }
    }

    public class SearchClientParameters
    {
        public int UsersId { get; set; }
        public string UserRole { get; set; }
        public string UserEmailID { get; set; }
        public string sort { get; set; }
        public string dir { get; set; }
        public int currentpage { get; set; }
        public int pageSize { get; set; }
        public List<string> JobFilter { get; set; }
        public List<string> FreelancerFilter { get; set; }
        public List<string> InvApproverFilter { get; set; }
        public SearchClientParameters()
        {
            JobFilter = new List<string>();
            FreelancerFilter = new List<string>();
            InvApproverFilter = new List<string>();
        }
    }

    public class ReassignedJobs
    {
        public int JobID { get; set; }
        public string JobNo { get; set; }
        public string OldPMName { get; set; }
        public string OldPMEmailId { get; set; }
        public string NewPMName { get; set; }
        public string NewPMEmailId { get; set; }
        public int ReassignedUsersId { get; set; }
        public string ReassignedBy { get; set; }
        public string ReassignedEmailId { get; set; }
    }

    public class ClientJobDetailsModel : JobDetailsModel
    {
        public bool isReadyForRate { get; set; }
        //[Required(ErrorMessage = "Please select Due Date")]
        public string ExpectedCompletionDate { get; set; }
        public string AgencyName { get; set; }
        public string AgencyEmail { get; set; }
        public int? AgencyUserId { get; set; }
        public int? ClientId { get; set; }
        public bool ContractRequired { get; set; }
        public string FilePath { get; set; }
    }
    public class ClientUser
    {
        public int? ClientId { get; set; }
        public string UserName { get; set; }
        public string ClientCode { get; set; }
        public String ClientName { get; set; }
        public string ClientEmailID { get; set; }
        public bool ContractRequired { get; set; }
        public bool CreateJob { get; set; }
        public string JobPrefix { get; set; }
        

    }
}
