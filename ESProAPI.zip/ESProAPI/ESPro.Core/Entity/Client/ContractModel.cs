﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ESPro.Core.Entity.Client
{
    public class ContractModel
    {
        public string JobNo { get; set; }
        public string ContractorName { get; set; }
        public string WileyContact { get; set; }
        public string ClientName { get; set; }
      
        public string Author { get; set; }
        public string Title { get; set; }
        public string Edition { get; set; }
        public string ISBN { get; set; }
        public string WorkDescription { get; set; }
        public string DueDate { get; set; }
        public string TypeofUnit { get; set; }
        public decimal? NumberofUnits { get; set; }
        public decimal? ContractedRateperUnit { get; set; }
        public string ContractedCurrency { get; set; }
        public string TotalValueofAssignment { get; set; }
        public string EffectiveDate { get; set; }
    }

    public class DownloadFile
    {
        public FileStream fileStream { get; set; }
        public string contentType { get; set; }
    }
}
