﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    class MEF
    {
    }
    public class MEFVideoDetails
    {
        public int? MEFVideosId { get; set; }
        public int? MEFLearningPathId { get; set; }
        public string LearningPath { get; set; }
        public int? MEFTestMasterId { get; set; }
        public int? TestSeq { get; set; }
        public string TestName { get; set; }
        public string VideoTitle { get; set; }
        public string FileType { get; set; }
        public string FilePath { get; set; }
        public string SrtPath { get; set; }
        public string Duration { get; set; }
        public string Learning { get; set; }
        public string ThumbnailPath { get; set; }
        public int? ViewCount { get; set; }
        public string Keyword { get; set; }
        public string Passed { get; set; }
        public bool? IsCompletelyViewed { get; set; }
    }
    public class MEFLearnongPath
    {
        public int? MEFLearningPathId { get; set; }
        public string LearningPath { get; set; }
        public int? MappedByUsersId { get; set; }
        public string bgColor { get; set; }
        public DateTime? MappingDate { get; set; }
        public string MappedByName { get; set; }
        public List<MEFVideoDetails> MEFVideoDetailsList { get; set; }
    }
    public class MEFParam
    {
        public int? MEFLearningPathId { get; set; }
        public int? MEFVideosId { get; set; }
        public int? UsersId { get; set; }
    }

    public class MEFDashboard
    {
        public int userid { get; set; }
        public string FullName { get; set; }
        public string LearningPath { get; set; }
        public int? LearningPathId { get; set; }
        public string VideoTitle { get; set; }
        public int? videoid { get; set; }
        public bool? Result { get; set; }
        public int? cnt { get; set; }
        public int? TestScore { get; set; }
        public int? MappedBy { get; set; }
        public int? ViewCount { get; set; }
    }

    public class MEFDashboardResponse
    {
        public int? userid { get; set; }
        public string FullName { get; set; }
        public string LearningPath { get; set; }
        public int? LearningPathId { get; set; }
        public Boolean isExpanded { get; set; }
        public Boolean Badge { get; set; }
        public List<MEFDashboardResponseInner> response { get; set; }
        public MEFDashboardResponse()
        {
            response = new List<MEFDashboardResponseInner>();
        }
    }
    public class MEFDashboardResponseInner
    {
        public string VideoTitle { get; set; }
        public int? videoid { get; set; }
        public bool? Result { get; set; }
        public int? cnt { get; set; }
        public int? TestScore { get; set; }
        public int? MappedBy { get; set; }
        public int? ViewCount { get; set; }
    }

    public class MEFBadge
    {
        public int? MEFLearningPathId { get; set; }
        public int UsersId { get; set; }
        public string LearningPath { get; set; }
        public DateTime? EndDate { get; set; }
    }

    public class MEFAllocateTest
    {
        public MEFAllocateTest()
        {
            TestRegistrationID = 0;
            TestID = 0;
        }
        public int? UsersId { get; set; }
        public int? TestID { get; set; }
        public int? TestRegistrationID { get; set; }
        public string Action { get; set; }
        public string TestName { get; set; }
        //public string Administration { get; set; }
        //public string Instruction { get; set; }
        //public int SkillID { get; set; }
        //public string PassingGrade { get; set; }
        //public string Description { get; set; }
        //public int BufferDays { get; set; }
    }

    public class MEFQuestion
    {
        public int? QuestionMasterID { get; set; }
        public int? RightOptionID { get; set; }
        public string Question { get; set; }


        public string QuestionType { get; set; }
        public int? MEFTestMasterID { get; set; }
        public int? NoOfQuestion { get; set; }
        public string TestName { get; set; }

        public string Feedback { get; set; }
        public int? AttendQuestion { get; set; }
        public int? FeedbackReq { get; set; }

        public IEnumerable<MEFQuestionOption> Options { get; set; }
    }
    public class MEFQuestionOption
    {
        public int? OptionID { get; set; }
        public string OptionName { get; set; }
        public int? QuestionID { get; set; }
        public bool? IsRight { get; set; }
        //public string Problem { get; set; }
        //public string Feedback { get; set; }
    }

    public class MEFQuestionOptionModel
    {
        public MEFQuestionOptionModel()
        {
            CrudAction = string.Empty;
        }
        public int QuestionID { get; set; }
        public List<int> checkArray { get; set; }
        public int OptionID { get; set; }
        public string Question { get; set; }
        public string QuestionType { get; set; }

        public string OptionName { get; set; }
        public int UserID { get; set; }
        public int TestID { get; set; }
        public int TestRegistrationID { get; set; }
        public string CrudAction { get; set; }
        public string TestType { get; set; }
        public string DescAns { get; set; }
    }

    public class MEFTestCode
    {
        public MEFTestCode()
        {
            ErrorCode = "";

        }
        public string ErrorCode { get; set; }

    }

    public class MEFTestResult
    {
        public int MEFTestMasterId { get; set; }
        public string TestName { get; set; }
        public int NoOfQuestion { get; set; }
        public int PassingMarks { get; set; }
        public int MEFTestRegistrationID { get; set; }
        public int TestScore { get; set; }
        public int Status { get; set; }
        public decimal Percentage { get; set; }
        public int TotalAttemptQuestion { get; set; }

    }

}
