﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    public class BankInfo
    {
         public Boolean? IsDefault { get; set; }
        public int ID { get; set; }
        public int UsersID { get; set; }
        public int UpdatedBy { get; set; }
        public string UpdatedUserRole { get; set; }
        public string BankCountry { get; set; }
        public string BankISOCode { get; set; }
        public int? LocationId { get; set; }
        public string RoutingID { get; set; }
        public string SwiftCode { get; set; }
        public string IBANNumber { get; set; }
        public string BankName { get; set; }
        public string BankAddress { get; set; }
        public string AccountName { get; set; }
        public string AccountNumber { get; set; }
        public string WireFee { get; set; }
        public string TaxID { get; set; }
        public string Currency { get; set; }
        public string BeneficiaryType { get; set; }
        public int IsVerified { get; set; }
        public string HomeAddress { get; set; }
        public string FLUserName { get; set; }
        public string FLUserEmailID { get; set; }
        public string FinanceUserName { get; set; }
        public string FinanceEmailID { get; set; }
        public int RoutingIDReq { get; set; }
        public int SwiftCodeReq { get; set; }
        public int IBANReq { get; set; }
        public int WireFeeReq { get; set; }
        public string Street1 { get; set; }
        public string City1 { get; set; }
        public string PostalCode1 { get; set; }
        public string State1 { get; set; }
        public string Location { get; set; }
        public string HomeCountry { get; set; }
    }

    public class BankingInfoParam
    {
        public int? UsersID { get; set; }
        public int? FLBankInfoId { get; set; }
    }

    public class FreelancerBankDashboardParameters
    {

        public int? UsersID { get; set; }
        public string sort { get; set; }
        public string dir { get; set; }
        public int currentpage { get; set; }
        public int pageSize { get; set; }

    }
    public class FreelancerBankDashboard
    {
        public int? FLBankInfoId { get; set; }
        public int? UsersID { get; set; }
        public string BankName { get; set; }
        public string AccountNumber { get; set; }
        public string WireFee { get; set; }
        public string FullName { get; set; }
        public string Currency { get; set; }
        public string BeneficiaryType { get; set; }
        public string Location { get; set; }
        public Boolean? IsDefault { get; set; }
    }

    public class SearchFreelancerInvoices
    {
        public int? UsersID { get; set; }
        public string UserEmailID { get; set; }
        public int? FLBankInfoId { get; set; }
    }

    public class SearchFreelancerAccountParameters
    {
        public string UserIDs { get; set; }
        public string FLBankInfoIds { get; set; }
        public string sort { get; set; }
        public string dir { get; set; }
        public int currentpage { get; set; }
        public int pageSize { get; set; }
        public List<string> FreelancerFilter { get; set; }
        public SearchFreelancerAccountParameters()
        {
            FreelancerFilter = new List<string>();
        }
    }

    public class FreelancerBankDetails
    {
        public Boolean select { get; set; }
        public int UsersID { get; set; }
        public string FreelancerName { get; set; }
        public string EmailID { get; set; }
        public string Currency { get; set; }
        public string WireFee { get; set; }
        public string BeneficiaryType { get; set; }
        public string FLEsproCode { get; set; }
        public string BankCountry { get; set; }
        public string RoutingID { get; set; }
        public string SwiftCode { get; set; }
        public string IBANNumber { get; set; }
        public string BankName { get; set; }
        public string BankAddress { get; set; }
        public string AccountNumber { get; set; }
        public string AccountName { get; set; }
        public string TaxID { get; set; }
        public string HomeAddress { get; set; }
        public string ContactNumber { get; set; }
        public string AlternateContactNumber { get; set; }
        public string IsVerified { get; set; }
        public bool isExpanded { get; set; }
        public bool isVisible { get; set; }
        public string Street1 { get; set; }
        public string City1 { get; set; }
        public string PostalCode1 { get; set; }
        public string State1 { get; set; }
        public string LocationsId1 { get; set; }
        public List<FreelancerBankInfoInnerData> freelancerBankInfoInnerData { get; set; }
        public FreelancerBankDetails()
        {
            freelancerBankInfoInnerData = new List<FreelancerBankInfoInnerData>();
        }
    }

    public class FreelancerBankInfoInnerData
    {
        public string EmailID { get; set; }
        public string HomeAddress { get; set; }
        public string ContactNumber { get; set; }
        public string AlternateContactNumber { get; set; }
    }
}
