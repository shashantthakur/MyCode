﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    class Certification
    {
    }

    public class Certificate
    {
        public int SkillTestMappingID { get; set; }
        public string TestName { get; set; }
        public int NoOfQuestion { get; set; }
        public int PassingMarks { get; set; }
        public string Description { get; set; }
        public string Administration { get; set; }
        public string SkillName { get; set; }
        public int SkillID { get; set; }
    }

    public class CertificateUserTestHistory
    {
        public int TestRegistrationID { get; set; }
        public string CompletionDate { get; set; }
        public string CreatedDate { get; set; }
        public string Status { get; set; }
        public int TestScore { get; set; }
    }

    public class AllocateTest
    {
        public AllocateTest()
        {
            TestRegistrationID = 0;
            TestID = 0;
        }
        public int? UsersId { get; set; }
        public int? TestID { get; set; }
        public int? TestRegistrationID { get; set; }
        public string CRUDAction { get; set; }
        public string TestName { get; set; }
        public string Administration { get; set; }
        public string Instruction { get; set; }
        public int SkillID { get; set; }
        public string PassingGrade { get; set; }
        public string Description { get; set; }
        public int BufferDays { get; set; }
    }

    public class SkillQuestion
    {
        public int? QuestionMasterID { get; set; }
        public int? RightOptionID { get; set; }
        public string Question { get; set; }
        public string ImageName { get; set; }
        public string AltText { get; set; }
        public int? SkillID { get; set; }
        public string QuestionType { get; set; }
        public int? SkillTestMappingID { get; set; }
        public int? NoOfQuestion { get; set; }
        public string TestName { get; set; }
        public int? AttendQuestion { get; set; }
        public int? FeedbackReq { get; set; }

        public IEnumerable<SkillQuestionOption> Options { get; set; }
    }
    public class SkillQuestionOption
    {
        public int? OptionID { get; set; }
        public string OptionName { get; set; }
        public int? QuestionID { get; set; }
        public bool? IsRight { get; set; }
        public string Problem { get; set; }
        public string Feedback { get; set; }
    }
    public class QuestionParam
    {
        public int? UserId { get; set; }
        public int? SkillID { get; set; }
        public int? TestID { get; set; }
        public int? TestRegistrationId { get; set; }
    }


    public class QuestionOptionModel
    {
        public QuestionOptionModel()
        {
            CrudAction = string.Empty;
        }
        public int QuestionID { get; set; }
        public List<int> checkArray { get; set; }
        public int OptionID { get; set; }
        public string Question { get; set; }
        public string QuestionType { get; set; }
        public string SKillID { get; set; }
        public string OptionName { get; set; }
        public int UserID { get; set; }
        public int TestID { get; set; }
        public int TestRegistrationID { get; set; }
        public string CrudAction { get; set; }
        public string TestType { get; set; }
        public string DescAns { get; set; }
    }

    public class TestResult
    {
        public TestResult()
        {
            ErrorCode = "";
            SkillCertification = "";
        }
        public string ErrorCode { get; set; }
        public string SkillCertification { get; set; }
    }
    public class TestAnalysis
    {
        public int? Seq { get; set; }
        public int? QuestionId { get; set; }
        public string Question { get; set; }
        public string UserAnswer { get; set; }
        public string ActualAnswer { get; set; }
        public string Explanation { get; set; }
    }

    public class UserTestInfo
    {
        public int? TestRegistrationID { get; set; }
        public int? Attempt { get; set; }
        public int? UserID { get; set; }
        public int? TestID { get; set; }
        public string CreatedDate { get; set; }
        public string CompletionDate { get; set; }
        public string Status { get; set; }
        public int? TestScore { get; set; }
        public string Administration { get; set; }
        public string TestName { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public string Result { get; set; }
        public string IsTestReAppeared { get; set; }
        public int? SkillPhase2TestID { get; set; }
        public string PDFPath { get; set; }
        public int? Phase2Status { get; set; }
        public int? SkillID { get; set; }
        public string SkillName { get; set; }
        public string Description { get; set; }
        public int NoOfQuestion { get; set; }
        public int PassingMarks { get; set; }
        public int SkillTestMappingID { get; set; }
    }


    public class TestResultFeedback
    {

        public int? TestRegistrationID { get; set; }
        public string Feedback { get; set; }
    }


    public class SkillPhase2Test
    {
        public int SkillPhase2TestID { get; set; }
        public int SkillID { get; set; }
        public string PDFPath { get; set; }
        public int BufferDays { get; set; }
        public int Status { get; set; }
        public string PassingMarks { get; set; }
        public string Description { get; set; }
        public string Instruction { get; set; }
        public string Administration { get; set; }
        public string TestName { get; set; }
        public int IsSetFirst { get; set; }
        public int CreatedBy { get; set; }
    }

    public class Phase2Registration
    {
        public int? Phase2RegistrationID { get; set; }
        public int? UserID { get; set; }
        public int? SkillPhase2TestID { get; set; }
        public string UploadedDate { get; set; }
        public int? Status { get; set; }
        public int? TestScore { get; set; }
        public Int16? IsPassed { get; set; }
        public string CheckedBy { get; set; }
        public DateTime? CheckedDate { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public string SkillName { get; set; }
        public string FilePath { get; set; }
        public string Type { get; set; }
        public string CrudAction { get; set; }
    }

    public class Phase2FileUpload
    {
        public int? UserID { get; set; }
        public int? Status { get; set; }
        public string Type { get; set; }
        public string CrudAction { get; set; }
        
        public int? SkillPhase2TestID { get; set; }
        public IFormFile SkillPhase2File { get; set; }
      
    }
    public class CertificateInfo : SkillTestMapping
    {
        public int NoOfUser { get; set; }
        public string SkillName { get; set; }
        public string StatusName { get; set; }
    }

    public class SkillTestMapping
    {
        public int SkillTestMappingID { get; set; }
        public int TestRegistrationID { get; set; }
        public int TestID { get; set; }
        public int SkillID { get; set; }
        public int ComplexityID { get; set; }
        public int NoOfQuestion { get; set; }
        public int BufferDays { get; set; }
        public int Status { get; set; }
        public string Name { get; set; }
        public string PassingMarks { get; set; }
        public string Description { get; set; }
        public string Instruction { get; set; }
        public string Administration { get; set; }
        public string SkillName { get; set; }
        public int UserConfigurationID { get; set; }
        public string FilePath { get; set; }

    }

    public class CertificateUser
    {

        public int? TestId { get; set; }
        public int? TestRegistrationID { get; set; }
        public int? UsersId { get; set; }
        public string UserName { get; set; }
        public string FullName { get; set; }
        public int WIP { get; set; }
        public int Passed { get; set; }
        public int Failed { get; set; }

    }

    public class SkillCertificateUser
    {
        public int UsersID { get; set; }
        public string FullName { get; set; }
        public string TestName { get; set; }
        public int Attempts { get; set; }
        public string Status { get; set; }
        public string QuestionAttempted { get; set; }
        public string TestScore { get; set; }
        public string Feedback { get; set; }
        public string ReActiveTest { get; set; }
    }

}
