﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    public class ErrorLog
    {
        public string RequestUri { get; set; }
        public string Host { get; set; }
        public string UsersId { get; set; }
        public string UserName { get; set; }
        public string StatusCode { get; set; }
        public string Type { get; set; }
        public string Message { get; set; }
    }
}
