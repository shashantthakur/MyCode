﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    class Master
    {
    }

    public class MasterRateUnit
    {
        public int RateUnitId { get; set; }
        public string RateUnit { get; set; }
    }
    public class Currency
    {
        public int CurrencyId { get; set; }
        public string CurrencyName { get; set; }
    }

    public class Locations
    {
        public int LocationsId { get; set; }
        public string Location { get; set; }
        public string ISOCode { get; set; }
        public int RoutingIDReq { get; set; }
        public int SwiftCodeReq { get; set; }
        public int IBANReq { get; set; }
        public int WireFeeReq { get; set; }
    }

    public class Languages
    {
        public int LanguagesID { get; set; }
        public string Language { get; set; }
    }

    public class Skills
    {
        public int SkillsId { get; set; }
        public string SkillName { get; set; }
        public string SkillCode { get; set; }
    }

    public class Stylesheets
    {
        public int StylesheetsId { get; set; }
        public int SkillID { get; set; }
        public string StylesheetName { get; set; }
    }

    public class SystemFamilarity
    {
        public int SystemFamilarityId { get; set; }
        public string SystemPlatform { get; set; }
    }

    public class AllMaster
    {
        public List<Locations> Locations { get; set; }
        public List<Languages> Languages { get; set; }
        public List<Skills> Skills { get; set; }
        public List<SystemFamilarity> SystemFamilarity { get; set; }

    }

    public class SubjectExpertise
    {
        public int ExpertiseId { get; set; }
        public string ExpertiseArea { get; set; }
    }

    public class SubDisciplines
    {
        public int SubDisciplinesId { get; set; }
        public int ExpertiseId { get; set; }
        public string SubDiscipline { get; set; }
    }

    public class SubjectMatterExpertise
    {
        public SubjectExpertise subjectExpertise { get; set; }
        public List<SubDisciplines> subDisciplines { get; set; }
    }
    public class SubjectMatterExpertiseGroup
    {
        public int ExpertiseId { get; set; }
        public string ExpertiseArea { get; set; }
        public int SubDisciplinesId { get; set; }        
        public string SubDiscipline { get; set; }
    }

        public class Clients
    {
        public int ClientId { get; set; }
        public string ClientName { get; set; }

        public bool IsVendorAllow { get; set; }
    }

    public class Qualifications
    {
        public string ID { get; set; }
        public string Qualification { get; set; }
    }


    public class WritingSample
    {
        public int? UserWrittingSampleId { get; set; }
        public int? UsersId { get; set; }
        public string Headline { get; set; }
        public string WrittingSample { get; set; }
        public List<int> ClientId { get; set; }
    }

    public class MEFLearningPath
    {
        public int Id { get; set; }
        public string LearningPath { get; set; }
        public int? MEFUserLearningPathMappingId { get; set; }
        public Boolean disabled { get; set; }
        public string MEFLearningPaths { get; set; }
        public int FreelancerID { get; set; }
        public int UserID { get; set; }
    }

    public class UserFLComments
    {
        public int? UserOtherInfoId { get; set; }
        public int? UsersId { get; set; }
        public string Headline { get; set; }
        public string FLComments { get; set; }
        public string AdminComment { get; set; }
        public string ClientComment { get; set; }
        public List<int> ClientId { get; set; }
        public List<int> PreferredId { get; set; }
    }

    public class Rating
    {
        public int RatingId { get; set; }
        public string RatingTitle { get; set; }
    }

    public class RatingCategories
    {
        public int CatagoryId { get; set; }
        public string RatingCatagory { get; set; }
    }

    public class ImageREsult
    {
        public string usersid { get; set; }
        public string Image { get; set; }
    }

    public class Roles
    {
        public int RoleId { get; set; }
        public string UserRole { get; set; }
        public string RoleTitle { get; set; }
    }

    public class AgencyMaster
    {
        public int AgencyId { get; set; }
        public string AgencyName { get; set; }
    }

    public class UserMaster
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
    }

    public class SelectList
    {
        public string Value { get; set; }
        public string Text { get; set; }
    }

}
