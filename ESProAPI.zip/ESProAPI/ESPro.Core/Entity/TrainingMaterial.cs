﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    public class TrainingMaterial
    {
        public int? TrainingMaterialId { get; set; }
        public string UnitTitle { get; set; }
        public string UnitTitle1 { get; set; }
        public string bgColor { get; set; }
        public int? RoleId { get; set; }
        public int? UnitSeq { get; set; }
    }

    public class SearchTrainingDetails
    {
        public int? TrainingDetailsId { get; set; }
        public int? TrainingMasterId { get; set; }
        public string SubUnitText { get; set; }
        public string FileType { get; set; }
        public string Duration { get; set; }
        public int? ViewCount { get; set; }
        public string Keyword { get; set; }
    }

    public class TrainingDetails
    {
        public int? TrainingDetailsId { get; set; }
        public int? TrainingMasterId { get; set; }
        public int? TrainingMenuId { get; set; }
        public string SubUnitText { get; set; }
        public string FileType { get; set; }
        public string FilePath { get; set; }
        public string SrtPath { get; set; }
        public string VttPath { get; set; }
        public string Duration { get; set; }
        public string Discription { get; set; }
        public string Learning { get; set; }
        public string ThumbnailPath { get; set; }
        public int? ViewCount { get; set; }
        public string Keyword { get; set; }
    }
    public class TrainingMaterialList
    {
        public int? TrainingMaterialId { get; set; }
        public string UnitTitle { get; set; }
        public string UnitTitle1 { get; set; }
        public string bgColor { get; set; }
        public int? RoleId { get; set; }

        public int? UnitSeq { get; set; }
        public List<TrainingDetails> TrainingDetailsList { get; set; }
    }

    public class TrainingMaterialMenu
    {
        public int? TrainingMaterialMenuId { get; set; }
        public string Heading { get; set; }
        public string bgColor { get; set; }
        public string RedirectType { get; set; }
        public List<TrainingDetails> TrainingDetailsList { get; set; }
    }
    public class TrainingVideoDescription
    {
        public int? Id { get; set; }
        public int? TrainingDetailsId { get; set; }
        public int? Second { get; set; }
        public string Description { get; set; }
    }

    public class VTT_TranScript
    {
        public int? Id { get; set; }

        public string TrsanScriptText { get; set; }
        public double StartTime { get; set; }
        public double EndTime { get; set; }
    }

    public class UpdateTrainingViewsCount
    {
        public int UserID { get; set; }
        public string UserEmailID { get; set; }
        public int TrainingDetailsId { get; set; }
        public int VideoViews { get; set; }
    }

    public class InsertLikeDislikeFlagCountParameters
    {
        public int TrainingDetailsId { get; set; }
        public int UserID { get; set; }
        public string LikeDislikeFlag { get; set; }
        public string VideoIssues { get; set; }
        public string AudioIssues { get; set; }
        public string SubtitlesIssues { get; set; }
        public string ContentRecommendations { get; set; }
        public string FlagOffensiveContent { get; set; }
        public string Type { get; set; }
        public Boolean? Anonymous { get; set; }
    }

    public class LikeDislikeFlagCount
    {
        public int TotalLikeCount { get; set; }
        public int TotalDisLikeCount { get; set; }
        public int TotalFlagCount { get; set; }
        public int UserLikeCount { get; set; }
        public int UserDisLikeCount { get; set; }
        public int UserFlagCount { get; set; }
    }
    public class TrainingVideoReport
    {
        public int? TrainingVideoReportId { get; set; }
        public int? TrainingDetailsId { get; set; }
        public DateTime? EnteredOn { get; set; }
        public string Name { get; set; }
        public string SubUnitText { get; set; }
        public string VideoIssues { get; set; }
        public string AudioIssues { get; set; }
        public string SubtitlesIssues { get; set; }

        public string ContentRecommendations { get; set; }
        public string FlagOffensiveContent { get; set; }

        public string Anonymous { get; set; }
    }
}