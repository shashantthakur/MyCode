﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
   public class BulkMail
    {
        public int? UsersId { get; set; }
        public string UserName { get; set; }
        public string FullName { get; set; }        
        public int? FilterId { get; set; }
        public List<int> RolesId { get; set; }
        public string MailSubject { get; set; }
        public string MailBody { get; set; }
        public string MailTo { get; set; }
    }

    public class RoleWiseUserList
    {
        public int? UsersId { get; set; }
        public string UserName { get; set; }
        public string UserRole { get; set; }   
        public string FullName { get; set; }
    }

    public class MailTemplate
    {       
        public int? MailTemplateId { get; set; }
        public int? UsersId { get; set; }
        public string TemplateName { get; set; }
        public string MailSub { get; set; }
        public string MailBody { get; set; }
    }
}
