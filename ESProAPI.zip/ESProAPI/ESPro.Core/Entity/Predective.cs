﻿﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    public class Predective
    {
        //public int statusCode { get; set; }
        //public string message { get; set; }
        //public string data { get; set; }
        public string Name { get; set; }
        public Decimal? Value { get; set; }

    }

    public class PredictiveResult
    {
        public string FSResult { get; set; }
        public string WritingNotes { get; set; }
    }

    public class PredictiveData
    {
        public int UsersID { get; set; }
        public string WritingNotes { get; set; }
    }

    public class PredectiveModel
    {
        public List<Predective> Values { get; set; }
        public List<Predective> Openness { get; set; }
        public List<Predective> Need { get; set; }
        public List<Predective> Conscientiousness { get; set; }
        public List<Predective> Extraversion { get; set; }
        public List<Predective> Agreeableness { get; set; }
        public List<Predective> Emotional_range { get; set; }
        public string Result { get; set; }
        public PredectiveModel()
        {
            Values = new List<Predective>();
            Openness = new List<Predective>();
            Need = new List<Predective>();
            Conscientiousness = new List<Predective>();
            Extraversion = new List<Predective>();
            Agreeableness = new List<Predective>();
            Emotional_range = new List<Predective>();
        }
    }
}