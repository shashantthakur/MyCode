﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    public class KillJobs
    {
        public string KillJobIds { get; set; }
        public int UpdatedBy { get; set; }
    }
}
