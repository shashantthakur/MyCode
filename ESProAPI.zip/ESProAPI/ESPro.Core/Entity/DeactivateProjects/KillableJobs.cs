﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    public class KillableJobs
    {
        public Int64 JobId { get; set; }
        public string JobNo { get; set; }
        public string JobStatus { get; set; }
        public string Client { get; set; }
        public string ISBN13 { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string FreelancerName { get; set; }
        public string FreelancerEmail { get; set; }
        public string ProjectManager { get; set; }
        public string ProjectManagerEmail { get; set; }
    }

    public class SearchKillableJobs
    {
        public string CompletionStartDate { get; set; }
        public string CompletionEndDate { get; set; }
        public string JobNos { get; set; }
        public string Authors { get; set; }
        public string sort { get; set; }
        public string dir { get; set; }
        public int currentpage { get; set; }
        public int pageSize { get; set; }
    }
}
