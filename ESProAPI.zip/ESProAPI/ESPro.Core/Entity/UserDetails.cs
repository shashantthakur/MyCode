﻿
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    public class UsersDetails
    {
        public Users users { get; set; }
        public AddressDetails addressDetails { get; set; }
        public PersonalDetails personalDetails { get; set; }
    }
    public class Users
    {
        public int? UsersId { get; set; }
        public string UserName { get; set; }
        public string CommunicationEmai { get; set; }
        public string Password { get; set; }
        public DateTime? CreatedDate { get; set; }

        public int? ProfileCompleteness { get; set; }
    }

    public class UsersDetailsModel
    {
        public int? UsersId { get; set; }
        public string UserName { get; set; }
        public string CommunicationEmai { get; set; }
        public string Password { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string Name { get; set; }
        public int? ProfileCompleteness { get; set; }
        public string AuthenticationType { get; set; }
    }

    public class PersonalDetails
    {
        public int? UsersId { get; set; }
        public string FullName { get; set; }
        public string Currency { get; set; }
        public double? TargetHourlyRate { get; set; }
        public double? WireFee { get; set; }
        public string ContactNumber { get; set; }
        public string AlternateContactNumber { get; set; }
        public string Fax { get; set; }
        public string PrimaryContact { get; set; }
    }

    public class FreelancerList
    {
        public int ID { get; set; }
        public string FullName { get; set; }
    }

    public class AdminComments
    {
        public string usersid { get; set; }
        public string GenComment { get; set; }
        public string ClientComments { get; set; }
        public string CurrentUserRole { get; set; }
        public string CurrentUsersId { get; set; }
        public string CurrentClientcode { get; set; }
    }
    public class AddressDetails
    {
        public int? UsersId { get; set; }
        public string Street1 { get; set; }
        public string City1 { get; set; }
        public string State1 { get; set; }
        public string PostalCode1 { get; set; }
        public string Street2 { get; set; }
        public string City2 { get; set; }
        public string State2 { get; set; }
        public string PostalCode2 { get; set; }
        public int? LocationsId1 { get; set; }
        public int? LocationsId2 { get; set; }
    }
    public class UserSkills
    {
        public int? UsersId { get; set; }
        public string CompanyName { get; set; }
        public string WorkTime { get; set; }
        public string DigitalContentExperience { get; set; }
        public List<int> Languages { get; set; }
        public List<int> Skills { get; set; }
        public List<int> Stylesheets { get; set; }
        public List<int> SubDisciplines { get; set; }
        public List<int> SystemFamilarity { get; set; }
        public List<UserDisciplineEducationLevel> userDisciplineEducationLevels { get; set; }

        public List<UserSystemExperienceLevel> userSystemExperienceLevels { get; set; }
    }
    public class UserSkillsSingle
    {
        public int? UsersId { get; set; }
        public string CompanyName { get; set; }
        public string WorkTime { get; set; }
        public string DigitalContentExperience { get; set; }
    }
    public class UserSelectedSkills
    {
        public int FieldId { get; set; }
        public string TableName { get; set; }

    }
    public class ComponentPermission
    {
        public int? ComponentId { get; set; }
        public string ComponentName { get; set; }
        public string Description { get; set; }
    }
    public class UserDisciplineEducationLevel
    {
        public int? DisciplineEducationLevelId { get; set; }
        public int? UsersId { get; set; }
        public int? SubDisciplinesId { get; set; }
        public string SubDiscipline { get; set; }
        public Boolean? WorkingKnowledgeOnly { get; set; }
        public Boolean? CollegeDegree { get; set; }
        public Boolean? MasterDegree { get; set; }
        public Boolean? PhD { get; set; }
        public Boolean? TeachingExperience { get; set; }
    }

    public class UserSystemExperienceLevel
    {
        public int? SystemExperienceLevelId { get; set; }
        public int? UsersId { get; set; }
        public int? SystemFamilarityId { get; set; }
        public string SystemPlatform { get; set; }
        public Boolean? Beginner { get; set; }
        public Boolean? Experienced { get; set; }
        public Boolean? Advanced { get; set; }

    }

    public class UserSelectedClients
    {
        public int? ClientsId { get; set; }

    }

    public class ResumeAndSample
    {
        public int? UsersId { get; set; }
        public string ResumeFilePath { get; set; }
        public string SampleFilePath { get; set; }
        public string LinkToOnlineProfile { get; set; }
    }

    public class UserProfile
    {

        public int? UsersId { get; set; }
        public string UserName { get; set; }
        public string FullName { get; set; }
        public double? TargetHourlyRate { get; set; }
        public double? Rating { get; set; }
        public string Picture { get; set; }
        public string ContactNumber { get; set; }
        public string CompanyName { get; set; }
        public string Headline { get; set; }
        public int? ProfileCompleteness { get; set; }
        public int? RoleId { get; set; }
        public string LastUpdatedDate { get; set; }
        public string UserRole { get; set; }
        public string PreferredFreelancer { get; set; }
        public string CertificationName { get; set; }
        public int SmartAssessor { get; set; }
    }

    public class UserRoles
    {
        public int RolesId { get; set; }
        public string UserRole { get; set; }
        public string RoleTitle { get; set; }
    }

    public class SearchRoleParameter
    {
        public int UsersID { get; set; }
        public string UserRole { get; set; }
    }

    public class ResumeSample
    {
        public int? UsersId { get; set; }
        public IFormFile Resume { get; set; }
        public IFormFile SampleFile { get; set; }
        public string OnlineProfile { get; set; }

    }



    public class UserResumeSample
    {
        public int? UsersId { get; set; }
        public string ResumeFilePath { get; set; }
        public string SampleFilePath { get; set; }
        public string LinkToOnlineProfile { get; set; }

    }



    public class UserProfileCompleteness
    {
        public int? ProfileCompleteness { get; set; }

    }

    public class InvoiceModelData
    {
        public int invoiceNumber { get; set; }
        public string createdByEmail { get; set; }
        public string invoiceDate { get; set; }
        public string approvedRejectedDate { get; set; }
        public string freelancerEmailId { get; set; }
        public string Contracted_Currency { get; set; }
        public string noOfFRFitems { get; set; }
        public string totalAmount { get; set; }
        public string jobNo { get; set; }
        public List<FreelancerInvoiceCost> invoiceDetails = new List<FreelancerInvoiceCost>();
    }

    public class FreelancerInvoiceCost
    {
        public string hrs { get; set; }
        public string recordId { get; set; }
        public string newRecordId { get; set; }
        public string assignmentId { get; set; }
        public string unitType { get; set; }
        public string contractedAmount { get; set; }
        public string Contracted_Currency { get; set; }
        public string noOfUnit { get; set; }
        public string sumAmount { get; set; }
        public string ratePerUnit { get; set; }
        public string serviceName { get; set; }
        public string notes { get; set; }
        public string invoiceType { get; set; }
    }

}
