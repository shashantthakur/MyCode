﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    public class RatingUsers
    {
        public int UsersId { get; set; }
        public string UserName { get; set; }
        public string EmailId { get; set; }
    }
}
