﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{

    public class RatingParamaters
    {
        public int UsersId { get; set; }
        public int currentuserid { get; set; }
        public string currentuserrole { get; set; }
        public string sort { get; set; }
        public string dir { get; set; }
        public int currentpage { get; set; }
        public int pageSize { get; set; }
        public List<string> JobFilter { get; set; }
        //public List<string> FreelancerFilter { get; set; }
        public RatingParamaters()
        {
            JobFilter = new List<string>();
            //FreelancerFilter = new List<string>();
        }
    }
    public class RatingDetails
    {
        public Boolean select { get; set; }
        public Int64 RatingId { get; set; }
        public Int64 JobId { get; set; }
        public string JobNo { get; set; }
        public string Client { get; set; }
        public string ISBN13 { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string Edition { get; set; }

        public int FreelancerUserID { get; set; }
        public string AgencyUser { get; set; }
        public string FreelancerName { get; set; }
        public string ProjectManager { get; set; }

        public string OverallQualityOfWork { get; set; }
        public string AdherenceToSchedule { get; set; }
        public string Communication { get; set; }

        public bool isExpanded { get; set; }
        public bool isVisible { get; set; }

        public string AgencyUserEmailID { get; set; }
        public string FreelancerEmailID { get; set; }
        public string ProjectManagerEmail { get; set; }
        public string InvApproverName { get; set; }
        public string InvApproverEmail { get; set; }
        public string InvApproverName2 { get; set; }
        public string InvApproverEmail2 { get; set; }

        public List<RatingDetailsInnerData> ratingDetailsInnerData { get; set; }
        public RatingDetails()
        {
            ratingDetailsInnerData = new List<RatingDetailsInnerData>();
        }
    }

    public class RatingDetailsInnerData
    {
        public Int64 JobId { get; set; }
        public string AgencyUserEmailID { get; set; }
        public string FreelancerEmailID { get; set; }
        public string ProjectManagerEmail { get; set; }
        public string InvApproverName { get; set; }
        public string InvApproverEmail { get; set; }
        public string InvApproverName2 { get; set; }
        public string InvApproverEmail2 { get; set; }
    }
}
