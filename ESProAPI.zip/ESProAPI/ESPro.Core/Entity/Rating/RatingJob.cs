﻿using ESPro.Core.Entity.Client;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    class RatingJob
    {
    }

    public class DefaultRating : RatingModelForJob
    {
        public JobDetailsModel jobDetailsModel = new JobDetailsModel();
        public List<RatingModel> lstddlATSRating = new List<RatingModel>();
        public List<RatingModel> lstddlOQWRating = new List<RatingModel>();
        public List<RatingModel> lstddlCommunicationRating = new List<RatingModel>();
    }
    public class RatingModelForJob
    {
        public int ddlATSRating { get; set; }
        public int ddlOQWRating { get; set; }
        public int ddlCommunicationRating { get; set; }

        public string OQWComments { get; set; }
        public string ATSComments { get; set; }
        public string CommunicationComments { get; set; }
        public string ButtonName { get; set; }

    }
    public class RatingModel
    {       
        public int ID { get; set; }       
        public string Rating { get; set; }
    }
}
