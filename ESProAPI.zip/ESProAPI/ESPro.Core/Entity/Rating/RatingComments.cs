﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    public class RatingComments
    {
        public int CommentsId { get; set; }
        public int RatingCategoryId { get; set; }
        public string Comments { get; set; }
        public int OverallQualityOfWork { get; set; }
        public int AdherenceToSchedule { get; set; }
        public int Communication { get; set; }
    }
}
