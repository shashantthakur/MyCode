﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    public class RatingSave
    {
        public Int64 RatingId { get; set; }
        public Int64 JobId { get; set; }
        public Int64 UsersId { get; set; }

        public string FreelanceName { get; set; }
        public string FreelancerEmailID { get; set; }
        public string AgencyUser { get; set; }
        public string AgencyUserEmailID { get; set; }
        public string JobPM { get; set; }
        public string InvApproverEmail { get; set; }
        public string InvApproverEmail2 { get; set; }

        public string Skill { get; set; }
        public string JobNo { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }

        public Int64 OverallQualityRating { get; set; }
        public Int64 OverallQualityCatagoryId { get; set; }
        public Int64 OverallQualityCommentId { get; set; }
        public string OverallQualityComment { get; set; }

        public Int64 AdherenceToScheduleRating { get; set; }
        public Int64 AdherenceToScheduleCommentId { get; set; }
        public Int64 AdherenceToScheduleCatagoryId { get; set; }
        public string AdherenceToScheduleComment { get; set; }

        public Int64 CommunicationRating { get; set; }
        public Int64 CommunicationCommentId { get; set; }
        public Int64 CommunicationCatagoryId { get; set; }
        public string CommunicationComment { get; set; }
        public Int64 RatedBy { get; set; }

        public string RatingFrom { get; set; }

        public string UserName { get; set; }
        public string UserEmailID { get; set; }
        public string UserRole { get; set; }
        public Int64 InvoiceId { get; set; }
    }
}
