﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    public class RatingJobNoDetails
    {
        public Int64? RatingId { get; set; }
        public Int64 JobId { get; set; }
        public string JobNo { get; set; }
        public Int64? UsersId { get; set; }
        public string Client { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string Edition { get; set; }
        public string Skill { get; set; }
        public string ISBN13 { get; set; }
        public string Unit { get; set; }
        public string NoOfUnits { get; set; }
        public string Budget { get; set; }
        public string BudgetCurrency { get; set; }
        public string ContractedRate { get; set; }
        public string ContractedCurrency { get; set; }
        public string OverallQualityOfWork { get; set; }
        public string AdherenceToSchedule { get; set; }
        public string Communication { get; set; }
        public string FreelancerName { get; set; }
        public string FreelancerEmailID { get; set; }
        public string AgencyUser { get; set; }
        public string AgencyUserEmailID { get; set; }
        public string JobPM { get; set; }
        public string InvApproverEmail { get; set; }
        public string InvApproverEmail2 { get; set; }
        public DateTime? RatedOn { get; set; }
    }
}
