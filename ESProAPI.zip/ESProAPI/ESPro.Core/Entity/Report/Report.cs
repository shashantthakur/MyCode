﻿using ESPro.Core.Entity.Search;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity.Report
{
    public class ReportType
    {
        public int ID { get; set; }
        public string ReportName { get; set; }
    }

    public class CustomerWorked
    {
        public string Customer { get; set; }
    }

    public class MasterOverdueReports
    {
        public int ID { get; set; }
        public string ReportName { get; set; }
    }

    public class MasterRatingCompositeReport
    {
        public int ID { get; set; }
        public string RatingCompositeName { get; set; }
    }

    public class TestCompletedUsers
    {
        public string Value { get; set; }
        public string Text { get; set; }
    }

    public class CustomeRoles
    {
        public int ID { get; set; }
        public string RoleName { get; set; }
    }

    public class ReportParameters
    {
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public int ReportID { get; set; }
        public string Role { get; set; }
        public string UsersId { get; set; }
        public string UserEmailID { get; set; }
        public int ClientCode { get; set; }
        public string ClientName { get; set; }
        public string Customers { get; set; }
        public int OverdueReportID { get; set; }
        public int RatingCompositeReportID { get; set; }
        public string FreelancerName { get; set; }
        public string Skills { get; set; }
        public string Disciplines { get; set; }
        public string CustomeRoles { get; set; }
        public string InvoiceStatus { get; set; }
        public string InvoiceDateType { get; set; }
        public int CurrentUserId { get; set; }
    }

    public class TestResultCompleted
    {
        public string userName { get; set; }
        public string userId { get; set; }
        public string TargetHourlyRate { get; set; }
        public string Location { get; set; }
        public List<TestCompleted> lstTestCompleted = new List<TestCompleted>();
    }

    //public class TestCompleted
    //{
    //    public string HourlyRate { get; set; }
    //    public decimal AwardTotal { get; set; }
    //    public string rank { get; set; }
    //    public string user_first_name { get; set; }
    //    public string user_last_name { get; set; }
    //    public string user_id { get; set; }
    //    public string user_email { get; set; }
    //    public string test_completed_name { get; set; }
    //    public string test_completed_number { get; set; }
    //    public string correlation { get; set; }
    //    public decimal correlation2 { get; set; } //Sorting
    //    public string useremail { get; set; }
    //    public string Rating { get; set; }
    //    public string user_role { get; set; }
    //    public decimal OverAllRating { get; set; }
    //    public decimal AdherenceToSchedule { get; set; }
    //    public decimal Communication { get; set; }
    //    public decimal OverallQualityOfWork { get; set; }
    //    public string OfProjectRated { get; set; }
    //    public string Location { get; set; }
    //}

    //public class ExistingRecord
    //{
    //    public int ID { get; set; }
    //    public string user_id { get; set; }
    //    public string skills { get; set; }
    //    public string username { get; set; }
    //    public string americanized_user_id { get; set; }
    //    public string Rating { get; set; }
    //    public string HourlyRate { get; set; }
    //    public string user_role { get; set; }
    //    public decimal OverAllRating { get; set; }
    //    public decimal AdherenceToSchedule { get; set; }
    //    public decimal Communication { get; set; }
    //    public decimal OverallQualityOfWork { get; set; }
    //    public string OfProjectRated { get; set; }
    //    public string Location { get; set; }
    //}

    public class DemographicData
    {

    }

    public class ServiceReport
    {
        public string JobNo { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public DateTime? AssignedDate { get; set; }
        public DateTime? CompletionDate { get; set; }
        public string AssignmentType { get; set; }
        public string FreelancerType { get; set; }
        public string Service { get; set; }
        public string Skill { get; set; }
        public string NoOfUnits { get; set; }
        public string Unit { get; set; }
        public string ClientBudget { get; set; }
        public string ContractedRate { get; set; }
        public string AgencyName { get; set; }
        public string FreelancerName { get; set; }
        public string PM_Name { get; set; }
        public string invApproverName { get; set; }
        public string InvApproverName2 { get; set; }
    }

    public class RatingReport
    {
        public string Name { get; set; }
        public string UserID { get; set; }
        public string AgencyName { get; set; }
        public string Clients { get; set; }
        public string TargetHourlyRate { get; set; }
        public string OverAllRating { get; set; }
        public string AdherenceToSchedule { get; set; }
        public string Communication { get; set; }
        public string OverallQualityOfWork { get; set; }
        public string OfProjectRated { get; set; }
        public string Location { get; set; }
        public string Skills { get; set; }
        public string ExpertArea { get; set; }
    }

    public class SubDisciplineRatingReport
    {
        public string Name { get; set; }
        public string UserID { get; set; }
        public string AgencyName { get; set; }
        public string Clients { get; set; }
        public string TargetHourlyRate { get; set; }
        public string OverAllRating { get; set; }
        public string AdherenceToSchedule { get; set; }
        public string Communication { get; set; }
        public string OverallQualityOfWork { get; set; }
        public string OfProjectRated { get; set; }
        public string Location { get; set; }
        public string SubDiscipline { get; set; }
        public string ExpertArea { get; set; }
        public string Skills { get; set; }
    }

    public class RatingHistoryReport
    {
        public string RatingId { get; set; }
        public string JobId { get; set; }
        public string JobNo { get; set; }
        public string FreelancerName { get; set; }
        public string FreelancerEmailId { get; set; }
        public string OverallQualityofWork { get; set; }
        public string AdherenceToSchedule { get; set; }
        public string Communication { get; set; }
        public string OverallJobRating { get; set; }
        public string Customer { get; set; }
        public string ISBN13 { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string Edition { get; set; }
        public string Skill { get; set; }
        public string PM_Name { get; set; }
        public string PMEmailId { get; set; }
        public string InvApproverName { get; set; }
        public string InvApproverName2 { get; set; }
        public string JobRatedBy { get; set; }
        public string ProjectType { get; set; }
    }

    public class OverDueReport
    {
        public string JobNo { get; set; }
        public string Customer { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string AgencyName { get; set; }
        public string FreelancerName { get; set; }
        public DateTime? CompletionDate { get; set; }
        public string PM_Name { get; set; }
        public string JobPM { get; set; }
        public string InvApproverName { get; set; }
        public string InvApproverEmail { get; set; }
        public string InvApproverName2 { get; set; }
        public string InvApproverEmail2 { get; set; }
        public string Skill { get; set; }
        public string AssignedBy { get; set; }
        public string RatingMethod { get; set; }
        public string Vertical { get; set; }
        public string DepartmentHead { get; set; }
        public string FreelancerLocation { get; set; }
        public string CustomerContactName { get; set; }
        public string CustomerContactEmail { get; set; }
        public DateTime? ExpectedCompletionDate { get; set; }
        public string IsManualRecord { get; set; }
    }

    public class PredictiveTestingReport
    {
        public string EmployeeCode { get; set; }
        public string FreelancerName { get; set; }
        public string AgencyName { get; set; }
        public DateTime? DateCreated { get; set; }
        public string UserEmailID { get; set; }
        public string UserRole { get; set; }
        public string FSStatus { get; set; }
        public string Location { get; set; }
    }

    public class RatingCompositeReport
    {
        public string UserID { get; set; }
        public string Name { get; set; }
        public string AgencyName { get; set; }
        public string Clients { get; set; }
        public string OverAllRating { get; set; }
        public string AdherenceToSchedule { get; set; }
        public string Communication { get; set; }
        public string OverallQualityOfWork { get; set; }
        public string OfProjectRated { get; set; }
        public string Location { get; set; }
        public string Skills { get; set; }
        public string Result { get; set; }
        public string FsResultDate { get; set; }
        public string userrole { get; set; }
    }

    public class FLInvoicesPendingPMApprovalReport
    {
        public string JobNo { get; set; }
        public string Customer { get; set; }
        public string FreelancerName { get; set; }
        public string Name { get; set; }
        public string Status { get; set; }
        public string TotalAmount { get; set; }
        public string InvoiceDate { get; set; }
        public string InvApproveDate1 { get; set; }
        public string Vertical { get; set; }
        public string Service { get; set; }
        public string Skill { get; set; }
        public string PM_Name { get; set; }
        public string JobPM { get; set; }
        public string InvApproverName { get; set; }
        public string InvApproverEmail { get; set; }
        public string InvApproverName2 { get; set; }
        public string InvApproverEmail2 { get; set; }
        public string ContractedBy { get; set; }
    }

    public class PersonalInsights
    {
        public int ID { get; set; }
        public string EmailID { get; set; }
        public string Result { get; set; }
        public string FsResultDate { get; set; }
        public string username { get; set; }
        public string AgencyName { get; set; }
        public string user_role { get; set; }
    }

    public class LuminaFreelancerCost
    {
        public string JobNo { get; set; }
        public string Customer { get; set; }
        public string FreelancerName { get; set; }
        public string Name { get; set; }
        public string Unit { get; set; }
        public string NoOfUnit { get; set; }
        public string BudgetValuePerUnit { get; set; }
        public string BudgetCurrency { get; set; }
        public string ValuePerUnit { get; set; }
        public string ContractedCurrency { get; set; }
        public string TotalAmount { get; set; }
        public string AmountInUSD { get; set; }
        public string Status { get; set; }
        public string InvoiceDate { get; set; }
        public string ApprovedDate { get; set; }
        public string ApprovedDate2 { get; set; }
        public string vertical { get; set; }
        public string service { get; set; }
        public string Skill { get; set; }
        public string InvApproverName { get; set; }
        public string InvApproverEmail { get; set; }
        public string InvApproverName2 { get; set; }
        public string InvApproverEmail2 { get; set; }
        public string ContractedBy { get; set; }
    }

    public class WileyFreelancerCost
    {
        public string Month { get; set; }
        public string Year { get; set; }
        public DateTime InvoiceDate { get; set; }
        public DateTime DateInvoicePaid { get; set; }
        public string Name { get; set; }
        public string WileyContact { get; set; }
        public string ContractorName { get; set; }
        public string isbn13 { get; set; }
        public string Skill { get; set; }
        public string GLCode { get; set; }
        public string LocalCurrencyAmount { get; set; }
        public string AmountInUSD { get; set; }
        public string BankChargesInLocalCurrency { get; set; }
        public string Total { get; set; }
        public string AmountRemaining { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string Edition { get; set; }
        public DateTime? APActionDate { get; set; }
        public string CreditDebitType { get; set; }
        public string LocalCreditAmount { get; set; }
        public string CreditAmountInUSD { get; set; }
        public string CreditReason { get; set; }
        public DateTime? CreditEnteredDate { get; set; }
    }

    public class TaskReport
    {
        public string FullName { get; set; }
        public string Username { get; set; }
        public string AgencyName { get; set; }
        public string UserRole { get; set; }
        public string NumberOfProjectsRated { get; set; }
        public string JobRatedBySkillwise { get; set; }
        public string ProfileCreationDate { get; set; }
        public string AvgOverallQualityOfWork { get; set; }
        public string AvgAdherenceToSchedule { get; set; }
        public string AvgCommunication { get; set; }
        public string AvgOverallJobRating { get; set; }
        public string empno { get; set; }
        public string EmpSupervisor { get; set; }
        public string EmpDesignation { get; set; }
        public string EmpCity { get; set; }
        public string Location { get; set; }
        public string Skills { get; set; }
        public string StatusofFSWritingSample { get; set; }
    }

    public class FreelancerRollOff
    {
        public string FullName { get; set; }
        public string EmailID { get; set; }
        public decimal? CompositeRating { get; set; }
        public decimal? OverallQualityofWork { get; set; }
        public decimal? AdherencetoSchedule { get; set; }
        public decimal? Communication { get; set; }
        public string JobNo { get; set; }
        public string InvApprover { get; set; }
        public string InvApprover2 { get; set; }
        public string Client { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string Edition { get; set; }
        public string TaskAssigned { get; set; }
        public decimal? Units { get; set; }
        public decimal? ContractedRate { get; set; }
        public decimal? RatePerUnit { get; set; }
        public string ContractedCurrency { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
    public class AdHocMLReport
    {
        public string FullName { get; set; }
        public string UserName { get; set; }
        public string RoleTitle { get; set; }
        public string Field { get; set; }
        public string Skills { get; set; }
        public string Language { get; set; }
        public string Location { get; set; }
        public string FLComments { get; set; }
    }

    public class MacMillanFreelancerDetails
    {
        public string UserName { get; set; }
        public string FullName { get; set; }
        public string Skills { get; set; }
        public string SubDiscipline { get; set; }
        public string WorkingKnowledgeOnly { get; set; }
        public string CollegeDegree { get; set; }
        public string MasterDegree { get; set; }
        public string PhD { get; set; }
        public string TeachingExperience { get; set; }
        public string CompositeOverallRating { get; set; }
        public string TotalProjectsRated { get; set; }
        public string MLComments { get; set; }
        public string FLComments { get; set; }
    }

    public class MacMillanCompletedJobs
    {
        public string JobNo { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string JobCategory { get; set; }
        public string FreelancerName { get; set; }
        public string PM_Name { get; set; }
        public string Clientname { get; set; }
        public string Skill { get; set; }
        public string AdherancetoScheduleRating { get; set; }
        public string AdherancetoScheduleComment { get; set; }
        public string OverallQualityofWorkRating { get; set; }
        public string OverallQualityofWorkComment { get; set; }
        public string CommunicationRating { get; set; }
        public string CommunicationComment { get; set; }
        public string OverallJobRating { get; set; }
    }

    public class MacMillanPendingJobs
    {
        public string JobNo { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string JobCategory { get; set; }
        public string FreelancerName { get; set; }
        public string PM_Name { get; set; }
        public string Clientname { get; set; }
        public string Skill { get; set; }
        public string AssignedDate { get; set; }
        public string ExpectedCompletionDate { get; set; }
    }

    public class SmartAssessorReport
    {

    }
}


