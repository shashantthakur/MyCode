﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity.HSBC
{
    public class TransactionMaster
    {
        public string transactionDate { get; set; }
        public string transactionTimeFrom { get; set; }
        public string transactionTimeTo { get; set; }
        public string accountNumber { get; set; }
        public string accountCountry { get; set; }
        public string accountType { get; set; }
        public string institutionCode { get; set; }    
    }
    public class HSBCTransactionEnquiry
    {
        public string transactionsRequestBase64 { get; set; }

    }
    public class TransactionEnqResponce
    {
        public string referenceId { get; set; }
        public string profileId { get; set; }
        public string statusCode { get; set; }
        public string statusDesc { get; set; }
        public string reportBase64 { get; set; }
    }


    public class Scheme
    {
        public string identification { get; set; }
    }

   

    public class TransactionAmount
    {
        public string amount { get; set; }
        public string currency { get; set; }
    }

    public class BankTransactionCode
    {
        public string code { get; set; }
        public string subcode { get; set; }
    }

    public class ProprietaryBankTransactionCode
    {
        public string code { get; set; }
        public string issuer { get; set; }
    }

    public class Items
    {
        public string transactionReference { get; set; }
        public string statementReference { get; set; }
        public string creditDebitIndicator { get; set; }
        public string transactionStatus { get; set; }
        public string bookingDateTime { get; set; }
        public string valueDateTime { get; set; }
        public string transactionInformation { get; set; }
        public TransactionAmount transactionAmount { get; set; }
        public BankTransactionCode bankTransactionCode { get; set; }
        public ProprietaryBankTransactionCode proprietaryBankTransactionCode { get; set; }
    }

    public class Transaction
    {
        public Items items { get; set; }
    }

    public class Pagination
    {
        public string pageNumber { get; set; }
        public string lastpageInd { get; set; }
    }

    public class Transactions
    {
        public Scheme scheme { get; set; }
        public string requestorAccountId { get; set; }
        public List<Balance2> balance { get; set; }
        public string statementCount { get; set; }
        public List<Transaction> transaction { get; set; }
        public Pagination pagination { get; set; }
    }

    public class TransactionsReportBase64
    {
        public Transactions transactions { get; set; }
    }
}
