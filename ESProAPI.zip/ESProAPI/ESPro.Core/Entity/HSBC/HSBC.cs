﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace ESPro.Core.Entity.HSBC
{
    class HSBC
    {
    }


    public class SearchAmountToBePaidParameters
    {
        public string ProjectCode { get; set; }
        public int BankAccountId { get; set; }
        public string BankCurrency { get; set; }
        public string InvoiceSummaryIDs { get; set; }
        public Decimal total { get; set; }        
    }

    public class SearchPaymentMethodParameters
    {
        public string ProjectCode { get; set; }
        public int BankAccountId { get; set; }
    }

   

    public class BankTransactionHistoryParameters 
    {
        public string ProjectCode { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string Status { get; set; }
        public string Role { get; set; }
        public int UsersID { get; set; }
       
    }

    public class MasterBankAccount
    {
        public int? BankAccountId { get; set; }
        public string AccountNumber { get; set; }
        public string Location { get; set; }
        public string Currency { get; set; }
        public string Balance { get; set; }
    }

    public class MasterPaymentType
    {
        public int? BankAccountId { get; set; }
        public int? PaymentTypeId { get; set; }
        public string PaymentType { get; set; }
    }

    public class MasterPaymentTypeFieldValidation
    {
        public string PaymentType { get; set; }
        public int AccountNumberReq { get; set; }
        public int RoutingIDReq { get; set; }
        public int SwiftCodeReq { get; set; }
        public int IBANNumberReq { get; set; }
    }

    public class DeActiveInvoiceParameters
    {
        public int InvoiceSummaryID { get; set; }
        public string DeactiveComment { get; set; }
        public string ProjectCode { get; set; }
        public int? TransactionDetailsId { get; set; }
    }

    public class InvoiceBankInfoList
    {
        public IEnumerable<InvoiceBankInfo> invoiceBankInfosList { get; set; }
    }

    public class InvoiceBankInfo
    {
        public int InvoiceID { get; set; }
        public string InvoiceName { get; set; }
        public string ProfileName { get; set; }
        public string ProfileCurrency { get; set; }
        public string Street { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string PostalCode { get; set; }
        public string HomeAddressISOCode { get; set; }
        public string AccountName { get; set; }
        public string BankAddress { get; set; }
        public string BankISOCode { get; set; }
        public string BankName { get; set; }
        public string AccountNumber { get; set; }
        public string BeneficiaryType { get; set; }
        public string RoutingID { get; set; }
        public string SwiftCode { get; set; }
        public string IBANNumber { get; set; }
        public string Currency { get; set; }
        public string EINSSN { get; set; }
        public DateTime? PMApproveDate { get; set; }
        public DateTime? APApproveDate { get; set; }
        public string FreelancerEmail { get; set; }
        public string FLCode { get; set; }
        public string AccountType { get; set; }

        public string union_Street { get; set; }
        public string union_City { get; set; }
        public string union_State { get; set; }
        public string union_PostalCode { get; set; }
        public string union_CountryISOCode { get; set; }
        public string union_Name { get; set; }
        public string union_MmbId { get; set; }
    }

    public class InvoiceInfo
    {
        public int? BankAccountId { get; set; }
        public int? PaymentTypeId { get; set; }
        public int? UsersId { get; set; }
        public int? InvoiceSummaryId { get; set; }
        public string InvoiceName { get; set; }
        public DateTime? InvoiceDate { get; set; }
        public DateTime? ApproveDate { get; set; }
        public DateTime? PaymentDate { get; set; }
        public string ProfileCurrency { get; set; }
        public string ContractCurrency { get; set; }
        public string TotalAmount { get; set; }
        public string WireFee { get; set; }
        public string ProjectCode { get; set; }
        public bool IsRePayment { get; set; }
        public int? TransactionDetailsId { get; set; }
        public string Status { get; set; }
        public string DeActiveComment { get; set; }
        public int? IsActive { get; set; }
    }

    public class BankTransactionHistory
    {
        public int TransactionDetailsId { get; set; }
        public int InvoiceSummaryID { get; set; }
        public string InvoiceName { get; set; }
        public int UsersID { get; set; }
        public string VendorID { get; set; }
        public string FreelancerName { get; set; }
        public string FreelancerEmail { get; set; }       
        public DateTime? InvoiceSubmissionDate { get; set; }       
        public DateTime? PMApproveDate { get; set; }
        public DateTime? APApproveDate { get; set; }
        public DateTime? PaymentDate { get; set; }
        public DateTime? PaymentExecutionDate { get; set; }
        public string BankCurrency { get; set; }
        public string ContractCurrency { get; set; }
        public string TotalAmount { get; set; }
        public string WireFee { get; set; }
        public string Status { get; set; }
        public string PaymentType { get; set; }
        public string MsgId { get; set; }
        public string PmtInfId { get; set; }
        public string EndToEndId { get; set; }
        public string DeActiveComment { get; set; }
    }

    public class StatusDetailsParameters
    {
        public int? TransactionDetailsId { get; set; }
        public string ProjectCode { get; set; }
    }
    public class StatusDetails
    {
        public int? TransactionDetailsId { get; set; }
        public string Status { get; set; }
        public string EnqStatusCode { get; set; }
        public string EnqStatusDesc { get; set; }
        public string StatusResponseBase64 { get; set; }
        public string PaymentStatusCode { get; set; }
        public string PaymentStatusDesc { get; set; }
        public string PaymentResponseBase64 { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string DeActiveComment { get; set; }
        

    }


}
