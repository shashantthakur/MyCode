﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity.HSBC
{
    public class BankAccountBalance
    {
        public int? BankAccountId { get; set; }
        public string AccountNumber { get; set; }
        public string institutionCode { get; set; }
        public string Location { get; set; }
        public string Balance { get; set; }
        public DateTime? BalDate { get; set; }
        public string RoutingId { get; set; }
        public string AccountType { get; set; }

    }

    public class BalanceEnq
    {
        public BalanceEnq()
        {
            accountBalances = new List<accountDetails>();
        }
        public List<accountDetails> accountBalances { get; set; }
    }

    public class HSBCKeyValue
    {
        public string Key { get; set; }
        public string Value { get; set; }

    }
    public class accountDetails
    {
        public string accountNumber { get; set; }
        public string accountCountry { get; set; }
        public string institutionCode { get; set; }
        public string accountType { get; set; }
    }
    public class HSBCBalanceEnquiry
    {
        public string balancesRequestBase64 { get; set; }

    }


    public class Amount
    {
        public string amount { get; set; }
        public string currency { get; set; }
    }

    public class CreditLine
    {
        public bool included { get; set; }
        public Amount amount { get; set; }
    }

    public class Balance2
    {
        public string type { get; set; }
        public string creditDebitIndicator { get; set; }
        public object dateTime { get; set; }
        public Amount amount { get; set; }
        public List<CreditLine> creditLine { get; set; }
    }

    public class Balance
    {
        public string identification { get; set; }
        public List<Balance2> balance { get; set; }
    }


    
    public class BalancereportBase64
    {
        public List<Balance> balances { get; set; }
    }
    public class BalanceEnqResponce
    {
        public string referenceId { get; set; }
        public string profileId { get; set; }
        public string statusCode { get; set; }
        public string statusDesc { get; set; }
        public string reportBase64 { get; set; }
    }

}
