﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    public class SmartAssessor
    {

    }

    public class AddCommentToQuestionParameter
    {
        public int UserID { get; set; }
        public int QuestionID { get; set; }
        public int SATestRegistrationID { get; set; }
        public string Comment { get; set; }
    }

    public class SmartAssessorTestParamaters
    {
        public int UserId { get; set; }
        public string TestType { get; set; }
        public string FromWhere { get; set; }
        public string sort { get; set; }
        public string dir { get; set; }
        public int currentpage { get; set; }
        public int pageSize { get; set; }
    }

    public class CertificatePassedOnDetails
    {
        public string CertificationName { get; set; }
        public string PassedOn { get; set; }
    }

    public class SmartAssessorTest
    {
        public int SmartAssessorTestID { get; set; }
        public string SmartAssessorTestName { get; set; }
        public int NoOfQuestion { get; set; }
        public int PassingMarks { get; set; }
        public int BufferDays { get; set; }
        public string ExcerptFile { get; set; }
        public DateTime? LastTestUpdate { get; set; }
        public string PassFail { get; set; }
        public string TestScore { get; set; }
        public int FailCount { get; set; }
        public int NoofAttempts { get; set; }
        public int DisableTest { get; set; }
        public DateTime? LastTimeAttend { get; set; }
        public DateTime? NextTimeTestTaken { get; set; }
        public int Status { get; set; }
        public DateTime? StartDate { get; set; }
        public int? EnrolledUsers { get; set; }
    }

    public class SmartAssessorTestResult
    {
        public int SmartAssessorTestID { get; set; }
        public string SmartAssessorTestName { get; set; }
        public int NoOfQuestion { get; set; }
        public int PassingMarks { get; set; }
        public int SATestRegiID { get; set; }
        public int TestScore { get; set; }
        public int Status { get; set; }
        public decimal Percentage { get; set; }
        public int TotalValidQuestion { get; set; }
        public int TotalFaultyQuestion { get; set; }
        public int UserValidQuestion { get; set; }
        public int UserFaultyQuestion { get; set; }
    }

    public class DownloadPath
    {
        public string FilePath { get; set; }
    }

    //public class QuestionParam
    //{
    //    public int? UserId { get; set; }
    //    public int? SkillID { get; set; }
    //    public int? TestID { get; set; }
    //    public int? TestRegistrationId { get; set; }
    //}
}
