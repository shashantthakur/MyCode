﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    public class RegiModel
    {
        public string EmailId { get; set; }
        public string FullName { get; set; }
        public string ContactNumber { get; set; }
        public string Password { get; set; }
        public Boolean Resend { get; set; }
    }
    public class ResetPassword
    {
        public string UsersId { get; set; }
        public string Password { get; set; }
    }


    public class ResetPasswordUser
    {
        public string UsersId { get; set; }
        public string NewPassword { get; set; }
        public string OldPassword { get; set; }
    }

    public class LinkedInAPIPost
    {
        public string access_token { set; get; }
        public int expires_in { set; get; }
    }

    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    public class ProfilePicture
    {
        public string displayImage { get; set; }
    }

    public class Localized
    {
        public string en_US { get; set; }
    }

    public class PreferredLocale
    {
        public string country { get; set; }
        public string language { get; set; }
    }

    public class FirstName
    {
        public Localized localized { get; set; }
        public PreferredLocale preferredLocale { get; set; }
    }

    public class Localized2
    {
        public string en_US { get; set; }
    }

    public class PreferredLocale2
    {
        public string country { get; set; }
        public string language { get; set; }
    }

    public class LastName
    {
        public Localized2 localized { get; set; }
        public PreferredLocale2 preferredLocale { get; set; }
    }

    public class Handle
    {
        public string emailAddress { get; set; }
    }

    public class EmailElement
    {
        public Handle handles { get; set; }
        public string handle { get; set; }
    }

    public class LinkedInEmail
    {
        public List<EmailElement> elements { get; set; }
    }


    public class LinkedINProfileData
    {
        public string localizedLastName { get; set; }
        public ProfilePicture profilePicture { get; set; }
        public FirstName firstName { get; set; }
        public LastName lastName { get; set; }
        public string id { get; set; }
        public string localizedFirstName { get; set; }
    }




    public class Login
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        //public string RoleId { get; set; }
        public string Token { get; set; }
        public string From { get; set; }
    }

    public class ExternalResponse
    {
        public string name { get; set; }
        public string username { get; set; }
        public string Picture { get; set; }
        public string AuthenticationFrom { get; set; }
    }

    public class GoogleResponse
    {
        public string iss { get; set; }
        public string azp { get; set; }
        public string aud { get; set; }
        public string sub { get; set; }
        public string email { get; set; }
        public string email_verified { get; set; }
        public string at_hash { get; set; }
        public string name { get; set; }
        public string picture { get; set; }
        public string given_name { get; set; }
        public string family_name { get; set; }
        public string locale { get; set; }
        public string iat { get; set; }
        public string exp { get; set; }
        public string jti { get; set; }
        public string alg { get; set; }
        public string kid { get; set; }
        public string typ { get; set; }
    }

    public class SwitchUser
    {
        public string UserName { get; set; }

        public int? RoleId { get; set; }
        public string Process { get; set; }
        public string ProjectCode { get; set; }
        public string TokenString { get; set; }
    }

    public class UserStatus
    {
        public int UsersId { get; set; }
        public string UserName { get; set; }
        public string FullName { get; set; }
        public int RolesId { get; set; }
        public string RoleTitle { get; set; }
        public string UserRole { get; set; }
        public string Picture { get; set; }
        public int? ProfileCompleteness { get; set; }
        public decimal? Rating { get; set; }
        public List<ComponentPermission> componentPermissions { get; set; }
        public string TokenString { get; set; }
        public int? ClientsId { get; set; }
        public string ClientName { get; set; }
        public int? WPAID { get; set; }
        public string WorkAs { get; set; }
        public bool? F2Auth { get; set; }
        public string AuthenticationType { get; set; }
        public bool? IsRestricted { get; set; }
        public int? IsSearchTermsAccepted { get; set; }
    }

    public class UserIsRestricted
    {
        public int UsersId { get; set; }
        public bool? IsRestricted { get; set; }
    }

    public static class TokenInfo
    {
        public static string Token { get; set; }
        // public static string ProjectCode { get; set; }

        public static int Id { get; set; }
        public static string UserName { get; set; }

        //public static string FullName { get; set; }
        public static bool isTokenValid { get; set; }
        public static string ErrorMsg { get; set; }

    }

    public class RatingJobModel
    {
        public int RatingID { get; set; }
        private string RatingJobID { get; set; }
        private string RJFreelancerEmailID { get; set; }
        public decimal OverallQualityOfWork { get; set; }
        public decimal AdherenceToSchedule { get; set; }
        public decimal Communication { get; set; }
        public decimal OverallJobRating { get; set; }
        public string RatedOn { get; set; }
    }

    public class TableResport
    {
        public string sort { get; set; }
        public string dir { get; set; }
        public int currentpage { get; set; }
        public int pageSize { get; set; }
    }

    public class ProjectSpecific : TableResport
    {
        public int? usersid { get; set; }
        public int? jobID { get; set; }
        public string CurrentUserRole { get; set; }
        public string CurrentUserId { get; set; }
        public string TeamType { get; set; }
    }

    public class UserActiveDeactive
    {
        public string User_Role { get; set; }
        public int? CurrentUserId { get; set; }
        public int? usersid { get; set; }
        public string status { get; set; }
        public string Comments { get; set; }
    }

    public class AuthModel
    {
        public int Id { get; set; }
        public bool F2Auth { get; set; }
        public string OTPMail { get; set; }
    }
    public class FreelancerRatingComment
    {
        public int? JobID { get; set; }
        public string Comment { get; set; }
    }

    public class ProjectSpecificCategoryModel : RatingJobModel
    {
        public int JobID { get; set; }
        public string RecordID { get; set; }
        public string AssignmentID { get; set; }
        public string JobNo { get; set; }
        public string JobStatus { get; set; }
        public string Customer { get; set; }
        public string ISBN13 { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string Edition { get; set; }
        public string Unit { get; set; }
        public string NoOfUnits { get; set; }
        public string ClientBudget { get; set; }
        public string ContractedRate { get; set; }
        public string Skill { get; set; }
        public string Status { get; set; }
        public string ExpectedCompletionDate { get; set; }
        public string CompletionDate { get; set; }
        public string AgencyName { get; set; }
        public string AgencyEmail { get; set; }
        public string FreelancerName { get; set; }
        public string FreelancerEmailID { get; set; }
        public string JobPM { get; set; }
        public string AssignedBy { get; set; }
        public string AssignedDate { get; set; }
        public string LastUpdate { get; set; }
        public bool IsRequestMail { get; set; }
        public string RequestComment { get; set; }

        public bool isExpanded { get; set; }
        public bool isVisible { get; set; }

        public List<ProjectSpecificCategoryInnerData> projectSpecificCategoryInnerData { get; set; }
        public ProjectSpecificCategoryModel()
        {
            projectSpecificCategoryInnerData = new List<ProjectSpecificCategoryInnerData>();
        }

    }

    public class ProjectSpecificCategoryInnerData
    {
        public Boolean select { get; set; }
        public int JobID { get; set; }
        public string RecordID { get; set; }
        public string AssignmentID { get; set; }
        public string JobNo { get; set; }
        public string JobStatus { get; set; }
        public string Customer { get; set; }
        public string ISBN13 { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string Edition { get; set; }
        public string Unit { get; set; }
        public string NoOfUnits { get; set; }
        public string ClientBudget { get; set; }
        public string ContractedRate { get; set; }
        public string Skill { get; set; }
        public string Status { get; set; }
        public string ExpectedCompletionDate { get; set; }
        public string CompletionDate { get; set; }
        public string AgencyName { get; set; }
        public string AgencyEmail { get; set; }
        public string JobPM { get; set; }
        public string AssignedBy { get; set; }
        public string AssignedDate { get; set; }
        public string LastUpdate { get; set; }
        public bool IsRequestMail { get; set; }
        public string RequestComment { get; set; }

        public bool isExpanded { get; set; }
        public bool isVisible { get; set; }
    }



    public class CategorySpecificModel : CategoryRatingNFModel
    {
        public string CategoryName { get; set; }
        public string AverageRating { get; set; }
        public int? RatCatId { get; set; }
        public string FreelancerEmailID { get; set; }
        public string FreelancerName { get; set; }
        public string Skill { get; set; }
        public string OQWC { get; set; }
        public string ASC { get; set; }
        public string CommC { get; set; }
        public string JobNo { get; set; }
        public string customer { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string Edition { get; set; }

    }

    public class CategoryRatingNFModel
    {
        public string Comments { get; set; }
        public string Details { get; set; }
        public decimal? AdherenceToSchedule { get; set; }
        public decimal? OverallQualityOfWork { get; set; }
        public decimal? Communication { get; set; }
        public decimal? OverallJobRating { get; set; }
        public string RatedOn { get; set; }
        public int? JobID { get; set; }
        public int? RatingCategoryID { get; set; }
    }

    public class SkillSpecificRatingModel : SkillSpecificNFRatingModel
    {
        public string AverageRating { get; set; }
        public string Skill { get; set; }
    }

    public class SkillSpecificNFRatingModel
    {
        public int? JobID { get; set; }
        public string JobNo { get; set; }
        public string Customer { get; set; }
        public string ISBN13 { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string Edition { get; set; }
        public decimal? AdherenceToSchedule { get; set; }
        public decimal? OverallQualityOfWork { get; set; }
        public decimal? Communication { get; set; }
        public decimal? OverallJobRating { get; set; }
        public string AdherancetoScheduleComment { get; set; }
        public string OverallQualityofWorkComment { get; set; }
        public string CommunicationComment { get; set; }
        public string RatedOn { get; set; }
        public string FreelancerName { get; set; }
        public string FreelancerEmailID { get; set; }
    }

    public class WorkAsSave
    {
        public int UserID { get; set; }
        public string UserEmailID { get; set; }
        public string WorkAs { get; set; }
    }
    public class ES2User
    {
        public string user_id { get; set; }
        public string password { get; set; }
    }

    public class HireFreelancerExpertReq
    {
        public string ProjectName { get; set; }
        public string ProjectDescription { get; set; }
        public string FullName { get; set; }
        public string EmailId { get; set; }
        public string ContactNumber { get; set; }
        public IFormFile SampleFile { get; set; }
    }

    public class GenerateOtp
    {
        public int UsersId { get; set; }
        public string OtpType { get; set; }
        public string Otp { get; set; }
    }

   

    public class GetOtp
    {
        public int Id { get; set; }
        public int UsersId { get; set; }
        public string Otp { get; set; }
        public string OtpType { get; set; }
        public DateTime CreatedDate { get; set; }

    }

    public class CaptchaModel
    {
        public string CaptchaId { get; set; }
        public string UserEnteredCaptchaCode { get; set; }
    }
}
