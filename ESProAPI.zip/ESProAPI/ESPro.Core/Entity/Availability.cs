﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
   public class Availability
    {
        public int? AvailabilityId { get; set; }
        public int? UsersId { get; set; }
        public int? EventTypeId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
       
        
        public int? Year { get; set; }
        public int? Month { get; set; }
        public string EventTitle { get; set; }
        public string Description { get; set; }
        public string WeekOffDays { get; set; }
       
    }

    public class AvailabilityListParam
    {
        public int? UsersId { get; set; }
        public int? month { get; set; }
        public int? year { get; set; }

        public int? AvailabilityId { get; set; }
    }
    public class AvailabilityList
    {
        public int? AvailabilityId { get; set; }
        public int? AvailabilityDetailsId { get; set; }
        public int? UsersId { get; set; }
        public int? EventTypeId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string EventType { get; set; }
        public DateTime EventDate { get; set; }
        public string EventDay { get; set; }
        public string EventTitle { get; set; }
        public string EventColor { get; set; }
        public string Description { get; set; }
    }

}
