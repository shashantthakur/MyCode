﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    public class DemographicData
    {
    }
    public class MasterDemographicData
    {

        public List<MasterEthnicity> RaceEthnicityList { get; set; }
        public List<MasterEthnicity> EthnicityList { get; set; }
        public List<MasterGender> GenderList { get; set; }
        public List<MasterAgeBracket> AgeBracketList { get; set; }
        public List<MasterDisability> DisabilityList { get; set; }
        public List<MasterMilitary> MilitaryList { get; set; }
        public List<MasterBusinessClassification> BusinessClassificationList { get; set; }
        public List<MasterDemographicAgencies> DemographicAgenciesList { get; set; }
        public List<MasterAboutESPro> AboutESProList { get; set; }
        //public MasterDemographicData()
        //{
        //    EthnicityList = new List<MasterEthnicity>();
        //    GenderList = new List<MasterGender>();
        //    AgeBracketList = new List<MasterAgeBracket>();
        //    DisabilityList = new List<MasterDisability>();
        //    MilitaryList = new List<MasterMilitary>();
        //    BusinessClassificationList = new List<MasterBusinessClassification>();
        //    DemographicAgenciesList = new List<MasterDemographicAgencies>();

        //}
    }
    public class DemographicAdditionalInfo
    {
        public int? Id { get; set; }
        public bool? OwnBusiness { get; set; }
        public string AgencyName { get; set; }
        public string AboutESProOther { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }
    public class UserDemographicData
    {
        public int? UsersId { get; set; }

        public int? Race { get; set; }
        public int? Gender { get; set; }
        public int? AgeBracket { get; set; }
        public int? Disability { get; set; }
        public int? VeteranStatus { get; set; }
        public bool? IsOwnBusiness { get; set; }
        public List<int> BusinessClassification { get; set; }
        public List<int> Agency { get; set; }
        public string AgencyName { get; set; }
        public int? Ethnicity { get; set; }
        public int? AboutESPro { get; set; }
        public string AboutESProOther { get; set; }
    }

    public class MasterAboutESPro
    {
        public int? Id { get; set; }
        public string AboutESPro { get; set; }
    }
    public class MasterEthnicity
    {
        public int? Id { get; set; }
        public string Ethnicity { get; set; }
    }
    public class MasterGender
    {
        public int? Id { get; set; }
        public string Gender { get; set; }
    }
    public class MasterAgeBracket
    {
        public int? Id { get; set; }
        public string AgeBracket { get; set; }
    }
    public class MasterDisability
    {
        public int? Id { get; set; }
        public string Disability { get; set; }
    }
    public class MasterMilitary
    {
        public int? Id { get; set; }
        public string Military { get; set; }
    }
    public class MasterBusinessClassification
    {
        public int? Id { get; set; }
        public string BusinessClassification { get; set; }
    }
    public class MasterDemographicAgencies
    {
        public int? Id { get; set; }
        public string DemographicAgencies { get; set; }
    }

    public class DemographicDataReport
    {
        public int? SRNO { get; set; }
        public string Customer { get; set; }
        public string RaceEthnicity { get; set; }
        public string Gender { get; set; }
        public string AgeBracket { get; set; }
        public string Disability { get; set; }
        public string MilitaryStatus { get; set; }
        public string BusinessClassification { get; set; }
        public string BusinessEthnicity { get; set; }
        public string DemographicAgencies { get; set; }
        public int? ProjectRatedCount { get; set; }
        public string Location { get; set; }
        public string Language { get; set; }
        public string LevelOfField { get; set; }
        public string Skills { get; set; }
        public string Disciplines { get; set; }
    }
    public class DemographicDataReportParam
    {
        public string Customers { get; set; }
    }
}
