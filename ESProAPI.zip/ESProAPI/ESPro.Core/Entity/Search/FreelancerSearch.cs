﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity.Search
{
    public class FreelancerSearch
    {
    }

    public class FreelancerFilterModel
    {
        public string[] Discipline { get; set; }
        public string[] System { get; set; }
        public string[] Language { get; set; }
        public string[] Location { get; set; }
        public string[] SkillList { get; set; }
        public string[] Statuses { get; set; }
        public string[] Rating { get; set; }
        public string[] Qualification { get; set; }
        public string[] Familiarity { get; set; }
        public string[] Freelancer { get; set; }
        public string[] Ratingval { get; set; }
        public string[] Agency { get; set; }

        public string[] selectedDiscipline { get; set; }
        public string[] selectedSystem { get; set; }
        public string[] selectedLanguage { get; set; }
        public string[] selectedLocation { get; set; }
        public string[] selectedSkillList { get; set; }
        public string[] selectedStatuses { get; set; }
        public string[] selectedagencies { get; set; }
        public string selectedRating { get; set; }
        public string[] selectedQualification { get; set; }
        public string[] selectedFamiliarity { get; set; }
        public string[] selectedFreelancer { get; set; }
        public string selectedratingval { get; set; }

        public IEnumerable<FreelancerTabModel> FreelancerTabModel { get; set; }
        //public IEnumerable<SelectListItem> Disciplines { get; set; }
        //public IEnumerable<SelectListItem> Systems { get; set; }
        //public IEnumerable<SelectListItem> Languages { get; set; }
        //public IEnumerable<SelectListItem> Locations { get; set; }
        //public IEnumerable<SelectListItem> SkillLists { get; set; }
        //public IEnumerable<SelectListItem> Status { get; set; }
        //public IEnumerable<SelectListItem> Agencies { get; set; }
        //public IEnumerable<SelectListItem> Ratings { get; set; }
        //public IEnumerable<SelectListItem> Ratingvals { get; set; }
        //public IEnumerable<SelectListItem> Qualifications { get; set; }
        //public IEnumerable<SelectListItem> Familiarities { get; set; }
        //public IEnumerable<SelectListItem> Freelancers { get; set; }
        //public IEnumerable<SelectListItem> UserRoles { get; set; }
        //public IEnumerable<SelectListItem> lstClient { get; set; }
        //public IEnumerable<SelectListItem> PMtypes { get; set; }
    }

    public class FreelancerTabfilterModel
    {
        public int ID { get; set; }
        public string User_id { get; set; }
        public string Username { get; set; }
        public string CertificationName { get; set; }
        public string AgencyName { get; set; }
        public List<Tuple<string, List<string>>> ExpertArea { get; set; }
        public List<Tuple<string, List<string>>> SystemName { get; set; }
        public string Skills { get; set; }
        public string Stylesheets { get; set; }
        public string Rating { get; set; }
        public string Location { get; set; }
        public string Languages { get; set; }
        public string Agencies { get; set; }
        public string user_status { get; set; }
        public string user_role { get; set; }
        public bool IsTestCompleted { get; set; }
        public int isNew { get; set; }
        public decimal AwardAmount { get; set; }
        public string PreferredFreelancer { get; set; }
        public string ClientName { get; set; }

        public string Comments { get; set; }
        public DateTime? LastUpdatedDate { get; set; }
        public FreelancerTabfilterModel()
        {
            ExpertArea = new List<Tuple<string, List<string>>>();
            SystemName = new List<Tuple<string, List<string>>>();
        }
    }

    public class FSCompResult
    {
        public decimal Match_Value { get; set; }
        public int UsersId { get; set; }
        public decimal values_conservation { get; set; }
        public decimal values_openness_to_change { get; set; }
        public decimal values_hedonism { get; set; }
        public decimal values_self_enhancement { get; set; }
        public decimal values_self_transcendence { get; set; }
        public decimal needs_challenge { get; set; }
        public decimal needs_closeness { get; set; }
        public decimal needs_curiosity { get; set; }
        public decimal needs_excitement { get; set; }
        public decimal needs_harmony { get; set; }
        public decimal needs_ideal { get; set; }
        public decimal needs_liberty { get; set; }
        public decimal needs_love { get; set; }
        public decimal needs_practicality { get; set; }
        public decimal needs_self_expression { get; set; }
        public decimal needs_stability { get; set; }
        public decimal needs_structure { get; set; }
        public decimal openness { get; set; }
        public decimal openness_adventurousness { get; set; }
        public decimal openness_artistic_interests { get; set; }
        public decimal openness_emotionality { get; set; }
        public decimal openness_imagination { get; set; }
        public decimal openness_intellect { get; set; }
        public decimal openness_authority_challenging { get; set; }
        public decimal conscientiousness { get; set; }
        public decimal conscientiousness_achievement_striving { get; set; }
        public decimal conscientiousness_cautiousness { get; set; }
        public decimal conscientiousness_dutifulness { get; set; }
        public decimal conscientiousness_orderliness { get; set; }
        public decimal conscientiousness_self_discipline { get; set; }
        public decimal conscientiousness_self_efficacy { get; set; }
        public decimal extraversion { get; set; }
        public decimal extraversion_activity_level { get; set; }
        public decimal extraversion_assertiveness { get; set; }
        public decimal extraversion_cheerfulness { get; set; }
        public decimal extraversion_excitement_seeking { get; set; }
        public decimal extraversion_outgoing { get; set; }
        public decimal extraversion_gregariousness { get; set; }
        public decimal agreeableness { get; set; }
        public decimal agreeableness_altruism { get; set; }
        public decimal agreeableness_cooperation { get; set; }
        public decimal agreeableness_modesty { get; set; }
        public decimal agreeableness_uncompromising { get; set; }
        public decimal agreeableness_sympathy { get; set; }
        public decimal agreeableness_trust { get; set; }
        public decimal emotional_range { get; set; }
        public decimal emotional_range_fiery { get; set; }
        public decimal emotional_range_prone_to_worry { get; set; }
        public decimal emotional_range_melancholy { get; set; }
        public decimal emotional_range_immoderation { get; set; }
        public decimal emotional_range_self_consciousness { get; set; }
        public decimal emotional_range_susceptible_to_stress { get; set; }
    }

    public class TestCompleted
    {
        public int serialNo { get; set; }
        public string HourlyRate { get; set; }
        public decimal AwardTotal { get; set; }
        public string rank { get; set; }
        public string user_first_name { get; set; }
        public string user_last_name { get; set; }
        public string user_id { get; set; }
        public string user_email { get; set; }
        public string test_completed_name { get; set; }
        public string test_completed_number { get; set; }
        public string correlation { get; set; }
        public decimal correlation2 { get; set; } //Sorting
        public string useremail { get; set; }
        public string Rating { get; set; }
        public string user_role { get; set; }
        public decimal OverAllRating { get; set; }
        public decimal AdherenceToSchedule { get; set; }
        public decimal Communication { get; set; }
        public decimal OverallQualityOfWork { get; set; }
        public string OfProjectRated { get; set; }
        public string Location { get; set; }
        public string TargetHourlyRate { get; set; }
    }

    public class ExistingRecord
    {
        public int ID { get; set; }
        public string user_id { get; set; }
        public string skills { get; set; }
        public string username { get; set; }
        public string americanized_user_id { get; set; }
        public string Rating { get; set; }
        public string TargetHourlyRate { get; set; }
        public string UserRole { get; set; }
        public decimal OverAllRating { get; set; }
        public decimal AdherenceToSchedule { get; set; }
        public decimal Communication { get; set; }
        public decimal OverallQualityOfWork { get; set; }
        public string OfProjectRated { get; set; }
        public string Location { get; set; }
    }


    public class FreelancerTabModel
    {
        public int ID { get; set; }
        public string User_id { get; set; }
        public string Username { get; set; }
        public string CertificationName { get; set; }
        public string ExpertArea { get; set; }
        public string SystemName { get; set; }
        public string Skills { get; set; }
        public string Stylesheets { get; set; }
        public string Rating { get; set; }
        public string Location { get; set; }
        public string Language { get; set; }
        public string Agency { get; set; }
        public string user_status { get; set; }
        public bool IsTestCompleted { get; set; }
        public string PreferredFreelancer { get; set; }
        public string ClientName { get; set; }
        public string User_role { get; set; }
        public string Comments { get; set; }
        public string FLComments { get; set; }
        public string Headline { get; set; }
        public string WritingSample { get; set; }
        public DateTime? LastUpdatedDate { get; set; }
        public int? IsNew { get; set; }
    }

    public class FreelancerTabModelAward : FreelancerTabModel
    {
        public decimal AwardAmount { get; set; }
    }


    public class TranscationUserInfo
    {
        public string username { get; set; }
        public string user_id { get; set; }
        public decimal Total { get; set; }

    }

    public class UserWiseSaveSearchParameters
    {
        public int UserID { get; set; }
        public int SaveSearchID { get; set; }
        public string sort { get; set; }
        public string dir { get; set; }
        public int currentpage { get; set; }
        public int pageSize { get; set; }
    }

    public class FilterList
    {
        public int SaveSearchID { get; set; }
        public string SaveSearchName { get; set; }
        public int UserID { get; set; }
    }
    public class SaveSearch
    {
        public int SaveSearchID { get; set; }
        public int UserID { get; set; }
        public string SaveSearchName { get; set; }
        public string Field { get; set; }
        public string LevelOfField { get; set; }
        public string SystemPlatformFamilarity { get; set; }
        public string LevelOfSystemFamilarity { get; set; }
        public string Skills { get; set; }
        public string Stylesheet { get; set; }
        public string Languages { get; set; }
        public string Keywords { get; set; }
        public string Country { get; set; }
        public string Agency { get; set; }
        public string FreelancerName { get; set; }
        public string FreelancerNameID { get; set; }
        public string PreferedFreelancer { get; set; }
        public string PreferredFreelancerBoolean { get; set; }
        public string LuminaCertification { get; set; }
        public string IsActive { get; set; }
        public bool isExpanded { get; set; }
        public string Action { get; set; }
        public DateTime? LastAccessedOn { get; set; }
        public DateTime? PreviousSearchDate { get; set; }
        public List<SaveSearchInnerData> saveSearchInnerData { get; set; }
        public SaveSearch()
        {
            saveSearchInnerData = new List<SaveSearchInnerData>();
        }
    }

    public class SaveSearchInnerData
    {
        public string Languages { get; set; }
        public string Keywords { get; set; }
        public string Country { get; set; }
        public string Agency { get; set; }
        public string FreelancerName { get; set; }
        public string FreelancerNameID { get; set; }
        public string PreferedFreelancer { get; set; }
        public string PreferredFreelancerBoolean { get; set; }
        public string LuminaCertification { get; set; }
    }

    public class SearchParameters
    {
        public string Discipline { get; set; }
        public string System { get; set; }
        public string Language { get; set; }
        public string Location { get; set; }
        public string Skill { get; set; }
        public string Stylesheets { get; set; }
        public string Statuses { get; set; }
        public string Rating { get; set; }
        public string Qualification { get; set; }
        public string Familiarity { get; set; }
        public string Freelancer { get; set; }
        public string RatingVal { get; set; }
        public string IsPMRole { get; set; }
        public string isStaffSearch { get; set; }
        public string Agency { get; set; }
        public bool IsPreferedFL { get; set; }
        public bool IsLuminaCertFL { get; set; }
        public string DDLPreferedFLVal { get; set; }
        public string Pmtype { get; set; }
        public string Client_code { get; set; }
        public int currentusersid { get; set; }
        public string currentuserrole { get; set; }
        public string currentuseremailid { get; set; }
        public string Keywords { get; set; }
        public string sort { get; set; }
        public string dir { get; set; }
        public int currentpage { get; set; }
        public int pageSize { get; set; }
        public int flag { get; set; }
        public string from { get; set; }
    }

    public class SearchTermsAccepted
    {
        public int UsersId { get; set; }
        public int? IsSearchTermsAccepted { get; set; }
    }

    public class searchMatchingFreelancer
    {
        public int UsersId { get; set; }
        public List<string> SelectedSkilles { get; set; }
        public List<string> UserRoles { get; set; }
        public List<string> SelectedDispline { get; set; }
        public string CurrentRole { get; set; }
        public int CurrentUserId { get; set; }
        public string sort { get; set; }
        public string dir { get; set; }
        public int currentpage { get; set; }
        public int pageSize { get; set; }


        public searchMatchingFreelancer()
        {
            SelectedDispline = new List<string>();
            UserRoles = new List<string>();
            SelectedSkilles = new List<string>();
        }
    }
    public class DataSourceResult
    {
        public object ExtraData { get; set; }
        public IEnumerable Data { get; set; }
        public object Errors { get; set; }
        public int Total { get; set; }
    }

    public class FilterSearch
    {
        public int filterid { get; set; }
        public string Client_code { get; set; }
    }

    public class UsersComment
    {
        public int UsersId { get; set; }
        public int CommenterId { get; set; }
        public string Comment { get; set; }
    }
    public class userResult
    {
        public int UsersId { get; set; }
        public string UserName { get; set; }
        public string UserEmailId { get; set; }
        public string UserRole { get; set; }
        public string RoleId { get; set; }
    }

    public class TableResponse
    {
        public int Lastpage { get; set; }
        public object data { get; set; }
        public int TotalRecords { get; set; }
    }

    public class FreelancerTabSearchModel
    {
        public int ID { get; set; }
        public string User_id { get; set; }
        public string Username { get; set; }
        public string User_role { get; set; }
        public string Agency { get; set; }
    }
}
