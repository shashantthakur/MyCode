﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    
    public class CandidateList
    {
        public int? CandidateListId { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public int? OwnerId { get; set; }
        public string OwnerName { get; set; }
        public string ListName { get; set; }        
        public Boolean? IsActive { get; set; }
    }

    public class CandidateListParam
    {
        public int? CandidateListId { get; set; }
     
        public int? OwnerId { get; set; }
        public string sort { get; set; }
        public string dir { get; set; }
        public int currentpage { get; set; }
        public int pageSize { get; set; }
    }

    public class CandidateListUserParam
    {
        public List<int?> CandidateListId { get; set; }
        public int? CandidateListUsersId { get; set; }
        public int? CandidateListShareId { get; set; }
        public int? OwnerId { get; set; }
        public int? UsersId { get; set; }


       
    }
    public class CandidateListUsers
    {
        public int? CandidateListUsersId { get; set; }
        public int? FreelancerUsersId { get; set; }
        public string FreelancerName { get; set; }
        public string FreelancerEmailId { get; set; }
        public int? OwnerId { get; set; }
        public string OwnerName { get; set; }
        public int? CandidateListId { get; set; }

        public string ListName { get; set; }

        public DateTime? AddedOn { get; set; }
        public int? AddedBy { get; set; }

    }
    public class ShareListParam
    {
        public int? UsersId { get; set; }

        public int? UsersRoleId { get; set; }

        public string UsersRole { get; set; }
        public int? ClientId { get; set; }

    }
    public class ShareListMailParam
    {
        public List<string> UsersEmail { get; set; }
        public int? FromUsersId { get; set; }
        public string FromEmail { get; set; }
        public string FromFullName { get; set; }
        public int? CandidateListId { get; set; }
        public string ListName { get; set; }
        public int? ClientId { get; set; }
        public string Status { get; set; }
        public string Comments { get; set; }

    }
    public class ShareListUsers
    {
        public int? UsersId { get; set; }
        public string UserName { get; set; }
        public string FullName { get; set; }        
    }

    public class CandidateListShareUsers
    {
        public  int? CandidateListShareId { get; set; }
        public int? ShareUsersId { get; set; }
        public string ShareUsersName { get; set; }
        public int? OwnerId { get; set; }
        public string OwnerName { get; set; }
        public int? CandidateListId { get; set; }
        public string ListName { get; set; }

        public DateTime? UpdatedOn { get; set; }
        public DateTime? ShareOn { get; set; }
        public DateTime? AcceptedOn { get; set; }
        public string Status { get; set; }
        

    }

}
