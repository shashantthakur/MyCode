﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    public class Agency
    {
    }

    public class AgenciesModel
    {
        public int? AgencyId { get; set; }
        public int? AgencyExclusiveID { get; set; }
        public string AgencyNames { get; set; }
        public string URL { get; set; }
        public string Address { get; set; }
    }

    public class AgenciesDetailsModel
    {
        public int? AgencyID { get; set; }
        public bool? AgencyExclusiveID { get; set; }
        public string AgencyName { get; set; }
        public string URL { get; set; }
        public string Address { get; set; }
        public int? AgencyUserInfoID { get; set; }
        public string AgencyUserName { get; set; }
        public string skypeid { get; set; }
        public string ContactNumber { get; set; }
        public string Fax { get; set; }
        public string EmailId { get; set; }
    }

    public class AgenciesUserDetailsModel
    {
        public int? AgencyUserInfoID { get; set; }
        public string AgencyUserName { get; set; }
        public string skypeid { get; set; }
        public string ContactNumber { get; set; }
        public string Fax { get; set; }
        public string EmailId { get; set; }
    }

    public class AgencyViewModel
    {
        public string FreelancerName { get; set; }
        public string FreelancerEmailID { get; set; }
        public int? AgencyId { get; set; }
        public int? UsersId { get; set; }
        public bool? AgencyExclusiveID { get; set; }
        public string AgencyNames { get; set; }
        public string URL { get; set; }
        public string Address { get; set; }
        public List<AgenciesUserDetailsModel> _agencydetails { get; set; }

        public AgencyViewModel()
        {
            _agencydetails = new List<AgenciesUserDetailsModel>();
        }
    }
}
