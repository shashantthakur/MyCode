﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity.JobPost
{
    public class JobPost
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Field { get; set; }
        public string SystemFamilarity { get; set; }
        public string Skills { get; set; }
        public string Stylesheets { get; set; }
        public string Languages { get; set; }
        public string Country { get; set; }
        public string BudgetCurrency { get; set; }
        public string BudgetAmount { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public DateTime? ExpiredOn { get; set; }
        public string IsExpired { get; set; }
        public int InsertedBy { get; set; }
        public int IsActive { get; set; }
        public Int64? Days { get; set; }
        public Int64? Hours { get; set; }
        public Int64? Minutes { get; set; }
        public Int64? Seconds { get; set; }
        public string ExpiredIn { get; set; }
        public int Like { get; set; }
        public int DisLike { get; set; }
        public int TotalMailCount { get; set; }
        public int? TotalMailReplied { get; set; }
        public int? TotalMailReplyPending { get; set; }
        public int TotalLikeCount { get; set; }
        public int TotalDisLikeCount { get; set; }
        public string InsertedFullName { get; set; }
        public string InsertedEmailId { get; set; }
        public string FreelancerName { get; set; }
        public string FreelancerEmailId { get; set; }
        public string ClientName { get; set; }
        public string MoreInfo { get; set; }
        public string Url { get; set; }
        public string Type { get; set; }
        public int? TrainingLikeDisLikeFlagDetailsId { get; set; }
        public Boolean? IsHighPriority { get; set; }
}

    public class JobPostUserInfo
    {
        public int? JobPostUsersInfoId { get; set; }
        public int? JobPostInfoId { get; set; }

        public int? JobPostedByUsersId { get; set; }
        public string FullName { get; set; }
        public string MoreInfo { get; set; }
        public string LikeDislikeMailOn { get; set; }

        public DateTime? RepliedOn { get; set; }
        
    }

    public class SearchJobPostParameters
    {
        public int PostJobId { get; set; }
        public int UserId { get; set; }
        public string UserRole { get; set; }
        public string country { get; set; }
        public string LikeDislikeType { get; set; }
        public string Type { get; set; }
        public string sort { get; set; }
        public string dir { get; set; }
        public int currentpage { get; set; }
        public int pageSize { get; set; }

        public DateTime? PostedFrom { get; set; }
        public DateTime? PostedTo { get; set; }
        public DateTime? ProjectStartDate { get; set; }
        public DateTime? ProjectEndDate { get; set; }
        public string Skills { get; set; }
        public string SubDiscipline { get; set; }
        public string SearchJobType { get; set; }
        public string SearchJobPostedBy { get; set; }
    }
}
