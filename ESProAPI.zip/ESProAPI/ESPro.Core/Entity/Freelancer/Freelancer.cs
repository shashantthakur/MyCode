﻿using ESPro.Core.Entity.Invoice;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity.Freelancer
{
    public class Freelancer
    {
    }
    public class SearchFreelancerParameters
    {
        public int UserID { get; set; }
        public string UserEmailID { get; set; }
        public string UserRole { get; set; }
        public string sort { get; set; }
        public string dir { get; set; }
        public int currentpage { get; set; }
        public int pageSize { get; set; }
        public List<string> JobFilter { get; set; }
        public SearchFreelancerParameters()
        {
            JobFilter = new List<string>();
        }
    }

    

    public class WileyPreferredUsers
    {
        public string FullName { get; set; }
        public string EmailID { get; set; }
    }


    public class SearchCreditDebitParameters : filter
    {
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string CreditDebitType { get; set; }
        public string Role { get; set; }
        public string UserEmailID { get; set; }
        public string sort { get; set; }
        public string dir { get; set; }
        public int currentpage { get; set; }
        public int pageSize { get; set; }
    }

    public class FreelancerDashboardSummary
    {
        public Boolean select { get; set; }
        public int? JobID { get; set; }
        public string JobNo { get; set; }
        public string Customer { get; set; }

        public string FreelancerName { get; set; }
        public string FreelancerEmailID { get; set; }
        public string PM_Name { get; set; }
        public string JobPM { get; set; }
        public string InvApproverName { get; set; }
        public string InvApproverEmail { get; set; }
        public string InvApproverName2 { get; set; }
        public string InvApproverEmail2 { get; set; }
        public string AgencyName { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }

        public string Author { get; set; }
        public string Title { get; set; }
        public string Edition { get; set; }
        public string ISBN13 { get; set; }
        public string Unit { get; set; }
        public string skill { get; set; }
        public decimal? ClientBudget { get; set; }
        public decimal? ContractedRate { get; set; }
        public bool IsManualRecord { get; set; }
        public string AssignmentType { get; set; }
        public string Service_Email { get; set; }

        public decimal? NoOfUnits { get; set; }
        public decimal? RemainUnit { get; set; }
        public decimal? RaisedUnit { get; set; }
        public decimal? RatePerUnit { get; set; }

        public string LastStatus { get; set; }
        public string Service { get; set; }
        public string Notes { get; set; }
        public string RequestComment { get; set; }
        public string Budget_Currency { get; set; }
        public string Contracted_Currency { get; set; }
        public string ContractStatus { get; set; }
        public int? ContractID { get; set; }
        public string FilePath { get; set; }
        public string FreelancerInvoiceComments { get; set; }
        public string SubTotal { get; set; }
        public string InvoiceType { get; set; }
        public string AmountInUSD { get; set; }
        public string ConversionRateinUSD { get; set; }
        public string ConversionCurrency { get; set; }
        public int FLBankInfoId { get; set; }
    }

    public class FreelancerDashboard
    {
        public Boolean select { get; set; }
        public string JobNo { get; set; }
        public string Customer { get; set; }
        public string PM_Name { get; set; }
        public string AgencyName { get; set; }
        public string FreelancerName { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string Edition { get; set; }
        public string ContractStatus { get; set; }
        public int? ContractID { get; set; }
        public string FilePath { get; set; }
        public bool isExpanded { get; set; }
        public bool isVisible { get; set; }
        public List<freelancerInnerData> freelancerInnerData { get; set; }
        public FreelancerDashboard()
        {
            freelancerInnerData = new List<freelancerInnerData>();
        }
    }

    public class freelancerInnerData
    {
        public string FreelancerName { get; set; }
        public string FreelancerEmailID { get; set; }
        public string JobPM { get; set; }
        public string InvApproverName { get; set; }
        public string InvApproverEmail { get; set; }
        public string InvApproverName2 { get; set; }
        public string InvApproverEmail2 { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string JobNo { get; set; }
        public int? JobID { get; set; }
        public string InvoiceType { get; set; }
        //public int? ContractID { get; set; }
        public string ISBN13 { get; set; }
        public string Unit { get; set; }
        public string skill { get; set; }
        public decimal? ClientBudget { get; set; }
        public decimal? ContractedRate { get; set; }
        public bool IsManualRecord { get; set; }
        public string AssignmentType { get; set; }
        public string Service_Email { get; set; }

        public decimal? NoOfUnits { get; set; }
        public decimal? RemainUnit { get; set; }
        public decimal? RaisedUnit { get; set; }
        public string LastStatus { get; set; }
        public string Service { get; set; }
        public string Notes { get; set; }
        public string RequestComment { get; set; }
        public string Budget_Currency { get; set; }
        public string Contracted_Currency { get; set; }
        public string ContractStatus { get; set; }
        //public string FilePath { get; set; }
    }

    public class ContractSave
    {
        public int JobID { get; set; }
        public int? ContractID { get; set; }
        public Int64 UsersId { get; set; }
        public string Status { get; set; }
        public string RejectionComments { get; set; }
        public string Initials { get; set; }
    }

    public class RemoveJobs
    {
        public string JobIDs { get; set; }
        public string Type { get; set; }
    }

    

    public class FreelancerCreditDebitDetails
    {
        public string InvoiceName { get; set; }
        public string FreelancerName { get; set; }
        public string FreelancerEmailID { get; set; }
        public string PMName { get; set; }
        public string PMEmailID { get; set; }
        public string InvApproverName { get; set; }
        public string InvApproverEmail { get; set; }
        public string InvApproverName2 { get; set; }
        public string InvApproverEmail2 { get; set; }
        public string JobNo { get; set; }
        public string Currency { get; set; }
        public string Amount { get; set; }
        public string CreditDebitType { get; set; }
        public string Reason { get; set; }
        public string EnteredBy { get; set; }
        public string EnteredDate { get; set; }

        public int CreditDebitID { get; set; }
        public int InvoiceSummaryID { get; set; }
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string UserEmailID { get; set; }
        public string Action { get; set; }
    }


    
}
