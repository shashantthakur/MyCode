﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Entity
{
    public class Jobs
    {
        public string JobNo { get; set; }
        public string Client { get; set; }
        public string ProjectManager { get; set; }
        public string ISBN13 { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string Skill { get; set; }
        public string user_status { get; set; }

    }

    public class inData
    {
        //public string FreelancerName { get; set; }
        public string FreelancerEmailID { get; set; }
        public string JobPM { get; set; }
        public string InvApproverEmail { get; set; }
        public string InvApproverEmail2 { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string unit { get; set; }
        public string Rate { get; set; }
        public string Note { get; set; }
        public string currency { get; set; }
    }

    public class JobViewMode
    {
        public string JobNo { get; set; }
        public string Client { get; set; }
        public string AgencyName { get; set; }
        public string FreelancerName { get; set; }
        public string ProjectManager { get; set; }
        public string InvApproverName { get; set; }
        public string InvApproverName2 { get; set; }
        public string ISBN13 { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string Skill { get; set; }
        public string user_status { get; set; }
        public string Edition { get; set; }
        public bool isExpanded { get; set; }
        public List<inData> inData { get; set; }

        public JobViewMode()
        {
            inData = new List<inData>();
        }
    }

    public class TableFilter
    {
        public string sort { get; set; }
        public string dir { get; set; }
        public int currentpage { get; set; }
        public int pageSize { get; set; }
    }

    public class JobHistoryParameter : TableFilter
    {
        public int Userid { get; set; }
        public string FromWhere { get; set; }
        public string CurrentUserRole { get; set; }
        public string CurrentUserId { get; set; }
        public string TeamType { get; set; }
    }


    public class JobSummaryModel
    {
        //public int ID { get; set; }
        //
        //public string RatingCategory { get; set; }
        public int? JobID { get; set; }
        public string JobNo { get; set; }
        public string Customer { get; set; }
        public string ISBN13 { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string Edition { get; set; }
        public string Skill { get; set; }
        public string AdherenceToSchedule { get; set; }
        public string OverallQualityOfWork { get; set; }
        public string Communication { get; set; }
        public string OverallJobRating { get; set; }
        public string AgencyName { get; set; }
        public string FreelancerName { get; set; }
        public string CompletionDate { get; set; }
        public string FreelancerEmailID { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string user_status { get; set; }
        public string user_id { get; set; }
        public string JobPM { get; set; }
        public string InvApproverName { get; set; }
        public string InvApproverEmail { get; set; }
        public string InvApproverName2 { get; set; }
        public string InvApproverEmail2 { get; set; }
        public string PMName { get; set; }
        public string Currency { get; set; }
        public string Units { get; set; }
        public string Rate { get; set; }

        public string Notes { get; set; }
    }

    public class JobModel
    {
        public int? JobId { get; set; }
        public int? User_id { get; set; }
        public string Location { get; set; }
        public string JobNo { get; set; }
        public string Customer { get; set; }
        public string ISBN { get; set; }
        public string Author { get; set; }
        public string Title { get; set; }
        public string Skill { get; set; }
        public string FreelancerName { get; set; }
        public decimal OverallJobRating { get; set; }
        public string user_status { get; set; }
        public string Comments { get; set; }
        public decimal? NoOfUnits { get; set; }
        public decimal? ClientBudget { get; set; }
        public decimal? ContractedRate { get; set; }
        public decimal? perUnitBuget { get; set; }
        public decimal? perUnitPrice { get; set; }
        public string Unit { get; set; }
        public string Budget_Currency { get; set; }
        public string Contracted_Currency { get; set; }
        public decimal? OverallQualityOfWork { get; set; }
        public decimal? AdherenceToSchedule { get; set; }
        public decimal? Communication { get; set; }
    }

    public class FreelancerByProjectViewModel
    {
        public string JobNo { get; set; }
        public string ISBN { get; set; }
        public string AuthorName { get; set; }
        public string Title { get; set; }
        public string SelectdLocation { get; set; }
        public string SelectdSkill { get; set; }
        public string CurrentUserRole { get; set; }
        public string TeamType { get; set; }
        public string sort { get; set; }
        public string dir { get; set; }
        public int currentpage { get; set; }
        public int pageSize { get; set; }
    }
    public class JobSearchModel
    {
        public int? JobID { get; set; }
        public string RecordID { get; set; }
        public string AssignmentID { get; set; }
        public string JobNo { get; set; }
        public string JobStatus { get; set; }
        public string Customer { get; set; }
        public string Status { get; set; }
        public string FreelancerName { get; set; }
        public string FreelancerEmailID { get; set; }
        public string AssignedBy { get; set; }
        public DateTime? AssignedDate { get; set; }
        public string JobPM { get; set; }
        public string PM_Name { get; set; }
        public string InvApproverName { get; set; }
        public string InvApproverEmail { get; set; }
        public string IsManualRecord { get; set; }
        public Boolean IsActive { get; set; }
        public string AssignedBy_Email { get; set; }
        public string AssignmentType { get; set; }

        public List<JobInvoiceSearchModel> jobInvoiceSearchData { get; set; }

        public JobSearchModel()
        {
            jobInvoiceSearchData = new List<JobInvoiceSearchModel>();
        }
    }
    public class JobInvoiceSearchModel
    {
        public int? InvoiceSummaryId { get; set; }
        public int? JobID { get; set; }
        public string Invoicetype { get; set; }
        public string Name { get; set; }
        public DateTime? InvoiceDate { get; set; }
        public string Status { get; set; }
        public string RejectionComments { get; set; }
        public float? TotalAmount { get; set; }
        public DateTime? ApprovedRejectedDate { get; set; }
        public Boolean IsActive { get; set; }
        public string APRejectionComments { get; set; }
        public DateTime? APActionDate { get; set; }   
        public float? BankingCharges { get; set; }
       
    }

    public class JobSearchParameters
    {
       
        public string SearchField { get; set; }
        public string SearchText { get; set; }
        public string sort { get; set; }
        public string dir { get; set; }
        public int currentpage { get; set; }
        public int pageSize { get; set; }
        
    }
}
