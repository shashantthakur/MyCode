﻿using ESPro.Core.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Interface
{
    public interface IBulkMail
    {
        bool SendBulkMail(BulkMail bulkMail);
        int SaveMailTemplate(MailTemplate mailTemplate);
         int DeleteMailTemplate(MailTemplate mailTemplate);
        List<MailTemplate> GetUserMailTemplate(MailTemplate mailTemplate);
    }
}
