﻿using ESPro.Core.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Interface
{
    public interface ISmartAssessor
    {
        List<CertificatePassedOnDetails> GetCertificatePassedOn(int UserID, string CertificateType);
        List<SmartAssessorTest> GetSmartAssessorTestDetailsEnrolledUser(SmartAssessorTestParamaters smartAssessorTestParamaters);
        List<SmartAssessorTest> GetSmartAssessorAllTestList(int UserID);
        List<SmartAssessorTest> GetSmartAssessorTestList(SmartAssessorTestParamaters smartAssessorTestParamaters);
        int AllocateTest(AllocateTest allocateTest);
        int SmartAssessorReActiveTest(int UserID, string TestType);
        SkillQuestion GetQuestionsOnSmartAssessor(int UsesId, int TestID, int TestRegistrationId);
        TestResult SaveTest(QuestionOptionModel questionOptionModel);
        List<SmartAssessorTestResult> GetSmartAssessorTestResult(int UsesId, int TestRegistrationId);

        SkillQuestion GetFeedbackQuestionsOnSmartAssessor(int UsesId, int TestRegistrationId);
        TestResult SaveFeedback1Answer(QuestionOptionModel questionOptionModel);

        SkillQuestion GetFeedbackDescQuestionsOnSmartAssessor(int UsesId, int TestRegistrationId, int FeedbackQuestionMasterID);
        TestResult SaveFeedback2Answer(QuestionOptionModel questionOptionModel);

        Boolean AddCommentToQuestion(AddCommentToQuestionParameter addCommentToQuestionParameter);
    }
}
