﻿using ESPro.Core.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Interface
{
    public interface IMEF
    {
        List<MEFLearnongPath> GetLearningPath(int UsersId);
        List<MEFVideoDetails> GetMEFVideos(int UsersId, int MEFLearningPathId);
        int UpdateVideoViews(MEFParam _mEFParam);
        string UpdateVideoCompletelyView(int UsersId, int MEFVideosId);
        int AllocateTest(MEFAllocateTest allocateTest);
        MEFQuestion GetQuestionForUser(int UsesId, int TestID, int TestRegistrationId);
        MEFTestCode SaveTest(MEFQuestionOptionModel questionOptionModel);
        MEFTestResult GetTestResult(int UsesId, int TestRegistrationId);
        int SaveFeedbackData(TestResultFeedback testResultFeedback);
        bool CheckLearningPathAcess(int UsersId);
        List<MEFBadge> GetMEFBadge(int userid = 0);
        List<MEFDashboard> GetMEFDashboard(int UsersId, string Role);
    }
}
