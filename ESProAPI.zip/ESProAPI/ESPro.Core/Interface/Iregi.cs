﻿using ESPro.Core.Entity;
using ESPro.Core.Entity.Search;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Configuration;
namespace ESPro.Core.Interface
{
    public interface IRegi
    {
        List<FreelancerTabModelAward> GetStylesheetForCopyEditingSkill(string UserID);
        string GenerateToken(int userId);
        string GenerateTokenAndSendMail(int userId, string EmailId, string FullName);
        string ValidateToken(string token, out string ActivationID);
        string EmailValidate(string EmailId);
        string InsertUserForActivation(RegiModel _userRegistrationModel);
        string ResendUserActivationLink(RegiModel _userRegistrationModel);
        string ResetPassword(ResetPassword resetPassword);
        UserStatus UserLogin(Login login);
        UserStatus SwitchUser(SwitchUser switchUser);

        int UpdateStatusOfRequestMail(int? JobID, string comments);
        string ManageActiveDeactive(string status, int? usersid, int? currentUserId, string comments = "");
        string GenerateForgetTokenAndSendMail(int userId, string EmailId, string FullName, string Subject= "ESPro Reset Password");
        string ResendUserForotLink(string EmailId);
        string ValidateResetPaswordToken(string token, out string ActivationID);
        object OtpMailSend(string usersid);
        AuthModel GetAuth(string uid);
        int UpdateAuth(AuthModel data);
        UserStatus RegisterOrLoginExternalUser(ExternalResponse login);
        int SaveWorkAsDetails(WorkAsSave workAsSave);
        int InsertHireFreelancerExpertReq(HireFreelancerExpertReq hireFreelancerExpertReq);
        string LoginToES2(IConfiguration _Configuration);
        int GenerateOTP(GenerateOtp generateOtp);
        bool ValidateOTP(GenerateOtp generateOtp);
    }
}
