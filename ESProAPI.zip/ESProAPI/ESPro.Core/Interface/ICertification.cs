﻿using ESPro.Core.Entity;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ESPro.Core.Interface
{
    public interface ICertification
    {
        IEnumerable<Certificate> GetUnEnrolledCertificate(int UsersId);
        AllocateTest GetTestDetails(int TestID);
        int AllocateTest(AllocateTest allocateTest);
        SkillQuestion GetQuestionsOnSkill(int UsesId, int TestID, int SkillID, int TestRegistrationId);
        IEnumerable<TestAnalysis> GetTestAnalysis(int TestRegistrationId);

        TestResult SaveTest(QuestionOptionModel questionOptionModel);
        IEnumerable<UserTestInfo> GetUserTestInfo(int UsersId);
        AllocateTest GetSelectedTest(int UsersId, int TestID);
        int SaveFeedbackData(TestResultFeedback testResultFeedback);
        SkillPhase2Test GetPhase2Test(int SkillPhase2TestID);
        int SavePhase2Registration(Phase2Registration _phase2);
        Task SaveFile(string path, IFormFile file, string fileName);

        IEnumerable<CertificateInfo> GetCertificate();
        IEnumerable<SkillCertificateUser> GetCertificateUser(int TestRegistrationID, string CertificateType);
        IEnumerable<Phase2Registration> GetPhase2Registration(int Status);
    }
}
