﻿using ESPro.Core.Entity;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ESPro.Core.Interface
{
    public interface IMaster
    {
        List<Currency> GetCurrency();
        List<MasterRateUnit> GetRateUnit();
        List<Locations> GetLocations();
        List<Languages> GetLanguages();
        List<Skills> GetSkills();
        List<Stylesheets> GetStylesheets();
        List<SystemFamilarity> GetSystemFamilarity();
        Task<AllMaster> GetAllMaster();
        List<SubjectMatterExpertise> GetSubjectMatterExpertise();
        List<SubjectMatterExpertiseGroup> GetSubjectMatterExpertiseGroup();
        List<Clients> GetClients();
        List<Rating> GetRating();
        List<RatingCategories> GetRatingCategories();
        IEnumerable<Qualifications> GetQualifications();
        List<Roles> GetRoles(string RolesFrom);
        List<AgencyMaster> GetAgency();
        List<SelectList> GetDistinctJobs();
        List<SelectList> GetDistinctAuthors();
        List<SelectList> GetDistinctUsers(string UserRole);
    }
}
