﻿using ESPro.Core.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Interface
{
   public interface ITrainingMaterial
    {
        List<SearchTrainingDetails> GetTrainingMaterialListForExtendedSearch(int RoleId, int ClientId);
        List<TrainingMaterialList> GetTrainingMaterialList(int RoleId, int ClientId, int MenuId);
        //List<TrainingMaterialList> GetTrainingMaterialDetailsMenu(int RoleId, int ClientId, int MenuId);
        List<TrainingMaterialMenu> GetTrainingMaterialDetailsMenu(int RoleId, int ClientId, int MenuId);
        List<TrainingMaterialMenu> GetTrainingMaterialMenu(int RoleId, int ClientId);
        List<TrainingVideoDescription> GetTrainingVideoDescription(int SubId, int Seconds);
        int UpdateTrainingViews(UpdateTrainingViewsCount updateTrainingViewsCount);
        List<VTT_TranScript> GetTrsanScriptText(string vttPath);
        int InsertLikeDislikeFlagCount(InsertLikeDislikeFlagCountParameters datas);
        LikeDislikeFlagCount GetInsertLikeDislikeFlagCount(InsertLikeDislikeFlagCountParameters datas);
        List<TrainingVideoReport> GetTrainingVideoProblemReport(string StartDate, string EndDate);
    }
}
