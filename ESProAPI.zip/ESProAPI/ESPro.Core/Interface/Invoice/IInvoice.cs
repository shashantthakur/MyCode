﻿using ESPro.Core.Entity.Freelancer;
using ESPro.Core.Entity.Invoice;
using System;
using System.Collections.Generic;
using System.Text;


namespace ESPro.Core.Interface
{
    public interface IInvoice
    {
        List<InvoiceRatingStatus> InvoiceRatedbyPM(string JobNo, string FreelancerEmailID, int InvoiceSummaryID);
        List<AllUsers> GetAllUsers(string Role);
        IEnumerable<FinanceMatrix> GetFinanceMatrix();
        IEnumerable<InvoiceStatus> GeInvoicesStatusList(string UserRole);
        IEnumerable<SendMailTo> GetSendMailDetails(string MailType, int clientid = 0);
        List<Invoice> GetInvoicesList(string StartDate, string EndDate, string Status, string ContractType, string ProfileCurrency, string ContractCurrency, string Role, string UserEmailID, string DateColumn, int currentPage, int pagesize, string sort, string dir, out int totalcount, out List<string> Jobs, out List<string> Freelancers, out List<string> InvoiceNames, out List<string> InvApprovers, List<string> JobFilter = null, List<string> FreelancerFilter = null, List<string> InvoiceNameFilter = null, List<string> InvApproverFilter = null, string InvoiceDateType = "", string flag = "A");
        List<Invoice> GetInvoicesListNotSendToConnect();
        List<InvoiceDetails> GetInvoiceDetails(int InvoiceSummaryID);
        int SaveInvoiceDetails(InvoiceSave saveInvoice);
        int UpdateInvoiceDetails(InvoiceDetailsSave invoiceDetailsSave);
        int CreateInvoice(List<FreelancerDashboardSummary> invoiceModels, int UsersId);
        List<Invoice> CheckFinalInvoiceRaisedorNot(int JobID, string FreelancerEmailID);
        List<WileyPrefundingDetails> GePrefundingDetails(WileyPrefundingDetailsSearchParameters wileyPrefundingDetailsSearchParameters);
        int SaveWileyPrefunding(WileyPrefundingDetails wileyPrefundingDetails);
        int UpdatePrefundingBalance(WileyPrefundingDetails wileyPrefundingDetails);

        bool PushDataToIConnect(InvoiceSave invoiceSave, out string Error, out string FullError, out string jsonData);
        int InsertInvoiceLog(int InvoiceId, string ApiType, bool Status, string Error, string JsonData);
        int AddInvoiceLog(string methodName, string processPoint, string freelanceEmailId, bool isInvoiceGenerated, string invoiceName);

        List<Invoice> GeInvoicesforAPApproval(string InvoiceSummaryIDs);

        int SaveWireFeeDetails(WireFeeSave wireFeeSave);

        SaveInvoiceResult SaveInvoiceDetails(InvoiceSave[] saveInvoice, string RequestUrl);
        List<DateFilterTypes> GetFilterDateType(string status);
        List<PrefundingClient> PrefundingClients();
    }
}
