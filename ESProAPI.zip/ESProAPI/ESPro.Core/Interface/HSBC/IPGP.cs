﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Interface.HSBC
{
   public interface IPGP
    {

        string Base64Encode(string plainText);
        string Base64Decode(string base64EncodedData);
    }
}
