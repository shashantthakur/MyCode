﻿using ESPro.Core.Entity.HSBC;
using ESPro.Core.Entity.Invoice;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Configuration;
namespace ESPro.Core.Interface.HSBC
{
   public interface IHSBC
    {
        IEnumerable<MasterBankAccount> GetBankAccount(string ProjectCode);
        IEnumerable<MasterPaymentType> GetPaymentType(string ProjectCode, int BankAccountId);
        IEnumerable<InvoiceStatus> GetPaymentStatusList(string UserRole);
        List<BankTransactionHistory> GetInvoiceDetails(string ProjectCode, int InvoiceSummaryID);
        List<BankTransactionHistory> GetBankTransactionHistory(string ProjectCode, string StartDate, string EndDate, string Status, string Role, string UsersID, int BankAccountId, string ReportType);
        IEnumerable<MasterPaymentTypeFieldValidation> GetPaymentTypeFieldValidation(int PaymentTypeId);
        List<InvoiceBankInfo> GetInvoiceBankInfo(string InvoiceSummaryIDs);
        bool InsertInvoiceInfo(InvoiceInfo _invoiceInfo);
        bool DeActiveInvoice(DeActiveInvoiceParameters deActiveInvoiceParameters);
        IEnumerable<BankAccountBalance> GetBankAccountBalance(string ProjectCode);
        BalanceEnqResponce CallBalanceApi(IConfiguration _Configuration, string jsonString);
        int UpdateAccountBalance(int BankAccountId, string Balance);
        TransactionEnqResponce CallTransactionApi(IConfiguration _Configuration, string jsonString);
        StatusDetails GetStatusDetails(int TransactionDetailsId, string ProjectCode);
    }
}
