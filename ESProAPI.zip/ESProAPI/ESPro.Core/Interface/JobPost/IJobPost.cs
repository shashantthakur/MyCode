﻿using ESPro.Core.Entity;
using ESPro.Core.Entity.JobPost;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Interface
{
    public interface IJobPost
    {
        int SaveJobPostInfo(JobPost jobPost);
        int SaveJobPostUsersInfo(JobPost jobPost);
        List<UserMaster> GetJobPostedBy();
        List<JobPost> GetPostJobList(SearchJobPostParameters searchJobPostParameters);
        List<JobPostUserInfo> GetPostJobUsersInfoList(SearchJobPostParameters searchJobPostParameters);
        int MarkAsRepliedUsersJobPostMail(JobPostUserInfo jobPost);
    }
}
