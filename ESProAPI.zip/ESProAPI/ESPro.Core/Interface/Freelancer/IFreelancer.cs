﻿using ESPro.Core.Entity;
using ESPro.Core.Entity.Freelancer;
using ESPro.Core.Entity.Invoice;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Interface
{
    public interface IFreelancer
    {
        List<WileyPreferredUsers> GetAllWileyPreferredUsers();
        List<FreelancerDashboardSummary> GetFreelancerRemoveJobList(int UserID, string UserEmailID, string UserRole);
        List<FreelancerDashboardSummary> GetFreelancerDashboardList(int UserID, string UserEmailID, string UserRole);
        List<FreelancerDashboardSummary> GetJobDetails(string JobIDs);
       // IEnumerable<BankInfo> GetFreelancerBankingInfo(int UserID);
       
        List<FreelancerCreditDebitDetails> GetFreelancerCreditDebitDetailsList(string StartDate, string EndDate, string CreditDebitType, string Role, string UserEmailID);


    
        string EncryptBankDetails(BankInfo bankInfo);
        string InsertUpdateCreditDebitInfo(FreelancerCreditDebitDetails freelancerCreditDebitDetails);

        int SaveContract(ContractSave contractSave);
        int RemoveJobFromInvoice(string JobIds, string Type);
        void FreelancerRequestDetailsOnMail(int? jobID, string comment);
    }
}
