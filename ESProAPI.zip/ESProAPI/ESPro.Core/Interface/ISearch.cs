﻿using ESPro.Core.Entity.Search;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Interface
{
    public interface ISearch
    {
        string InsertUpdateDeleteSaveSearch(SaveSearch saveSearch);
        List<FreelancerTabModelAward> GetFreelancerData(SearchParameters datas, out int totalcount, bool extra = false);
        List<SaveSearch> GetUserWiseSaveSearch(UserWiseSaveSearchParameters datas);
        List<FilterList> GetFilterList(int UsersId);
        bool CheckIsValidForPMView(string currentRole, bool isPMSearch);
        List<userResult> GetFreelancersFromFilter(FilterSearch search, out int totalcount, bool extra = false);
        //List<FreelancerTabModel> GetFreelancerTabDetailsQM(int userid, string Role = "FREELANCER");
        List<FreelancerTabModel> GetFreelancerTabDetailsQM(int userid, string CurrentUserRole, string Client_code, out int totalcount, string Role = "FREELANCER", string keyword = "", SearchParameters datavariables = null, bool IsPM = false, bool IsStaff = false, bool extra = false);
        List<FreelancerTabSearchModel> GetFreelancerTabSearchDetailsQM(int userid, string CurrentUserRole, string Client_code, string Role = "FREELANCER", string keyword = "");
        List<FSCompResult> GetFSCompMatching(int UsersId);

        List<ExistingRecord> GetSelectedSkillFreelancer(string selectedSkill, int userid);

        List<SearchTermsAccepted> GetSearchTermsAcceptedDetails(int UsersID);
        int SaveSearchTerms(int UserID);
        int SaveUsersComment(UsersComment usersComment);
        int DeleteUsersComment(UsersComment usersComment);
        UsersComment GetUsersComment(UsersComment usersComment);


    }
}
