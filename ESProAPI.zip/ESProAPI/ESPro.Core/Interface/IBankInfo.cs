﻿using ESPro.Core.Entity;
using ESPro.Core.Entity.Invoice;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Interface
{
    public interface IBankInfo
    {
        List<FreelancerBankDashboard> GetFreelancerBankDashboard(int UserID);
        List<Invoice> GetInvoicesList(SearchFreelancerInvoices datas);
        int DeleteFreelancerBankInfo(int FLBankInfoId);
        //int SetDefaultFreelancerBankInfo(int FLBankInfoId);
        IEnumerable<BankInfo> GetFreelancerAllBankingInfo(int UserID);
        BankInfo GetFreelancerBankingInfo(int UserID, int FLBankInfoId);
        string InsertUpdateBankingInfo(BankInfo bankInfo);
        List<FreelancerBankDetails> GetFreelancersAccountDetails(string UserIDs, string FLBankInfoIds);
    }
}
