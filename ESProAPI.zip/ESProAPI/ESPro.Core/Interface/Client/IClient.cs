﻿using ESPro.Core.Entity.Client;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Interface
{
    public interface IClient
    {
        IEnumerable<ClientJobDetailsModel> GetClientDashboard(int UsersId, string UserRole, string UserEmailID);
        ClientJobDetailsModel GetJobDetailsFromID(int JobId);
        ClientUser GetUserClientName(int UsersId);
        List<ClientUser> GetAllClientUsers(int ClientCode);
        string CreateClientJob(ClientJobDetailsModel model);
        string UpdateClientJob(ClientJobDetailsModel model);
        int DeleteClientJob(ClientJobDetailsModel clientJobDetailsModel);
        string UpdatePMName(ReassignedJobs reassignedJobs);
        void SendMailToFreelancerContract(ClientJobDetailsModel jdmodel, bool isSigned = false, string MailType = "", string RejectionComments = "");
        bool ConvertHTMLToPDF(string FilePath, string HTMLString, string PDFName, string HTMLCSS, out string Error);
    }
}
