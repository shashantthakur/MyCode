﻿using ESPro.Core.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Interface
{
    public interface IAuth
    {
        string GenerateToken(UserStatus userStatus);
        string ReGenerateToken(string token);
        ClientLogin ApiClientLogin(ClientLogin clientLogin);
        Boolean ValidateToken(string token);
    }
}
