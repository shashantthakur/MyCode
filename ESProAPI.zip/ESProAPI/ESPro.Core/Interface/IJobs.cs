﻿using System;
using System.Collections.Generic;
using System.Text;
using ESPro.Core.Entity;

namespace ESPro.Core.Interface
{
    public interface IJobs
    {
        IEnumerable<JobSummaryModel> getFreelancerDetails(int userID, string FromWhere);

        IEnumerable<JobModel> GetJobDetailsWithFileter(string JobNo, string ISBN, string AuthorName, string Title, string SelectdLocation, string SelectdSkill);
        IEnumerable<JobSearchModel> GetJobSearch(string SearchField, string SearchText);
    }
}
