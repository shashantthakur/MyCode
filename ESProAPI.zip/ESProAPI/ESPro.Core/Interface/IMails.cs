﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Interface
{
    public interface IMails
    {
        //string SendMail(string MsgBody, string Subject, string ToMail, string CCMail, string astrAttatchment = "", string BccMail = "");
        string SendMail(string BodyStr, string SubjectStr, string toAddress, string CCAddress, string FromMail_UserName, string astrAttatchment = "", string BCCAddress = "", string ReplTo = "");
    }
}
