﻿using ESPro.Core.Entity.Report;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace ESPro.Core.Interface
{
    public interface IReport
    {
        List<TestCompletedUsers> GetTestCompletedUsers(string UserRole, int ReportID);
        List<CustomeRoles> GetAllCustomeRoles(int ClientCode);
        List<ReportType> GetReportTypes(string UserRole, int ClientId);
        List<CustomerWorked> GetCustomerWorked();
        List<MasterOverdueReports> GetOverdueReportTypes(string UserRole);
        List<MasterRatingCompositeReport> GetRatingCompositeReportTypes(string UserRole);
        List<ServiceReport>  GetServiceReportList(string StartDate, string EndDate, string Role, string UserEmailID, int ClientCode);
        List<RatingReport> GetRatingReportList(string UserEmailID, string Role, string Skill);
        List<OverDueReport> GetOverDueReportList(string UserEmailID, string UserRole, int ClientCode, int OverdueReportID);
        List<OverDueReport> GetOverDueEndDateReportList();
        List<PersonalInsights> GetPersonalInsightsList(string Role);
        //List<PredictiveTestingReport> GetPredictiveTestingList(string Role);
        DataTable GetPredictiveTestingList(string Role);
        List<RatingCompositeReport> GetRatingCompositeReports(int ClientCode, string CustomeRoles, string Role, int RatingCompositeReportID);
        List<FLInvoicesPendingPMApprovalReport> GetFLInvoicesPendingPMApprovalReports(string ReportType);
        List<RatingHistoryReport> GetRatingHistoryReports(string UserEmailID, string FreelancerEmailID, int ClientCode, string Role);
        List<LuminaFreelancerCost> GetLuminaFreelancerCosts(string StartDate, string EndDate, int ClientCode);
        List<WileyFreelancerCost> GetWileyFreelancerCost(string StartDate, string EndDate, int ClientCode, string Currency, string Limit);
        List<TaskReport> GetTaskReport(string UserEmailID, string UserRole, string Skills, int ClientCode);
        List<FreelancerRollOff> GetFreelancerRollOff();
        List<AdHocMLReport> GetAdHocMLReport();
        List<MacMillanFreelancerDetails> GetMacMillanFreelancerDetails();
        List<MacMillanCompletedJobs> GetMacMillanCompletedJobs();
        List<MacMillanPendingJobs> GetMacMillanPendingJobs();
        DataTable SmartAssessorReportPerTest(string UserID, int TestID);


        DataTable PersonalInsightsInfo(DataTable dt);
        DataTable DTRatingCompositeReport(DataTable dt);

        byte[] DownloadReport(DataTable dtToExport, int ReportID, int ClientCode, string TemplateFile, string ExportFileName, string FromRows, string ToRows, int HeaderLength, DataTable dtToExport1, DataTable dtToExport2);
        List<SubDisciplineRatingReport> GetSubDisciplineRatingReportList(string UserEmailID, string Role, string Skill);
    }
}
