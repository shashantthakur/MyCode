﻿using ESPro.Core.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Interface
{
   public interface IAvailability
    {
        int ApplyLeave(Availability availability);
        List<Availability> CheckAvailability(int UsersId, DateTime StartDate, DateTime EndDate, int AvailabilityId);
        List<AvailabilityList> GetAvailability(int UsersId, int Month, int Year, int AvailabilityId);
        int DeleteAvailability(int AvailabilityId);
    }
}
