﻿using ESPro.Core.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Interface
{
    public interface IAgency
    {
        IEnumerable<AgenciesModel> GetAgencies();
        IEnumerable<AgenciesDetailsModel> GetAgenciesDetaiils(int Agencyid);
        IEnumerable<AgenciesDetailsModel> GetUsersAgenciesDetaiils(int Userid);
        bool InsertAgency(AgencyViewModel agency);
    }
}
