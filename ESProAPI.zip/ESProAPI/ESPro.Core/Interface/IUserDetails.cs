﻿using ESPro.Core.Entity;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ESPro.Core.Interface
{
    public interface IUserDetails
    {
        List<UserRoles> GetUserRoles(int UsersId, string CurrentRole);
        UserProfileCompleteness getUserProfileCompleteness(int UsersId,int RoleId);
        List<ComponentPermission> GetComponentPermission(int UsersId, int RoleId, int ClientsId);
        List<MEFLearningPath> GetMEFLearningPath(int FreelancerID, int UserID);
        UsersDetails GetUsersDetails(string UsersId);
        Users getUser(string UsersId);
        AddressDetails GetAddressDetails(string UsersId);
        PersonalDetails GetPersonalDetails(string UsersId);
        int UpdateAddressDetails(AddressDetails addressDetails);
        int UpdatePersonalDetails(PersonalDetails personalDetails);

        int UpdateProfilePic(string image, int usersid);

        int UpdateUserSkills(UserSkills userSkills);
        int InsertSkills(int? UsersId, int? SkillId, string TableName);
        UserSkills GetUserSkills(int UsersId);
        //WritingSample GetUserWritingSample(int UsersId);
        //int UpdateUserWritingSample(WritingSample writingSample);
        UserFLComments GetUserFLComments(int UsersId, string UserRole, int ClientId);
        int UpdateFLComments(UserFLComments writingSample);
        UserProfile GetUserProfile(int UsersId);
        Task SaveFile(string path, IFormFile file, string fileName);
        int UpdateResumeSample(int UsersId, string ResumeFilePath, string SampleFilePath, string LinkToOnlineProfile);
        UserResumeSample GetUserResumeSample(int UsersId);
        List<FreelancerList> GetFreelancer();
        int SaveGeneralComments(AdminComments data);
        int DeleteProfile(int UsersId, int RoleId);
        bool DeleteProfileFromConnect(string UserEmailId);

        Boolean CallApiForChangeEmail(string OldEmail, string NewEmail, string Type);
        string GetUserProfilePic(int usersId);

        List<UsersDetailsModel> GetUserUsersId(string EmailID);
        string ForgotUserPassword(UsersDetailsModel ud);
        void loginStatus(string userName, string iP, string status, string From,string Data);

        int UpdateMEFLearningPaths(MEFLearningPath mEFLearningPath);
    }
}
