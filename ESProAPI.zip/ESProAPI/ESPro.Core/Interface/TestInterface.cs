﻿using ESPro.Core.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Interface
{
    public interface ITestInterface
    {
        string MapPath(string path);
        string GetData();
        List<FSConfigModel> GetFSConfig();
    }
}
