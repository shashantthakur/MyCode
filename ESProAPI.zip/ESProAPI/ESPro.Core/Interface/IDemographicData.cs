﻿using ESPro.Core.Entity;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ESPro.Core.Interface
{    
   public interface IDemographicData
    {
         Task<MasterDemographicData> GetDemographicDataMaster();
        List<MasterEthnicity> GetEthnicity();
        List<MasterGender> GetGender();
        List<MasterAgeBracket> GetAgeBracket();
        List<MasterDisability> GetDisability();
        List<MasterMilitary> GetMilitary();
        List<MasterBusinessClassification> GetBusinessClassification();
        List<MasterDemographicAgencies> GetDemographicAgencies();
        int UpdateDemographicData(UserDemographicData userSkills);
        UserDemographicData GetDemographicData(int UsersId);
        DemographicAdditionalInfo GetDemographicAdditionalInfo(int UsersId);
        List<DemographicDataReport> GenerateDemographicDataReport(DemographicDataReportParam demographicDataReportParam);
    }
}
