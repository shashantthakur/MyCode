﻿using ESPro.Core.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Interface
{
   public interface ICandidate
    {
        int SaveCandidateList(CandidateList preferedUsers);

        List<CandidateList> GetCandidateListDashboard(int OwnerId);
        List<CandidateList> GetCandidateList(int OwnerId);
        int SaveCandidateListUser(CandidateListUserParam candidateListUserParam);
        List<ShareListUsers> GetShareListUsers(ShareListParam shareListParam);
        int DeleteCandidateListUser(int CandidateListUsersId);
        int DeleteCandidateList(int CandidateListId);
        string GenerateMailShareCandidateList(ShareListMailParam shareListMailParam);
        string ValidateToken(string token);
        int AcceptShareList(int CandidateShareListId);
        List<CandidateListUsers> GetCandidateListUsers(int CandidateListId);
        List<CandidateListShareUsers> GetCandidateListShareUsers(int CandidateListId);
        int UnshareCandidateList(int CandidateListShareId);
    }
}
