﻿using ESPro.Core.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Interface
{
    public interface IRating
    {
        IEnumerable<RatingJobNoDetails> GetRatingJobNoDetails(int JobId);

        IEnumerable<RatingDetails> GetRatingHistory(int UsersId, int currentuserid, string currentuserrole);

        IEnumerable<RatingUsers> GetRatingUsersList(int UsersId, int currentuserid, string currentrole);

        IEnumerable<RatingComments> GetRatingComments(int JobId);

        IEnumerable<CategorySpecificModel> GetCategorySpecificCategoryDetails(int? usersid);

        IEnumerable<ProjectSpecificCategoryModel> GetProjectSpecificCategoryDetails(int? usersid, int? jobID);

        IEnumerable<CategorySpecificModel> GetCategorySpecificCategoryDetailsForNonFreelancer(int? usersid);

        IEnumerable<SkillSpecificRatingModel> GetSkillSpecificCategoryDetails(int? usersid);

        IEnumerable<SkillSpecificRatingModel> GetSkillSpecificCategoryDetailsForNonFreelancer(int? usersid, string skill);

        int SaveRatingDetails(RatingSave ratingDetails);

        string GetRatedPM(int? jobID);
    }
}
