﻿using ESPro.Core.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Interface
{
    public interface IFSConfig
    {
        IEnumerable<FSConfig> GetFSConfig();

        int UpdateFSConfig(FSConfig FSconfig);
    }
}
