﻿using ESPro.Core.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Interface
{
    public interface IDeactivateProjects
    {
        IEnumerable<KillableJobs> GetKillableJobs(SearchKillableJobs SearchJob);

        int DeactivateProjects(KillJobs KillJobs);
    }
}
