﻿using ESPro.Core.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Interface
{
    public interface IAdminManage
    {
        IEnumerable<UserRoleList> GetUsersAndRoleList();
        
        int UpdateEmailId(AdminManage ratingDetails);

        int UpdateUsersDetails(AdminManageUsersDetails usersDetails);

        int SaveNewUsersDetails(NewUser usersDetails);

        IEnumerable<UsersWithPreferredClient> GetUsersWithPreferredClient();

        int UpdateUsersWithPreferredClients(AdminManageUsersWithPreferredClients usersPreferredClientDetails);
    }
}
