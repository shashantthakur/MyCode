﻿using ESPro.Core.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Interface
{
    public interface IAdminDashboard
    {
        IEnumerable<AdminDashboard> GetAdminDashboard(string UserName, string UserRole);
    }
}
