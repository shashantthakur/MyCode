﻿﻿using ESPro.Core.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace ESPro.Core.Interface
{
    public interface IPredective
    {
        PredictiveResult GetFsResult(int userdid);

        bool UpSertWritingSample(PredictiveData data,string Resilt);
    }
}