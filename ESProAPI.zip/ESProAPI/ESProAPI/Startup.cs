﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using ESPro.Infrastructure.Service;

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Swashbuckle.AspNetCore.Swagger;
using Microsoft.OpenApi.Models;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using ESPro.Core.Entity;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.AspNetCore.Http;
using ESProAPI.Class;
using Microsoft.AspNetCore.Diagnostics;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Authorization;
using Newtonsoft.Json.Serialization;
using ESPro.Core.Interface.HSBC;
using ESPro.Infrastructure.Service.HSBC;

namespace ESProAPI
{
    public class Startup
    {
        readonly string MyAllowSpecificOrigins = "_myAllowSpecificOrigins";
        public Startup(IConfiguration configuration, IHostingEnvironment hostingEnvironment, ILoggerFactory loggerFactory)
        {
            Configuration = configuration;
            _hostingEnvironment = hostingEnvironment;
            loggerFactory.AddLog4Net(); // << Add this line
        }

        public IConfiguration Configuration { get; }
        public IHostingEnvironment _hostingEnvironment { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //for Connection string

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1).AddJsonOptions(opt => opt.SerializerSettings.ContractResolver = new DefaultContractResolver()); ;

            services.AddCors(c =>
            {
                c.AddPolicy(MyAllowSpecificOrigins, options => options.AllowAnyOrigin()
                .AllowAnyMethod().AllowAnyHeader());
            });


            ESPro.Infrastructure.Class.Common Obj = new ESPro.Infrastructure.Class.Common(Configuration, _hostingEnvironment);
            Utilities objUtilities = new Utilities(Configuration, _hostingEnvironment);
            //Token
            services.AddAuthentication(x =>
            {
                x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
           .AddJwtBearer(x =>
           {
               x.Events = new JwtBearerEvents
               {
                   OnTokenValidated = context =>
                   {
                       var accessToken = context.SecurityToken as JwtSecurityToken;
                       if (accessToken != null)
                       {
                           int PID;
                           TokenInfo.Token = accessToken.RawData.ToString();
                           TokenInfo.UserName = accessToken.Subject;
                           TokenInfo.isTokenValid = true;
                           int.TryParse(accessToken.Claims.Where(z => z.Type.Equals("unique_name")).FirstOrDefault().Value, out PID);
                           TokenInfo.Id = PID;
                           //TokenInfo.FullName = accessToken.Audiences.FirstOrDefault();
                       }
                       return Task.CompletedTask;
                   },
                   //OnAuthenticationFailed = c =>
                   //{
                   //    c.Response.WriteAsync("Invalid token. Error :" + c.Exception.Message).Wait();

                   //    return Task.CompletedTask;

                   //},

               };
               x.RequireHttpsMetadata = false;
               x.SaveToken = true;
               x.TokenValidationParameters = new TokenValidationParameters
               {
                   ValidateIssuer = true,
                   ValidateAudience = true,
                   ValidateLifetime = true,
                   ValidateIssuerSigningKey = true,
                   ValidIssuer = Configuration["JwtToken:myIssuer"],
                   ValidAudience = Configuration["JwtToken:myAudience"],
                   IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["JwtToken:SecretKey"])),
                   ClockSkew = TimeSpan.Zero
               };
           });


            //End Token
            //remove service depedancies
            services.AddScoped<ITestInterface, TestService>();
            services.AddScoped<IMails, MailService>();
            services.AddScoped<IRegi, RegiService>();
            services.AddSingleton<IAuth, AuthService>();
            services.AddSingleton<IErrorLog, ErrorLogService>();
            services.AddSingleton<IUserDetails, UserDetailsService>();
            services.AddSingleton<IMaster, MasterService>();
            services.AddSingleton<IAgency, AgencyService>();
            services.AddSingleton<IPredective, PredectiveService>();
            services.AddSingleton<IJobs, JobsService>();
            services.AddSingleton<IAdminHome, AdminHomeService>();
            services.AddSingleton<IAdminDashboard, AdminDashboardService>();
            services.AddSingleton<IRating, RatingService>();
            services.AddSingleton<IAdminManage, AdminManageService>();
            services.AddSingleton<IFSConfig, FSConfigService>();
            services.AddSingleton<IInvoice, InvoiceService>();
            services.AddSingleton<ISearch, SearchService>();
            services.AddSingleton<IClient, ClientService>();
            services.AddSingleton<IFreelancer, FreelancerService>();
            services.AddSingleton<IReport, ReportService>();
            services.AddSingleton<ICertification, CertificationSevice>();
            services.AddSingleton<IDeactivateProjects, DeactivateProjectsService>();
            services.AddSingleton<ITrainingMaterial, TrainingMaterialService>();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddSingleton<IPGP, PGPService>();
            services.AddSingleton<IHSBC, HSBCService>();
            services.AddSingleton<ISmartAssessor, SmartAssessorService>();
            services.AddSingleton<IAvailability, AvailabilityService>();
            services.AddSingleton<IJobPost, JobPostService>();
            services.AddSingleton<IBulkMail, BulkMailService>();
            services.AddSingleton<IBankInfo, BankInfoService>();
            services.AddSingleton<IDemographicData, DemographicDataService>();
            services.AddSingleton<ICandidate, CandidateService>();
            services.AddSingleton<IMEF, MEFService>();

            // Web API routes
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "ESPro API", Version = "v1" });
            });


        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {

                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }

            app.UseAuthentication();
            app.UseStaticFiles();

            app.UseCors(builder =>
            builder.AllowAnyHeader().AllowAnyOrigin().AllowAnyMethod());
            app.UseMiddleware(typeof(ErrorHandlingMiddleware));



            // Web API routes          

            app.UseSwagger();
            app.UseSwaggerUI(c =>
             {
                 //c.SwaggerEndpoint("/ui.esproapi/swagger/v1/swagger.json", "ESPro API V1");
                  c.SwaggerEndpoint("/swagger/v1/swagger.json", "ESPro API V1");
                
             });
            app.UseHttpsRedirection();
            app.UseMvc();

        }
    }
}


//Swagger
//https://docs.microsoft.com/en-us/aspnet/core/tutorials/getting-started-with-swashbuckle?view=aspnetcore-3.1&tabs=visual-studio
