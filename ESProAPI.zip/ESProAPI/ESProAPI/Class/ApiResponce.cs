﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ESProAPI.Class
{
    public class ApiResponce
    {
        public string Text { get; set; }
    }


    public class CommonResult
    {
        public string Status { get; set; }
        public string ErrorMessage { get; set; }
    }

    public enum Status
    {
        SUCCESS,
        FAILED
    }
}
