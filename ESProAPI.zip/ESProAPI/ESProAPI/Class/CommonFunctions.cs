﻿using ESPro.Core.Entity;
using ESPro.Core.Entity.Client;
using ESPro.Core.Entity.Search;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using ESPro.Infrastructure.Service;
using ESProAPI.Controllers;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;


namespace ESProAPI.Class
{
    public class CommonFunctions
    {
        private static IMaster _master;

        SearchService _ISearch = new SearchService();

        ClientService _IClient = new ClientService();

        public IEnumerable<List<T>> SplitList<T>(List<T> Data, int nSize = 30)
        {
            for (int i = 0; i < Data.Count; i += nSize)
            {
                yield return Data.GetRange(i, Math.Min(nSize, Data.Count - i));
            }
        }
        public string FormatCurrency(object input)
        {
            decimal localdecimal;
            decimal.TryParse(Convert.ToString(input), out localdecimal);
            return localdecimal.ToString("N", CultureInfo.CurrentCulture);
        }

        public List<T> ConvertToList<T>(DataTable dt)
        {
            List<T> data = new List<T>();
            foreach (DataRow row in dt.Rows)
            {
                T item = GetItem<T>(row);
                data.Add(item);
            }
            return data;
        }
        public static T GetItem<T>(DataRow dr)
        {
            Type temp = typeof(T);
            T obj = Activator.CreateInstance<T>();

            foreach (DataColumn column in dr.Table.Columns)
            {
                foreach (PropertyInfo pro in temp.GetProperties())
                {
                    if (pro.Name == column.ColumnName)
                        pro.SetValue(obj, dr[column.ColumnName], null);
                    else
                        continue;
                }
            }
            return obj;
        }

        public DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);

            //Get all the properties
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Defining type of data column gives proper data table 
                var type = (prop.PropertyType.IsGenericType && prop.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>) ? Nullable.GetUnderlyingType(prop.PropertyType) : prop.PropertyType);
                //Setting column names as Property names
                dataTable.Columns.Add(prop.Name, type);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    //inserting property values to datatable rows
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }
            //put a breakpoint here and check datatable
            return dataTable;
        }
        public string GetCallerMemberName([CallerMemberName] string name = "")
        {
            return name;
        }
        public TableResponse TableResponce<T>(IEnumerable<T> Data, string sort, string dir, int currentpage, int pageSize)
        {
            if (!string.IsNullOrEmpty(sort))
            {
                var param = sort;
                var propertyInfo = typeof(T).GetProperty(param);
                if (dir == "desc")
                {
                    Data = Data.OrderByDescending(x => propertyInfo.GetValue(x, null));
                }
                else
                {
                    Data = Data.OrderBy(x => propertyInfo.GetValue(x, null));
                }

            }




            var subdata = SplitList(Data.ToList(), pageSize);

            if (currentpage >= subdata.Count())
            {
                currentpage = (subdata.Count() - 1);
            }
            var response = new TableResponse
            {
                Lastpage = subdata.Count(),
                data = subdata.Count() > 0 ? subdata.ElementAt(currentpage) : Data,
                TotalRecords = Data.Count(),
            };

            ////int LastPg = 0;
            //if (Data.Count() % pageSize == 0 && currentpage != 0)
            //{
            //    currentpage = currentpage - 1;
            //    //LastPg = subdata.Count() - 1;
            //}
            ////else
            ////    LastPg = subdata.Count();
            //var response = new
            //{
            //    Lastpage = subdata.Count(),
            //    data = subdata.Count() > 0 ? subdata.ElementAt(currentpage) : Data,
            //    TotalRecords = Data.Count()
            //};
            return response;
        }

        public static string GetRequest(string URL, string Token = "")
        {
            string ErrorMsg = string.Empty;
            try
            {
                using (var client = new HttpClient())
                {
                    if (!string.IsNullOrEmpty(Token))
                    {
                        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", Token);
                    }
                    var GetData = client.GetStringAsync(URL);
                    GetData.Wait();
                    var result = GetData.Result;
                    return result;
                }
            }
            catch (Exception ex)
            {
                ErrorMsg = Convert.ToString(ex.InnerException);
                return ex.Message;
            }
            return "";
        }

        public static dynamic GetUserRoles(bool isPM, string User_Role, List<Roles> Roles)
        {
            try
            {
                List<SelectListItem> items = new List<SelectListItem>();

                foreach (var item in Roles)
                {

                    if (item.UserRole.ToUpper().Trim() == "LUMINAOTHERS" && !User_Role.Equals(Convert.ToString(userRole.CLIENTADMIN), StringComparison.OrdinalIgnoreCase) && !User_Role.Equals(Convert.ToString(userRole.CLIENT), StringComparison.OrdinalIgnoreCase))
                    {
                        var newItem = new SelectListItem { Value = item.UserRole, Text = "Lumina Staff" };
                        items.Add(newItem);
                        newItem = new SelectListItem { Value = "All", Text = "All" };
                        items.Add(newItem);
                    }

                    else if (item.UserRole.ToUpper().Trim() == "FREELANCER")
                    {
                        SelectListItem newItem = new SelectListItem();
                        newItem = new SelectListItem { Value = item.UserRole, Text = "Freelancer", Selected = true };
                        items.Add(newItem);
                    }

                    if (item.UserRole.ToUpper().Trim() == Convert.ToString(userRole.QUALITYMANAGER) && isPM)
                    {
                        var newItem = new SelectListItem { Value = item.UserRole, Text = "Quality Manger", Selected = true };
                        items.Add(newItem);
                    }

                }
                return items;
            }
            catch (Exception wx)
            {
                throw;
            }
        }


        public async Task<List<TestCompleted>> FillCompletedTestCorrelationResultAsync(int UsersId, List<string> SelectedSkilles, List<string> UserRoles, List<string> SelectedDispline, string Role, int CurrentUserId, List<ExistingRecord> dataTable = null)
        {
            List<TestCompleted> freelancerSummary = new List<TestCompleted>();
            if (UsersId == 0)
                return await Task.FromResult<List<TestCompleted>>(freelancerSummary);

            string filteredSkills = string.Empty;// jsonResult = string.Empty;
            List<TestCompleted> testCompleteds = new List<TestCompleted>();
            List<FSCompResult> FSCompResult = _ISearch.GetFSCompMatching(UsersId);
            try
            {
                if (FSCompResult != null)
                {
                    filteredSkills = GetFilterString(SelectedSkilles, UserRoles, SelectedDispline, filteredSkills, Role, CurrentUserId);
                    var existingRecords = _ISearch.GetSelectedSkillFreelancer(filteredSkills, UsersId);
                    existingRecords = (from f in existingRecords
                                       where UsersId != Convert.ToInt32(f.ID)
                                       select f).ToList();

                    int slNo = 1;
                    if (existingRecords.Count < FSCompResult.Count)
                    {
                        foreach (var item in existingRecords)
                        {
                            TestCompleted testCompleted = new TestCompleted();
                            var data = FSCompResult.Where(z => z.UsersId == Convert.ToInt32(item.ID)).FirstOrDefault();
                            if (data != null)
                            {
                                AssignData(item, testCompleted, data);
                                testCompleted.serialNo = slNo++;
                                freelancerSummary.Add(testCompleted);
                            }
                        }
                    }
                    else
                    {
                        int count = 0;
                        foreach (var item in FSCompResult.OrderByDescending(c => c.Match_Value).ToList())
                        {
                            var data = existingRecords.Where(c => Convert.ToInt32(c.ID) == item.UsersId).FirstOrDefault();
                            if (data != null)
                            {
                                TestCompleted testCompleted = new TestCompleted();
                                testCompleted.serialNo = slNo++;
                                testCompleted.user_first_name = data.username;
                                testCompleted.user_email = data.user_id;
                                testCompleted.correlation = Convert.ToString(Math.Round(item.Match_Value, 2));
                                testCompleted.correlation2 = Math.Round(item.Match_Value, 2);
                                testCompleted.Rating = string.IsNullOrEmpty(Convert.ToString(data.Rating)) ? "0" : Convert.ToString(data.Rating);
                                if (!string.IsNullOrEmpty(Convert.ToString(data.TargetHourlyRate)))
                                    testCompleted.TargetHourlyRate = Convert.ToString(data.TargetHourlyRate);
                                testCompleted.user_role = data.UserRole;
                                testCompleted.user_id = Convert.ToString(data.ID);
                                freelancerSummary.Add(testCompleted);
                                existingRecords.Remove(data);
                                count++;
                            }
                            if (count > 11)
                                break;
                        }
                    }
                }
                return await Task.FromResult<List<TestCompleted>>(freelancerSummary.OrderByDescending(z => z.correlation2).ToList());
            }
            catch (Exception ex)
            {
                return await Task.FromResult<List<TestCompleted>>(freelancerSummary);
            }
        }

        public string GetFilterString(List<string> SelectedSkilles, List<string> UserRoles, List<string> SelectedDispline, string filteredSkills, string User_Role, int UsersId)
        {
            if (SelectedSkilles != null && SelectedSkilles.Count > 0)
            {
                for (int i = 0; i < SelectedSkilles.Count; i++)
                {
                    if (SelectedSkilles[i].Trim() != "")
                        filteredSkills += string.Concat(" [ColumnName] like ##%", SelectedSkilles[i].Trim(), "%## and ");
                }
                filteredSkills = filteredSkills.Trim();
            }
            if (SelectedDispline != null && SelectedDispline.Count > 0)
            {
                for (int i = 0; i < SelectedDispline.Count; i++)
                {
                    if (SelectedDispline[i].Trim() != "")
                        filteredSkills += string.Concat(" [ColumnNameDispline] like ##%", SelectedDispline[i].Trim(), "%## and ");
                }
                filteredSkills = filteredSkills.Trim();
            }
            if (UserRoles != null && UserRoles.Count > 0)
            {
                string CommaSeparatedRoles = string.Join(",", UserRoles);
                if (CommaSeparatedRoles.ToUpper().Contains("ALL"))
                    CommaSeparatedRoles = "FREELANCER,AGENCY,FLPROJECTMANAGER,LUMINAOTHERS,HUMANRESOURCE,QUALITYMANAGER,ADMIN";
                else if (CommaSeparatedRoles.ToUpper().Contains("FREELANCER"))
                    CommaSeparatedRoles = CommaSeparatedRoles + ",FREELANCER,AGENCY,FLPROJECTMANAGER";
                else if (CommaSeparatedRoles.ToUpper().Contains("LUMINAOTHERS"))
                    CommaSeparatedRoles = CommaSeparatedRoles + ",HUMANRESOURCE,QUALITYMANAGER,ADMIN";
                CommaSeparatedRoles = CommaSeparatedRoles.Replace(",", "','");
                filteredSkills += " userrole IN('" + CommaSeparatedRoles + "') and";
            }
            else if (!User_Role.Equals(Convert.ToString(userRole.ADMIN)))
            {
                string CommaSeparatedRoles = "FREELANCER,LUMINAOTHERS";
                CommaSeparatedRoles = CommaSeparatedRoles.Replace(",", "','");
                filteredSkills += "userrole IN('" + CommaSeparatedRoles + "') and";
            }

            bool IsRestricted = false;
            if (User_Role == "CLIENT")
            {
                ESPro.Core.Entity.UserIsRestricted _userIsRestricted = CommonResource.ToCollection<ESPro.Core.Entity.UserIsRestricted>(DbContext.DbUser.ExecuteDataSet("usp_CheckIsRestricted", UsersId).Tables[0]).FirstOrDefault();
                if (_userIsRestricted != null)
                {
                    IsRestricted = _userIsRestricted.IsRestricted.Value;
                }
            }
            if (User_Role == "CLIENT" && IsRestricted)
            {
                var dts = _IClient.GetUserClientName(UsersId);
                filteredSkills += " [ColumnNamePreferredFreelancer] like ##%" + dts.ClientName + "%## and";
            }
            return filteredSkills;
        }

        private void AssignData(ExistingRecord item, TestCompleted testCompleted, FSCompResult data)
        {
            testCompleted.user_first_name = item.username;
            testCompleted.correlation = Convert.ToString(Math.Round(data.Match_Value));
            testCompleted.correlation2 = Math.Round(data.Match_Value, 2);
            testCompleted.user_email = item.user_id;
            testCompleted.Rating = string.IsNullOrEmpty(Convert.ToString(item.Rating)) ? "0" : Convert.ToString(item.Rating);
            if (!string.IsNullOrEmpty(Convert.ToString(item.TargetHourlyRate)))
                testCompleted.TargetHourlyRate = Convert.ToString(item.TargetHourlyRate);
            testCompleted.user_role = item.UserRole;
            testCompleted.user_id = Convert.ToString(item.ID);
            testCompleted.OverAllRating = item.OverAllRating;
            testCompleted.AdherenceToSchedule = item.AdherenceToSchedule;
            testCompleted.Communication = item.Communication;
            testCompleted.OverallQualityOfWork = item.OverallQualityOfWork;
            testCompleted.OfProjectRated = item.OfProjectRated;
            testCompleted.Location = item.Location;
        }



    }
}
