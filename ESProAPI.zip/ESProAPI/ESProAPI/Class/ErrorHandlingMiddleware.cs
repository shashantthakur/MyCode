﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Service;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
namespace ESProAPI.Class
{
    public class ErrorHandlingMiddleware
    {
        private readonly RequestDelegate next;

        public ErrorHandlingMiddleware(RequestDelegate next)
        {
            this.next = next;
        }

        public async Task Invoke(HttpContext context /* other dependencies */)
        {
            try
            {
                await next(context);
                LogRequestEndPointsAsync(context);
            }
            catch (Exception ex)
            {
                await HandleExceptionAsync(context, ex);
            }
        }

        private static void LogRequestEndPointsAsync(HttpContext context)
        {
            ErrorLog errorLog = new ErrorLog();
            ErrorLogService errorLogService = new ErrorLogService();
            try
            {

                if (context.Request.Path.HasValue)
                {
                    var _IP = "RemoteIp:" + context.Request.HttpContext.Connection.RemoteIpAddress.ToString() + " - LocalIpAddress:" +
                              context.Request.HttpContext.Connection.LocalIpAddress;
                    try
                    {
                        _IP += " IP.AddressFamily:" + Dns.GetHostEntry(Dns.GetHostName()).AddressList[1].ToString();
                        _IP += " HostName:" + Dns.GetHostEntry(Dns.GetHostName()).HostName;
                    }
                    catch (Exception e)
                    {
                    }

                    errorLog.Host = _IP;
                    errorLog.RequestUri = context.Request.Path.ToString();
                    if (TokenInfo.Id != null)
                    {
                        errorLog.UsersId = TokenInfo.Id.ToString();
                    }
                    if (TokenInfo.UserName != null)
                    {
                        errorLog.UserName = TokenInfo.UserName.ToString();
                    }
                    string baseurl = context.Request.Path.ToString();
                    string hostname = context.Request.Host.ToString();
                }
                var error = context.Features[typeof(IExceptionHandlerFeature)] as IExceptionHandlerFeature;

                //when authorization has failed, should retrun a json message to client
                errorLog.StatusCode = "200";
                //errorLog.Message = error.Error.Message + "\r\n" + exception.StackTrace.ToString();
                errorLog.Type = "EndPoint Hit Success";
                if (errorLog.UsersId != "0")
                {
                    int cnt = errorLogService.InsertErrorLog(errorLog);
                }
            }
            catch (Exception ex)
            {
                errorLog.StatusCode = "500";
                //errorLog.Message = exception.Message + "\r\n" + exception.StackTrace.ToString();
                errorLog.Type = "InternalServerError";
                int cnt = errorLogService.InsertErrorLog(errorLog);
            }
        }

        private static Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            ErrorLog errorLog = new ErrorLog();
            ErrorLogService errorLogService = new ErrorLogService();
            try
            {

                if (context.Request.Path.HasValue)
                {
                    var _IP = "RemoteIp:" + context.Request.HttpContext.Connection.RemoteIpAddress.ToString() + " - LocalIpAddress:" +
                              context.Request.HttpContext.Connection.LocalIpAddress;
                    try
                    {
                        _IP += " IP.AddressFamily:" + Dns.GetHostEntry(Dns.GetHostName()).AddressList[1].ToString();
                        _IP += " HostName:" + Dns.GetHostEntry(Dns.GetHostName()).HostName;
                    }
                    catch (Exception e)
                    {
                    }

                    errorLog.Host = _IP;
                    errorLog.RequestUri = context.Request.Path.ToString();
                    if (TokenInfo.Id != null)
                    {
                        errorLog.UsersId = TokenInfo.Id.ToString();                      
                    }
                    if (TokenInfo.UserName != null)
                    {
                        errorLog.UserName = TokenInfo.UserName.ToString();
                    }
                        string baseurl = context.Request.Path.ToString();
                    string hostname = context.Request.Host.ToString();
                }
                var error = context.Features[typeof(IExceptionHandlerFeature)] as IExceptionHandlerFeature;

                //when authorization has failed, should retrun a json message to client
                if (error != null && error.Error is SecurityTokenExpiredException)
                {
                    errorLog.StatusCode = "401";
                    errorLog.Message = error.Error.Message + "\r\n" + exception.StackTrace.ToString();
                    errorLog.Type = "SecurityTokenExpiredException";
                    int cnt = errorLogService.InsertErrorLog(errorLog);

                    context.Response.StatusCode = 401;
                    context.Response.ContentType = "application/json";
                    return context.Response.WriteAsync(JsonConvert.SerializeObject(new
                    {
                        State = "Unauthorized",
                        Msg = "token expired"
                    }));
                }
                //when orther error, retrun a error message json to client
                else if (error != null && error.Error != null)
                {
                    errorLog.StatusCode = "500";
                    errorLog.Message = error.Error.Message + "\r\n" + exception.StackTrace.ToString();
                    errorLog.Type = "InternalServerError";
                    int cnt = errorLogService.InsertErrorLog(errorLog);

                    context.Response.StatusCode = 500;
                    context.Response.ContentType = "application/json";
                    return context.Response.WriteAsync(JsonConvert.SerializeObject(new
                    {
                        State = "Internal Server Error",
                        Msg = error.Error.Message
                    }));
                }
                else
                {
                    errorLog.StatusCode = "500";
                    errorLog.Message = exception.Message + "\r\n" + exception.StackTrace.ToString();
                    errorLog.Type = "InternalServerError";
                    int cnt = errorLogService.InsertErrorLog(errorLog);

                    context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    context.Response.ContentType = "application/json";
                    return context.Response.WriteAsync(JsonConvert.SerializeObject(new
                    {
                        State = "Internal Server Error",
                        Msg = exception.Message
                    }));
                }
            }
            catch (Exception ex)
            {
                errorLog.StatusCode = "500";
                errorLog.Message = exception.Message + "\r\n" + exception.StackTrace.ToString();
                errorLog.Type = "InternalServerError";
                int cnt = errorLogService.InsertErrorLog(errorLog);

                context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                context.Response.ContentType = "application/json";
                return context.Response.WriteAsync(JsonConvert.SerializeObject(new
                {
                    State = "Internal Server Error",
                    Msg = ex.Message
                }));
            }
        }
    }
}
