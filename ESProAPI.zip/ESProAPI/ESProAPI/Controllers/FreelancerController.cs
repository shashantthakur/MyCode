﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ESPro.Core.Entity;
using ESPro.Core.Entity.Client;
using ESPro.Core.Entity.Freelancer;
using ESPro.Core.Entity.Invoice;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using ESPro.Infrastructure.Service;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml.Style;

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class FreelancerController : ControllerBase
    {
        public CommonFunctions commonFn = new CommonFunctions();
        private readonly IFreelancer _freelancer;
        private readonly IClient _client;
        private readonly IInvoice _invoice;
        public FreelancerController(IFreelancer freelancer, IClient client, IInvoice invoice)
        {
            _freelancer = freelancer;
            _client = client;
            _invoice = invoice;
        }

        [HttpPost("export.creditdebitdetails")]
        public IActionResult ExportCreditDebitDetails([FromBody] SearchCreditDebitParameters datas)
        {
            List<FreelancerCreditDebitDetails> lstFreelancerCreditDebitDetails = new List<FreelancerCreditDebitDetails>();
            lstFreelancerCreditDebitDetails = _freelancer.GetFreelancerCreditDebitDetailsList(datas.StartDate, datas.EndDate, datas.CreditDebitType, datas.Role, datas.UserEmailID);

            DataTable dtToExport = commonFn.ToDataTable(lstFreelancerCreditDebitDetails);
            dtToExport.Columns.Remove("CreditDebitID");
            dtToExport.Columns.Remove("InvoiceSummaryID");
            dtToExport.Columns.Remove("UserID");
            dtToExport.Columns.Remove("UserName");
            dtToExport.Columns.Remove("UserEmailID");
            dtToExport.AcceptChanges();
            string TemplateFile = "";
            TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "CreditDebitDetails.xlsx");
            try
            {
                using (var pck = new OfficeOpenXml.ExcelPackage())
                {
                    using (var stream = System.IO.File.OpenRead(TemplateFile))
                    {
                        pck.Load(stream);
                    }

                    string ToRows = "", FromRows = "", modelRange = "";
                    FromRows = "A2";
                    ToRows = "N";
                    string FileName = "Credit_Debit_Details";

                    var ws = pck.Workbook.Worksheets[1];


                    ws.Cells[FromRows].LoadFromDataTable(dtToExport, false);

                    var modelCells = ws.Cells[FromRows];
                    var modelRows = dtToExport.Rows.Count + 1;
                    modelRange = FromRows + ":" + ToRows.ToString() + modelRows.ToString();
                    ws.Cells[FromRows + ":" + ToRows.ToString() + modelRows.ToString()].Style.Font.SetFromFont(new Font("Calibri", 10));
                    var modelTable = ws.Cells[modelRange];
                    // Assign borders
                    modelTable.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    modelTable.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    modelTable.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    modelTable.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    byte[] data = pck.GetAsByteArray();
                    return Ok(new { data, contenttype = "application/octet-stream", filename = FileName + "_" + DateTime.Now.ToString("ddMMyyyyHHmmss") + ".xlsx" });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        [AllowAnonymous]
        [HttpPost("GetAllWileyPreferredUsers")]
        public object GetAllWileyPreferredUsers()
        {
            List<WileyPreferredUsers> wileyPreferredUsers = new List<WileyPreferredUsers>();
            wileyPreferredUsers = _freelancer.GetAllWileyPreferredUsers();
            return wileyPreferredUsers;
        }

        [HttpPost("get.freelancers.creditdebit.details")]
        public object GetFreelancersCreditDebitDetails([FromBody] SearchCreditDebitParameters datas)
        {
            List<FreelancerCreditDebitDetails> lstFreelancerCreditDebitDetails = new List<FreelancerCreditDebitDetails>();
            lstFreelancerCreditDebitDetails = _freelancer.GetFreelancerCreditDebitDetailsList(datas.StartDate, datas.EndDate, datas.CreditDebitType, datas.Role, datas.UserEmailID);

            List<string> Jobs = lstFreelancerCreditDebitDetails.Select(a => a.JobNo).Distinct().ToList(); if (!(datas.JobFilter.Count == 1 && datas.JobFilter.Where(a => a == "0").Count() > 0))
                lstFreelancerCreditDebitDetails = lstFreelancerCreditDebitDetails.Where(a => datas.JobFilter.Where(b => a.JobNo == b).Count() > 0).ToList();

            List<string> Freelancers = lstFreelancerCreditDebitDetails.Select(a => a.FreelancerName).Distinct().ToList();
            if (!(datas.FreelancerFilter.Count == 1 && datas.FreelancerFilter.Where(a => a == "0").Count() > 0))
                lstFreelancerCreditDebitDetails = lstFreelancerCreditDebitDetails.Where(a => datas.FreelancerFilter.Where(b => a.FreelancerName == b).Count() > 0).ToList();

            List<string> InvoiceNames = lstFreelancerCreditDebitDetails.Select(a => a.InvoiceName).Distinct().ToList();
            if (!(datas.InvoiceNameFilter.Count == 1 && datas.InvoiceNameFilter.Where(a => a == "0").Count() > 0))
                lstFreelancerCreditDebitDetails = lstFreelancerCreditDebitDetails.Where(a => datas.InvoiceNameFilter.Where(b => a.InvoiceName == b).Count() > 0).ToList();

            var response = commonFn.TableResponce(lstFreelancerCreditDebitDetails, datas.sort, datas.dir, datas.currentpage, datas.pageSize);
            var data = new
            {
                Jobs = Jobs,
                Freelancers = Freelancers,
                Invoices = InvoiceNames,
                response = response
            };
            return data;
        }

        [HttpPost("insert.update.CreditDebitInfo")]
        public async Task<IActionResult> InsertUpdateCreditDebitInfo([FromBody] FreelancerCreditDebitDetails freelancerCreditDebitDetails)
        {

            CommonResult commonResult = new CommonResult();
            var response = _freelancer.InsertUpdateCreditDebitInfo(freelancerCreditDebitDetails);

            if (response == "Success")
            {
                if (freelancerCreditDebitDetails.CreditDebitID == 0)
                    commonResult.ErrorMessage = freelancerCreditDebitDetails.CreditDebitType + " Info added successfully";
                else
                {
                    if (freelancerCreditDebitDetails.Action == "Delete")
                        commonResult.ErrorMessage = freelancerCreditDebitDetails.CreditDebitType + " Info deleted successfully";
                    else
                        commonResult.ErrorMessage = freelancerCreditDebitDetails.CreditDebitType + " Info updated successfully";
                }
                commonResult.Status = response;
            }
            else
            {
                commonResult.ErrorMessage = response;
                commonResult.Status = "Fail";
            }
            return Ok(commonResult);
        }

        [HttpGet("get.approvedbyAPinvoicelist")]
        public object GeApprovedByApInvoicesList()
        {
            List<Invoice> lstInvoices = new List<Invoice>();
            int total = 0;
            List<string> Jobs = null;
            List<string> Freelancers = null;
            List<string> InvoiceNames = null;
            List<string> InvApprovers = null;
            lstInvoices = _invoice.GetInvoicesList("", "", "APPROVEDBYAP", "", "", "", "FINANCEMANAGER", "", "", -1, 5, null, null, out total, out Jobs, out Freelancers, out InvoiceNames, out InvApprovers);
            return lstInvoices;
        }

        //[HttpPost("EncryptBankDetails")]
        //public ActionResult EncryptBankDetails()
        //{
        //    CryptoService cryptoService = new CryptoService();
        //    ApiResponce apiResponce = new ApiResponce();
        //    List<FreelancerBankDetails> lstFreelancerBankDetails = new List<FreelancerBankDetails>();
        //    lstFreelancerBankDetails = _freelancer.GetFreelancersAccountDetails("0");
        //    for (int i = 0; i < lstFreelancerBankDetails.Count; i++)
        //    {
        //        try
        //        {
        //            BankInfo bankInfo = new BankInfo();
        //            bankInfo.UsersID = lstFreelancerBankDetails[i].UsersID;
        //            bankInfo.RoutingID = lstFreelancerBankDetails[i].RoutingID == null ? lstFreelancerBankDetails[i].RoutingID : cryptoService.Encrypt(lstFreelancerBankDetails[i].RoutingID);
        //            bankInfo.SwiftCode = lstFreelancerBankDetails[i].SwiftCode == null ? lstFreelancerBankDetails[i].SwiftCode : cryptoService.Encrypt(lstFreelancerBankDetails[i].SwiftCode);
        //            bankInfo.IBANNumber = lstFreelancerBankDetails[i].IBANNumber == null ? lstFreelancerBankDetails[i].IBANNumber : cryptoService.Encrypt(lstFreelancerBankDetails[i].IBANNumber);
        //            bankInfo.BankName = cryptoService.Encrypt(lstFreelancerBankDetails[i].BankName);
        //            bankInfo.BankAddress = cryptoService.Encrypt(lstFreelancerBankDetails[i].BankAddress == null ? "" : lstFreelancerBankDetails[i].BankAddress);
        //            bankInfo.AccountNumber = cryptoService.Encrypt(lstFreelancerBankDetails[i].AccountNumber);
        //            bankInfo.TaxID = lstFreelancerBankDetails[i].TaxID == null ? lstFreelancerBankDetails[i].TaxID : cryptoService.Encrypt(lstFreelancerBankDetails[i].TaxID);
        //            apiResponce.Text = _freelancer.EncryptBankDetails(bankInfo);
        //        }
        //        catch (Exception ex)
        //        {

        //            //throw;
        //        }
        //    }
        //    return Ok(apiResponce);
        //}

        //[HttpPost("get.freelancers.account.detailsforAP")]
        //public object GetFreelancersAccountDetailsForAP([FromBody] SearchFreelancerAccountParameters datas)
        //{
        //    List<FreelancerBankDetails> lstFreelancerBankDetails = new List<FreelancerBankDetails>();
        //    lstFreelancerBankDetails = _freelancer.GetFreelancersAccountDetails(datas.UserIDs);
        //    return lstFreelancerBankDetails;
        //}




        [HttpPost("get.freelancer.RemoveJobList")]
        public object GetFreelancerRemoveJobList([FromBody] SearchFreelancerParameters datas)
        {
            List<FreelancerDashboardSummary> lstFreelancerDashboard = new List<FreelancerDashboardSummary>();
            lstFreelancerDashboard = _freelancer.GetFreelancerRemoveJobList(datas.UserID, datas.UserEmailID, datas.UserRole);
            var response = MakingInnerData(datas, lstFreelancerDashboard);
            return response;
        }

        [HttpPost("MakingInnerData")]
        public object MakingInnerData(SearchFreelancerParameters datas, List<FreelancerDashboardSummary> lstFreelancerDashboard)
        {
            var data = lstFreelancerDashboard.GroupBy(a => new
            {
                a.select,
                a.JobNo,
                a.Customer,
                a.PM_Name,
                a.AgencyName,
                a.FreelancerName,
                a.Author,
                a.Title,
                a.Edition,
                a.ContractID,
                a.ContractStatus,
                a.FilePath
            }).Select(b => new FreelancerDashboard
            {
                select = b.Key.select,
                JobNo = b.Key.JobNo,
                Customer = b.Key.Customer,
                PM_Name = b.Key.PM_Name,
                AgencyName = b.Key.AgencyName,
                FreelancerName = b.Key.FreelancerName,
                Author = b.Key.Author,
                Title = b.Key.Title,
                Edition = b.Key.Edition,
                ContractID = b.Key.ContractID,
                ContractStatus = b.Key.ContractStatus,
                FilePath = b.Key.FilePath,
                isExpanded = false,
                freelancerInnerData = b.Select(c => new freelancerInnerData
                {
                    JobNo = c.JobNo,
                    JobID = c.JobID,
                    InvoiceType = c.InvoiceType,
                    InvApproverName = c.InvApproverName,
                    InvApproverName2 = c.InvApproverName2,
                    skill = c.skill,
                    Unit = c.Unit,
                    ContractedRate = c.ContractedRate,
                    Contracted_Currency = c.Contracted_Currency,
                    StartDate = c.StartDate,
                    EndDate = c.EndDate,
                    RaisedUnit = c.RaisedUnit,
                    NoOfUnits = c.NoOfUnits,
                    Notes = c.Notes,
                    //ContractID = c.ContractID,
                    ContractStatus = c.ContractStatus,
                    //FilePath = c.FilePath
                }).Distinct().ToList()
            }); ;
            List<string> Jobs = data.Select(a => a.JobNo).Distinct().ToList();
            if (!(datas.JobFilter.Count == 1 && datas.JobFilter.Where(a => a == "0").Count() > 0))
                data = data.Where(a => datas.JobFilter.Where(b => a.JobNo == b).Count() > 0).ToList();


            var response = commonFn.TableResponce(data, datas.sort, datas.dir, datas.currentpage, datas.pageSize);

            var finalresponse = new
            {
                Jobs = Jobs,
                response = response
            };

            return finalresponse;
        }

        [HttpPost("get.freelancer.dashboard")]
        public object GetFreelancerDashboardList([FromBody] SearchFreelancerParameters datas)
        {
            List<FreelancerDashboardSummary> lstFreelancerDashboard = new List<FreelancerDashboardSummary>();
            lstFreelancerDashboard = _freelancer.GetFreelancerDashboardList(datas.UserID, datas.UserEmailID, datas.UserRole).Distinct().ToList();
            var response = MakingInnerData(datas, lstFreelancerDashboard);
            return response;
        }

        [HttpPost("save.contract")]
        public ActionResult SaveContract([FromBody] ContractSave contractSave)
        {
            ApiResponce apiResponce = new ApiResponce();
            if (_freelancer.SaveContract(contractSave) > 0)
            {
                var ClientJobDetails = _client.GetJobDetailsFromID(contractSave.JobID);
                bool isSigned = false;
                if (contractSave.Status == "ACCEPTED")
                {
                    isSigned = true;
                }
                //commonFn.SendMailToFreelancerContract(ClientJobDetails, isSigned, contractSave.Status, contractSave.RejectionComments);
                _client.SendMailToFreelancerContract(ClientJobDetails, isSigned, contractSave.Status, contractSave.RejectionComments);
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }

        [HttpPost("remove.invoices.record")]
        public ActionResult RemoveJobFromInvoice([FromBody] RemoveJobs datas)
        {
            ApiResponce apiResponce = new ApiResponce();
            int cnt = _freelancer.RemoveJobFromInvoice(datas.JobIDs.TrimStart(',').Trim(), datas.Type);
            if (cnt != null && cnt > 0)
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }

        [HttpGet("get.jobdetails/{JobIDs}")]
        public object GeInvoiceDetails(string JobIDs)
        {
            return _freelancer.GetJobDetails(JobIDs.TrimStart(',').Trim());
        }
    }
}
