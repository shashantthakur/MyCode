﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ESPro.Core.Entity;
using ESPro.Core.Entity.Freelancer;
using ESPro.Core.Entity.HSBC;
using ESPro.Core.Entity.Invoice;
using ESPro.Core.Entity.Search;
using ESPro.Core.Interface;
using ESPro.Core.Interface.HSBC;
using ESPro.Infrastructure.Class;
using ESPro.Infrastructure.Service;
using ESProAPI.Class;
using iText.Html2pdf;
using iText.Kernel.Pdf;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml.Style;

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class InvoiceController : ControllerBase
    {
        private readonly IHSBC _hSBC;
        private readonly IInvoice _invoice;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public CommonFunctions commonFn = new CommonFunctions();

        public InvoiceController(IHSBC hSBC, IInvoice invoice, IHttpContextAccessor httpContextAccessor)
        {
            _hSBC = hSBC;
            _invoice = invoice;
            _httpContextAccessor = httpContextAccessor;
        }
        [HttpPost("get.invoicelist")]
        public object GeInvoicesList([FromBody] SearchInvoiceParameters datas)
        {
            List<Invoice> lstInvoices = new List<Invoice>();
            int total = 0;
            List<string> Jobs = null;
            List<string> Freelancers = null;
            List<string> InvoiceNames = null;
            List<string> InvApprovers = null;
            lstInvoices = _invoice.GetInvoicesList(datas.StartDate, datas.EndDate, datas.Status, datas.ContractType, datas.ProfileCurrency, datas.ContractCurrency, datas.Role, datas.UserEmailID, datas.DateColumn,
                  datas.currentpage, datas.pageSize, datas.sort, datas.dir, out total, out Jobs, out Freelancers, out InvoiceNames, out InvApprovers,
                 datas.JobFilter, datas.FreelancerFilter, datas.InvoiceNameFilter, datas.InvApproverFilter, "", "B");

            //List<Invoice> lstInvoices1 = new List<Invoice>();
            //for (int i = 0; i < lstInvoices.Count(); i++)
            //{
            //    if (lstInvoices[i].Inv2ApprovedRejectedDate != null)
            //        lstInvoices[i].InvApprovedRejectedDate = lstInvoices[i].Inv2ApprovedRejectedDate;

            //    if (datas.Status == "APPROVED")
            //    {
            //        if (lstInvoices[i].Status == "Approved by PM (Pending Accounts Payable Approval)" && (Convert.ToString("" + lstInvoices[i].InvApproverName2) == "" || (Convert.ToString("" + lstInvoices[i].InvApproverName2) != "" && Convert.ToString("" + lstInvoices[i].Inv2ApprovedRejectedDate) != "")))
            //            lstInvoices1.Add(lstInvoices[i]);
            //    }
            //    else if (datas.Status == "APPLIED")
            //    {
            //        if (lstInvoices[i].Status == "Approved by PM (Pending Accounts Payable Approval)" && (Convert.ToString("" + lstInvoices[i].InvApproverName2) != "" && Convert.ToString("" + lstInvoices[i].Inv2ApprovedRejectedDate) == ""))
            //            lstInvoices1.Add(lstInvoices[i]);
            //        else if (lstInvoices[i].Status == "Pending PM Approval")
            //            lstInvoices1.Add(lstInvoices[i]);
            //    }
            //    else
            //        lstInvoices1.Add(lstInvoices[i]);
            //}

            //lstInvoices = lstInvoices1;

            List<Currency> ProfileCurrency = CommonResource.ToCollection<Currency>(DbContext.DbUser.ExecuteDataSet("usp_GetProfileCurrency", datas.ContractType).Tables[0]);
            List<Currency> ContractCurrency = CommonResource.ToCollection<Currency>(DbContext.DbUser.ExecuteDataSet("usp_GetContractedCurrency", datas.ContractType).Tables[0]);

            //List<string> Jobs = lstInvoices.Select(a => a.JobNo).Distinct().ToList();
            //if (!(datas.JobFilter.Count == 1 && datas.JobFilter.Where(a => a == "0").Count() > 0))
            //    lstInvoices = lstInvoices.Where(a => datas.JobFilter.Where(b => a.JobNo == b).Count() > 0).ToList();

            //List<string> Freelancers = lstInvoices.Select(a => a.FreelancerName).Distinct().ToList();
            //if (!(datas.FreelancerFilter.Count == 1 && datas.FreelancerFilter.Where(a => a == "0").Count() > 0))
            //    lstInvoices = lstInvoices.Where(a => datas.FreelancerFilter.Where(b => a.FreelancerName == b).Count() > 0).ToList();

            //List<string> InvoiceNames = lstInvoices.Select(a => a.Name).Distinct().ToList();
            //if (!(datas.InvoiceNameFilter.Count == 1 && datas.InvoiceNameFilter.Where(a => a == "0").Count() > 0))
            //    lstInvoices = lstInvoices.Where(a => datas.InvoiceNameFilter.Where(b => a.Name == b).Count() > 0).ToList();

            //List<string> InvApprovers = lstInvoices.Select(a => a.InvApproverName).Distinct().ToList();
            //if (!(datas.InvApproverFilter.Count == 1 && datas.InvApproverFilter.Where(a => a == "0").Count() > 0))
            //    lstInvoices = lstInvoices.Where(a => datas.InvApproverFilter.Where(b => a.InvApproverName == b).Count() > 0).ToList();

            //var response = commonFn.TableResponce(lstInvoices, datas.sort, datas.dir, datas.currentpage, datas.pageSize);
            int lastpage = Convert.ToInt32(Math.Ceiling(Convert.ToDecimal(Convert.ToDecimal(total) / Convert.ToDecimal(datas.pageSize))));
            var data = new
            {
                Jobs = Jobs,
                Freelancers = Freelancers,
                InvApprovers = InvApprovers,
                Invoices = InvoiceNames,
                ProfileCurrency = ProfileCurrency,
                ContractCurrency = ContractCurrency,
                response = new TableResponse
                {
                    Lastpage = lastpage,
                    data = lstInvoices,
                    TotalRecords = total,
                }
            };
            return data;
            //return _invoice.GetInvoicesList(datas.StartDate, datas.EndDate, datas.Status, datas.Role, datas.UserEmailID);
        }

        [HttpGet("get.invoicestatuslist/{UserRole}")]
        public object GeInvoicesStatusList(string UserRole)
        {
            if (UserRole == "REPORT")
                UserRole = "";
            return _invoice.GeInvoicesStatusList(UserRole);
        }

        [HttpGet("get.financialmatrix")]
        public object GetFinanceMatrix()
        {
            return _invoice.GetFinanceMatrix();
        }

        [HttpGet("get.GetFilterDateType/{StatusName}")]
        public object GetFilterDateType(string StatusName)
        {
            return _invoice.GetFilterDateType(StatusName);
        }

        [HttpGet("get.invoicedetails/{InvoiceSummaryID}")]
        public object GeInvoiceDetails(int InvoiceSummaryID)
        {
            return _invoice.GetInvoiceDetails(InvoiceSummaryID);
        }

        [HttpGet("get.prefundingclient")]
        public object GetPrefundingClients()
        {
            return _invoice.PrefundingClients();
        }

        [HttpPost("get.prefundingdetails")]
        public object GePrefundingDetails([FromBody] WileyPrefundingDetailsSearchParameters wileyPrefundingDetailsSearchParameters)
        {
            List<WileyPrefundingDetails> lstWileyPrefundingDetails = new List<WileyPrefundingDetails>();
            lstWileyPrefundingDetails = _invoice.GePrefundingDetails(wileyPrefundingDetailsSearchParameters);

            var response = commonFn.TableResponce(lstWileyPrefundingDetails, wileyPrefundingDetailsSearchParameters.sort, wileyPrefundingDetailsSearchParameters.dir, wileyPrefundingDetailsSearchParameters.currentpage, wileyPrefundingDetailsSearchParameters.pageSize);

            var finalresponse = new
            {
                response = response
            };
            return finalresponse;
        }

        [HttpPost("save.prefundingdetails")]
        public ActionResult SaveWileyPrefundingDetails([FromBody] WileyPrefundingDetails PrefundingDetails)
        {
            ApiResponce apiResponce = new ApiResponce();

            WileyPrefundingDetailsSearchParameters wileyPrefundingDetailsSearchParameters = new WileyPrefundingDetailsSearchParameters();
            wileyPrefundingDetailsSearchParameters.Currency = PrefundingDetails.PrefundingCurrency;
            wileyPrefundingDetailsSearchParameters.Client = PrefundingDetails.PrefundingClient;
            wileyPrefundingDetailsSearchParameters.PrefundingFlag = 1;
            List<WileyPrefundingDetails> lstWileyPrefundingDetails = _invoice.GePrefundingDetails(wileyPrefundingDetailsSearchParameters);
            if (lstWileyPrefundingDetails.Count > 0)
            {
                PrefundingDetails.StartDate = lstWileyPrefundingDetails[lstWileyPrefundingDetails.Count-1].PrefundingDate.ToString("yyyy-MM-dd");
                int aaa = _invoice.UpdatePrefundingBalance(PrefundingDetails);
            }

            if (_invoice.SaveWileyPrefunding(PrefundingDetails) > 0)
            {
                var SendMailTo = _invoice.GetSendMailDetails("WileyPrefundingUpdation", PrefundingDetails.PrefundingClient).ToList();
                string clientname = _invoice.PrefundingClients().Where(b => b.Id == PrefundingDetails.PrefundingClient).FirstOrDefault().ClientName;
                string MailSubject = "ESPro: Prefunding Amount Update for <b>" + clientname + "</b> for " + PrefundingDetails.PrefundingCurrency + " Currency";
                string ToMail = PrefundingDetails.UserEmailID;
                if (SendMailTo.Count > 0)
                {
                    if (Convert.ToString("" + SendMailTo[0].ToMailList).Trim() != "")
                        ToMail += "; " + SendMailTo[0].ToMailList;
                    string CCMail = SendMailTo[0].CCMailList;
                    string BCCMail = SendMailTo[0].BCCMailList;
                    StringBuilder sbMailBody = new StringBuilder(System.IO.File.ReadAllText(Path.Combine(CommonResource.MailTemplatePath, "WileyPrefundingUpdateMail.html")));
                    sbMailBody.Replace("[AP]", PrefundingDetails.UserName);
                    sbMailBody.Replace("[PrefundingAmount]", PrefundingDetails.PrefundingCurrency + " " + PrefundingDetails.PrefundingAmount);
                    sbMailBody.Replace("[PrefundingDate]", Convert.ToDateTime(PrefundingDetails.PrefundingDate).ToString("dd-MMM-yyyy"));
                    sbMailBody.Replace("[Regards]", CommonResource.MailRegards);
                    MailService objMail = new MailService();
                    objMail.SendMail(sbMailBody.ToString(), MailSubject, ToMail, CCMail, BCCMail);
                    apiResponce.Text = "success";
                }
                else
                {
                    apiResponce.Text = "DB updated, but send mail details not found.";
                }
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }

        [HttpPost("create.invoice/{UsersId}")]
        public async Task<IActionResult> CreateInvoice([FromBody] List<FreelancerDashboardSummary> invoiceModels, int UsersId)
        {
            _invoice.AddInvoiceLog(commonFn.GetCallerMemberName(), "GenerateInvoiceStart", invoiceModels[0].FreelancerEmailID, false, "");
            CommonResult commonResult = new CommonResult();
            int errorFound = 0;
            for (int i = 0; i < invoiceModels.Count; i++)
            {
                if (invoiceModels[0].InvoiceType == "Final")
                {
                    if (_invoice.CheckFinalInvoiceRaisedorNot(Convert.ToInt32("0" + invoiceModels[i].JobID), invoiceModels[i].FreelancerEmailID).Count > 0)
                    {
                        errorFound = 1;
                        commonResult.ErrorMessage += "Final Invoice already raised for job no " + invoiceModels[0].JobNo + " and Job Id " + invoiceModels[0].JobID;
                        commonResult.Status = "fail";
                    }
                }
            }
            if (errorFound == 0)
            {
                int cnt = 0;
                if (UsersId > 0)
                    cnt = _invoice.CreateInvoice(invoiceModels, UsersId);
                if (cnt != null && cnt > 0)
                {
                    _invoice.AddInvoiceLog(commonFn.GetCallerMemberName(), "GenerateInvoiceSuccess", invoiceModels[0].FreelancerEmailID, true, "");
                    commonResult.ErrorMessage = "Invoice raised successfully.";
                    commonResult.Status = "success";
                }
                else
                {
                    _invoice.AddInvoiceLog(commonFn.GetCallerMemberName(), "GenerateInvoiceFail", invoiceModels[0].FreelancerEmailID, false, "");
                    commonResult.ErrorMessage = "Something went wrong, please try after some time.";
                    commonResult.Status = "fail";
                }
            }
            return Ok(commonResult);
        }

        [HttpPost("save.invoiceA")]
        public ActionResult SaveInvoiceDetailsA()
        {
            CommonResult CommonResult = new CommonResult();
            List<Invoice> lstInvoices = new List<Invoice>();
            lstInvoices = _invoice.GetInvoicesListNotSendToConnect();

            for (int i = 0; i < lstInvoices.Count(); i++)
            {
                InvoiceSave saveInvoice = new InvoiceSave();
                saveInvoice.InvoiceSummaryID = Convert.ToInt16(lstInvoices[i].ID);
                saveInvoice.JobNo = lstInvoices[i].JobNo;
                saveInvoice.FreelancerEmailID = lstInvoices[i].FreelancerEmail;
                saveInvoice.Status = lstInvoices[i].Status;
                string FullError = string.Empty;
                bool resultStatus = true;
                string Error;
                _invoice.AddInvoiceLog(commonFn.GetCallerMemberName(), "Invoice : " + saveInvoice.InvoiceSummaryID + " and Status: " + saveInvoice.Status + " for iConnect Integration Start(Job No.: " + saveInvoice.JobNo + ")", saveInvoice.FreelancerEmailID, false, "");
                string jsonData = String.Empty;
                bool result = _invoice.PushDataToIConnect(saveInvoice, out Error, out FullError, out jsonData);
                if (!result)
                {
                    _invoice.AddInvoiceLog(commonFn.GetCallerMemberName(), "Invoice : " + saveInvoice.InvoiceSummaryID + " and Status: " + saveInvoice.Status + " for iConnect Integration Error(" + FullError + ")", saveInvoice.FreelancerEmailID, false, "");

                    _invoice.InsertInvoiceLog(saveInvoice.InvoiceSummaryID, "iConnect", false, FullError, jsonData);

                    CommonResult.Status = "fail";
                    CommonResult.ErrorMessage = "Error: Something went wrong. Please try again. Description: Error from I-connect API: " + FullError;
                    resultStatus = false;
                }
                else
                    _invoice.InsertInvoiceLog(saveInvoice.InvoiceSummaryID, "iConnect", true, FullError, jsonData);
            }
            return Ok(CommonResult);
        }

        [HttpPost("save.invoice")]
        public ActionResult SaveInvoiceDetails([FromBody] InvoiceSave[] saveInvoice)
        {
            SaveInvoiceResult CommonResult = new SaveInvoiceResult();
            string RequestUrl = _httpContextAccessor.HttpContext.Request.Host.Value.ToLower();
            CommonResult = _invoice.SaveInvoiceDetails(saveInvoice, RequestUrl);
            return Ok(CommonResult);
        }

        [HttpPost("export.toXLS")]
        public async Task<FileStreamResult> ExportToXLS([FromBody] InvoiceDownload datas)
        {
            List<InvoiceDetails> result = _invoice.GetInvoiceDetails(datas.InvoiceSummaryID);

            StringBuilder sb = new StringBuilder(System.IO.File.ReadAllText(Path.Combine(CommonResource.MailTemplatePath, "InvoiceSample.html")));
            if (result != null && result.Count > 0)
            {
                var ResultObj = result.FirstOrDefault();
                sb.Replace("{InvoiceDate}", ResultObj.InvoiceDate);
                sb.Replace("{PMName}", ResultObj.JobPM);
                sb.Replace("{InvApproverName}", ResultObj.InvApproverName);
                sb.Replace("{Invoice#}", ResultObj.Name);
                sb.Replace("{FLName}", ResultObj.FreelancerName);
                sb.Replace("{Project}", Convert.ToString("" + ResultObj.JobNo) + " " + Convert.ToString("" + ResultObj.Author) + " " + Convert.ToString("" + ResultObj.Title) + "/" + Convert.ToString("" + ResultObj.Edition));
                StringBuilder stringBuilder = new StringBuilder("");
                sb.Replace("{TotalAmount}", ResultObj.Contracted_Currency + " " + commonFn.FormatCurrency(ResultObj.TotalAmount));

                sb.Replace("{ServiceArea}", ResultObj.Service);
                sb.Replace("{TaskCompleted}", ResultObj.Task);
                sb.Replace("{ContractCurrency}", ResultObj.Contracted_Currency);

                for (int i = 0; i < result.Count; i++)
                {
                    if (i % 2 == 0)
                        stringBuilder.Append("<tr style='background-color: #f2f2f2;' id='table'>");
                    else
                        stringBuilder.Append("<tr>");
                    stringBuilder.AppendFormat("<td style='border:1px solid #cccccc;padding:3px 10px;'>{0}</td>", result[i].Notes);
                    stringBuilder.AppendFormat("<td style='border:1px solid #cccccc;padding:3px 10px;'>{0}</td>", result[i].Unit);
                    stringBuilder.AppendFormat("<td style='border:1px solid #cccccc;padding:3px 10px;'>{0}</td>", commonFn.FormatCurrency(result[i].RatePerUnit));
                    stringBuilder.AppendFormat("<td style='border:1px solid #cccccc;padding:3px 10px;'>{0}</td>", result[i].UnitsAssigned);
                    stringBuilder.AppendFormat("<td style='border:1px solid #cccccc;padding:3px 10px;'>{0}</td>", result[i].UnitsApplied);
                    stringBuilder.AppendFormat("<td style='border:1px solid #cccccc;padding:3px 10px;'>{0}</td>", result[i].TotalUnitsApplied);
                    if (ResultObj.InvoiceType == "Full")
                        stringBuilder.AppendFormat("<td style='border:1px solid #cccccc;padding:3px 10px;'>{0}</td>", "Final");
                    else
                        stringBuilder.AppendFormat("<td style='border:1px solid #cccccc;padding:3px 10px;'>{0}</td>", result[i].InvoiceType);
                    stringBuilder.AppendFormat("<td style='border:1px solid #cccccc;padding:4px 10px;'>{0}</td>", result[i].InvoiceComments);
                    stringBuilder.AppendFormat("<td style='border:1px solid #cccccc;padding:3px 10px;'>{0}</td>", commonFn.FormatCurrency(result[i].SumAmount));
                    stringBuilder.Append("</tr>");
                }
                stringBuilder.AppendFormat("<tr><td style='border:1px solid #cccccc;padding:3px 10px;' colspan='6'></td><td style='border:1px solid #cccccc;padding:4px 10px;text-align:right;' colspan='2'><b>TOTAL INVOICE:</b></td><td style='border:1px solid #cccccc;padding:4px 10px;'>{0}</td></tr>", commonFn.FormatCurrency(
                    ResultObj.TotalAmount));
                sb.Replace("{Invoicebody}", stringBuilder.ToString());
                sb.Replace("{TotalAmount}", commonFn.FormatCurrency(ResultObj.TotalAmount));

                byte[] byteArray = Encoding.ASCII.GetBytes(sb.ToString());

                MemoryStream stream = new MemoryStream(byteArray);

                var contentType = MimeMapping.MimeUtility.GetMimeMapping(datas.FyleType);

                if (datas.FyleType.ToLower() == ".pdf")
                {
                    var workStream = new MemoryStream();

                    PdfWriter writer = new PdfWriter(workStream);
                    writer.SetCloseStream(false);
                    PdfDocument pdf = new PdfDocument(writer);
                    pdf.SetTagged();
                    iText.Kernel.Geom.PageSize pageSize = iText.Kernel.Geom.PageSize.A4.Rotate();
                    pdf.SetDefaultPageSize(pageSize);
                    ConverterProperties properties = new ConverterProperties();
                    //properties.SetBaseUri(baseUri);
                    iText.StyledXmlParser.Css.Media.MediaDeviceDescription mediaDeviceDescription
                        = new iText.StyledXmlParser.Css.Media.MediaDeviceDescription(iText.StyledXmlParser.Css.Media.MediaType.SCREEN);
                    mediaDeviceDescription.SetWidth(pageSize.GetWidth());
                    properties.SetMediaDeviceDescription(mediaDeviceDescription);
                    HtmlConverter.ConvertToPdf(sb.ToString(), pdf, properties);

                    //var workStream = new MemoryStream();
                    //using (var pdfWriter = new PdfWriter(workStream))
                    //{
                    //    pdfWriter.SetCloseStream(false);
                    //    ConverterProperties properties = new ConverterProperties();                       
                    //    using (var document = HtmlConverter.ConvertToDocument(sb.ToString(), pdfWriter))
                    //    {
                    //    }
                    //}

                    workStream.Position = 0;
                    return new FileStreamResult(workStream, contentType);

                }
                else
                {
                    var responce = new FileStreamResult(stream, contentType);
                    return responce;
                }
            }
            else
            {
                throw new ArgumentException();
                //return Ok("Database connectivity issue, please try after some time.");
            }

        }

        [HttpPost("export.invoice")]
        public IActionResult ExportFile([FromBody] SearchInvoiceParameters datas)
        {
            List<Invoice> lstInvoices = new List<Invoice>();
            int total = 0;
            List<string> Jobs = new List<string>();
            List<string> Freelancers = new List<string>();
            List<string> InvoiceNames = new List<string>();
            List<string> InvApprovers = new List<string>();
            lstInvoices = _invoice.GetInvoicesList(datas.StartDate, datas.EndDate, datas.Status, datas.ContractType, datas.ProfileCurrency, datas.ContractCurrency, datas.Role, datas.UserEmailID, datas.DateColumn, -1, datas.pageSize, datas.sort, datas.dir,
                out total, out Jobs, out Freelancers, out InvoiceNames, out InvApprovers, datas.JobFilter, datas.FreelancerFilter, datas.InvoiceNameFilter, datas.InvApproverFilter);

            List<Invoice> lstInvoices1 = new List<Invoice>();
            for (int i = 0; i < lstInvoices.Count(); i++)
            {
                if (datas.Status == "APPROVED")
                {
                    if (lstInvoices[i].Status == "Approved by PM (Pending Accounts Payable Approval)" && (Convert.ToString("" + lstInvoices[i].InvApproverName2) == "" || (Convert.ToString("" + lstInvoices[i].InvApproverName2) != "" && Convert.ToString("" + lstInvoices[i].Inv2ApprovedRejectedDate) != "")))
                        lstInvoices1.Add(lstInvoices[i]);
                }
                else if (datas.Status == "APPLIED")
                {
                    if (lstInvoices[i].Status == "Approved by PM (Pending Accounts Payable Approval)" && (Convert.ToString("" + lstInvoices[i].InvApproverName2) != "" && Convert.ToString("" + lstInvoices[i].Inv2ApprovedRejectedDate) == ""))
                        lstInvoices1.Add(lstInvoices[i]);
                    else if (lstInvoices[i].Status == "Pending PM Approval")
                        lstInvoices1.Add(lstInvoices[i]);
                }
                else
                    lstInvoices1.Add(lstInvoices[i]);
            }

            lstInvoices = lstInvoices1;

            //List<string> Jobs = lstInvoices.Select(a => a.JobNo).Distinct().ToList();
            //if (!(datas.JobFilter.Count == 1 && datas.JobFilter.Where(a => a == "0").Count() > 0))
            //    lstInvoices = lstInvoices.Where(a => datas.JobFilter.Where(b => a.JobNo == b).Count() > 0).ToList();

            //List<string> Freelancers = lstInvoices.Select(a => a.FreelancerName).Distinct().ToList();
            //if (!(datas.FreelancerFilter.Count == 1 && datas.FreelancerFilter.Where(a => a == "0").Count() > 0))
            //    lstInvoices = lstInvoices.Where(a => datas.FreelancerFilter.Where(b => a.FreelancerName == b).Count() > 0).ToList();

            //List<string> InvoiceNames = lstInvoices.Select(a => a.Name).Distinct().ToList();
            //if (!(datas.InvoiceNameFilter.Count == 1 && datas.InvoiceNameFilter.Where(a => a == "0").Count() > 0))
            //    lstInvoices = lstInvoices.Where(a => datas.InvoiceNameFilter.Where(b => a.Name == b).Count() > 0).ToList();

            //var response = commonFn.TableResponce(lstInvoices, datas.sort, datas.dir, datas.currentpage, datas.pageSize);

            DataTable dtToExport = commonFn.ToDataTable(lstInvoices);
            dtToExport.Columns.RemoveAt(0);
            dtToExport.Columns.Remove("FreelancerID");
            dtToExport.Columns.Remove("FLBankInfoId");
            dtToExport.Columns.Remove("ProfileWireFee");
            dtToExport.AcceptChanges();
            string TemplateFile = "";
            string path = "";
            TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "InvoiceDetails.xlsx");
            try
            {
                using (var pck = new OfficeOpenXml.ExcelPackage())
                {
                    using (var stream = System.IO.File.OpenRead(TemplateFile))
                    {
                        pck.Load(stream);
                    }

                    string ToRows = "", FromRows = "", modelRange = "";
                    FromRows = "A2";
                    ToRows = "AE";
                    string FileName = "";

                    var ws = pck.Workbook.Worksheets[1];

                    if (datas.Status == "APPLIED")
                    {
                        FileName = "Pending_PM_Approval";
                    }
                    else if (datas.Status == "REJECTED")
                    {
                        FileName = "Rejected_by_PM";
                    }
                    else if (datas.Status == "APPROVED")
                    {
                        FileName = "Approved_by_PM_(Pending_Accounts_Payable_Approval)";
                        ToRows = "AJ";
                        if (datas.Role != "FINANCEMANAGER")
                            ToRows = "AE";
                    }
                    else if (datas.Status == "APPROVEDBYAP")
                    {
                        FileName = "Approved_by_Accounts_Payable";
                    }
                    else if (datas.Status == "REJECTEDBYAP")
                    {
                        FileName = "Rejected_by_Accounts_Payable";
                    }
                    else if (datas.Status == "PAIDINVOICES")
                    {
                        FileName = "Paid_Invoices_by_Wallet";
                    }



                    if (datas.Role != "FINANCEMANAGER")
                    {
                        dtToExport.Columns.Remove("ContractType");
                        dtToExport.Columns.Remove("FLEsproCode");
                        dtToExport.Columns.Remove("DueInDays");
                        dtToExport.Columns.Remove("ConversionCurrencyRate");
                        dtToExport.Columns.Remove("TotalAmountInUSD");


                        ws.DeleteColumn(3);
                        ws.DeleteColumn(4);
                        ws.DeleteColumn(18);
                        ws.DeleteColumn(22);
                        ws.DeleteColumn(24);
                        ws.DeleteColumn(32);

                        ws.Column(14).Style.Numberformat.Format = "dd-MMM-yyyy";
                        ws.Column(15).Style.Numberformat.Format = "dd-MMM-yyyy";
                        ws.Column(16).Style.Numberformat.Format = "dd-MMM-yyyy";
                        ws.Column(17).Style.Numberformat.Format = "dd-MMM-yyyy";
                        ws.Column(18).Style.Numberformat.Format = "dd-MMM-yyyy";
                    }
                    else if (datas.Role == "FINANCEMANAGER" && (datas.Status == "APPROVEDBYAP" || datas.Status == "REJECTEDBYAP"))
                    {
                        dtToExport.Columns.Remove("DueInDays");
                        ws.DeleteColumn(20);

                        ws.Column(16).Style.Numberformat.Format = "dd-MMM-yyyy";
                        ws.Column(17).Style.Numberformat.Format = "dd-MMM-yyyy";
                        ws.Column(18).Style.Numberformat.Format = "dd-MMM-yyyy";
                        ws.Column(20).Style.Numberformat.Format = "dd-MMM-yyyy";

                        ToRows = "AI";
                    }
                    else
                    {
                        ws.Column(16).Style.Numberformat.Format = "dd-MMM-yyyy";
                        ws.Column(17).Style.Numberformat.Format = "dd-MMM-yyyy";
                        ws.Column(18).Style.Numberformat.Format = "dd-MMM-yyyy";
                        ws.Column(19).Style.Numberformat.Format = "dd-MMM-yyyy";
                        ws.Column(21).Style.Numberformat.Format = "dd-MMM-yyyy";
                    }

                    ws.Cells[FromRows].LoadFromDataTable(dtToExport, false);

                    var modelCells = ws.Cells[FromRows];
                    var modelRows = dtToExport.Rows.Count + 1;
                    modelRange = FromRows + ":" + ToRows.ToString() + modelRows.ToString();
                    ws.Cells[FromRows + ":" + ToRows.ToString() + modelRows.ToString()].Style.Font.SetFromFont(new Font("Calibri", 10));
                    var modelTable = ws.Cells[modelRange];
                    // Assign borders
                    modelTable.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    modelTable.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    modelTable.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    modelTable.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    byte[] data = pck.GetAsByteArray();
                    return Ok(new { data, contenttype = "application/octet-stream", filename = FileName + "_" + DateTime.Now.ToString("ddMMyyyyHHmmss") + ".xlsx" });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        [HttpPost("update.invoiceType")]
        public ActionResult UpdateInvoiceType([FromBody] InvoiceDetailsSave invoiceDetailsSave)
        {
            ApiResponce apiResponce = new ApiResponce();
            if (_invoice.UpdateInvoiceDetails(invoiceDetailsSave) > 0)
            {
                var inv = _invoice.GetInvoiceDetails(invoiceDetailsSave.InvoiceSummaryID);
                StringBuilder sbMailBody = null;
                string TemplateName = String.Empty;
                string MailSubject = "";
                string ToMail = "";
                string CCMail = "";
                string BCCMail = "";
                _invoice.AddInvoiceLog(commonFn.GetCallerMemberName(), "Invoice Type Updated for invoice details id: " + invoiceDetailsSave.InvoiceDetailsID, invoiceDetailsSave.UserEmailID, false, "");
                TemplateName = "InvoiceTypeUpdate.html";
                MailSubject = "ESPro: Invoice Type Updated: " + inv[0].Name;
                ToMail = inv[0].FreelancerEmailID;
                CCMail = inv[0].JobPM + "; " + inv[0].InvApproverEmail + "; " + invoiceDetailsSave.UserEmailID;
                sbMailBody = new StringBuilder(System.IO.File.ReadAllText(Path.Combine(CommonResource.MailTemplatePath, TemplateName)));
                sbMailBody.Replace("{Freelancer}", inv[0].FreelancerName);
                sbMailBody.Replace("{LuminaJobNumber}", inv[0].JobNo);
                sbMailBody.Replace("{InvoiceDetailsID}", invoiceDetailsSave.InvoiceDetailsID.ToString());
                sbMailBody.Replace("{OldInvoiceType}", invoiceDetailsSave.OldInvoiceType);
                sbMailBody.Replace("{NewInvoiceType}", invoiceDetailsSave.NewInvoiceType);
                sbMailBody.Replace("{Regards}", CommonResource.MailRegards);
                MailService objMail = new MailService();
                objMail.SendMail(sbMailBody.ToString(), MailSubject, ToMail, CCMail, BCCMail);
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }

        [HttpGet("get.invoicesforAPApproval/{InvoiceSummaryIDs}")]
        public object GeInvoicesforAPApproval(string InvoiceSummaryIDs)
        {
            return _invoice.GeInvoicesforAPApproval(InvoiceSummaryIDs.TrimStart(',').Trim());
        }

        [HttpPost("get.invoicesforAPApproval")]
        public object GeInvoicesforAPApprovalPost([FromBody] SearchCheckedInvoiceID datas)
        {
            return _invoice.GeInvoicesforAPApproval(datas.checkedID.TrimStart(',').Trim());
        }

        [HttpPost("GetBankTransactionHistory")]
        public object GetBankTransactionHistory([FromBody] SearchBankTransactionHistoryParameters datas)
        {
            List<BankTransactionHistory> lstBankTransactionHistory = new List<BankTransactionHistory>();
            lstBankTransactionHistory = _hSBC.GetBankTransactionHistory(datas.ProjectCode, datas.StartDate, datas.EndDate, datas.Status, datas.Role, Convert.ToString(datas.UsersID), 0, "");

            string InvoiceSummaryIDs = string.Join(',', lstBankTransactionHistory.Select(c => c.InvoiceSummaryID).ToList());

            IEnumerable<InvoiceBankInfo> _BankAccount = _hSBC.GetInvoiceBankInfo(InvoiceSummaryIDs);

            for (int i = 0; i < lstBankTransactionHistory.Count; i++)
            {
                lstBankTransactionHistory[i].FreelancerName = _BankAccount.Where(a => a.InvoiceID == lstBankTransactionHistory[i].InvoiceSummaryID).Select(c => c.ProfileName).ToList().Count > 0 ? _BankAccount.Where(a => a.InvoiceID == lstBankTransactionHistory[i].InvoiceSummaryID).Select(c => c.ProfileName).ToList()[0] : "";
                lstBankTransactionHistory[i].PMApproveDate = _BankAccount.Where(a => a.InvoiceID == lstBankTransactionHistory[i].InvoiceSummaryID).Select(c => c.PMApproveDate).ToList().Count > 0 ? _BankAccount.Where(a => a.InvoiceID == lstBankTransactionHistory[i].InvoiceSummaryID).Select(c => c.PMApproveDate).ToList()[0] : null;
                lstBankTransactionHistory[i].APApproveDate = _BankAccount.Where(a => a.InvoiceID == lstBankTransactionHistory[i].InvoiceSummaryID).Select(c => c.APApproveDate).ToList().Count > 0 ? _BankAccount.Where(a => a.InvoiceID == lstBankTransactionHistory[i].InvoiceSummaryID).Select(c => c.APApproveDate).ToList()[0] : null;
            }

            List<string> Freelancers = lstBankTransactionHistory.Select(a => a.FreelancerName).Distinct().ToList();
            if (!(datas.FreelancerFilter.Count == 1 && datas.FreelancerFilter.Where(a => a == "0").Count() > 0))
                lstBankTransactionHistory = lstBankTransactionHistory.Where(a => datas.FreelancerFilter.Where(b => a.FreelancerName == b).Count() > 0).ToList();

            List<string> InvoiceNames = lstBankTransactionHistory.Select(a => a.InvoiceName).Distinct().ToList();
            if (!(datas.InvoiceNameFilter.Count == 1 && datas.InvoiceNameFilter.Where(a => a == "0").Count() > 0))
                lstBankTransactionHistory = lstBankTransactionHistory.Where(a => datas.InvoiceNameFilter.Where(b => a.InvoiceName == b).Count() > 0).ToList();

            var response = commonFn.TableResponce(lstBankTransactionHistory, datas.sort, datas.dir, datas.currentpage, datas.pageSize);
            var data = new
            {
                Freelancers = Freelancers,
                Invoices = InvoiceNames,
                response = response
            };
            return data;
        }

        [HttpPost("ExportBankTransactionHistory")]
        public IActionResult ExportFile([FromBody] SearchBankTransactionHistoryParameters datas)
        {
            List<BankTransactionHistory> lstBankTransactionHistory = new List<BankTransactionHistory>();
            lstBankTransactionHistory = _hSBC.GetBankTransactionHistory(datas.ProjectCode, datas.StartDate, datas.EndDate, datas.Status, datas.Role, Convert.ToString(datas.UsersID), 0, datas.ReportType);

            string InvoiceSummaryIDs = string.Join(',', lstBankTransactionHistory.Select(c => c.InvoiceSummaryID).ToList());

            IEnumerable<InvoiceBankInfo> _BankAccount = _hSBC.GetInvoiceBankInfo(InvoiceSummaryIDs);

            for (int i = 0; i < lstBankTransactionHistory.Count; i++)
            {
                if (lstBankTransactionHistory[i].InvoiceName == "CLJ-090421051801_inv_25082021_01")
                {

                }

                lstBankTransactionHistory[i].FreelancerName = _BankAccount.Where(a => a.InvoiceID == lstBankTransactionHistory[i].InvoiceSummaryID).Select(c => c.ProfileName).ToList().Count > 0 ? _BankAccount.Where(a => a.InvoiceID == lstBankTransactionHistory[i].InvoiceSummaryID).Select(c => c.ProfileName).ToList()[0] : "";
                lstBankTransactionHistory[i].FreelancerEmail = _BankAccount.Where(a => a.InvoiceID == lstBankTransactionHistory[i].InvoiceSummaryID).Select(c => c.FreelancerEmail).ToList().Count > 0 ? _BankAccount.Where(a => a.InvoiceID == lstBankTransactionHistory[i].InvoiceSummaryID).Select(c => c.FreelancerEmail).ToList()[0] : "";
                lstBankTransactionHistory[i].PMApproveDate = _BankAccount.Where(a => a.InvoiceID == lstBankTransactionHistory[i].InvoiceSummaryID).Select(c => c.PMApproveDate).ToList().Count > 0 ? _BankAccount.Where(a => a.InvoiceID == lstBankTransactionHistory[i].InvoiceSummaryID).Select(c => c.PMApproveDate).ToList()[0] : null;
                lstBankTransactionHistory[i].VendorID = _BankAccount.Where(a => a.InvoiceID == lstBankTransactionHistory[i].InvoiceSummaryID).Select(c => c.FLCode).ToList().Count > 0 ? _BankAccount.Where(a => a.InvoiceID == lstBankTransactionHistory[i].InvoiceSummaryID).Select(c => c.FLCode).ToList()[0] : "";

            }

            DataTable dtToExport = commonFn.ToDataTable(lstBankTransactionHistory);

            dtToExport.Columns.Remove("TransactionDetailsId");
            //dtToExport.Columns.Remove("InvoiceSummaryId");
            dtToExport.Columns.Remove("UsersId");
            dtToExport.Columns.Remove("PaymentDate");
            dtToExport.Columns.Remove("PaymentExecutionDate");
            dtToExport.AcceptChanges();
            string TemplateFile = "";
            string path = "";
            TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "BankTransactionHistory.xlsx");
            try
            {
                using (var pck = new OfficeOpenXml.ExcelPackage())
                {
                    using (var stream = System.IO.File.OpenRead(TemplateFile))
                    {
                        pck.Load(stream);
                    }

                    string ToRows = "", FromRows = "", modelRange = "";
                    FromRows = "A2";
                    ToRows = "Q";

                    var ws = pck.Workbook.Worksheets[1];

                    ws.Cells[FromRows].LoadFromDataTable(dtToExport, false);

                    var modelCells = ws.Cells[FromRows];
                    var modelRows = dtToExport.Rows.Count + 1;
                    modelRange = FromRows + ":" + ToRows.ToString() + modelRows.ToString();
                    ws.Cells[FromRows + ":" + ToRows.ToString() + modelRows.ToString()].Style.Font.SetFromFont(new Font("Calibri", 10));
                    var modelTable = ws.Cells[modelRange];
                    // Assign borders
                    modelTable.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    modelTable.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    modelTable.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    modelTable.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    byte[] data = pck.GetAsByteArray();
                    return Ok(new { data, contenttype = "application/octet-stream", filename = "BankTransactionHistory_" + DateTime.Now.ToString("ddMMyyyyHHmmss") + ".xlsx" });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        [HttpPost("save.WireFee")]
        public ActionResult SaveWireFeeDetails([FromBody] WireFeeSave saveWireFeeDetails)
        {
            CommonResult CommonResult = new CommonResult();
            try
            {
                if (_invoice.SaveWireFeeDetails(saveWireFeeDetails) > 0)
                {
                    CommonResult.Status = "success";
                    CommonResult.ErrorMessage = "";
                }
                else
                {
                    CommonResult.Status = "fail";
                    CommonResult.ErrorMessage = "Data not updated.";
                }
            }
            catch (Exception ex)
            {
                CommonResult.Status = "fail";
                CommonResult.ErrorMessage = ex.Message.ToString();
            }
            return Ok(CommonResult);
        }
    }
}