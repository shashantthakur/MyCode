﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;

using ESPro.Core.Entity;
using ESPro.Core.Entity.Search;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using ESPro.Infrastructure.Service;
using ESProAPI.Class;
using log4net;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using OfficeOpenXml;
using OfficeOpenXml.Style;

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class regiController : ControllerBase
    {
        public CommonFunctions commonFn = new CommonFunctions();
        private readonly IUserDetails _userDetails;
        private readonly IRegi _IUserRegistration;
        private readonly IFreelancer _IFreelancer;
        private readonly IAuth _auth;
        public IConfiguration _Configuration { get; }
        private static readonly ILog log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        public regiController(IRegi IUserRegistration, IUserDetails userDetails, IConfiguration configuration, IFreelancer Freelancer, IAuth iauth)
        {
            _IUserRegistration = IUserRegistration;
            _userDetails = userDetails;
            _Configuration = configuration;
            _IFreelancer = Freelancer;
            _auth = iauth; ;
        }

        [Authorize]
        [HttpGet("GetStylesheetForCopyEditingSkill/{UserID}")]
        public object GetStylesheetForCopyEditingSkill(string UserID)
        {
            List<FreelancerTabModelAward> lstFreelancerTabModelAward = new List<FreelancerTabModelAward>();
            lstFreelancerTabModelAward = _IUserRegistration.GetStylesheetForCopyEditingSkill(UserID);
            return lstFreelancerTabModelAward;
        }

        [HttpGet("email.validate")]
        public ActionResult EmailValidate([FromQuery] string emailid)
        {
            ApiResponce apiResponce = new ApiResponce();
            var Result = _IUserRegistration.EmailValidate(emailid);
            apiResponce.Text = Result;
            return Ok(apiResponce);
        }

        [HttpGet("link.validate")]
        public ActionResult Get([FromQuery] string token)
        {
            string ActivationID;
            var Result = _IUserRegistration.ValidateToken(token, out ActivationID);

            if (Result.ToString() == "register")
            {
                return Redirect(_Configuration["UiUrl"] + "/SignIn");
            }
            else if (Result.ToString() == "0")
            {
                return BadRequest("Link Expired");
            }
            else
            {
                CryptoService cryptoService = new CryptoService();
                string Id = cryptoService.Encrypt(Result);
                return Redirect(_Configuration["UiUrl"] + "/CreateAccount?ID=" + Id);
            }
            // return Redirect("http://localhost:4200/CreateAccount?ID=" + ActivationID);
            // return Ok(apiResponce);
        }

        [HttpGet("link.validateToken")]
        public ActionResult GetToken([FromQuery] string token)
        {
            string ActivationID;
            var Result = _IUserRegistration.ValidateResetPaswordToken(token, out ActivationID);

            if (Result.ToString() == "register")
            {
                return Redirect(_Configuration["UiUrl"] + "/SignIn");
            }
            else if (Result.ToString() == "0")
            {
                return BadRequest("Link Expired");
            }
            else
            {
                CryptoService cryptoService = new CryptoService();
                string Id = System.Web.HttpUtility.HtmlEncode(cryptoService.Encrypt(Result));
                return Redirect(_Configuration["UiUrl"] + "/CreateAccount?UID=" + Id);
            }
            // return Redirect("http://localhost:4200/CreateAccount?ID=" + ActivationID);
            // return Ok(apiResponce);
        }

        [HttpPost("user.login")]
        public async Task<IActionResult> UserLogin([FromBody] Login login)
        {
            try
            {
                log.Debug("In");
                var remoteIpAddress = HttpContext.Connection.RemoteIpAddress;
                UserStatus userStatus = new UserStatus();
                string Data = "";
                string From = login.From;
                log.Debug("From: " + login.From);
                if (From == "Internal")
                {
                    userStatus = _IUserRegistration.UserLogin(login);
                }
                else if (From == "Google")
                {
                    Data = CommonFunctions.GetRequest("https://oauth2.googleapis.com/tokeninfo?id_token=" + login.Token);
                    var dt = Newtonsoft.Json.JsonConvert.DeserializeObject<GoogleResponse>(Data);
                    if (dt.email_verified == "true")
                    {
                        ExternalResponse response = new ExternalResponse();
                        response.Picture = dt.picture;
                        response.AuthenticationFrom = From;
                        response.username = dt.email;
                        response.name = dt.name;
                        userStatus = _IUserRegistration.RegisterOrLoginExternalUser(response);
                    }
                }
                else if (From == "LinkedIN")
                {

                    log.Debug("Internal From: " + login.From);
                    string URL = @"https://www.linkedin.com/oauth/v2/accessToken?grant_type=authorization_code";
                    URL = URL + "&code=" + login.Token;
                    string redirecturl = CommonResource.UiUrl + @"/SignIn";
                    redirecturl = HttpUtility.UrlEncode(redirecturl);
                    URL = URL + "&&redirect_uri=" + redirecturl;
                    URL = URL + "&client_id=865d8jed25ajsk";
                    URL = URL + "&client_secret=CoS6pu4I9zvmhbeD";

                    log.Debug("URL: " + URL);
                    string result = CommonResource.PostRequest(URL, "", "");
                    log.Debug("Result: " + result);
                    if (string.IsNullOrEmpty(result))
                    {
                        log.Debug("Result: is empty");
                        _userDetails.loginStatus(login.UserName, remoteIpAddress.ToString(), "FAILED", From, Data);
                        return new ContentResult() { Content = "Invalid Authentication Token", StatusCode = (int)HttpStatusCode.Unauthorized };
                    }
                    else if (result == "Bad Request")
                    {
                        log.Debug("Result: Bad");
                        _userDetails.loginStatus(login.UserName, remoteIpAddress.ToString(), "FAILED", From, Data);

                        return new ContentResult() { Content = "Invalid Authentication Token", StatusCode = (int)HttpStatusCode.Unauthorized };
                    }
                    else if (Regex.Match(result, "access_token", RegexOptions.IgnoreCase).Success)
                    {

                        log.Debug("Result: access_token");
                        LinkedInAPIPost ResultData = Newtonsoft.Json.JsonConvert.DeserializeObject<LinkedInAPIPost>(result);
                        string accesstoken = ResultData.access_token;
                        int time = ResultData.expires_in;
                        URL = "https://api.linkedin.com/v2/me";
                        string ProfileData = CommonFunctions.GetRequest(URL, accesstoken);
                        LinkedINProfileData LinkedInProfile = Newtonsoft.Json.JsonConvert.DeserializeObject<LinkedINProfileData>(ProfileData);
                        URL = "https://api.linkedin.com/v2/emailAddress?q=members&projection=(elements*(handle~))";
                        string EmailData = CommonFunctions.GetRequest(URL, accesstoken);
                        EmailData = Regex.Replace(EmailData, @"handle~", "handles");
                        LinkedInEmail LinkedInEmail = Newtonsoft.Json.JsonConvert.DeserializeObject<LinkedInEmail>(EmailData);
                        ExternalResponse response = new ExternalResponse();
                        response.username = LinkedInEmail.elements[0].handles.emailAddress;
                        response.name = LinkedInProfile.localizedFirstName + " " + LinkedInProfile.localizedLastName;
                        response.AuthenticationFrom = From;
                        userStatus = _IUserRegistration.RegisterOrLoginExternalUser(response);
                    }
                    else
                    {
                        return new ContentResult() { Content = result, StatusCode = (int)HttpStatusCode.Unauthorized };
                    }
                }



                if (userStatus != null)
                {
                    if (userStatus.AuthenticationType != From)
                    {
                        _userDetails.loginStatus(login.UserName, remoteIpAddress.ToString(), "FAILED", From, Data);
                        return new ContentResult() { Content = "Authentication Missmatch " + userStatus.AuthenticationType, StatusCode = (int)HttpStatusCode.Unauthorized };
                    }
                    else
                    {
                        AuthService authService = new AuthService();
                        userStatus.TokenString = authService.GenerateToken(userStatus);
                        userStatus.componentPermissions = _userDetails.GetComponentPermission(userStatus.UsersId, userStatus.RolesId, Convert.ToInt16(0 + userStatus.ClientsId));
                        _userDetails.loginStatus(login.UserName, remoteIpAddress.ToString(), "SUCCESS", From, Data);
                        return Ok(userStatus);
                    }
                }
                else
                {
                    _userDetails.loginStatus(login.UserName, remoteIpAddress.ToString(), "FAILED", From, Data);
                    return new ContentResult() { Content = "User not found", StatusCode = (int)HttpStatusCode.Unauthorized };
                }
            }
            catch (Exception ex)
            {
                return new ContentResult() { Content = ex.Message, StatusCode = (int)HttpStatusCode.Unauthorized };
            }
        }

        [Authorize]
        [HttpPost("switch.user")]
        public async Task<IActionResult> SwitchUser([FromBody] SwitchUser switchUser)
        {
            UserStatus userStatus = _IUserRegistration.SwitchUser(switchUser);
            if (userStatus != null)
            {
                AuthService authService = new AuthService();
                userStatus.TokenString = authService.GenerateToken(userStatus);
                userStatus.componentPermissions = _userDetails.GetComponentPermission(userStatus.UsersId, userStatus.RolesId, Convert.ToInt16(0 + userStatus.ClientsId));
                if (string.IsNullOrEmpty(switchUser.Process))
                {
                    return Ok(userStatus);
                }
                else if (switchUser.Process.ToUpper() == "AUTOLOGIN" && (switchUser.ProjectCode.ToUpper() == "ES2" || switchUser.ProjectCode.ToUpper() == "ESC"))
                {
                    CryptoService cryptoService = new CryptoService();
                    string UsersId = System.Web.HttpUtility.HtmlEncode(cryptoService.Encrypt(userStatus.UserName.ToString()));
                    string RoleId = System.Web.HttpUtility.HtmlEncode(cryptoService.Encrypt(userStatus.RolesId.ToString()));
                    //return Redirect(_Configuration["UiUrl"] + "/CreateAccount?ID=" + Id);
                    //string url = "http://localhost:4200/SignIn?uid='" + UsersId + "'&roleId='" + RoleId + "'&token='" + userStatus.TokenString + "'";
                    ApiResponce apiResponce = new ApiResponce();
                    apiResponce.Text = _Configuration["UiUrl"] + "/SignIn?uid=" + UsersId + "&roleId=" + RoleId + "&token=" + userStatus.TokenString + "";
                    return Ok(apiResponce);

                }
                else if (switchUser.Process.ToUpper() == "AUTOLOGIN" && switchUser.ProjectCode.ToUpper() == "ESPRO")
                {
                    ApiResponce apiResponce = new ApiResponce();
                    apiResponce.Text = _IUserRegistration.LoginToES2(_Configuration).Trim('\"');
                    return Ok(apiResponce);
                }
                else
                {
                    return Ok(userStatus);
                }
            }
            else
            {
                return Unauthorized();
            }
        }


        [HttpPost("LoginAs")]
        public async Task<IActionResult> LoginAs([FromBody] SwitchUser switchUser)
        {
            UserStatus userStatus = _IUserRegistration.SwitchUser(switchUser);
            if (userStatus != null && !string.IsNullOrEmpty(switchUser.TokenString))
            {
                Boolean flag = _auth.ValidateToken(switchUser.TokenString);
                if (flag == true)
                {
                    AuthService authService = new AuthService();
                    userStatus.TokenString = authService.GenerateToken(userStatus);
                    userStatus.componentPermissions = _userDetails.GetComponentPermission(userStatus.UsersId, userStatus.RolesId, Convert.ToInt16(0 + userStatus.ClientsId));

                    return Ok(userStatus);
                }
                else
                {
                    return Unauthorized();
                }

            }
            else
            {
                return Unauthorized();
            }
        }
        //[HttpPost("switch.user")]
        //public async Task<IActionResult> SwitchUser([FromBody] SwitchUser switchUser)
        //{
        //    UserStatus userStatus = _IUserRegistration.SwitchUser(switchUser);
        //    if (userStatus != null)
        //    {
        //        AuthService authService = new AuthService();
        //        userStatus.TokenString = authService.GenerateToken(userStatus);
        //        userStatus.componentPermissions = _userDetails.GetComponentPermission(userStatus.UsersId, userStatus.RolesId, Convert.ToInt16(0 +  userStatus.ClientsId));
        //        return Ok(userStatus);
        //    }
        //    else
        //    {
        //        return Unauthorized();
        //    }
        //}

        [HttpPost("reset.password")]
        public async Task<IActionResult> ResetPassword([FromBody] ResetPassword resetPassword)
        {
            var Result = _IUserRegistration.ResetPassword(resetPassword);
            ApiResponce apiResponce = new ApiResponce();
            if (Result.ToString() == "0")
            {
                apiResponce.Text = "fail";
            }
            else
            {
                apiResponce.Text = "success";
            }
            return Ok(apiResponce);
        }

        [Authorize]
        [HttpPost("reset.password.user")]
        public async Task<IActionResult> ResetPasswordUser([FromBody] ResetPasswordUser resetPassword)
        {
            ApiResponce apiResponce = new ApiResponce();

            ResetPassword RP = new ResetPassword();

            string Result = "0";
            var ud = _userDetails.GetUserUsersId(resetPassword.UsersId);


            if (ud.Count > 0)
            {
                //RegiModel Model = new RegiModel();
                //Model.EmailId = resetPassword.UsersId;


                var detail = ud.FirstOrDefault();
                //Model.FullName = detail.Name;
                //var dt = PostData(Model);
                var oldpassword = detail.Password;
                if (oldpassword != resetPassword.OldPassword)
                {
                    apiResponce.Text = "WrongPassword";
                }
                else if (resetPassword.OldPassword == resetPassword.NewPassword)
                {
                    apiResponce.Text = "SamePassword";
                }
                else
                {
                    RP.UsersId = Convert.ToString(detail.UsersId.Value);
                    RP.Password = resetPassword.NewPassword;
                    Result = _IUserRegistration.ResetPassword(RP);
                    if (Result.ToString() == "0")
                    {
                        apiResponce.Text = "fail";
                    }
                    else
                    {
                        apiResponce.Text = "PasswordUpdated";
                    }
                }
            }
            else
            {
                apiResponce.Text = "NoUser";
            }
            return Ok(apiResponce);
        }

        [HttpGet("email.forgot")]
        public ActionResult EmailForgotPassword([FromQuery] string emailid)
        {
            ApiResponce apiResponce = new ApiResponce();


            var Result = _IUserRegistration.EmailValidate(emailid);
            if (Result == "register" || Result == "unactivated")
            {
                CryptoService ENCry = new CryptoService();
                var users = _userDetails.GetUserUsersId(emailid);
                if (users.Count > 0)
                {
                    if (users.FirstOrDefault().AuthenticationType == "Internal")
                    {
                        RegiModel Model = new RegiModel();
                        Model.EmailId = emailid;
                        Model.FullName = users.FirstOrDefault().Name;
                        var data = PostData(Model);
                        apiResponce.Text = "MailSent";
                    }
                    else if(users.FirstOrDefault().AuthenticationType == "LinkedIN")
                    {
                        apiResponce.Text = "AuthenticationFromLinkedIN";
                    }
                    else
                    {
                        apiResponce.Text = "AuthenticationFromGoogle";
                    }
                    //_userDetails.ForgotUserPassword(users[0]);
                    //apiResponce.Text = "MailSent";
                }
            }
            else
                apiResponce.Text = Result;

            return Ok(apiResponce);
        }

        [HttpPost("reset.userpassword")]
        public async Task<IActionResult> PostData([FromBody] RegiModel UserRegistration)
        {
            ApiResponce apiResponce = new ApiResponce();
            string Result = _IUserRegistration.ResendUserForotLink(UserRegistration.EmailId);
            if (Result != "" && Result != "0")
            {
                string MailResult = _IUserRegistration.GenerateForgetTokenAndSendMail(Convert.ToInt32(Result), UserRegistration.EmailId, UserRegistration.FullName);
            }
            return Ok(apiResponce);
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] RegiModel UserRegistration)
        {

            ApiResponce apiResponce = new ApiResponce();
            string Result = "";

            if (UserRegistration.Resend)// if resenf true then send valiation link again
            {
                Result = _IUserRegistration.ResendUserActivationLink(UserRegistration);
            }
            else
            {
                Result = _IUserRegistration.InsertUserForActivation(UserRegistration);
            }

            if (Result != "" && Result != "0")
            {

                if (Result.ToLower() == "register")//email id allredy register
                {
                    apiResponce.Text = Result.ToLower();
                }
                else if (Result.ToLower() == "unactivated")//email id available in athetication table
                {
                    apiResponce.Text = Result.ToLower();
                }
                else
                {
                    string MailResult = _IUserRegistration.GenerateTokenAndSendMail(Convert.ToInt32(Result), UserRegistration.EmailId, UserRegistration.FullName);
                    if (MailResult == "")
                    {
                        apiResponce.Text = "success";
                    }
                    else
                    {
                        apiResponce.Text = "error";
                    }
                }

                return Ok(apiResponce);
            }
            else
            {
                apiResponce.Text = "error";
                return Ok(apiResponce);
            }

        }

        [Authorize]
        [HttpGet("decode")]
        public string Decode([FromQuery] string data)
        {
            string data1 = System.Web.HttpUtility.UrlDecode(data);
            CryptoService cryptoService = new CryptoService();
            string Result = cryptoService.Decrypt(data1.Replace(" ", "+"));
            return Result;
        }

        [Authorize]
        [HttpGet("encode")]
        public string Encode([FromQuery] string data)
        {

            CryptoService cryptoService = new CryptoService();
            string Result = cryptoService.Encrypt(data);
            //Result = System.Web.HttpUtility.HtmlEncode(Result);
            return Result;
        }

        [Authorize]
        [HttpPost("get.SendFreelancerRequest")]
        public ActionResult MailSendingToAdmin([FromBody] FreelancerRatingComment Data)
        {
            ApiResponce apiResponce = new ApiResponce();
            //CreateMailAndSend.FreelancerRequestDetailsOnMail(jobID, comment);
            _IFreelancer.FreelancerRequestDetailsOnMail(Data.JobID, Data.Comment);
            int cnt = _IUserRegistration.UpdateStatusOfRequestMail(Data.JobID, Data.Comment);
            if (cnt > 0)
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }

        [Authorize]
        [HttpPost("post.DeactiveFreelancer")]
        public object ActiveDeactiveFreelancer([FromBody] UserActiveDeactive Data)
        {
            string result = "";
            try
            {
                string role = Convert.ToString("" + Data.User_Role).ToUpper().Trim();
                if (Data.status == "Inactive")
                {
                    result = _IUserRegistration.ManageActiveDeactive(Data.status, Data.usersid, Data.CurrentUserId, Data.Comments);
                }
                else if (Data.status == "Active")
                {
                    result = _IUserRegistration.ManageActiveDeactive(Data.status, Data.usersid, Data.CurrentUserId);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        [Authorize]
        [HttpGet("get.f2auth")]
        public object F2Auth(string uid)
        {
            AuthModel Model = _IUserRegistration.GetAuth(uid);
            return Model;
        }

        [Authorize]
        [HttpPost("post.f2auth")]
        public ActionResult F2Auth([FromBody] AuthModel data)
        {
            ApiResponce apiResponce = new ApiResponce();
            int cnt = _IUserRegistration.UpdateAuth(data);
            if (cnt != 0)
            {
                apiResponce.Text = "Updated";
            }
            else
            {
                apiResponce.Text = "Error";
            }

            return Ok(apiResponce);
        }

        [HttpGet("send.OTP.Authentication")]
        public object SendOTPMail(string UsersId)
        {
            ApiResponce apiResponce = new ApiResponce();
            var OTPData = _IUserRegistration.OtpMailSend(UsersId);
            return OTPData;
        }

        [Authorize]
        [HttpPost("save.WorkAs")]
        public ActionResult SaveWorkAsDetails([FromBody] WorkAsSave saveWorkAsDetails)
        {
            CommonResult CommonResult = new CommonResult();
            try
            {
                if (_IUserRegistration.SaveWorkAsDetails(saveWorkAsDetails) > 0)
                {
                    CommonResult.Status = "success";
                    CommonResult.ErrorMessage = "";
                }
                else
                {
                    CommonResult.Status = "fail";
                    CommonResult.ErrorMessage = "Data not updated.";
                }
            }
            catch (Exception ex)
            {
                CommonResult.Status = "fail";
                CommonResult.ErrorMessage = ex.Message.ToString();
            }
            return Ok(CommonResult);
        }

        [HttpPost("insert.hirefreelancerexpertreq")]
        public async Task<IActionResult> InsertHireFreelancerExpertReq([FromForm] HireFreelancerExpertReq hireFreelancerExpertReq)
        {
            ApiResponce apiResponce = new ApiResponce();

            //string SampleFilePath = "";
            //string SamplePath = _Configuration["HireFreelancerExpertPath"];
            //if (!System.IO.Directory.Exists(SamplePath))
            //    System.IO.Directory.CreateDirectory(SamplePath);
            int pk_id = _IUserRegistration.InsertHireFreelancerExpertReq(hireFreelancerExpertReq);

            //if (hireFreelancerExpertReq.SampleFile != null)
            //{
            //    string SampleFileName = hireFreelancerExpertReq.SampleFile.FileName;
            //    string SampleFileFullPath = SamplePath + "\\" + pk_id;

            //    _userDetails.SaveFile(SampleFileFullPath, hireFreelancerExpertReq.SampleFile, SampleFileName);
            //    SampleFilePath = pk_id + "\\" + SampleFileName;
            //}

            if (pk_id != null && pk_id > 0)
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }

        [Authorize]
        [HttpPost("GenerateOTP")]
        public ActionResult GenerateOTP([FromBody] GenerateOtp generateOtp)
        {
            ApiResponce apiResponce = new ApiResponce();
            int cnt = _IUserRegistration.GenerateOTP(generateOtp);
            if (cnt != null && cnt != 0)
            {
                apiResponce.Text = cnt.ToString();
            }
            else
            {
                apiResponce.Text = "Error";
            }
            return Ok(apiResponce);
        }

        [Authorize]
        [HttpPost("ValidateOTP")]
        public ActionResult ValidateOTP([FromBody] GenerateOtp generateOtp)
        {
            ApiResponce apiResponce = new ApiResponce();
            bool result = _IUserRegistration.ValidateOTP(generateOtp);
            if (result)
            {
                apiResponce.Text = "true";
            }
            else
            {
                apiResponce.Text = "false";
            }

            return Ok(apiResponce);
        }

        [HttpPost("regenerate.token")]
        public async Task<IActionResult> RegenerateToken([FromBody] ClientLogin Client)
        {
            if (String.IsNullOrEmpty(Client.Token))
            {
                return BadRequest();
            }
            else
            {
                SwitchUser usr = new SwitchUser();
                usr.UserName = Client.UserName;
                usr.RoleId = Convert.ToInt32(Client.Client);
                UserStatus userStatus = _IUserRegistration.SwitchUser(usr);
                userStatus.componentPermissions = _userDetails.GetComponentPermission(userStatus.UsersId, usr.RoleId.GetValueOrDefault(), Convert.ToInt16(0 + userStatus.ClientsId));
                userStatus.TokenString = _auth.ReGenerateToken(Client.Token);
                return Ok(userStatus);
            }
        }

        [HttpGet("get.PDF")]
        public async Task<FileStreamResult> GetPDF(string File)
        {
            //FileInfo newFilepdf = new FileInfo(@"E:\Document\ES2\ESII.pdf");
            //var contentType = MimeMapping.MimeUtility.GetMimeMapping(Path.GetExtension(newFilepdf.FullName));
            //var stream = new FileStream(newFilepdf.FullName, FileMode.Open, FileAccess.Read);

            //var result = new FileStreamResult(stream, contentType);
            //// result.FileDownloadName = "1.pdf";
            //return result;
            var contentType = MimeMapping.MimeUtility.GetMimeMapping(Path.GetExtension(File));
            string filePath = "";

            filePath = CommonResource.ResumePath + "\\" + File;
            // string file = CommonResource.ContractPath + "\\" + File;
            var stream = new FileStream(filePath, FileMode.Open, FileAccess.Read);

            var result = new FileStreamResult(stream, contentType);
            // result.FileDownloadName = "1.pdf";
            return result;
        }
    }
}