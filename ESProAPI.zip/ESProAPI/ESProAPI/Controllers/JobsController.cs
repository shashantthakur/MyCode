﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class JobsController : Controller
    {
        public CommonFunctions commonFn = new CommonFunctions();
        private readonly IJobs _jobs;
        public JobsController(IJobs JOBS)
        {
            _jobs = JOBS;
        }


        [HttpPost("get.freelancerbyproject")]
        public object Freelancerbyproject([FromBody] FreelancerByProjectViewModel data)
        {
            var datas = _jobs.GetJobDetailsWithFileter(data.JobNo, data.ISBN, data.AuthorName, data.Title, data.SelectdLocation, data.SelectdSkill);

            List<JobModel> remodel = new List<JobModel>();
            foreach (var item in datas)
            {
                JobModel M = new JobModel();
                M = item;
                if (item.Customer.ToUpper().Trim() != data.TeamType.ToUpper().Trim() && data.CurrentUserRole == "CLIENT")
                {
                    M.JobNo = "REDACTED";
                    M.Author = "REDACTED";
                    M.Title = "REDACTED";
                    M.Unit = "REDACTED";
                    M.Budget_Currency = "REDACTED";
                    M.Contracted_Currency = "REDACTED";
                    M.Comments = "REDACTED";
                }

                remodel.Add(M);
            }
            datas = remodel;

            //foreach (var item in datas)
            //{
            //    string ClientSymbol = string.Empty;
            //    string ContrantSymbol = string.Empty;
            //    TryGetCurrencySymbol(item.Budget_Currency, out ClientSymbol);
            //    TryGetCurrencySymbol(item.Contracted_Currency, out ContrantSymbol);
            //    item.Contracted_Currency = string.Format("{0}{1}", ContrantSymbol, item.ContractedRate).ToString();
            //    item.Budget_Currency = string.Format("{0}{1}", ClientSymbol, item.ClientBudget);
            //}

            //if (!string.IsNullOrEmpty(data.sort))
            //{
            //    var param = data.sort;
            //    var propertyInfo = typeof(JobModel).GetProperty(param);
            //    if (data.dir == "desc")
            //    {
            //        datas = datas.OrderByDescending(x => propertyInfo.GetValue(x, null));
            //    }
            //    else
            //    {
            //        datas = datas.OrderBy(x => propertyInfo.GetValue(x, null));
            //    }
            //}

            //var subdata = CommonResource.SplitList(datas.ToList(), data.pageSize);
            //var response = new
            //{
            //    Lastpage = subdata.Count(),
            //    data = subdata.Count() > 0 ? subdata.ElementAt(data.currentpage) : datas,
            //    TotalRecords = datas.Count()
            //};
            //return response;

            var response = commonFn.TableResponce(datas, data.sort, data.dir, data.currentpage, data.pageSize);

            var finalresponse = new
            {
                response = response
            };

            return finalresponse;
        }


        //[HttpGet("get.getqaresult")]
        //public object GetQAResultTableTest(int Userid, string FromWhere, string sort, string dir, int currentpage, int pageSize)
        //{
        [HttpPost("get.getqaresult")]
        public object GetQAResultTableTest([FromBody] JobHistoryParameter Data)
        {
            //var orderByAddress = items.OrderBy(x => propertyInfo.GetValue(x, null));
            List<JobSummaryModel> Model = new List<JobSummaryModel>();
            Model = _jobs.getFreelancerDetails(Data.Userid, Data.FromWhere).ToList();

            var data = Model.GroupBy(a => new
            {
                a.JobNo,
                a.Customer,
                a.AgencyName,
                a.FreelancerName,
                a.PMName,
                a.InvApproverName,
                a.InvApproverName2,
                a.ISBN13,
                a.Author,
                a.Title,
                a.Skill,
                a.user_status,
                //a.StartDate,
                //a.EndDate,
                a.Edition
            }).Select(b => new JobViewMode
            {
                JobNo = b.Key.JobNo,
                Client = b.Key.Customer,
                AgencyName = b.Key.AgencyName,
                FreelancerName = b.Key.FreelancerName,
                ProjectManager = b.Key.PMName,
                InvApproverName = b.Key.InvApproverName,
                InvApproverName2 = b.Key.InvApproverName2,
                ISBN13 = b.Key.ISBN13,
                Author = b.Key.Author,
                Title = b.Key.Title,
                Skill = b.Key.Skill,
                user_status = b.Key.user_status,
                //StartDate = b.Key.StartDate,
                //EndDate = b.Key.EndDate,
                Edition = b.Key.Edition,
                isExpanded = false,
                inData = b.Select(c => new inData
                {
                    FreelancerEmailID = c.FreelancerEmailID,
                    JobPM = c.JobPM,
                    InvApproverEmail = c.InvApproverEmail,
                    InvApproverEmail2 = c.InvApproverEmail2,
                    StartDate = c.StartDate,
                    EndDate = c.EndDate,
                    unit = c.Units,
                    Rate = c.Rate,
                    Note = c.Notes,
                    currency = c.Currency
                }).Distinct().ToList()
            });

            List<JobViewMode> remodel = new List<JobViewMode>();

            foreach (var item in data)
            {
                JobViewMode M = new JobViewMode();
                M = item;
                if (item.Client.ToUpper().Trim() != Data.TeamType.ToUpper().Trim() && Data.CurrentUserRole == "CLIENT")
                {
                    M.JobNo = "REDACTED";
                    M.Client = "REDACTED";
                    M.Author = "REDACTED";
                    M.Title = "REDACTED";
                    M.Edition = "REDACTED";
                    M.ProjectManager = "REDACTED";
                    M.InvApproverName = "REDACTED";
                    M.InvApproverName2 = "REDACTED";
                    M.ISBN13 = "REDACTED";
                    foreach (var a in M.inData)
                    {
                        a.JobPM = "REDACTED";
                        a.InvApproverEmail = "REDACTED";
                        a.InvApproverEmail2 = "REDACTED";
                        a.unit = "REDACTED";
                        a.currency = "REDACTED";
                        a.Rate = "REDACTED";
                        a.Note = "REDACTED";
                    }
                }
                remodel.Add(M);

                //if (string.IsNullOrEmpty(item.StartDate))
                //    item.StartDate = string.Empty;
                //if (string.IsNullOrEmpty(item.EndDate))
                //    item.EndDate = string.Empty;
                //if (!string.IsNullOrEmpty(item.StartDate))
                //{
                //    item.StartDate = Convert.ToDateTime(item.StartDate).Date.ToString("dd-MMM-yyyy");
                //}
                //if (!string.IsNullOrEmpty(item.EndDate))
                //{
                //    item.EndDate = Convert.ToDateTime(item.EndDate).Date.ToString("dd-MMM-yyyy");
                //}
            }

            var Results = commonFn.TableResponce(remodel, Data.sort, Data.dir, Data.currentpage, Data.pageSize);
            return Results;
        }

        [HttpPost("GetJobSearch")]
        public object GetJobSearch(JobSearchParameters data)
        {
            IEnumerable<JobSearchModel> _jobSearches = _jobs.GetJobSearch(data.SearchField,data.SearchText);

            CommonFunctions commonFunctions = new CommonFunctions();
            var response = commonFunctions.TableResponce(_jobSearches, data.sort, data.dir, data.currentpage, data.pageSize);

            var finalresponse = new
            {
               
                response = response
            };          

            return finalresponse;
        }
        
    }
}