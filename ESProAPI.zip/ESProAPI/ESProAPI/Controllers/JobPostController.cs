﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ESPro.Core.Entity;
using ESPro.Core.Entity.JobPost;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using ESPro.Infrastructure.Service;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class JobPostController : ControllerBase
    {
        private readonly IJobPost _jobPost;
        private readonly IInvoice _invoice;
        private readonly ITrainingMaterial _trainingMaterial;
        public CommonFunctions commonFn = new CommonFunctions();

        public JobPostController(IJobPost jobPost, IInvoice invoice, ITrainingMaterial trainingMaterial)
        {
            _jobPost = jobPost;
            _invoice = invoice;
            _trainingMaterial = trainingMaterial;
        }

        [HttpPost("insert.update.JobPostInfo")]
        public ActionResult SaveJobPostInfo([FromBody] JobPost jobPost)
        {
            ApiResponce apiResponce = new ApiResponce();
            if (_jobPost.SaveJobPostInfo(jobPost) > 0)
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }

        [HttpPost("MarkAsRepliedUsersJobPostMail")]
        public ActionResult MarkAsRepliedUsersJobPostMail([FromBody] JobPostUserInfo jobPost)
        {
            ApiResponce apiResponce = new ApiResponce();
            if (_jobPost.MarkAsRepliedUsersJobPostMail(jobPost) > 0)
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }

        [HttpPost("JobPostSendMail")]
        public ActionResult JobPostSendMail([FromBody] JobPost jobPost)
        {
            CommonResult commonResult = new CommonResult();
            try
            {
                InsertLikeDislikeFlagCountParameters datas = new InsertLikeDislikeFlagCountParameters();
                datas.TrainingDetailsId = jobPost.Id;
                datas.UserID = jobPost.InsertedBy;
                datas.LikeDislikeFlag = "Mail";
                datas.Type = "PostJob";
                int TrainingLikeDisLikeFlagDetailsId = _trainingMaterial.InsertLikeDislikeFlagCount(datas);
                jobPost.TrainingLikeDisLikeFlagDetailsId = TrainingLikeDisLikeFlagDetailsId;
                if (TrainingLikeDisLikeFlagDetailsId > 0)
                {
                    
                    if (_jobPost.SaveJobPostUsersInfo(jobPost) > 0)
                    {
                        var SendMailTo = _invoice.GetSendMailDetails("JobPost").ToList();
                        string TemplateName = "FLJobPost.html";
                        string MailSubject = "ESPro: Job Post Mail: " + jobPost.Title;
                        string ToMail = jobPost.InsertedEmailId;
                        string CCMail = jobPost.FreelancerEmailId;
                        string BCCMail = SendMailTo[0].BCCMailList;
                        StringBuilder sbMailBody = new StringBuilder(System.IO.File.ReadAllText(Path.Combine(CommonResource.MailTemplatePath, TemplateName)));
                        sbMailBody.Replace("[Client]", jobPost.InsertedFullName);
                        sbMailBody.Replace("[Description]", jobPost.Description);
                        sbMailBody.Replace("[MoreInfo]", jobPost.MoreInfo);
                        sbMailBody.Replace("[Url]", jobPost.Url);
                        sbMailBody.Replace("[Title]", jobPost.Title);
                        sbMailBody.Replace("[LogninLink]", CommonResource.UiUrl);
                        sbMailBody.Replace("[Regards]", "Expert Source Mailer");
                        MailService objMail = new MailService();
                        objMail.SendMail(sbMailBody.ToString(), MailSubject, ToMail, CCMail, BCCMail);
                        commonResult.Status = "success";
                        commonResult.ErrorMessage = "Job Post mail sent successfully to client";
                    }
                    else
                    {
                        commonResult.Status = "fail";
                        commonResult.ErrorMessage = "Data not updated.";
                    }
                }
                else
                {
                    commonResult.Status = "fail";
                }
            }
            catch (Exception ex)
            {
                commonResult.Status = "fail";
                commonResult.ErrorMessage = ex.Message.ToString();
            }
            return Ok(commonResult);
        }

        [HttpGet("get.JobPostedBy")]
        public List<UserMaster> GetJobPostedBy()
        {
            return _jobPost.GetJobPostedBy();
        }

        [HttpPost("get.GetNewJobPostCountFromLastLogin")]
        public object GetNewJobPostCountFromLastLogin([FromBody] SearchJobPostParameters datas)
        {
            List<JobPost> lstJobPost = _jobPost.GetPostJobList(datas);
            return lstJobPost.Count;
        }

        [HttpPost("get.PostJobList")]
        public object GetPostJobList([FromBody] SearchJobPostParameters datas)
        {
            List<JobPost> lstJobPost = _jobPost.GetPostJobList(datas);
            //return lstJobPost;
            var response = commonFn.TableResponce(lstJobPost, datas.sort, datas.dir, datas.currentpage, datas.pageSize);
            var data = new
            {
                response = response
            };
            return data;
        }

        [HttpPost("get.PostJobUsersInfo")]
        public object GetPostJobUsersInfoList([FromBody] SearchJobPostParameters datas)
        {
            List<JobPostUserInfo> lstJobPostUserInfo = _jobPost.GetPostJobUsersInfoList(datas);
            var response = commonFn.TableResponce(lstJobPostUserInfo, datas.sort, datas.dir, datas.currentpage, datas.pageSize);
            var finalresponse = new
            {
                response = response
            };
            return finalresponse;
        }

    }
}