﻿using ESPro.Core.Entity;
using ESPro.Core.Entity.Invoice;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml.Style;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class BankInfoController : ControllerBase
    {

        private readonly IBankInfo _bankInfo;
      
        public BankInfoController(IBankInfo bankInfo)
        {
            _bankInfo = bankInfo;
          
        }
        // GET: api/<BankInfoController>
        [HttpPost("GetFreelancerBankDashboard")]
        public object GetFreelancerBankDashboard(FreelancerBankDashboardParameters data)
        {           
            IEnumerable<FreelancerBankDashboard> _freelancerBankDashboard = _bankInfo.GetFreelancerBankDashboard(data.UsersID.Value); ;
            CommonFunctions commonFunctions = new CommonFunctions();
            var response = commonFunctions.TableResponce(_freelancerBankDashboard, data.sort, data.dir, data.currentpage, data.pageSize);
            var finalresponse = new
            {
                response = response
            };
            return finalresponse;
        }

        [HttpPost("get.freelancer.BankingInfo")]
        public BankInfo GetFreelancerBankingInfo(BankingInfoParam bankingInfoParam)
        {
            return _bankInfo.GetFreelancerBankingInfo(bankingInfoParam.UsersID.Value, bankingInfoParam.FLBankInfoId.Value);
        }

        [HttpGet("get.freelancer.AllBankingInfo/{UserID}")]
        public IEnumerable<BankInfo> GetFreelancerAllBankingInfo(int UserID)
        {
            return _bankInfo.GetFreelancerAllBankingInfo(UserID);
        }
        [HttpPost("get.freelancers.account.detailsforAP")]
        public object GetFreelancersAccountDetailsForAP([FromBody] SearchFreelancerAccountParameters datas)
        {
            List<FreelancerBankDetails> lstFreelancerBankDetails = new List<FreelancerBankDetails>();
            lstFreelancerBankDetails = _bankInfo.GetFreelancersAccountDetails(datas.UserIDs, datas.FLBankInfoIds);
            return lstFreelancerBankDetails;
        }
        [HttpPost("insert.update.BankingInfo")]
        public async Task<IActionResult> InsertUpdateBankingInfo([FromBody] BankInfo bankInfo)
        {
            ApiResponce apiResponce = new ApiResponce();
            apiResponce.Text = _bankInfo.InsertUpdateBankingInfo(bankInfo);

            return Ok(apiResponce);
        }

        [HttpPost("DeleteFreelancerBankInfo")]
        public async Task<IActionResult> DeleteFreelancerBankInfo([FromBody] SearchFreelancerInvoices datas)
        {
            CommonResult CommonResult = new CommonResult();
            List<Invoice> lstInvoices = new List<Invoice>();
            lstInvoices = _bankInfo.GetInvoicesList(datas);
            if (lstInvoices.Count() == 0)
            {
                int cnt = _bankInfo.DeleteFreelancerBankInfo(Convert.ToInt16(datas.FLBankInfoId));
                if (cnt > 0)
                {
                    CommonResult.Status = "success";
                    CommonResult.ErrorMessage = "Bank Account deleted successfully";
                }
                else
                {
                    CommonResult.Status = "fail";
                    CommonResult.ErrorMessage = "Error: Something went wrong. Account not deleted, please try again after some time";
                }
            }
            else
            {
                CommonResult.Status = "fail";
                CommonResult.ErrorMessage = "Error: Invoices are in approval stage. You can not delete this bank account now.";
            }
            return Ok(CommonResult);
        }

        //[HttpGet("SetDefaultFreelancerBankInfo/{FLBankInfoId}")]
        //public async Task<IActionResult> SetDefaultFreelancerBankInfo(int FLBankInfoId)
        //{
        //    ApiResponce apiResponce = new ApiResponce();
        //    int cnt = _bankInfo.SetDefaultFreelancerBankInfo(FLBankInfoId);
        //    if (cnt > 0)
        //    {
        //        apiResponce.Text = "success";
        //    }
        //    else
        //    {
        //        apiResponce.Text = "fail";
        //    }


        //    return Ok(apiResponce);
        //}


        [HttpPost("get.freelancers.account.details")]
        public object GetFreelancersAccountDetails([FromBody] SearchFreelancerAccountParameters datas)
        {
            List<FreelancerBankDetails> lstFreelancerBankDetails = new List<FreelancerBankDetails>();
            lstFreelancerBankDetails = _bankInfo.GetFreelancersAccountDetails(datas.UserIDs, datas.FLBankInfoIds);
            var response = MakingInnerBankData(datas, lstFreelancerBankDetails);
            return response;
        }

        [HttpPost("MakingInnerBankData")]
        public object MakingInnerBankData(SearchFreelancerAccountParameters datas, List<FreelancerBankDetails> lstFreelancerBankDetails)
        {
            var data = lstFreelancerBankDetails.GroupBy(a => new
            {
                a.select,
                a.UsersID,
                a.FreelancerName,
                a.Currency,
                a.WireFee,
                a.BeneficiaryType,
                a.FLEsproCode,
                a.BankCountry,
                a.RoutingID,
                a.SwiftCode,
                a.IBANNumber,
                a.BankName,
                a.BankAddress,
                a.AccountNumber,
                a.AccountName,
                a.TaxID
            }).Select(b => new FreelancerBankDetails
            {
                select = b.Key.select,
                UsersID = b.Key.UsersID,
                FreelancerName = b.Key.FreelancerName,
                Currency = b.Key.Currency,
                WireFee = b.Key.WireFee,
                BeneficiaryType = b.Key.BeneficiaryType,
                FLEsproCode = b.Key.FLEsproCode,
                BankCountry = b.Key.BankCountry,
                RoutingID = b.Key.RoutingID,
                SwiftCode = b.Key.SwiftCode,
                IBANNumber = b.Key.IBANNumber,
                BankName = b.Key.BankName,
                BankAddress = b.Key.BankAddress,
                AccountNumber = b.Key.AccountNumber,
                AccountName = b.Key.AccountName,
                isExpanded = false,
                freelancerBankInfoInnerData = b.Select(c => new FreelancerBankInfoInnerData
                {
                    EmailID = c.EmailID,
                    HomeAddress = c.HomeAddress,
                    ContactNumber = c.ContactNumber,
                    AlternateContactNumber = c.AlternateContactNumber
                }).Distinct().ToList()
            }); ;


            List<string> Freelancers = data.Select(a => a.FreelancerName).Distinct().ToList();
            if (datas.FreelancerFilter != null)
            {
                if (!(datas.FreelancerFilter.Count == 1 && datas.FreelancerFilter.Where(a => a == "0").Count() > 0))
                    data = data.Where(a => datas.FreelancerFilter.Where(b => a.FreelancerName == b).Count() > 0).ToList();
            }
            CommonFunctions commonFn = new CommonFunctions();
        var response = commonFn.TableResponce(data, datas.sort, datas.dir, datas.currentpage, datas.pageSize);

            var finalresponse = new
            {
                Freelancers = Freelancers,
                response = response
            };

            return finalresponse;

            //List<string> Freelancers = lstFreelancerBankDetails.Select(a => a.FreelancerName).Distinct().ToList();
            //if (!(datas.FreelancerFilter.Count == 1 && datas.FreelancerFilter.Where(a => a == "0").Count() > 0))
            //    lstFreelancerBankDetails = lstFreelancerBankDetails.Where(a => datas.FreelancerFilter.Where(b => a.FreelancerName == b).Count() > 0).ToList();
            //var response = commonFn.TableResponce(lstFreelancerBankDetails, datas.sort, datas.dir, datas.currentpage, datas.pageSize);
            //var finalresponse = new
            //{
            //    Freelancers = Freelancers,
            //    response = response
            //};
            //return finalresponse;
        }

        [HttpPost("export.freelancers.account.details")]
        public IActionResult ExportFreelancersAccountDetails([FromBody] SearchFreelancerAccountParameters datas)
        {
             CommonFunctions commonFn = new CommonFunctions();
            List<FreelancerBankDetails> lstFreelancerBankDetails = new List<FreelancerBankDetails>();
            lstFreelancerBankDetails = _bankInfo.GetFreelancersAccountDetails(datas.UserIDs, datas.FLBankInfoIds);
            DataTable dtToExport = commonFn.ToDataTable(lstFreelancerBankDetails);
            dtToExport.Columns.Remove("UsersID");
            dtToExport.Columns.Remove("select");
            dtToExport.Columns.Remove("isExpanded");
            dtToExport.Columns.Remove("isVisible");
            dtToExport.Columns.Remove("Street1");
            dtToExport.Columns.Remove("City1");
            dtToExport.Columns.Remove("PostalCode1");
            dtToExport.Columns.Remove("State1");
            dtToExport.Columns.Remove("LocationsId1");
            dtToExport.AcceptChanges();
            string TemplateFile = "";
            string path = "";
            TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "BankAccountDetails.xlsx");
            try
            {
                using (var pck = new OfficeOpenXml.ExcelPackage())
                {
                    using (var stream = System.IO.File.OpenRead(TemplateFile))
                    {
                        pck.Load(stream);
                    }

                    string ToRows = "", FromRows = "", modelRange = "";

                    FromRows = "A2";
                    ToRows = "S";
                    var ws = pck.Workbook.Worksheets[1];
                    ws.Cells[FromRows].LoadFromDataTable(dtToExport, false);

                    var modelCells = ws.Cells[FromRows];
                    var modelRows = dtToExport.Rows.Count + 1;
                    modelRange = FromRows + ":" + ToRows.ToString() + modelRows.ToString();
                    ws.Cells[FromRows + ":" + ToRows.ToString() + modelRows.ToString()].Style.Font.SetFromFont(new Font("Calibri", 10));
                    var modelTable = ws.Cells[modelRange];
                    // Assign borders
                    modelTable.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    modelTable.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    modelTable.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    modelTable.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                    byte[] data = pck.GetAsByteArray();
                    return Ok(new { data, contenttype = "application/octet-stream", filename = "BankAccountDetails_" + DateTime.Now.ToString("ddMMyyyyHHmmss") + ".xlsx" });
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }



    }
}
