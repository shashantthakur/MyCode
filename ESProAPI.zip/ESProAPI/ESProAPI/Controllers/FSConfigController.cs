﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class FSConfigController : ControllerBase
    {
        private readonly IFSConfig _fsConfig;

        public FSConfigController(IFSConfig FSConfig)
        {
            _fsConfig = FSConfig;
        }

        //[HttpGet("get.fsconfig")]
        //public object GetFSConfig()
        //{
        //    return _fsConfig.GetFSConfig();
        //}

        [HttpGet("get.fsconfig")]
        public object GetFSConfig(int UsersId, string sort, string dir, int currentpage, int pageSize)
        {
            List<FSConfig> Model = new List<FSConfig>();
            Model = _fsConfig.GetFSConfig().ToList();

            var data = Model.GroupBy(a => new
            {
                a.ConfigId,
                a.Field,
                a.Discrepancy,
                a.Weightage

            }).Select(b => new FSConfig
            {
                ConfigId = b.Key.ConfigId,
                Field = b.Key.Field,
                Discrepancy = b.Key.Discrepancy,
                Weightage = b.Key.Weightage
            });

            if (!string.IsNullOrEmpty(sort))
            {
                var param = sort;
                var propertyInfo = typeof(FSConfig).GetProperty(param);
                if (dir == "desc")
                {
                    data = data.OrderByDescending(x => propertyInfo.GetValue(x, null));
                }
                else
                {
                    data = data.OrderBy(x => propertyInfo.GetValue(x, null));
                }
            }
            CommonFunctions commonFunctions = new CommonFunctions();
            var subdata = commonFunctions.SplitList(data.ToList(), pageSize);
            var response = new
            {
                Lastpage = subdata.Count(),
                data = (subdata == null || subdata.Count() == 0) ? data : subdata.ElementAt(currentpage),
                TotalRecords = data.Count()
            };

            return response;
        }

        [HttpPost("update.fsconfig")]
        public ActionResult UpdateEmailId([FromBody] FSConfig saveFSConfig)
        {
            ApiResponce apiResponce = new ApiResponce();

            if (_fsConfig.UpdateFSConfig(saveFSConfig) > 0)
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }
    }
}