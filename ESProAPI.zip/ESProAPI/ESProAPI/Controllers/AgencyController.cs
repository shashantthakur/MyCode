﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using ESPro.Infrastructure.Service;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ESProAPI.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AgencyController : Controller
    {
        private readonly IInvoice _invoice;
        private readonly IAgency _agency;
        //public IConfiguration _Configuration { get; }
        public AgencyController(IAgency AGENCIES, IInvoice invoice)
        {
            _agency = AGENCIES;
            _invoice = invoice;
        }


        [HttpGet("get.allagencies")]
        public object GetAllAgencies()
        {
            object agenciesModels = _agency.GetAgencies().Select(a => new { AgencyID = a.AgencyId, AgencyNames = a.AgencyNames });
            return agenciesModels;

        }


        [HttpGet("get.allagenciesdetails/{Agencyid}")]
        public List<AgencyViewModel> allagenciesdetails(int Agencyid)
        {
            IEnumerable<AgenciesDetailsModel> result = _agency.GetAgenciesDetaiils(Agencyid);
            List<AgencyViewModel> ResultModel = new List<AgencyViewModel>();
            if (result.Count() > 0)
            {
                ResultModel = result.GroupBy(a => new { a.AgencyID, a.AgencyName, a.URL, a.Address, a.AgencyExclusiveID }).Select(b => new
                {
                    Address = b.Key.Address,
                    AgencyId = b.Key.AgencyID,
                    AgencyNames = b.Key.AgencyName,
                    URL = b.Key.URL,
                    AgencyExclusiveID = b.Key.AgencyExclusiveID,
                    data = b
                }).Select(c => new AgencyViewModel
                {
                    AgencyId = c.AgencyId,
                    Address = c.Address,
                    AgencyNames = c.AgencyNames,
                    URL = c.URL,
                    AgencyExclusiveID = c.AgencyExclusiveID,
                    _agencydetails = c.data.Select(d => new AgenciesUserDetailsModel
                    {
                        AgencyUserInfoID = d.AgencyUserInfoID,
                        AgencyUserName = d.AgencyUserName,
                        ContactNumber = d.ContactNumber,
                        Fax = d.Fax,
                        skypeid = d.skypeid,
                        EmailId = d.EmailId
                    }
                    ).ToList()
                }).ToList();

            }
            return ResultModel;

        }


        [HttpGet("get.agencydetailsbyUser/{Userid}")]
        public List<AgencyViewModel> agencydetailsbyUser(int Userid)
        {
            IEnumerable<AgenciesDetailsModel> result = _agency.GetUsersAgenciesDetaiils(Userid);
            List<AgencyViewModel> ResultModel = new List<AgencyViewModel>();
            if (result.Count() > 0)
            {
                ResultModel = result.GroupBy(a => new { a.AgencyID, a.AgencyName, a.URL, a.Address, a.AgencyExclusiveID }).Select(b => new
                {
                    Address = b.Key.Address,
                    AgencyId = b.Key.AgencyID,
                    AgencyNames = b.Key.AgencyName,
                    URL = b.Key.URL,
                    AgencyExclusiveID = b.Key.AgencyExclusiveID,
                    data = b
                }).Select(c => new AgencyViewModel
                {
                    AgencyId = c.AgencyId,
                    Address = c.Address,
                    AgencyNames = c.AgencyNames,
                    URL = c.URL,
                    AgencyExclusiveID = c.AgencyExclusiveID,
                    _agencydetails = c.data.Select(d => new AgenciesUserDetailsModel
                    {
                        AgencyUserInfoID = d.AgencyUserInfoID,
                        AgencyUserName = d.AgencyUserName,
                        ContactNumber = d.ContactNumber,
                        Fax = d.Fax,
                        skypeid = d.skypeid,
                        EmailId = d.EmailId
                    }
                    ).ToList()
                }).ToList();

            }
            return ResultModel;

        }


        [HttpPost("add.agenciesdetails")]
        public ActionResult Addagenciesdetails([FromBody] AgencyViewModel agencies)
        {
            ApiResponce apiResponce = new ApiResponce();
            agencies.AgencyId = agencies.AgencyId == 999999 ? 0 : agencies.AgencyId;
            if (_agency.InsertAgency(agencies))
            {
                if (agencies.AgencyId == 0)
                {
                    var SendMailTo = _invoice.GetSendMailDetails("NewAgencyCreated").ToList();
                    string ToMail = SendMailTo[0].ToMailList;
                    string CCMail = SendMailTo[0].CCMailList + "; " + agencies.FreelancerEmailID;
                    string BCCMail = SendMailTo[0].BCCMailList;
                    StringBuilder sbMailBody = new StringBuilder(System.IO.File.ReadAllText(Path.Combine(CommonResource.MailTemplatePath, "NewAgencyMail.html")));
                    sbMailBody.Replace("[FreelancerName]", agencies.FreelancerName);
                    sbMailBody.Replace("[AgencyName]", agencies.AgencyNames);
                    sbMailBody.Replace("[AgreementExclusive]", agencies.AgencyExclusiveID == true ? "Yes" : "No");
                    sbMailBody.Replace("[WebisteURL]", agencies.URL);
                    sbMailBody.Replace("[AgencyAddress]", agencies.Address);
                    if (agencies._agencydetails.Count() == 0)
                        sbMailBody.Replace("[TableData]<br /><br />", "");
                    else
                    {
                        string TableData = "";
                        TableData += "<table border=1><tr><th>Customer Name</th><th>Email ID</th><th>Skype ID</th><th>Customer Number</th><th>FAX</th></tr>";
                        for (int i = 0; i < agencies._agencydetails.Count(); i++)
                        {
                            TableData += "<tr>";
                            TableData += "<td>" + agencies._agencydetails[i].AgencyUserName + "</td>";
                            TableData += "<td>" + agencies._agencydetails[i].EmailId + "</td>";
                            TableData += "<td>" + agencies._agencydetails[i].skypeid + "</td>";
                            TableData += "<td>" + agencies._agencydetails[i].ContactNumber + "</td>";
                            TableData += "<td>" + agencies._agencydetails[i].Fax + "</td>";
                            TableData += "</tr>";
                        }
                        TableData += "</table>";
                        sbMailBody.Replace("[TableData]", TableData);
                    }
                    sbMailBody.Replace("[Regards]", CommonResource.MailRegards);
                    MailService objMail = new MailService();
                    objMail.SendMail(sbMailBody.ToString(), "EsPro: New Agency Created: " + agencies.AgencyNames, ToMail, CCMail, BCCMail);
                }
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }
    }
}