﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
 
    public class authController : ControllerBase
    {

        private readonly IAuth _auth;

        public authController(IAuth iauth)
        {
            _auth = iauth;
        }

       
        // POST: api/auth
        //[HttpPost("get.token")]
        //public async Task<IActionResult> GetToken([FromBody] UserStatus userStatus)
        //{
        //    string TokenString = _auth.GenerateToken(userStatus);
        //    if (String.IsNullOrEmpty(TokenString))
        //    {
        //        return BadRequest();
        //    }
        //    else
        //    {
        //        userStatus.TokenString = TokenString;
        //        return Ok(userStatus);
        //    }
        //}

        [HttpPost("generate.token")]
        public async Task<IActionResult> GenerateToken([FromBody] ClientLogin clientLogin)
        {
            ApiResponce apiResponce = new ApiResponce();
            var client = Request.Headers["Client"].ToString();
            
            if (String.IsNullOrEmpty(client) || String.IsNullOrEmpty(clientLogin.UserName) || String.IsNullOrEmpty(clientLogin.Password))
            {
                return BadRequest();
            }
            else
            {
                clientLogin.Client = client;
                ClientLogin _clientLogin = _auth.ApiClientLogin(clientLogin);
                if(_clientLogin==null || String.IsNullOrEmpty(_clientLogin.UserName))
                {
                    return Unauthorized();
             
                }
                else
                {
                    UserStatus userStatus = new UserStatus();
                    userStatus.UsersId = _clientLogin.Id.Value;
                    userStatus.UserName = _clientLogin.UserName;
                   apiResponce.Text= _auth.GenerateToken(userStatus);
                }
             
                return Ok(apiResponce);
            }
        }
        [HttpPost("validate.token")]
        public async Task<IActionResult> ValidateToken([FromBody] ClientLogin clientLogin)
        {
            ApiResponce apiResponce = new ApiResponce();
           

            if (String.IsNullOrEmpty(clientLogin.Token))
            {
                return BadRequest();
            }
            else
            {
                
                Boolean flag = _auth.ValidateToken(clientLogin.Token);
                apiResponce.Text = flag.ToString();
                return Ok(apiResponce);
            }
        }

    }
}
