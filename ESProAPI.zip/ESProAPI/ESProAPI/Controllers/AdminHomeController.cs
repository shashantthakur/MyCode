﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ESPro.Core.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AdminHomeController : Controller
    {
        private readonly IAdminHome _adminHome;
        //public IConfiguration _Configuration { get; }
        public AdminHomeController(IAdminHome AdminHome)
        {
            _adminHome = AdminHome;
        }


        [HttpGet("get.adminhome")]
        public object GetAdminHome()
        {
            return _adminHome.GetAdminHome();   
            //.Select(a => new { AgencyID = a.AgencyId, AgencyNames = a.AgencyNames });

        }
    }
}