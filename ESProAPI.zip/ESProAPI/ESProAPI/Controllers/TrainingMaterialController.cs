﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class TrainingMaterialController : ControllerBase
    {
        private readonly ITrainingMaterial _trainingMaterial ;

        public TrainingMaterialController(ITrainingMaterial trainingMaterial)
        {
            _trainingMaterial = trainingMaterial;
        }

        [HttpGet("get.TrainingMaterialForExtendedSearch")]
        public List<SearchTrainingDetails> GetTrainingMaterialListForExtendedSearch(int RoleId, int ClientId)
        {
            return _trainingMaterial.GetTrainingMaterialListForExtendedSearch(RoleId, ClientId);
        }

        [HttpGet("get.TrainingMaterial")]
        public List<TrainingMaterialList> GetTrainingMaterialList(int RoleId, int ClientId,int MenuId)
        {           
            return _trainingMaterial.GetTrainingMaterialList(RoleId, ClientId, MenuId);
        }

        [HttpGet("get.TrainingMaterialMenu")]
        public List<TrainingMaterialMenu> GetTrainingMaterialMenu(int RoleId, int ClientId)
        {

            return _trainingMaterial.GetTrainingMaterialMenu(RoleId, ClientId);
        }

        [HttpGet("get.TrainingMaterialMenuUnit")]
        public List<TrainingMaterialMenu> GetTrainingMaterialMenuUnit(int RoleId, int ClientId, int MenuId)
        {
            return _trainingMaterial.GetTrainingMaterialDetailsMenu(RoleId, ClientId, MenuId);
        }

        [HttpGet("get.video.description")]
        public List<TrainingVideoDescription> GetTrainingVideoDescription(int SubId, int Seconds)
        {
            return _trainingMaterial.GetTrainingVideoDescription(SubId, Seconds);
        }

        [HttpGet("get.TrsanScriptText")]
        public List<VTT_TranScript> GetTrsanScriptText(string vttPath)
        {
            return _trainingMaterial.GetTrsanScriptText(vttPath);
        }

        [HttpPost("update.views")]
        public ActionResult UpdateTrainingViews([FromBody] UpdateTrainingViewsCount updateTrainingViewsCount)
        {
            CommonResult commonResult = new CommonResult();
            try
            {
                if (_trainingMaterial.UpdateTrainingViews(updateTrainingViewsCount) > 0)
                {
                    commonResult.Status = "success";
                    commonResult.ErrorMessage = "";
                }
                else
                {
                    commonResult.Status = "fail";
                    commonResult.ErrorMessage = "Data not updated.";
                }
            }
            catch (Exception ex)
            {
                commonResult.Status = "fail";
                commonResult.ErrorMessage = ex.Message.ToString();
            }
            return Ok(commonResult);
        }

        [HttpPost("insert.likedislikeflagcount")]
        public IActionResult InsertLikeDislikeFlagCount([FromBody] InsertLikeDislikeFlagCountParameters datas)
        {
            CommonResult commonResult = new CommonResult();
            try
            {
                if (_trainingMaterial.InsertLikeDislikeFlagCount(datas) > 0)
                {
                    commonResult.Status = "success";
                    commonResult.ErrorMessage = "";
                }
                else
                {
                    commonResult.Status = "fail";
                    commonResult.ErrorMessage = "Data not updated.";
                }
            }
            catch (Exception ex)
            {
                commonResult.Status = "fail";
                commonResult.ErrorMessage = ex.Message.ToString();
            }
            return Ok(commonResult);
        }

        [HttpPost("get.likedislikeflagcount")]
        public LikeDislikeFlagCount GetInsertLikeDislikeFlagCount([FromBody] InsertLikeDislikeFlagCountParameters datas)
        {
            return _trainingMaterial.GetInsertLikeDislikeFlagCount(datas);
        }
    }
}
