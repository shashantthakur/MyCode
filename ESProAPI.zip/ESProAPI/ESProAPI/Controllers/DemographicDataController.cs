﻿using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class DemographicDataController : ControllerBase
    {
        private readonly IDemographicData _IDemographicData;
        public DemographicDataController(IDemographicData iDemographicData)
        {
            _IDemographicData = iDemographicData;        
        }


        [HttpGet("getMasterDemographicData")]
        public async Task<ActionResult> getMasterDemographicData()
        {
            var Responce = _IDemographicData.GetDemographicDataMaster();
            return Ok(Responce.Result);
        }

        [HttpPost("update.demographicData")]
        public async Task<IActionResult> UpdateDemographicData([FromBody] UserDemographicData userData)
        {
            ApiResponce apiResponce = new ApiResponce();
            int cnt = _IDemographicData.UpdateDemographicData(userData);
            if (cnt != null && cnt > 0)
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }


        [HttpGet("get.UserDemographicData/{UsersId}")]
        public UserDemographicData GetUserDemographicData(int UsersId)
        {
            return _IDemographicData.GetDemographicData(UsersId);
        }

        [HttpGet("get.DemographicAdditionalInfo/{UsersId}")]
        public DemographicAdditionalInfo DemographicAdditionalInfo(int UsersId)
        {
            return _IDemographicData.GetDemographicAdditionalInfo(UsersId);
        }

        [HttpPost("GenerateDemographicDataReport")]
        public List<DemographicDataReport> GenerateDemographicDataReport([FromBody] DemographicDataReportParam demographicDataReportParam)
        {
            return _IDemographicData.GenerateDemographicDataReport(demographicDataReportParam);
        }
       
    }
}
