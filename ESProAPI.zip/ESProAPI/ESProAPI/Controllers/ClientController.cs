﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ESPro.Core.Entity;
using ESPro.Core.Entity.Client;

using ESPro.Core.Interface;
using ESProAPI.Class;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.IO;
using System.Net.Http;
using System.Net;
using System.Net.Http.Headers;
using ESPro.Infrastructure.Class;
using Microsoft.AspNetCore.Authorization;

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class ClientController : ControllerBase
    {

        private readonly IClient _client;

        public ClientController(IClient client)
        {
            _client = client;
        }

        [HttpPost("post.client.dashboard")]
        //public List<ClientJobDetailsModel> GetClientDashboard(int UsersId)
        public object GetClientDashboard([FromBody] SearchClientParameters data)
        {
            IEnumerable<ClientJobDetailsModel> datas = _client.GetClientDashboard(data.UsersId, data.UserRole, data.UserEmailID);

            CommonFunctions commonFunctions = new CommonFunctions();
            List<string> Freelancers = new List<string>();
            List<string> Jobs = new List<string>();
            List<string> InvApprovers = new List<string>();
            if (datas != null)
            {
                Freelancers = datas.Select(a => a.FreelancerName).Distinct().ToList();
                if (!(data.FreelancerFilter.Where(a => a == "0").Count() > 0))
                    datas = datas.Where(a => data.FreelancerFilter.Where(b => a.FreelancerName == b).Count() > 0).ToList();
                Jobs = datas.Select(a => a.JobNo).Distinct().ToList();
                if (!(data.JobFilter.Where(a => a == "0").Count() > 0))
                    datas = datas.Where(a => data.JobFilter.Where(b => a.JobNo == b).Count() > 0).ToList();
                InvApprovers = datas.Select(a => a.InvApproverName).Distinct().ToList();
                //if (!(data.InvApproverFilter.Count == 1 && data.InvApproverFilter.Where(a => a == "0").Count() > 0))
                //    datas = datas.Where(a => data.InvApproverFilter.Where(b => a.InvApproverName == b).Count() > 0).ToList();
            }

            var response = commonFunctions.TableResponce(datas, data.sort, data.dir, data.currentpage, data.pageSize);

            var finalresponse = new
            {
                Jobs = Jobs,
                Freelancers = Freelancers,
                InvApprovers = InvApprovers,
                response = response
            };

            return finalresponse;

            //return response;
        }

        [HttpGet("get.Job.details/{JobId}")]
        public ClientJobDetailsModel GetJobDetailsFromID(int JobId)
        {
            ClientJobDetailsModel clientJobDetailsModel= _client.GetJobDetailsFromID(JobId);
            return clientJobDetailsModel;
        }

        [HttpGet("get.all.client.users/{ClientCode}")]
        public List<ClientUser> GetAllClientUsers(int ClientCode)
        {
            return _client.GetAllClientUsers(ClientCode);
        }

        [HttpGet("get.user.client/{UsersId}")]
        public ClientUser GetUserClientName(int UsersId)
        {
            return _client.GetUserClientName(UsersId);
        }

        [HttpPost("update.PMName")]
        public async Task<IActionResult> UpdatePMName([FromBody] ReassignedJobs reassignedJobs)
        {
            ApiResponce apiResponce = new ApiResponce();
            apiResponce.Text = _client.UpdatePMName(reassignedJobs);
            return Ok(apiResponce);
        }

        [HttpPost("create.client.job")]
        public async Task<IActionResult> CreateClientJob([FromBody] ClientJobDetailsModel clientJobDetailsModel)
        {
            ApiResponce apiResponce = new ApiResponce();
            apiResponce.Text = _client.CreateClientJob(clientJobDetailsModel);

            return Ok(apiResponce);
        }

        [HttpPost("update.client.job")]
        public async Task<IActionResult> UpdateClientJob([FromBody] ClientJobDetailsModel clientJobDetailsModel)
        {
            ApiResponce apiResponce = new ApiResponce();
            apiResponce.Text = _client.UpdateClientJob(clientJobDetailsModel);
            return Ok(apiResponce);
        }

        //[HttpGet("delete.client.job/{JobId}")]
        //public async Task<IActionResult> DeleteClientJob(int JobId)
        [HttpPost("delete.client.job")]
        public async Task<IActionResult> DeleteClientJob([FromBody] ClientJobDetailsModel clientJobDetailsModel)
        {
            ApiResponce apiResponce = new ApiResponce();
            int cnt = _client.DeleteClientJob(clientJobDetailsModel);
            if (cnt != null && cnt > 0)
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }

       

        //https://stackoverflow.com/questions/48864518/how-to-correctly-download-files-to-angular-from-asp-net-core/48864842
        [HttpGet("download.contract")]
        public async Task<FileStreamResult> Download(string ContractFile)
        {
            
            var contentType = MimeMapping.MimeUtility.GetMimeMapping(Path.GetExtension(ContractFile));
            string file = CommonResource.ContractPath +"\\"+ ContractFile;
            var stream = new FileStream(file, FileMode.Open, FileAccess.Read);
            
            var result = new FileStreamResult(stream, contentType);
           // result.FileDownloadName = "1.pdf";
            return result;
        }
        
            
    }
}
