﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class DeactivateProjectsController : ControllerBase
    {
        public CommonFunctions commonFn = new CommonFunctions();
        private readonly IDeactivateProjects _deactivateProjects;

        public DeactivateProjectsController(IDeactivateProjects DeactivateProjects)
        {
            _deactivateProjects = DeactivateProjects;
        }

        [HttpGet("get.jobsDropdown")]
        public object GetJobsDropdown()
        {
            SearchKillableJobs SearchJob = new SearchKillableJobs();
            List<KillableJobs> Model = new List<KillableJobs>();
            Model = _deactivateProjects.GetKillableJobs(SearchJob).ToList();

            return Model;
        }


        [HttpPost("get.killablejobs")]
        public object GetKillableJobs([FromBody] SearchKillableJobs searchKillableJobs)
        {
            List<KillableJobs> Model = new List<KillableJobs>();
            Model = _deactivateProjects.GetKillableJobs(searchKillableJobs).ToList();


            var data = Model.GroupBy(a => new
            {
                a.JobId,
                a.JobNo,
                a.Client,
                a.ISBN13,
                a.Author,
                a.Title,
                a.FreelancerName,
                a.FreelancerEmail,
                a.ProjectManager,
                a.ProjectManagerEmail

            }).Select(b => new KillableJobs
            {
                JobId = b.Key.JobId,
                JobNo = b.Key.JobNo,
                Client = b.Key.Client,
                ISBN13 = b.Key.ISBN13,
                Author = b.Key.Author,
                Title = b.Key.Title,
                FreelancerName = b.Key.FreelancerName,
                FreelancerEmail = b.Key.FreelancerEmail,
                ProjectManager = b.Key.ProjectManager,
                ProjectManagerEmail = b.Key.ProjectManagerEmail
            });

            var response = commonFn.TableResponce(data, searchKillableJobs.sort, searchKillableJobs.dir, searchKillableJobs.currentpage, searchKillableJobs.pageSize);
            var finalresponse = new
            {
                //Jobs = Jobs,
                response = response
            };
            return finalresponse;

            //if (!string.IsNullOrEmpty(sort))
            //{
            //    var param = sort;
            //    var propertyInfo = typeof(KillableJobs).GetProperty(param);
            //    if (dir == "desc")
            //    {
            //        data = data.OrderByDescending(x => propertyInfo.GetValue(x, null));
            //    }
            //    else
            //    {
            //        data = data.OrderBy(x => propertyInfo.GetValue(x, null));
            //    }

            //}
            //CommonFunctions commonFunctions = new CommonFunctions();
            //var subdata = commonFunctions.SplitList(data.ToList(), pageSize);
            //var response = new
            //{
            //    Lastpage = subdata.Count(),
            //    data = (subdata == null || subdata.Count() == 0) ? data : subdata.ElementAt(currentpage),
            //    TotalRecords = Model.Count
            //};



            return response;
        }


        [HttpPost("save.deactivateprojects")]
        public ActionResult DeactivateProjects([FromBody] KillJobs killJobs)
        {
            ApiResponce apiResponce = new ApiResponce();

            if (_deactivateProjects.DeactivateProjects(killJobs) > 0)
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }
    }
}