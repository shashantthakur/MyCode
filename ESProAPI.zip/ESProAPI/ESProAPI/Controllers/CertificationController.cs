﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml;
using OfficeOpenXml.Style;

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class CertificationController : ControllerBase
    {

        private readonly ICertification _certification;

        public CertificationController(ICertification certification)
        {
            _certification = certification;
        }

        // GET: api/Certification
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/Certification/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Certification
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT: api/Certification/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }

        [HttpGet("GetUnEnrolledCertificate")]
        public object GetUnEnrolledCertificate(int UsersId, string sort, string dir, int currentpage, int pageSize)
        {
            IEnumerable<Certificate> datas = _certification.GetUnEnrolledCertificate(UsersId);

            CommonFunctions commonFunctions = new CommonFunctions();
            var response = commonFunctions.TableResponce(datas, sort, dir, currentpage, pageSize);

            return response;
            //return datas;
        }

        [HttpGet("GetCertificate")]
        public object GetCertificate(string sort, string dir, int currentpage, int pageSize)
        {
            IEnumerable<CertificateInfo> datas = _certification.GetCertificate();
            CommonFunctions commonFunctions = new CommonFunctions();
            var response = commonFunctions.TableResponce(datas, sort, dir, currentpage, pageSize);

            return response;
            //return datas;
        }

        [HttpGet("GetCertificateUser")]
        public object GetCertificateUser(int TestRegistrationID, string sort, string dir, int currentpage, int pageSize)
        {
            IEnumerable<SkillCertificateUser> datas = _certification.GetCertificateUser(TestRegistrationID, "Certificate");
            CommonFunctions commonFunctions = new CommonFunctions();
            var response = commonFunctions.TableResponce(datas, sort, dir, currentpage, pageSize);

            return response;
            //return datas;
        }

        [HttpGet("get.DownloadCertificationResult")]
        public ActionResult DownloadCertificationResult(int TestRegistrationID)
        {
            IEnumerable<SkillCertificateUser> datas = _certification.GetCertificateUser(TestRegistrationID, "Certificate");
            using (ExcelPackage package = new ExcelPackage())
            {
                package.Workbook.Worksheets.Add("Result");
                OfficeOpenXml.ExcelWorksheet worksheet = package.Workbook.Worksheets[1];
                worksheet.Cells[1, 1].Value = "Full Name";
                worksheet.Cells[1, 2].Value = "Attempts";
                worksheet.Cells[1, 3].Value = "Status";
                worksheet.Cells[1, 4].Value = "Question Attempted";
                worksheet.Cells[1, 5].Value = "Test Score";
                worksheet.Cells[1, 6].Value = "Feedback";
                worksheet.Cells[1, 1, 1, 6].Style.Font.Bold = true;
                worksheet.Cells[1, 1, 1, 6].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                int i = 2;
                foreach (var item in datas)
                {
                    int col = 1;
                    worksheet.Cells[i, col++].Value = item.FullName;
                    worksheet.Cells[i, col++].Value = item.Attempts;
                    worksheet.Cells[i, col++].Value = item.Status;
                    worksheet.Cells[i, col++].Value = item.QuestionAttempted;
                    worksheet.Cells[i, col++].Value = item.TestScore;
                    worksheet.Cells[i, col++].Value = item.Feedback;
                    i++;
                }
                worksheet.Cells[1, 1, i - 1, 6].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[1, 1, i - 1, 6].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[1, 1, i - 1, 6].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[1, 1, i - 1, 6].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[1, 1, i - 1, 6].AutoFitColumns();
                return Ok(new { data = package.GetAsByteArray(), contenttype = "application/octet-stream", filename = "Certification_Result_" + DateTime.Now.ToString("ddMMyyyyHHmmss") + ".xlsx" });
            }
            return null;
        }

        [HttpGet("GetTestDetails/{TestID}")]
        public AllocateTest GetTestDetails(int TestID)
        {
            AllocateTest response = _certification.GetTestDetails(TestID);

            return response;

        }

        [HttpGet("GetUserPhase2Dashboard")]
        public object GetUserTestInfo(int UsersId, string sort, string dir, int currentpage, int pageSize)
        {
            IEnumerable<UserTestInfo> datas = _certification.GetUserTestInfo(UsersId);

            CommonFunctions commonFunctions = new CommonFunctions();
            var response = commonFunctions.TableResponce(datas, sort, dir, currentpage, pageSize);

            return response;
        }

        [HttpGet("GetSelectedTest")]
        public AllocateTest GetSelectedTest(int UsersId, int TestID)
        {
            AllocateTest response = _certification.GetSelectedTest(UsersId, TestID);
            return response;
        }

        [HttpPost("AllocateTest")]
        public int AllocateTest([FromBody] AllocateTest allocateTest)
        {
            int cnt = _certification.AllocateTest(allocateTest);
            return cnt;
        }

        [HttpPost("GetQuestionsOnSkill")]
        public SkillQuestion GetQuestionsOnSkill([FromBody] QuestionParam questionParam)
        {

            SkillQuestion _skillQuestion = _certification.GetQuestionsOnSkill(questionParam.UserId.Value, questionParam.TestID.Value, questionParam.SkillID.Value, questionParam.TestRegistrationId.Value);

            return _skillQuestion;
        }

        [HttpPost("SaveAnswer")]
        public TestResult SaveAnswer([FromBody] QuestionOptionModel questionParam)
        {
            TestResult _testResult = _certification.SaveTest(questionParam);

            return _testResult;
        }

        [HttpGet("GetTestAnalysis")]
        public object GetTestAnalysis(int TestRegistrationId, string sort, string dir, int currentpage, int pageSize)
        {
            IEnumerable<TestAnalysis> datas = _certification.GetTestAnalysis(TestRegistrationId);

            CommonFunctions commonFunctions = new CommonFunctions();
            var response = commonFunctions.TableResponce(datas, sort, dir, currentpage, pageSize);

            return response;
        }

        [HttpPost("SaveFeedbackData")]
        public ActionResult SaveFeedbackData([FromBody] TestResultFeedback data)
        {
            ApiResponce apiResponce = new ApiResponce();
            int cnt = _certification.SaveFeedbackData(data);
            if (cnt != null && cnt > 0)
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }



        [HttpGet("GetPhase2Test/{SkillPhase2TestID}")]
        public SkillPhase2Test GetPhase2Test(int SkillPhase2TestID)
        {
            SkillPhase2Test response = _certification.GetPhase2Test(SkillPhase2TestID);
            return response;
        }

        [HttpPost("download.Phase2Test")]
        public async Task<FileStreamResult> Download(Phase2Registration phase2)
        {
            SkillPhase2Test Phase2Test = _certification.GetPhase2Test(phase2.SkillPhase2TestID.Value);
            int cnt = _certification.SavePhase2Registration(phase2);

            var contentType = MimeMapping.MimeUtility.GetMimeMapping(Path.GetExtension(Phase2Test.PDFPath));
            string file = CommonResource.Phase2Test + "\\" + Phase2Test.PDFPath;
            var stream = new FileStream(file, FileMode.Open, FileAccess.Read);

            var result = new FileStreamResult(stream, contentType);
            // result.FileDownloadName = "1.pdf";
            return result;
        }
        [HttpPost("Upload.Phase2File")]
        public async Task<IActionResult> Phase2FileUpload([FromForm] Phase2FileUpload phase2FileUpload)
        {
            ApiResponce apiResponce = new ApiResponce();

            string Phase2TestUserUpload = CommonResource.Phase2TestUserUpload;
            if (phase2FileUpload.SkillPhase2File != null)
            {
                string SampleFileName = phase2FileUpload.SkillPhase2File.FileName;
                string SampleFileFullPath = Phase2TestUserUpload + "\\" + phase2FileUpload.UserID;

                _certification.SaveFile(SampleFileFullPath, phase2FileUpload.SkillPhase2File, SampleFileName);
                string SampleFilePath = phase2FileUpload.UserID + "\\" + SampleFileName;


                Phase2Registration phase2Registration = new Phase2Registration();
                phase2Registration.UserID = phase2FileUpload.UserID;
                phase2Registration.Status = phase2FileUpload.Status;
                phase2Registration.Type = phase2FileUpload.Type;
                phase2Registration.CrudAction = phase2FileUpload.CrudAction;
                phase2Registration.FilePath = SampleFilePath;
                phase2Registration.SkillPhase2TestID = phase2FileUpload.SkillPhase2TestID;

                int cnt = _certification.SavePhase2Registration(phase2Registration);

                if (cnt != null && cnt > 0)
                {
                    apiResponce.Text = "success";
                }
                else
                {
                    apiResponce.Text = "fail";
                }
            }

            return Ok(apiResponce);
        }

        [HttpGet("GetPhase2Registration")]
        public object GetPhase2Registration(int Status, string sort, string dir, int currentpage, int pageSize)
        {
            IEnumerable<Phase2Registration> datas = _certification.GetPhase2Registration(Status);

            CommonFunctions commonFunctions = new CommonFunctions();
            var response = commonFunctions.TableResponce(datas, sort, dir, currentpage, pageSize);

            return response;
            //return datas;
        }
        [HttpGet("download.UserPhase2Upload")]
        public async Task<FileStreamResult> DownloadUserPhase2Upload(string FilePath)
        {         
            var contentType = MimeMapping.MimeUtility.GetMimeMapping(Path.GetExtension(FilePath));

            if (!Directory.Exists(CommonResource.Phase2TestUserUpload))
                Directory.CreateDirectory(CommonResource.Phase2TestUserUpload);
            string file = CommonResource.Phase2TestUserUpload + "\\" + FilePath;
            var stream = new FileStream(file, FileMode.Open, FileAccess.Read);

            var result = new FileStreamResult(stream, contentType);
            // result.FileDownloadName = "1.pdf";
            return result;
        }

        [HttpPost("SavePhase2Result")]
        public async Task<IActionResult> SavePhase2Result( Phase2Registration _phase2Registration)
        {
            ApiResponce apiResponce = new ApiResponce();


                int cnt = _certification.SavePhase2Registration(_phase2Registration);

                if (cnt != null && cnt > 0)
                {
                    apiResponce.Text = "success";
                }
                else
                {
                    apiResponce.Text = "fail";
                }
            

            return Ok(apiResponce);
        }
    }
}
