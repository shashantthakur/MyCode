﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ESPro.Core.Entity.HSBC;
using ESPro.Core.Interface.HSBC;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using PgpCore;

namespace ESProAPI.Controllers
{
    //https://www.lirnberger.com/tools/pgpdump/
    //https://blog.bitscry.com/2018/07/05/pgp-encryption-and-decryption-in-c/
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class PGPController : ControllerBase
    {

        private readonly IPGP _pgp;
        public IHostingEnvironment _hostingEnvironment { get; }
        public IConfiguration _Configuration { get; }


        public PGPController(IPGP pGP, IConfiguration configuration, IHostingEnvironment hostingEnvironment)
        {
            _pgp = pGP;
            _hostingEnvironment = hostingEnvironment;
            _Configuration = configuration;
        }

        [HttpPost("Decrypt")]
        public String Decrypt(PGPData pGPData)
        {
            string PrivateKeyPath = Path.Combine(_hostingEnvironment.ContentRootPath, "PGPKeys") + "\\" + _Configuration["HSBC:LuminaPrivateKey"];
            string HSBC_PublicKeyPath = Path.Combine(_hostingEnvironment.ContentRootPath, "PGPKeys") + "\\" + _Configuration["HSBC:HSBCPublicKey"];

            string Buf = "";
            //string inputFile = @"D:\HSBC\Test\BalRep.txt";
            //string outputFile = @"D:\HSBC\Test\BalRep1.txt";
            try
            {
                byte[] byteArray = Encoding.ASCII.GetBytes(_pgp.Base64Decode(pGPData.Text));
                MemoryStream inputFileStream = new MemoryStream(byteArray, 0, byteArray.Length);

                // convert stream to string
                Stream outputFileStream = new MemoryStream();

                using (PGP pgp = new PGP())
                {
                    using (Stream privateKeyStream = new FileStream(PrivateKeyPath, FileMode.Open))
                    {
                        pgp.DecryptStream(inputFileStream, outputFileStream, privateKeyStream, "#espro#1234");
                        outputFileStream.Position = 0;
                        StreamReader reader = new StreamReader(outputFileStream);
                        Buf = reader.ReadToEnd();
                    }

                }
            }
            catch (Exception ex)
            {

                return ex.ToString();
            }
            return Buf;
        }

        [HttpPost("Encrypt")]
        public String Encrypt(PGPData pGPData)
        {
            string PrivateKeyPath = Path.Combine(_hostingEnvironment.ContentRootPath, "PGPKeys") + "\\" + _Configuration["HSBC:LuminaPrivateKey"];
            string HSBC_PublicKeyPath = Path.Combine(_hostingEnvironment.ContentRootPath, "PGPKeys") + "\\" + _Configuration["HSBC:HSBCPublicKey"];

            string Buf = "";
            try
            {
                byte[] byteArray = Encoding.ASCII.GetBytes(pGPData.Text.Trim());
                MemoryStream inputFileStream = new MemoryStream(byteArray, 0, byteArray.Length);

                // convert stream to string
                Stream outputFileStream = new MemoryStream();

                using (PGP pgp = new PGP())
                {

                    using (Stream privateKeyStream = new FileStream(PrivateKeyPath, FileMode.Open))
                    {
                        using (Stream publicKeyStream = new FileStream(HSBC_PublicKeyPath, FileMode.Open))
                        {
                            pgp.EncryptStreamAndSign(inputFileStream, outputFileStream, publicKeyStream, privateKeyStream, "#espro#1234", true, true);

                            outputFileStream.Position = 0;
                            StreamReader reader = new StreamReader(outputFileStream);
                            Buf = _pgp.Base64Encode(reader.ReadToEnd());
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                return ex.ToString();

            }
            return Buf;
        }


        [HttpPost("LuminaEncrypt")]
        public String LuminaEncrypt(PGPData pGPData)
        {
            string PrivateKeyPath = Path.Combine(_hostingEnvironment.ContentRootPath, "PGPKeys") + "\\" + _Configuration["HSBC:LuminaPrivateKey"];
            string PublicKeyPath = Path.Combine(_hostingEnvironment.ContentRootPath, "PGPKeys") + "\\" + _Configuration["HSBC:LuminaPublicKey"];

            string Buf = "";
            try
            {
                byte[] byteArray = Encoding.ASCII.GetBytes(pGPData.Text);
                MemoryStream inputFileStream = new MemoryStream(byteArray, 0, byteArray.Length);

                // convert stream to string
                Stream outputFileStream = new MemoryStream();


                using (PGP pgp = new PGP())
                {

                    using (Stream privateKeyStream = new FileStream(PrivateKeyPath, FileMode.Open))
                    {
                        using (Stream publicKeyStream = new FileStream(PublicKeyPath, FileMode.Open))
                        {
                            pgp.EncryptStreamAndSign(inputFileStream, outputFileStream, publicKeyStream, privateKeyStream, "#espro#1234", true, true);

                            outputFileStream.Position = 0;
                            StreamReader reader = new StreamReader(outputFileStream);
                            Buf = _pgp.Base64Encode(reader.ReadToEnd());
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                return ex.ToString();

            }
            return Buf;
        }
    }
}