﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AdminDashboardController : ControllerBase
    {
        private readonly IAdminDashboard _adminDashboard;

        public AdminDashboardController(IAdminDashboard AdminDashboard)
        {
            _adminDashboard = AdminDashboard;
        }

        [HttpPost("post.admindashboard")]
        public object GetAdminDashboard([FromBody] AdminParameters data)
        {
            IEnumerable<AdminDashboard> datas = _adminDashboard.GetAdminDashboard(data.UserEmailID, data.UserRole);

            CommonFunctions commonFunctions = new CommonFunctions();
            List<string> Jobs = datas.Select(a => a.JobNo).Distinct().ToList();

            if (!(data.JobFilter.Count == 1 && data.JobFilter.Where(a => a == "0").Count() > 0))
                datas = datas.Where(a => data.JobFilter.Where(b => a.JobNo == b).Count() > 0).ToList();
            if (!(data.FreelancerFilter.Count == 1 && data.FreelancerFilter.Where(a => a == "0").Count() > 0))
                datas = datas.Where(a => data.FreelancerFilter.Where(b => a.FreelancerName == b).Count() > 0).ToList();
            if (!(data.InvApproverFilter.Count == 1 && data.InvApproverFilter.Where(a => a == "0").Count() > 0))
                datas = datas.Where(a => data.InvApproverFilter.Where(b => a.InvApproverName == b).Count() > 0).ToList();

            List<string> Freelancers = datas.Select(a => a.FreelancerName).Distinct().ToList();
            List<string> InvApprovers = datas.Select(a => a.InvApproverName).Distinct().ToList();

            var response = commonFunctions.TableResponce(datas, data.sort, data.dir, data.currentpage, data.pageSize);

            var finalresponse = new
            {
                Jobs = Jobs,
                Freelancers = Freelancers,
                InvApprovers = InvApprovers,
                response = response
            };
            return finalresponse;
        }
        //public object GetAdminDashboard(string EmailId)
        //{
        //    return _adminDashboard.GetAdminDashboard(EmailId);
        //}


    }
}