﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class PredectiveController : Controller
    {
        private readonly IPredective _predective;
        public PredectiveController(IPredective PREDECTIVE)
        {
            _predective = PREDECTIVE;
        }

        [HttpGet("ConvertToNormal")]
        public string ConvertToNormal(string Text)
        {
            //if (!String.IsNullOrEmpty(Text))
            //    Text = new Entity_Convert.EntityConvert().HexaToChar(Text);
            return Text;
        }

        [HttpGet("get.fsresult/{Userid}")]
        public PredectiveModel GetFsResult(int Userid)
        {
            PredictiveResult Result = _predective.GetFsResult(Userid);
            PredectiveModel Data = new PredectiveModel();
            Data.Result = ConvertToNormal(Result.WritingNotes);
            if (string.IsNullOrEmpty(Result.FSResult))
            {
                return Data;
            }
            var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<Predective>(Result.FSResult);
            dynamic Dynamicobj = Newtonsoft.Json.JsonConvert.DeserializeObject(Result.FSResult);

            TextInfo TC = new CultureInfo("en-US", false).TextInfo;

            foreach (var item in Dynamicobj.data)
            {
                Predective dt = new Predective();
                dt.Name = item.Name;
                dt.Value = Math.Round(Convert.ToDecimal(item.Value) * 100, 2);
                if (Regex.Match(dt.Name, "^values_", RegexOptions.IgnoreCase).Success)
                {
                    dt.Name = Regex.Replace(dt.Name, "^values_", "", RegexOptions.IgnoreCase).Replace("_", " ");
                    dt.Name = TC.ToTitleCase(dt.Name);
                    Data.Values.Add(dt);
                }
                else if (Regex.Match(dt.Name, "^openness_", RegexOptions.IgnoreCase).Success)
                {
                    dt.Name = Regex.Replace(dt.Name, "^openness_", "", RegexOptions.IgnoreCase).Replace("_", " ");
                    dt.Name = TC.ToTitleCase(dt.Name);
                    Data.Openness.Add(dt);
                }
                else if (Regex.Match(dt.Name, "^needs_", RegexOptions.IgnoreCase).Success)
                {
                    dt.Name = Regex.Replace(dt.Name, "^needs_", "", RegexOptions.IgnoreCase).Replace("_", " ");
                    dt.Name = TC.ToTitleCase(dt.Name);
                    Data.Need.Add(dt);
                }
                else if (Regex.Match(dt.Name, "^conscientiousness", RegexOptions.IgnoreCase).Success)
                {
                    dt.Name = Regex.Replace(dt.Name, "^conscientiousness_", "", RegexOptions.IgnoreCase).Replace("_", " ");
                    dt.Name = TC.ToTitleCase(dt.Name);
                    Data.Conscientiousness.Add(dt);
                }
                else if (Regex.Match(dt.Name, "^extraversion", RegexOptions.IgnoreCase).Success)
                {
                    dt.Name = Regex.Replace(dt.Name, "^extraversion_", "", RegexOptions.IgnoreCase).Replace("_", " ");
                    dt.Name = TC.ToTitleCase(dt.Name);
                    Data.Extraversion.Add(dt);
                }
                else if (Regex.Match(dt.Name, "^agreeableness", RegexOptions.IgnoreCase).Success)
                {
                    dt.Name = Regex.Replace(dt.Name, "^agreeableness_", "", RegexOptions.IgnoreCase).Replace("_", " ");
                    dt.Name = TC.ToTitleCase(dt.Name);
                    Data.Agreeableness.Add(dt);
                }
                else if (Regex.Match(dt.Name, "^emotional_range", RegexOptions.IgnoreCase).Success)
                {
                    dt.Name = Regex.Replace(dt.Name, "^emotional_range_", "", RegexOptions.IgnoreCase).Replace("_", " ");
                    dt.Name = TC.ToTitleCase(dt.Name);
                    Data.Emotional_range.Add(dt);
                }

            }
            return Data;
        }


        [HttpPost("add.writingsample")]
        public ActionResult Addagenciesdetails([FromBody] PredictiveData PredictiveData)
        {
            ApiResponce apiResponce = new ApiResponce();
            apiResponce.Text = "fail";
            ////return _agency.InsertAgency(agencies) ? "success" : "fail";

            //Updated on 2nd September 2021

            //string Resilt = UtilitiesResource.FSResultAPICall(PredictiveData.WritingNotes);
            //if (_predective.UpSertWritingSample(PredictiveData, Resilt))
            if (_predective.UpSertWritingSample(PredictiveData, ""))
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }
    }
}