﻿using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using ESPro.Infrastructure.Service;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class userdetailController : ControllerBase
    {
        private readonly IUserDetails _userDetails;
        private readonly IRegi _IUserRegistration;
        public IConfiguration _Configuration { get; }
        private readonly IPredective _predective;



        public userdetailController(IRegi IUserRegistration, IUserDetails userDetails, IPredective PREDECTIVE, IConfiguration configuration)
        {
            _IUserRegistration = IUserRegistration;
            _userDetails = userDetails;
            _predective = PREDECTIVE;
            _Configuration = configuration;
        }
        // GET: api/userdetail
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        [HttpGet("get.users.ProfileCompletenes")]
        public UserProfileCompleteness getUserProfileCompleteness(int UsersId, int RoleId)
        {
            return _userDetails.getUserProfileCompleteness(UsersId, RoleId);
        }


        // GET: api/userdetail/get.users.details
        [HttpGet("get.users.details/{UsersId}")]
        public UsersDetails GetUsersDetails(int UsersId)
        {
            return _userDetails.GetUsersDetails(UsersId.ToString());
        }

        [HttpGet("get.personal.details/{UsersId}")]
        public PersonalDetails GetPersonalDetails(int UsersId)
        {
            return _userDetails.GetPersonalDetails(UsersId.ToString());
        }

        [HttpGet("get.address.details/{UsersId}")]
        public AddressDetails GetAddressDetails(int UsersId)
        {
            return _userDetails.GetAddressDetails(UsersId.ToString());
        }

        [HttpPost("get.user.roles")]
        public object GetUserRoles([FromBody] SearchRoleParameter datas)
        {
            return _userDetails.GetUserRoles(datas.UsersID, datas.UserRole);
        }

        [HttpGet("get.user.skills/{UsersId}")]
        public UserSkills GetUserSkills(int UsersId)
        {
            return _userDetails.GetUserSkills(UsersId);
        }

        //[HttpGet("get.user.writingsample/{UsersId}")]
        //public WritingSample GetUserWrittingSample(int UsersId)
        //{
        //    return _userDetails.GetUserWritingSample(UsersId);
        //}

        //[HttpGet("get.user.flcomments/{UsersId}")]

        [HttpGet("get.user.flcomments")]
        public UserFLComments GetUserFLComments(int UsersId, string UserRole, int ClientId)
        {
            return _userDetails.GetUserFLComments(UsersId, UserRole, ClientId);
        }

        [HttpGet("get.MEFLearningPath")]
        public object GetMEFLearningPath(int FreelancerID, int UserID)
        {
            var data = _userDetails.GetMEFLearningPath(FreelancerID, UserID);
            return data;
        }

        [HttpGet("get.user.profile/{UsersId}")]
        public UserProfile GetUserProfile(int UsersId)
        {
            var data = _userDetails.GetUserProfile(UsersId);
            return data;
        }

        [HttpGet("get.user.profilePic/{UsersId}")]
        public object GetUserProfilePic(int UsersId)
        {
            var Result = _userDetails.GetUserProfilePic(UsersId);
            Result = string.IsNullOrWhiteSpace(Result) ? "" : (Regex.Match(Result, @"https://\w+\.googleusercontent\.com", RegexOptions.IgnoreCase).Success ? Result : CommonResource.ImagePathUrl + Result);
            var Response = new
            {
                Picute = Result
            };
            return Response;
        }

        [HttpGet("get.user.profileandcomponent/{UsersId}")]
        public object GetUserProfilewithComponent(int UsersId)
        {
            var data = _userDetails.GetUserProfile(UsersId);
            var componentPermissions = _userDetails.GetComponentPermission(UsersId, data.RoleId.Value, 0);
            var datas = new
            {
                data = data,
                componentPermissions = componentPermissions
            };
            return datas;
        }

        [HttpPost("post.updateadmincomment")]
        public object updateadmincomments([FromBody] AdminComments data)
        {
            ApiResponce apiResponce = new ApiResponce();
            int cnt = _userDetails.SaveGeneralComments(data);
            if (cnt != null && cnt > 0)
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }


        [HttpGet("get.user.resumesample/{UsersId}")]
        public UserResumeSample GetUserResumeSample(int UsersId)
        {
            return _userDetails.GetUserResumeSample(UsersId);
        }

        [HttpPost("checking.ProhibitedCharacters")]
        public string CheckingProhibitedCharacters(AddressDetails addressDetails)
        {
            List<string> AllowedChars = CommonResource.ProhibitedCharsList();
            string error = "";
            error += CommonResource.FindProhibitedCharacters(Convert.ToString("" + addressDetails.Street1), AllowedChars, "Street1");
            error += CommonResource.FindProhibitedCharacters(Convert.ToString("" + addressDetails.City1), AllowedChars, "City1");
            error += CommonResource.FindProhibitedCharacters(Convert.ToString("" + addressDetails.State1), AllowedChars, "State1");
            error += CommonResource.FindProhibitedCharacters(Convert.ToString("" + addressDetails.PostalCode1), AllowedChars, "PostalCode1");
            error += CommonResource.FindProhibitedCharacters(Convert.ToString("" + addressDetails.Street2), AllowedChars, "Street2");
            error += CommonResource.FindProhibitedCharacters(Convert.ToString("" + addressDetails.City2), AllowedChars, "City2");
            error += CommonResource.FindProhibitedCharacters(Convert.ToString("" + addressDetails.State2), AllowedChars, "State2");
            error += CommonResource.FindProhibitedCharacters(Convert.ToString("" + addressDetails.PostalCode2), AllowedChars, "PostalCode2");
            return error.Trim().TrimEnd(',');
        }

        [HttpPost("update.address")]
        public async Task<IActionResult> UpdateAddressDetails([FromBody] AddressDetails addressDetails)
        {
            ApiResponce apiResponce = new ApiResponce();
            string prohibitedCharError = CheckingProhibitedCharacters(addressDetails);
            if (prohibitedCharError == "")
            {
                int cnt = _userDetails.UpdateAddressDetails(addressDetails);
                if (cnt != null && cnt > 0)
                {
                    apiResponce.Text = "success";
                }
                else
                {
                    apiResponce.Text = "fail";
                }
            }
            else
                apiResponce.Text = prohibitedCharError;
            return Ok(apiResponce);
        }

        [HttpPost("post.user.profilepic")]
        public ActionResult UpdateProfilePic([FromBody] ImageREsult Data)
        {

            //return _userDetails.GetUserSkills(UsersId);
            ApiResponce apiResponce = new ApiResponce();

            var base64Data = Regex.Match(Data.Image, @"data:image/(?<type>.+?),(?<data>.+)").Groups["data"].Value;

            byte[] imageBytes = Convert.FromBase64String(base64Data);
            MemoryStream ms = new MemoryStream(imageBytes, 0,
              imageBytes.Length);

            // Convert byte[] to Image
            ms.Write(imageBytes, 0, imageBytes.Length);
            Image image = Image.FromStream(ms, true);
            string Filename = DateTime.Now.ToString("ddMMyyyyHHmmss") + CommonResource.GenerateRandomNo().ToString() + ".png";

            image.Save(ESPro.Infrastructure.Class.CommonResource.ImagePath + "/" + Filename, System.Drawing.Imaging.ImageFormat.Png);
            int cnt = _userDetails.UpdateProfilePic(Filename, Convert.ToInt32(Data.usersid));
            apiResponce.Text = "success";
            return Ok(apiResponce);
        }



        [HttpPost("update.personal.details")]
        public async Task<IActionResult> UpdatePersonalDetails([FromBody] PersonalDetails personalDetails)
        {
            ApiResponce apiResponce = new ApiResponce();
            int cnt = _userDetails.UpdatePersonalDetails(personalDetails);
            if (cnt != null && cnt > 0)
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }


        [HttpGet("get.Freelancers")]
        public List<FreelancerList> GetFreelancer()
        {
            return _userDetails.GetFreelancer();
        }

        //[HttpPost("update.user.writingsample")]
        //public async Task<IActionResult> UpdatePersonalDetails([FromBody] WritingSample writingSample)
        //{
        //    ApiResponce apiResponce = new ApiResponce();
        //    int cnt = _userDetails.UpdateUserWritingSample(writingSample);

        //    string Result = UtilitiesResource.FSResultAPICall(writingSample.WrittingSample);

        //    PredictiveData predictiveData = new PredictiveData();
        //    predictiveData.UsersID = writingSample.UsersId.Value;
        //    predictiveData.WritingNotes = writingSample.WrittingSample;

        //    if (_predective.UpSertWritingSample(predictiveData, Result))
        //    {
        //        apiResponce.Text = "success";
        //    }
        //    else
        //    {
        //        apiResponce.Text = "fail";
        //    }


        //    return Ok(apiResponce);
        //}

        [HttpPost("update.user.flcomments")]
        public async Task<IActionResult> UpdateFLComments([FromBody] UserFLComments userFLComments)
        {
            ApiResponce apiResponce = new ApiResponce();
            int cnt = _userDetails.UpdateFLComments(userFLComments);

            if (cnt != null && cnt > 0)
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }


            return Ok(apiResponce);
        }


        [HttpPost("update.user.skills")]
        public async Task<IActionResult> UpdateUserSkills([FromBody] UserSkills userSkills)
        {
            ApiResponce apiResponce = new ApiResponce();
            int cnt = _userDetails.UpdateUserSkills(userSkills);
            if (cnt != null && cnt > 0)
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }

        [HttpPost("update.user.resumesample")]
        public async Task<IActionResult> UpdateUserResume([FromForm] ResumeSample resumeSample)
        {
            ApiResponce apiResponce = new ApiResponce();


            string ResumeFilePath = "";
            string SampleFilePath = "";
            string LinkToOnlineProfile = "";
            string ResumePath = _Configuration["ResumePath"];
            string SamplePath = _Configuration["SamplePath"];

            if (resumeSample.Resume != null)
            {
                string Resume_file_name = resumeSample.Resume.FileName;
                string ResumeFullPath = ResumePath + "\\" + resumeSample.UsersId;
                _userDetails.SaveFile(ResumeFullPath, resumeSample.Resume, Resume_file_name);
                ResumeFilePath = resumeSample.UsersId + "\\" + Resume_file_name;
            }

            if (resumeSample.SampleFile != null)
            {
                string SampleFileName = resumeSample.SampleFile.FileName;
                string SampleFileFullPath = SamplePath + "\\" + resumeSample.UsersId;

                _userDetails.SaveFile(SampleFileFullPath, resumeSample.SampleFile, SampleFileName);
                SampleFilePath = resumeSample.UsersId + "\\" + SampleFileName;
            }
            int cnt = _userDetails.UpdateResumeSample(resumeSample.UsersId.Value, ResumeFilePath, SampleFilePath, resumeSample.OnlineProfile);

            if (cnt != null && cnt > 0)
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }

        [HttpPost("get.user.resume/{UsersId}")]
        public HttpResponseMessage GetUserResumeFile(int UsersId)
        {
            // return byte[] FileByte = File.ReadAllBytes(FilePath); 
            UserResumeSample userResumeSample = _userDetails.GetUserResumeSample(UsersId);
            //  return System.IO.File.ReadAllBytes(userResumeSample.ResumeFilePath);

            var response = new HttpResponseMessage(HttpStatusCode.OK);


            var file = userResumeSample.ResumeFilePath;
            if (System.IO.File.Exists(file))
            {
                // var response = new HttpResponseMessage(HttpStatusCode.OK);
                response.Content = new StreamContent(System.IO.File.OpenRead(file));

                var contentType = MimeMapping.MimeUtility.GetMimeMapping(Path.GetExtension(file));
                response.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue(contentType);
                return response;
            }
            else
            {
                return response = new HttpResponseMessage(HttpStatusCode.InternalServerError);
            }


        }

        [HttpGet("get.Remove.user")]
        public object FreelancerDeleteProfile(int usersid, int roleid, string useremailid)
        {
            CommonResult commonResult = new CommonResult();
            try
            {
                if (_userDetails.DeleteProfile(usersid, roleid) > 0)
                {
                    string ErrorMsg = "";
                    string FullError = "";
                    List<KeyValuePair<string, string>> keyValuePair = new List<KeyValuePair<string, string>>();
                    keyValuePair.Add(new KeyValuePair<string, string>("Token", Convert.ToString(_Configuration["InvToken"])));
                    keyValuePair.Add(new KeyValuePair<string, string>("Email", useremailid));
                    if (CommonResource.InvoicePostRequestAsync<AdminManage>("DeleteFreelancerProfile", keyValuePair, out ErrorMsg, out FullError))
                    {
                        commonResult.Status = "success";
                        commonResult.ErrorMessage = "Deleted from ESPro as well as Connect";
                    }
                    else
                    {
                        commonResult.Status = "fail";
                        commonResult.ErrorMessage = ErrorMsg;
                    }
                }
                else
                {
                    commonResult.Status = "fail";
                    commonResult.ErrorMessage = "Please try again";
                }
            }
            catch (Exception ex)
            {
                commonResult.Status = "fail";
                commonResult.ErrorMessage = ex.Message.ToString();
            }
            return Ok(commonResult);
        }

        [HttpGet("download.ResumeSample")]
        public async Task<FileStreamResult> Download(string File,string Type)
        {

            var contentType = MimeMapping.MimeUtility.GetMimeMapping(Path.GetExtension(File));
            string filePath = "";
            if (Type=="Resume")
            {
                filePath = CommonResource.ResumePath + "\\" + File;
            }
            else
            {
                filePath = CommonResource.SamplePath + "\\" + File;
            }
           // string file = CommonResource.ContractPath + "\\" + File;
            var stream = new FileStream(filePath, FileMode.Open, FileAccess.Read);

            var result = new FileStreamResult(stream, contentType);
            // result.FileDownloadName = "1.pdf";
            return result;
        }
        //[HttpGet("email.forgot")]
        //public ActionResult EmailForgotPassword([FromQuery] string emailid)
        //{
        //    ApiResponce apiResponce = new ApiResponce();


        //    var Result = _IUserRegistration.EmailValidate(emailid);
        //    if (Result == "register" || Result == "unactivated")
        //    {
        //        CryptoService ENCry = new CryptoService();
        //        var users = _userDetails.GetUserUsersId(emailid);
        //        if (users.Count > 0)
        //        {
        //            _userDetails.ForgotUserPassword(users[0]);
        //            apiResponce.Text = "MailSent";
        //        }
        //    }
        //    else
        //        apiResponce.Text = Result;

        //    return Ok(apiResponce);
        //}

        [HttpPost("update.MEFLearningPaths")]
        public async Task<IActionResult> UpdateMEFLearningPaths([FromBody] MEFLearningPath mEFLearningPath)
        {
            ApiResponce apiResponce = new ApiResponce();
            if(_userDetails.UpdateMEFLearningPaths(mEFLearningPath) > 0)
                apiResponce.Text = "success";
            else
                apiResponce.Text = "fail";
            return Ok(apiResponce);
        }
    }
}
