﻿using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESProAPI.Class;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MEFController : ControllerBase
    {
        private readonly IMEF _MEF;

        public MEFController(IMEF iMEF)
        {
            _MEF = iMEF;
        }

        [HttpGet("CheckLearningPathAcess")]
        public int CheckLearningPathAcess(int UsersId)
        {
            CommonResult commonResult = new CommonResult();
            if (_MEF.CheckLearningPathAcess(UsersId))
            {
                //commonResult.Status = "true";
                //commonResult.ErrorMessage = "";
                return 1;
            }
            else
            {
                //commonResult.Status = "false";
                //commonResult.ErrorMessage = "";
                return 0;
            }
            // return Ok(commonResult);
        }

        [HttpGet("get.GetLearningPath")]
        public List<MEFLearnongPath> GetLearningPath(int UsersId)
        {
            return _MEF.GetLearningPath(UsersId);
        }

        [HttpGet("GetMEFVideos")]
        public List<MEFVideoDetails> GetMEFVideos(int UsersId, int MEFLearningPathId)
        {
            return _MEF.GetMEFVideos(UsersId, MEFLearningPathId);
        }


        [HttpGet("ViewCompletely")]
        public string ViewCompletely(int UsersId, int MEFVideosId)
        {
            _MEF.UpdateVideoCompletelyView(UsersId, MEFVideosId);
            return "";
        }

        [HttpGet("GetMEFDashboard")]
        public object GetMEFDashboard(int UsersId, string UserRole, string sort, string dir, int currentpage, int pageSize)
        {
            var datas = _MEF.GetMEFDashboard(UsersId, UserRole);
            var badge = _MEF.GetMEFBadge();
            List<MEFDashboardResponse> dt = datas.GroupBy(a => new { a.userid, a.LearningPathId, a.FullName, a.LearningPath }).Select(b =>
            new MEFDashboardResponse
            {
                isExpanded = false,
                FullName = b.Key.FullName,
                LearningPath = b.Key.LearningPath,
                LearningPathId = b.Key.LearningPathId,
                userid = b.Key.userid,
                Badge = (badge.Where(c => c.MEFLearningPathId == b.Key.LearningPathId).Where(d => d.UsersId == b.Key.userid).Count() > 0),
                response = b.Select(c => new MEFDashboardResponseInner
                {
                    cnt = c.cnt,
                    MappedBy = c.MappedBy,
                    Result = c.Result,
                    TestScore = c.TestScore,
                    videoid = c.videoid,
                    VideoTitle = c.VideoTitle,
                    ViewCount = c.ViewCount
                }).ToList()
            }
            ).ToList();
            CommonFunctions commonFunctions = new CommonFunctions();
            var response = commonFunctions.TableResponce(dt, sort, dir, currentpage, pageSize);
            return response;
        }

        [HttpGet("GetMEFBadge")]
        public object GetMEFDashboard(int UsersId)
        {
            return _MEF.GetMEFBadge(UsersId).Select(a => new { MEFLearningPathId = a.MEFLearningPathId, UsersId = a.UsersId, LearningPath = a.LearningPath, EndDate = "Issued " + a.EndDate.GetValueOrDefault().ToString("MMMM yyyy") });
        }

        [HttpPost("UpdateViews")]
        public ActionResult UpdateTrainingViews(MEFParam mEFParam)
        {
            CommonResult commonResult = new CommonResult();

            if (_MEF.UpdateVideoViews(mEFParam) > 0)
            {
                commonResult.Status = "success";
                commonResult.ErrorMessage = "";
            }
            else
            {
                commonResult.Status = "fail";
                commonResult.ErrorMessage = "Data not updated.";
            }

            return Ok(commonResult);
        }


        [HttpPost("AllocateTest")]
        public int AllocateTest(MEFAllocateTest allocateTest)
        {
            int cnt = _MEF.AllocateTest(allocateTest);
            return cnt;
        }

        [HttpPost("GetQuestionForUser")]
        public MEFQuestion GetQuestionForUser(QuestionParam questionParam)
        {
            MEFQuestion _skillQuestion = _MEF.GetQuestionForUser(questionParam.UserId.Value, questionParam.TestID.Value, questionParam.TestRegistrationId.Value);

            return _skillQuestion;
        }

        [HttpPost("SaveAnswer")]
        public MEFTestCode SaveAnswer(MEFQuestionOptionModel questionParam)
        {
            MEFTestCode _testResult = _MEF.SaveTest(questionParam);

            return _testResult;
        }

        [HttpPost("GetTestResult")]
        public MEFTestResult GetSmartAssessorTestResult([FromBody] QuestionParam questionParam)
        {
            MEFTestResult smartAssessorTestResults = _MEF.GetTestResult(questionParam.UserId.Value, questionParam.TestRegistrationId.Value);
            return smartAssessorTestResults;
        }

        [HttpPost("SaveFeedbackData")]
        public ActionResult SaveFeedbackData(TestResultFeedback data)
        {
            ApiResponce apiResponce = new ApiResponce();
            int cnt = _MEF.SaveFeedbackData(data);
            if (cnt != null && cnt > 0)
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }
    }
}
