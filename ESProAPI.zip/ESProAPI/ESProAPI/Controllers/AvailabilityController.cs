﻿using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AvailabilityController : ControllerBase
    {
        private readonly IAvailability _availability;
        public AvailabilityController(IAvailability availability)
        {
            _availability = availability;
        }


        [HttpPost("SaveEvent")]
        public async Task<IActionResult> SaveEvent ([FromBody] Availability availability)
        {
            ApiResponce apiResponce = new ApiResponce();
            int cnt = _availability.ApplyLeave(availability);
            if(cnt>0)
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }

           
            return Ok(apiResponce);
           
        }

        [HttpPost("CheckAvailability")]
        public List<Availability> CheckAvailability([FromBody] Availability availability)
        {
            List<Availability> availabilityList = _availability.CheckAvailability(availability.UsersId.Value, availability.StartDate, availability.EndDate, availability.AvailabilityId.Value);
            return availabilityList;
        }

        [HttpPost("GetAvailability")]
        public List<AvailabilityList> GetAvailability([FromBody] AvailabilityListParam availability)
        {
            List<AvailabilityList> availabilityList = _availability.GetAvailability(availability.UsersId.Value, availability.month.Value, availability.year.Value, availability.AvailabilityId.Value);
            return availabilityList;
        }

        [HttpGet("DeleteAvailability/{AvailabilityId}")]
        public async Task<IActionResult> DeleteAvailability(int AvailabilityId)
        {
            ApiResponce apiResponce = new ApiResponce();
            int cnt = _availability.DeleteAvailability(AvailabilityId);
            if (cnt > 0)
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }


            return Ok(apiResponce);
        }
           



    }
}
