﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ESPro.Core.Entity;
using ESPro.Core.Entity.Report;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using ESPro.Infrastructure.Service;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Hosting.Internal;

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class ValuesController : ControllerBase
    {

        private readonly ITestInterface _testInterface;

        public CommonFunctions commonFn = new CommonFunctions();
        public ValuesController(ITestInterface testInterface)
        {
            _testInterface = testInterface;
        }
        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<string>> Get()
        {

            //ReportService reportService = new ReportService();
            //List<SubDisciplineRatingReport> lstRatingReport = new List<SubDisciplineRatingReport>();
            //lstRatingReport = reportService.GetSubDisciplineRatingReportList("cgorakh@gmail.com", "Admin", "YES");

            //DataTable dtToExport = commonFn.ToDataTable(lstRatingReport);
            //string ExportFileName = "DisciplineRatingReport.xlsx";
            //foreach (DataRow datarow in dtToExport.Rows)
            //{
            //    datarow[12] = Regex.Replace(datarow[12].ToString(), "<<([^>]+)>>", "");
            //}

            //try
            //{
            //    DataTable dtToExport1 = new DataTable();
            //    DataTable dtToExport2 = new DataTable();
            //    string FromRows = "A2";
            //    string ToRows = "N";
            //    int HeaderLength = 1;
            //    string TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "RatingSubDescipline.xlsx");
            //    byte[] data = reportService.DownloadReport(dtToExport, 3, 0, TemplateFile, ExportFileName, FromRows, ToRows, HeaderLength, dtToExport1, dtToExport2);
            //    return Ok(new { data, contenttype = "application/octet-stream", filename = ExportFileName, recordcount = dtToExport.Rows.Count });
            //}
            //catch (Exception ex)
            //{
            //    throw;
            //}
            //CryptoService cryptoService = new CryptoService();
            //string str = cryptoService.Encrypt("password@123456");
            return new string[] { TokenInfo.UserName, "value1", "value2" };
        }
        //public IActionResult Get()
        //{
        //    return Redirect("https://rs.luminad.com/ui.esproapi/swagger/index.html");
        //}

        [HttpPost]
        public void Post([FromBody] string value)
        {
           

        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }

        ///sadfsjdfhjskdfjksdhfjkds
        //[HttpGet("get.pdf")]
        //public async Task<FileStreamResult> Download()
        //{
        //    string file = @"F:\Applications\ui.espro\Documents\Contract\149\19_08_2020_08_12_07\Contract_19082020081207.pdf";
        //    var stream = new System.IO.FileStream(file, FileMode.Open, FileAccess.Read);
        //    //var path = "<Get the file path using the ID>";
        //    //var stream = File.OpenRead(path);
        //    var result = new FileStreamResult(stream, "application/pdf");
        //    //result.FileDownloadName = "ravi.pdf";
        //    return result;
        //}


        //[HttpGet("get.pdf")]
        //public async Task<FileStreamResult> Download()
        //{
        //    string file = @"F:\Applications\ui.espro\Documents\Contract\149\19_08_2020_08_12_07\Contract_19082020081207.pdf";
        //    var stream = new FileStream(file, FileMode.Open, FileAccess.Read);
        //    //var path = "<Get the file path using the ID>";
        //    //var stream = File.OpenRead(path);
        //    return new FileStreamResult(stream, "application/pdf");
        //}

        //[HttpGet("get.pdf")]
        //public async Task<FileStream> DownloadFile2(string fileName)
        //{
        //    string file = @"F:\Applications\ui.espro\Documents\Contract\149\19_08_2020_08_12_07\Contract_19082020081207.pdf";
        //    return new FileStream(file, FileMode.Open, FileAccess.Read);
        //}
    }
}
