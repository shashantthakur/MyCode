﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class masterController : ControllerBase
    {

        private readonly IMaster _master;
        public masterController(IMaster master)
        {
            _master = master;
        }

        [HttpGet("get.allmaster")]
        public async Task<ActionResult> GetAllMaster()
        {
            var Responce = _master.GetAllMaster();
            return Ok(Responce.Result);
        }

        [HttpGet("get.clients")]
        public List<Clients> GetClients()
        {
            return _master.GetClients();
        }

        [HttpGet("get.currency")]
        public List<Currency> GetCurrency()
        {
            return _master.GetCurrency();
        }

        [HttpGet("get.rateunit")]
        public List<MasterRateUnit> GetRateUnit()
        {
            return _master.GetRateUnit();
        }
     
        [HttpGet("get.location")]
        public List<Locations> GetLocations()
        {
            return _master.GetLocations();
        }

        [HttpGet("get.languages")]
        public List<Languages> GetLanguages()
        {
            return _master.GetLanguages();
        }

        [HttpGet("get.skills")]
        public List<Skills> GetSkills()
        {
            return _master.GetSkills();
        }

        [HttpGet("get.stylesheets")]
        public List<Stylesheets> GetStylesheets()
        {
            return _master.GetStylesheets();
        }

        [HttpGet("get.systemfamilarity")]
        public List<SystemFamilarity> GetSystemFamilarity()
        {
            return _master.GetSystemFamilarity();
        }

        [HttpGet("get.subjectmatterexpertise")]
        public List<SubjectMatterExpertise> GetSubjectMatterExpertise()
        {
            return _master.GetSubjectMatterExpertise();
        }

        [HttpGet("get.subjectmatterexpertise.group")]
        public List<SubjectMatterExpertiseGroup> GetSubjectMatterExpertiseGroup()
        {
            return _master.GetSubjectMatterExpertiseGroup();
        }

        [HttpGet("get.ratings")]
        public List<Rating> GetRating()
        {
            return _master.GetRating();
        }

        [HttpGet("get.ratingcategories")]
        public List<RatingCategories> GetRatingCategories()
        {
            return _master.GetRatingCategories();
        }


        [HttpGet("get.roleslist/{RolesFrom}")]
        public List<Roles> GetRoles(string RolesFrom)
        {
            return _master.GetRoles(RolesFrom);
        }

        [HttpGet("get.Qualification")]
        public IEnumerable<Qualifications> GetQualification()
        {
            return _master.GetQualifications();
        }


        [HttpGet("get.agency")]
        public List<AgencyMaster> GetAgency()
        {
            return _master.GetAgency();
        }
        [HttpGet("get.GetUserRoles")]
        public object GetUserRoles(bool isPM, string User_Role)
        {
            return CommonFunctions.GetUserRoles(isPM, User_Role, _master.GetRoles(""));
        }


        [HttpGet("get.distinctjobs")]
        public List<SelectList> GetDistinctJobs()
        {
            return _master.GetDistinctJobs();
        }

        [HttpGet("get.distinctauthors")]
        public List<SelectList> GetDistinctAuthors()
        {
            return _master.GetDistinctAuthors();
        }

        [HttpGet("get.distinctusers/UserRole")]
        public List<SelectList> GetDistinctUsers(string UserRole)
        {
            return _master.GetDistinctUsers(UserRole);
        }
    }
}
