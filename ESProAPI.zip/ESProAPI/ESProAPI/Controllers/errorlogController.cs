﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Service;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
  
    public class errorlogController : ControllerBase
    {
        // GET: api/errorlog

        private readonly IErrorLog _errorLogService;
        public errorlogController(IErrorLog errorLogService)
        {
            _errorLogService = errorLogService;
        }

        [HttpPost("log")]
        public async Task<IActionResult> Post([FromBody] ErrorLog errorLog)
        {
            ApiResponce apiResponce = new ApiResponce();
            int cnt = _errorLogService.InsertErrorLog(errorLog);
            apiResponce.Text = "success";
            return Ok(apiResponce);
        }

       
    }
}
