﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ESPro.Core.Entity.HSBC;
using ESPro.Core.Entity.Invoice;
using ESPro.Core.Interface;
using ESPro.Core.Interface.HSBC;
using ESPro.Infrastructure.Class;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using OfficeOpenXml.Style;

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class HSBCController : ControllerBase
    {
        private readonly IInvoice _invoice;
        private readonly IHSBC _hSBC;
        private readonly IPGP _pgp;
        public IHostingEnvironment _hostingEnvironment { get; }
        public IConfiguration _Configuration { get; }
        public CommonFunctions commonFn = new CommonFunctions();

        public HSBCController(IPGP pGP, IHSBC hSBC, IInvoice invoice, IConfiguration configuration, IHostingEnvironment hostingEnvironment)
        {
            _pgp = pGP;
            _hSBC = hSBC;
            _hostingEnvironment = hostingEnvironment;
            _Configuration = configuration;
            _invoice = invoice;
        }

       
        [HttpGet("GetBankAccount/{ProjectCode}")]
        public IEnumerable<MasterBankAccount> GetBankAccount(string ProjectCode)
        {
            IEnumerable<MasterBankAccount> _BankAccount = _hSBC.GetBankAccount(ProjectCode);
            return _BankAccount;
        }

        
        [HttpPost("GetPaymentType")]
        public IEnumerable<MasterPaymentType> GetPaymentType([FromBody] SearchPaymentMethodParameters datas)
        {
            IEnumerable<MasterPaymentType> _BankAccount = _hSBC.GetPaymentType(datas.ProjectCode, datas.BankAccountId);
            return _BankAccount;
        }

        
        [HttpGet("GetPaymentStatusList/{UserRole}")]
        public object GetPaymentStatusList(string UserRole)
        {
            return _hSBC.GetPaymentStatusList(UserRole);
        }

       
        [HttpPost("GetAmountToBePaid")]
        public string GetAmountToBePaid([FromBody] SearchAmountToBePaidParameters datas)
        {
            decimal AmountToBePaid = 0;
            List<Invoice> invoices = _invoice.GeInvoicesforAPApproval(datas.InvoiceSummaryIDs.TrimStart(',').Trim());
            for (int i = 0; i < invoices.Count; i++)
            {
                if (invoices[i].ContractedCurrency == datas.BankCurrency)
                    AmountToBePaid = AmountToBePaid + Convert.ToDecimal(invoices[i].TotalAmount) + Convert.ToDecimal(invoices[i].BankingCharges);
                else
                {
                    string exchangeRate = "";
                    string totalAmount = CommonResource.CurrencyConversion(Convert.ToDecimal("0" + invoices[i].TotalAmount) + Convert.ToDecimal("0" + invoices[i].BankingCharges), invoices[i].ContractedCurrency, datas.BankCurrency, out exchangeRate);
                    AmountToBePaid = AmountToBePaid + Convert.ToDecimal(totalAmount);
                }
            }

            List<BankTransactionHistory> lstBankTransactionHistory = new List<BankTransactionHistory>();
            lstBankTransactionHistory = _hSBC.GetBankTransactionHistory(datas.ProjectCode, "", "", "YTS,WIP", "", "", datas.BankAccountId, "");
            for (int i = 0; i < lstBankTransactionHistory.Count; i++)
            {
                if (lstBankTransactionHistory[i].ContractCurrency == datas.BankCurrency)
                    AmountToBePaid = AmountToBePaid + Convert.ToDecimal(lstBankTransactionHistory[i].TotalAmount) + Convert.ToDecimal(lstBankTransactionHistory[i].WireFee);
                else
                {
                    string exchangeRate = "";
                    string totalAmount = CommonResource.CurrencyConversion(Convert.ToDecimal("0" + lstBankTransactionHistory[i].TotalAmount) + Convert.ToDecimal("0" + lstBankTransactionHistory[i].WireFee), lstBankTransactionHistory[i].ContractCurrency, datas.BankCurrency, out exchangeRate);
                    AmountToBePaid = AmountToBePaid + Convert.ToDecimal(totalAmount);
                }
            }

            return Convert.ToString(Math.Round(AmountToBePaid, 2));
        }

      
        [HttpPost("GetBankTransactionHistory")]
        public object GetBankTransactionHistory([FromBody] BankTransactionHistoryParameters datas)
        {
            List<BankTransactionHistory> lstBankTransactionHistory = new List<BankTransactionHistory>();
            lstBankTransactionHistory = _hSBC.GetBankTransactionHistory(datas.ProjectCode, datas.StartDate, datas.EndDate, datas.Status, datas.Role, Convert.ToString(datas.UsersID), 0, "");

            return lstBankTransactionHistory;
            //string InvoiceSummaryIDs = string.Join(',', lstBankTransactionHistory.Select(c => c.InvoiceSummaryID).ToList());

            //IEnumerable<InvoiceBankInfo> _BankAccount = _hSBC.GetInvoiceBankInfo(InvoiceSummaryIDs);

            //for (int i = 0; i < lstBankTransactionHistory.Count; i++)
            //{
            //    lstBankTransactionHistory[i].FreelancerName = _BankAccount.Where(a => a.InvoiceID == lstBankTransactionHistory[i].InvoiceSummaryID).Select(c => c.ProfileName).ToList().Count > 0 ? _BankAccount.Where(a => a.InvoiceID == lstBankTransactionHistory[i].InvoiceSummaryID).Select(c => c.ProfileName).ToList()[0] : "";
            //    lstBankTransactionHistory[i].PMApproveDate = _BankAccount.Where(a => a.InvoiceID == lstBankTransactionHistory[i].InvoiceSummaryID).Select(c => c.PMApproveDate).ToList().Count > 0 ? _BankAccount.Where(a => a.InvoiceID == lstBankTransactionHistory[i].InvoiceSummaryID).Select(c => c.PMApproveDate).ToList()[0] : "";
            //    lstBankTransactionHistory[i].APApproveDate = _BankAccount.Where(a => a.InvoiceID == lstBankTransactionHistory[i].InvoiceSummaryID).Select(c => c.APApproveDate).ToList().Count > 0 ? _BankAccount.Where(a => a.InvoiceID == lstBankTransactionHistory[i].InvoiceSummaryID).Select(c => c.APApproveDate).ToList()[0] : "";
            //}

            //List<string> Freelancers = lstBankTransactionHistory.Select(a => a.FreelancerName).Distinct().ToList();
            //if (!(datas.FreelancerFilter.Count == 1 && datas.FreelancerFilter.Where(a => a == "0").Count() > 0))
            //    lstBankTransactionHistory = lstBankTransactionHistory.Where(a => datas.FreelancerFilter.Where(b => a.FreelancerName == b).Count() > 0).ToList();

            //List<string> InvoiceNames = lstBankTransactionHistory.Select(a => a.InvoiceName).Distinct().ToList();
            //if (!(datas.InvoiceNameFilter.Count == 1 && datas.InvoiceNameFilter.Where(a => a == "0").Count() > 0))
            //    lstBankTransactionHistory = lstBankTransactionHistory.Where(a => datas.InvoiceNameFilter.Where(b => a.InvoiceName == b).Count() > 0).ToList();

            //var response = commonFn.TableResponce(lstBankTransactionHistory, datas.sort, datas.dir, datas.currentpage, datas.pageSize);
            //var data = new
            //{
            //    Freelancers = Freelancers,
            //    Invoices = InvoiceNames,
            //    response = response
            //};
            //return data;
        }



      
        [HttpGet("GetPaymentTypeFieldValidation/{PaymentTypeId}")]
        public IEnumerable<MasterPaymentTypeFieldValidation> GetPaymentTypeFieldValidation(int PaymentTypeId)
        {
            IEnumerable<MasterPaymentTypeFieldValidation> _PaymentTypeFieldValidation = _hSBC.GetPaymentTypeFieldValidation(PaymentTypeId);
            return _PaymentTypeFieldValidation;
        }

        //[AllowAnonymous]
        [HttpPost("GetInvoiceBankInfo")]
        public string GetInvoiceBankInfo(string InvoiceSummaryIDs)
        {
            List<InvoiceBankInfo> _BankAccount = _hSBC.GetInvoiceBankInfo(InvoiceSummaryIDs);
            InvoiceBankInfoList invoiceBankInfoList = new InvoiceBankInfoList();
            invoiceBankInfoList.invoiceBankInfosList = _BankAccount;
            var json = Newtonsoft.Json.JsonConvert.SerializeObject(invoiceBankInfoList);

            PGPData pGPData = new PGPData();
            pGPData.Text = json;

            PGPController pGPController = new PGPController(_pgp, _Configuration, _hostingEnvironment);

            string EncryptData = pGPController.LuminaEncrypt(pGPData);

            PGPData TpGPData = new PGPData();
            TpGPData.Text = EncryptData;

            pGPController.Decrypt(TpGPData);
            return EncryptData;
        }

        [HttpPost("InsertInvoiceInfo")]
        public async Task<IActionResult> InsertInvoiceInfo([FromBody] InvoiceInfo _invoiceInfo)
        {
            ApiResponce apiResponce = new ApiResponce();
            Boolean flag = _hSBC.InsertInvoiceInfo(_invoiceInfo);
            if (flag)
            {
                apiResponce.Text = "Success";
            }
            else
            {
                apiResponce.Text = "Fail";
            }
            return Ok(apiResponce);
        }

        [HttpPost("deactive.invoice")]
        public async Task<IActionResult> DeActiveInvoice([FromBody] DeActiveInvoiceParameters deActiveInvoiceParameters)
        {
            ApiResponce apiResponce = new ApiResponce();
            Boolean flag = _hSBC.DeActiveInvoice(deActiveInvoiceParameters);
            if (flag)
            {
                apiResponce.Text = "Success";
            }
            else
            {
                apiResponce.Text = "Fail";
            }
            return Ok(apiResponce);
        }


        [HttpPost("GetStatusDetails")]
        public async Task<IActionResult> GetStatusDetails([FromBody] StatusDetailsParameters statusDetailsParameters)
        {
            ApiResponce apiResponce = new ApiResponce();
            StatusDetails StatusDetails = _hSBC.GetStatusDetails(statusDetailsParameters.TransactionDetailsId.Value, statusDetailsParameters.ProjectCode);
            if (StatusDetails != null && !string.IsNullOrEmpty(StatusDetails.StatusResponseBase64))
            {
                System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
                doc.LoadXml(StatusDetails.StatusResponseBase64);

                System.Xml.XmlNodeList node = doc.GetElementsByTagName("DbtrAcct");
                if(node!=null && node.Count>0)
                {
                    node[0].ParentNode.RemoveChild(node[0]);
                }

                node = doc.GetElementsByTagName("DbtrAgt");
                if (node != null && node.Count > 0)
                {
                    node[0].ParentNode.RemoveChild(node[0]);
                }

               
                string jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(doc, Newtonsoft.Json.Formatting.Indented);
                StatusDetails.StatusResponseBase64 = jsonString;
            }
            if (StatusDetails != null && !string.IsNullOrEmpty(StatusDetails.PaymentResponseBase64))
            {
                System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
                doc.LoadXml(StatusDetails.PaymentResponseBase64);
                string jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(doc.GetElementsByTagName("Document"), Newtonsoft.Json.Formatting.Indented);
                StatusDetails.PaymentResponseBase64 = jsonString;
            }

            return Ok(StatusDetails);
        }

        
        [HttpGet("GetBankBalance")]
        public async Task<IActionResult> GetBankBalance(string ProjectCode)
        {
            Boolean Success = false;
            ApiResponce apiResponce = new ApiResponce();
            IEnumerable<BankAccountBalance> bankAccountBalance = _hSBC.GetBankAccountBalance(ProjectCode);
            if (bankAccountBalance.Count() > 0)
            {
                foreach (BankAccountBalance item in bankAccountBalance)
                {
                    BalanceEnq balanceEnq = new BalanceEnq();
                    accountDetails accountDetails = new accountDetails();
                    if (item.Location == "GB")
                    {
                        accountDetails.accountNumber = item.RoutingId.ToString() + item.AccountNumber.ToString();
                    }
                    else
                    {
                        accountDetails.accountNumber = item.AccountNumber.ToString();
                    }
                    accountDetails.accountCountry = item.Location;
                    accountDetails.institutionCode = item.institutionCode;
                    accountDetails.accountType = item.AccountType;
                    balanceEnq.accountBalances.Add(accountDetails);

                    string jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(balanceEnq);
                    PGPData pGPData = new PGPData();
                    pGPData.Text = jsonString;
                    PGPController pGPController = new PGPController(_pgp, _Configuration, _hostingEnvironment);
                    string EncryptData = pGPController.Encrypt(pGPData);
                    BalanceEnqResponce _balanceEnqResponce = _hSBC.CallBalanceApi(_Configuration, EncryptData);

                    if (!string.IsNullOrEmpty(_balanceEnqResponce.reportBase64))
                    {
                        pGPData.Text = _balanceEnqResponce.reportBase64;
                        string DecryptData = pGPController.Decrypt(pGPData);
                        BalancereportBase64 balancereportBase64 = Newtonsoft.Json.JsonConvert.DeserializeObject<BalancereportBase64>(DecryptData);
                        string Balance = balancereportBase64.balances[0].balance.Where(a => a.type == "OPAV").FirstOrDefault().amount.amount;
                        item.Balance = Balance;
                        _hSBC.UpdateAccountBalance(item.BankAccountId.Value, Balance);
                        Success = true;
                    }
                    else
                        Success = false;
                }

            }
            if (Success == true)
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }

        [HttpGet("GetTransactionDetails")]
        public IEnumerable<TransactionsReportBase64> GetTransactionDetails(string ProjectCode, string TransactionDate)
        {
            List<TransactionsReportBase64> transactionsReportBase64 = new List<TransactionsReportBase64>();
            IEnumerable<BankAccountBalance> bankAccountBalance = _hSBC.GetBankAccountBalance(ProjectCode);

            if (bankAccountBalance.Count() > 0)
            {
                foreach (BankAccountBalance item in bankAccountBalance)
                {
                    TransactionMaster _transaction = new TransactionMaster();

                    if (item.Location == "GB")
                    {
                        _transaction.accountNumber = item.RoutingId.ToString() + item.AccountNumber.ToString();
                    }
                    else
                    {
                        _transaction.accountNumber = item.AccountNumber.ToString();
                    }
                    if (String.IsNullOrEmpty(TransactionDate))
                    {
                        _transaction.transactionDate = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd");
                    }
                    else
                    {
                        _transaction.transactionDate = TransactionDate;
                    }
                    _transaction.transactionTimeFrom = "";
                    _transaction.transactionTimeTo = "";
                    _transaction.accountCountry = item.Location;
                    _transaction.institutionCode = item.institutionCode;
                    _transaction.accountType = item.AccountType;
                    //transactionEnq.accountBalances.Add(accountDetails);

                    string jsonString = Newtonsoft.Json.JsonConvert.SerializeObject(_transaction);


                    PGPData pGPData = new PGPData();
                    pGPData.Text = jsonString;
                    PGPController pGPController = new PGPController(_pgp, _Configuration, _hostingEnvironment);
                    string EncryptData = pGPController.Encrypt(pGPData);
                    TransactionEnqResponce _transactionEnqResponce = _hSBC.CallTransactionApi(_Configuration, EncryptData);

                    if (!string.IsNullOrEmpty(_transactionEnqResponce.reportBase64))
                    {
                        pGPData.Text = _transactionEnqResponce.reportBase64;
                        string DecryptData = pGPController.Decrypt(pGPData);
                        TransactionsReportBase64 _transactions = Newtonsoft.Json.JsonConvert.DeserializeObject<TransactionsReportBase64>(DecryptData);
                        transactionsReportBase64.Add(_transactions);
                        //string Balance = balancereportBase64.balances[0].balance.Where(a => a.type == "ITAV").FirstOrDefault().amount.amount;
                        //item.Balance = Balance;
                        //_hSBC.UpdateAccountBalance(item.BankAccountId.Value, Balance);
                    }
                }

            }
            return transactionsReportBase64;//bankAccountBalance;
        }
    }
}