﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ESPro.Core.Entity;
using ESPro.Core.Entity.Invoice;
using ESPro.Core.Entity.Report;
using ESPro.Core.Entity.Search;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using OfficeOpenXml;
using OfficeOpenXml.Style;

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class ReportController : ControllerBase
    {
        private readonly ISmartAssessor _smartAssessor;
        private readonly IInvoice _invoice;
        private readonly IReport _report;
        private readonly ISearch _search;
        private readonly IMaster _master;
        private readonly ITrainingMaterial _trainingMaterial;
        private readonly IDemographicData _DemographicData;
        public IConfiguration _configuration { get; }

        public CommonFunctions commonFn = new CommonFunctions();

        public ReportController(ISearch search, IReport report, IConfiguration configuration, IMaster master, IInvoice invoice, ISmartAssessor smartAssessor, ITrainingMaterial trainingMaterial, IDemographicData demographicData)
        {
            _search = search;
            _report = report;
            _configuration = configuration;
            _master = master;
            _invoice = invoice;
            _smartAssessor = smartAssessor;
            _trainingMaterial = trainingMaterial;
            _DemographicData = demographicData;
        }

        [HttpGet("get.reporttypelist")]
        public object GetReportTypes(string UserRole, int ClientId)
        {
            return _report.GetReportTypes(UserRole, ClientId);
        }

        [HttpGet("get.customersworked")]
        public object GetCustomerWorked()
        {
            return _report.GetCustomerWorked();
        }

        [HttpGet("get.overduereporttypelist/{UserRole}")]
        public object GetOverdueReportTypes(string UserRole)
        {
            return _report.GetOverdueReportTypes(UserRole);
        }

        [HttpGet("get.ratingcompositereporttypelist/{UserRole}")]
        public object GetRatingCompositeReportTypes(string UserRole)
        {
            return _report.GetRatingCompositeReportTypes(UserRole);
        }

        [HttpGet("get.testcompleteduserslist/{UserRole}/{ReportID}")]
        public object GetTestCompletedUsers(string UserRole, int ReportID)
        {
            return _report.GetTestCompletedUsers(UserRole, ReportID);
        }

        [HttpGet("get.customeroles/{ClientCode}")]
        public object GetAllCustomeRoles(int ClientCode)
        {
            return _report.GetAllCustomeRoles(ClientCode);
        }

        [HttpPost("export.report")]
        public IActionResult ExportFile([FromBody] ReportParameters datas)
        {
            List<DemographicDataReport> lstDemographicDataReport = new List<DemographicDataReport>();
            List<ServiceReport> lstServiceReport = new List<ServiceReport>();
            List<RatingReport> lstRatingReport = new List<RatingReport>();
            List<OverDueReport> lstOverDueReport = new List<OverDueReport>();
            List<PersonalInsights> lstPersonalInsights = new List<PersonalInsights>();
            List<PredictiveTestingReport> lstPredictiveTestingReports = new List<PredictiveTestingReport>();
            List<RatingCompositeReport> lstRatingCompositeReports = new List<RatingCompositeReport>();
            List<FLInvoicesPendingPMApprovalReport> lstFLInvoicesPendingPMApprovalReports = new List<FLInvoicesPendingPMApprovalReport>();
            List<RatingHistoryReport> lstRatingHistoryReport = new List<RatingHistoryReport>();
            List<LuminaFreelancerCost> lstLuminaFreelancerCosts = new List<LuminaFreelancerCost>();
            List<WileyFreelancerCost> lstWileyFreelancerCosts = new List<WileyFreelancerCost>();
            List<TaskReport> lstTaskReports = new List<TaskReport>();
            List<FreelancerRollOff> lstFreelancerRollOffs = new List<FreelancerRollOff>();
            List<Invoice> lstInvoices = new List<Invoice>();
            List<AdHocMLReport> lstAdHocMLReport = new List<AdHocMLReport>();
            List<MacMillanFreelancerDetails> lstMacMillanFreelancerDetails = new List<MacMillanFreelancerDetails>();
            List<MacMillanCompletedJobs> lstMacMillanCompletedJobs = new List<MacMillanCompletedJobs>();
            List<MacMillanPendingJobs> lstMacMillanPendingJobs = new List<MacMillanPendingJobs>();

            DataTable dtToExport = new DataTable();
            DataTable dtToExport1 = new DataTable();
            DataTable dtToExport2 = new DataTable();
            string TemplateFile = "";
            string ExportFileName = "";
            string FromRows = "A2";
            string ToRows = "";
            int HeaderLength = 1;
            if (datas.ReportID == 1)
            {
                ToRows = "R";
                lstServiceReport = _report.GetServiceReportList(datas.StartDate, datas.EndDate, datas.Role, datas.UserEmailID, datas.ClientCode);
                dtToExport = commonFn.ToDataTable(lstServiceReport);
                TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "ServiceReport.xlsx");
                if (datas.StartDate == "" && datas.EndDate == "")
                    ExportFileName = "Services.xlsx";
                else if (datas.StartDate != "" && datas.EndDate != "")
                    ExportFileName = "Services" + "_" + datas.StartDate + "_" + datas.EndDate + ".xlsx";
                else if (datas.EndDate != "")
                    ExportFileName = "Services" + "_till_" + datas.EndDate + ".xlsx";
                else if (datas.StartDate != "")
                    ExportFileName = "Services" + "_from_" + datas.StartDate + ".xlsx";
            }
            else if (datas.ReportID == 2 || datas.ReportID == 3)
            {
                ToRows = "M";
                TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "Rating.xlsx");
                if (datas.ReportID == 2)
                {
                    lstRatingReport = _report.GetRatingReportList(datas.UserEmailID, datas.Role, "NO");
                    ExportFileName = "Ratings_Report.xlsx";
                }
                else
                {
                    lstRatingReport = _report.GetRatingReportList(datas.UserEmailID, datas.Role, "YES");
                    ExportFileName = "Rating_by_Skill_Report.xlsx";
                }
                dtToExport = commonFn.ToDataTable(lstRatingReport);
                foreach (DataRow datarow in dtToExport.Rows)
                {
                    datarow[12] = Regex.Replace(datarow[12].ToString(), "<<([^>]+)>>", "");
                }
            }
            else if (datas.ReportID == 4)
            {
                ToRows = "S";
                lstOverDueReport = _report.GetOverDueReportList(datas.UserEmailID, datas.Role, datas.ClientCode, datas.OverdueReportID);
                dtToExport = commonFn.ToDataTable(lstOverDueReport);
                TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "OverDueReport.xlsx");
                ExportFileName = "Overdue_Ratings.xlsx";
                if (datas.OverdueReportID == 1)
                {
                    ExportFileName = "Lumina_Overdue_Ratings.xlsx";
                    dtToExport.Columns.Remove("CustomerContactName");
                    dtToExport.Columns.Remove("CustomerContactEmail");
                    dtToExport.AcceptChanges();
                }
                else if (datas.OverdueReportID == 2)
                {
                    ExportFileName = "Wiley_Overdue_Ratings.xlsx";
                    dtToExport.Columns.Remove("CustomerContactName");
                    dtToExport.Columns.Remove("CustomerContactEmail");
                    dtToExport.AcceptChanges();
                }
                else if (datas.OverdueReportID == 3)
                {
                    ExportFileName = "Macmilan_Overdue_Ratings.xlsx";
                    ToRows = "U";
                }
                else if (datas.OverdueReportID == 0 && datas.ClientCode != 3)
                {
                    dtToExport.Columns.Remove("CustomerContactName");
                    dtToExport.Columns.Remove("CustomerContactEmail");
                    dtToExport.AcceptChanges();
                }
            }
            else if (datas.ReportID == 5)
            {
                ToRows = "BD";
                lstPersonalInsights = _report.GetPersonalInsightsList(datas.Role).Where(a => a.Result != null).ToList();
                dtToExport = commonFn.ToDataTable(lstPersonalInsights);
                dtToExport = _report.PersonalInsightsInfo(dtToExport);
                TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "PersonalInsightReport.xlsx");
                ExportFileName = "Personality_Insights.xlsx";
            }
            else if (datas.ReportID == 6)
            {
                List<Skills> skills = _master.GetSkills();
                List<CustomeRoles> customeRoles = _report.GetAllCustomeRoles(0);
                //var selectedrolesList = customeRoles.Where(a => datas.CustomeRoles.Split(',').Where(b => Convert.ToString(a.ID) == b).Count() > 0).Select(c => c.RoleName).ToList();
                //string selectedroles = string.Join(',', selectedrolesList);
                datas.Skills = string.Join(',', skills.Where(a => datas.Skills.Split(',').Where(b => Convert.ToString(a.SkillsId) == b).Count() > 0).Select(c => c.SkillName).ToList());
                datas.CustomeRoles = string.Join(',', customeRoles.Where(a => datas.CustomeRoles.Split(',').Where(b => Convert.ToString(a.ID) == b).Count() > 0).Select(c => c.RoleName).ToList());

                ToRows = "I";
                TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "MatchingProfile.xlsx");
                ExportFileName = "MatchingProfile.xlsx";
                List<TestResultCompleted> lstTestResultCompleted = new List<TestResultCompleted>();
                List<ExistingRecord> existingRecords = _search.GetSelectedSkillFreelancer(string.Empty, Convert.ToInt32(datas.FreelancerName.Split("##")[0]));
                if (datas.FreelancerName != null)
                {
                    int totalcount = 0;
                    SearchParameters datavariables = new SearchParameters();
                    datavariables.sort = "";
                    datavariables.pageSize = 5;
                    datavariables.currentpage = -1;
                    var data = _search.GetFreelancerTabDetailsQM(Convert.ToInt32(datas.UsersId), datas.Role, datas.ClientCode.ToString(), out totalcount, "FREELANCER", "", datavariables);
                    Int32 UsersID = Convert.ToInt32(datas.FreelancerName.Split(new string[] { "##" }, StringSplitOptions.RemoveEmptyEntries)[0]);
                    var FreelancerInfo = data.Where(z => z.ID == UsersID).FirstOrDefault();
                    if (FreelancerInfo != null)
                    {
                        TestResultCompleted ObjlstTestResultCompleted = new TestResultCompleted();
                        ObjlstTestResultCompleted.userName = FreelancerInfo.Username;
                        ObjlstTestResultCompleted.userId = FreelancerInfo.User_id;
                        var MatchSkills = String.IsNullOrEmpty(datas.Skills) ? string.Empty : datas.Skills;
                        var MatchDis = String.IsNullOrEmpty(datas.Disciplines) ? String.Empty : datas.Disciplines;
                        var MatchRole = String.IsNullOrEmpty(datas.CustomeRoles) ? String.Empty : datas.CustomeRoles;

                        var ObjResult = commonFn.FillCompletedTestCorrelationResultAsync(Convert.ToInt32(UsersID), MatchSkills.Split(',').ToList(), MatchRole.Split(',').ToList(), MatchDis.Split(',').ToList(), datas.Role, datas.CurrentUserId);
                        var Result = ObjResult.Result;
                        if (Result == null)
                            ObjlstTestResultCompleted.lstTestCompleted = new List<TestCompleted>();
                        else
                            ObjlstTestResultCompleted.lstTestCompleted = Result;
                        lstTestResultCompleted.Add(ObjlstTestResultCompleted);
                    }
                }
                dtToExport = GenrateReprot(lstTestResultCompleted);

            }
            else if (datas.ReportID == 7)
            {
                ToRows = "H";
                //lstPredictiveTestingReports = _report.GetPredictiveTestingList(datas.Role);
                //dtToExport = commonFn.ToDataTable(lstPredictiveTestingReports);
                dtToExport = _report.GetPredictiveTestingList(datas.Role);
                TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "PredictiveTestingResultReport.xlsx");
                ExportFileName = "Predictive_Testing_Status.xlsx";
            }
            else if (datas.ReportID == 14)
            {
                ToRows = "BL";
                lstRatingCompositeReports = _report.GetRatingCompositeReports(datas.ClientCode, datas.CustomeRoles, datas.Role, datas.RatingCompositeReportID);
                dtToExport = commonFn.ToDataTable(lstRatingCompositeReports);
                dtToExport = _report.DTRatingCompositeReport(dtToExport);
                TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "RatingsandTestingComposite.xlsx");
                ExportFileName = "Ratings_Testing_Composite.xlsx";
                if (datas.RatingCompositeReportID == 2)
                    ExportFileName = "Wiley_Ratings_Testing_Composite.xlsx";
                else if (datas.RatingCompositeReportID == 3)
                    ExportFileName = "Lumina_Personnel_Ratings_Testing_Composite.xlsx";
            }
            else if (datas.ReportID == 18)
            {
                ToRows = "J";
                lstFLInvoicesPendingPMApprovalReports = _report.GetFLInvoicesPendingPMApprovalReports("Wiley");
                dtToExport = commonFn.ToDataTable(lstFLInvoicesPendingPMApprovalReports);
                dtToExport.Columns.Remove("Vertical");
                dtToExport.Columns.Remove("Service");
                dtToExport.Columns.Remove("Status");
                //dtToExport.Columns.Remove("InvoiceDate");
                dtToExport.Columns.Remove("InvApproveDate1");
                dtToExport.Columns.Remove("InvApproverName");
                dtToExport.Columns.Remove("InvApproverEmail");
                dtToExport.Columns.Remove("InvApproverName2");
                dtToExport.Columns.Remove("InvApproverEmail2");
                dtToExport.AcceptChanges();
                TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "WileyFreelanceInvoicesPendingApprovalReport.xlsx");
                ExportFileName = "Wiley_Freelance_Invoices_Pending_Approval_Report.xlsx";
            }
            else if (datas.ReportID == 19)
            {
                ToRows = "R";
                lstFLInvoicesPendingPMApprovalReports = _report.GetFLInvoicesPendingPMApprovalReports("Lumina");
                dtToExport = commonFn.ToDataTable(lstFLInvoicesPendingPMApprovalReports);
                TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "LuminaFreelanceInvoicesPendingApprovalReport.xlsx");
                ExportFileName = "Lumina_Freelance_Invoices_Pending_PM_Approval.xlsx";
            }
            else if (datas.ReportID == 12)
            {
                ToRows = "R";
                lstRatingHistoryReport = _report.GetRatingHistoryReports(datas.UserEmailID, "", datas.ClientCode, datas.Role);
                dtToExport = commonFn.ToDataTable(lstRatingHistoryReport);
                if (dtToExport.Columns.Contains("RatingId"))
                    dtToExport.Columns.Remove("RatingId");
                if (dtToExport.Columns.Contains("JobId"))
                    dtToExport.Columns.Remove("JobId");
                if (dtToExport.Columns.Contains("PMEmailID"))
                    dtToExport.Columns.Remove("PMEmailID");
                TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "RatingReport.xlsx");
                ExportFileName = "Rating_History_Report.xlsx";
            }
            else if (datas.ReportID == 13)
            {
                ToRows = "X";
                lstLuminaFreelancerCosts = _report.GetLuminaFreelancerCosts(datas.StartDate, datas.EndDate, datas.ClientCode);
                dtToExport = commonFn.ToDataTable(lstLuminaFreelancerCosts);
                TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "Lumina_Freelancer_Cost.xlsx");
                if (datas.StartDate == "" && datas.EndDate == "")
                    ExportFileName = "Lumina_Freelancer_Cost.xlsx";
                else if (datas.StartDate != "" && datas.EndDate != "")
                    ExportFileName = "Lumina_Freelancer_Cost" + "_" + datas.StartDate + "_" + datas.EndDate + ".xlsx";
                else if (datas.EndDate != null)
                    ExportFileName = "Lumina_Freelancer_Cost" + "_till_" + datas.EndDate + ".xlsx";
            }
            else if (datas.ReportID == 20 || datas.ReportID == 26 || datas.ReportID == 27)
            {
                FromRows = "A5";
                ToRows = "X";
                HeaderLength = 4;

                if (datas.ReportID == 20)
                    lstWileyFreelancerCosts = _report.GetWileyFreelancerCost(datas.StartDate, datas.EndDate, datas.ClientCode, "USD", "2021-02-23");
                else if (datas.ReportID == 26)
                    lstWileyFreelancerCosts = _report.GetWileyFreelancerCost(datas.StartDate, datas.EndDate, datas.ClientCode, "GBP", "2021-02-23");
                else
                    lstWileyFreelancerCosts = _report.GetWileyFreelancerCost(datas.StartDate, datas.EndDate, datas.ClientCode, "", "2021-02-23");

                dtToExport = commonFn.ToDataTable(lstWileyFreelancerCosts);
                TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "Wiley_Freelancer_Cost.xlsx");
                if (datas.StartDate == "" && datas.EndDate == "")
                    ExportFileName = "Wiley_Freelancer_Cost.xlsx";
                else if (datas.StartDate != "" && datas.EndDate != "")
                    ExportFileName = "Wiley_Freelancer_Cost" + "_" + datas.StartDate + "_" + datas.EndDate + ".xlsx";
                else if (datas.EndDate != "")
                    ExportFileName = "Wiley_Freelancer_Cost" + "_till_" + datas.EndDate + ".xlsx";
                else if (datas.StartDate != "")
                    ExportFileName = "Wiley_Freelancer_Cost" + "_from_" + datas.StartDate + ".xlsx";

                if (datas.ReportID == 20)
                    ExportFileName = ExportFileName.Replace("Wiley_Freelancer_Cost", "Wiley_Freelancer_Cost_non-GBP_Euro");
                else if (datas.ReportID == 26)
                    ExportFileName = ExportFileName.Replace("Wiley_Freelancer_Cost", "Wiley_Freelancer_Cost_GBP_Euro");
                else
                    ExportFileName = ExportFileName.Replace("Wiley_Freelancer_Cost", "Wiley_Freelancer_Cost_All_Currency_Till_22nd_Feb");
            }
            else if (datas.ReportID == 11)
            {
                ToRows = "R";
                lstTaskReports = _report.GetTaskReport(datas.UserEmailID, datas.Role, datas.Skills, datas.ClientCode);
                dtToExport = commonFn.ToDataTable(lstTaskReports);
                if (datas.ClientCode != 0)
                {
                    ToRows = "N";
                    dtToExport.Columns.Remove("empno");
                    dtToExport.Columns.Remove("EmpSupervisor");
                    dtToExport.Columns.Remove("EmpDesignation");
                    dtToExport.Columns.Remove("EmpCity");
                    dtToExport.AcceptChanges();
                }
                TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "TaskWiseReport.xlsx");
                ExportFileName = "Task_Report.xlsx";
            }
            else if (datas.ReportID == 21)
            {
                ToRows = "V";
                lstOverDueReport = _report.GetOverDueEndDateReportList();
                dtToExport = commonFn.ToDataTable(lstOverDueReport);
                TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "OverDueReport.xlsx");
                ExportFileName = "Overdue_End_Date_Report.xlsx";
            }
            else if (datas.ReportID == 22)
            {
                ToRows = "T";
                lstFreelancerRollOffs = _report.GetFreelancerRollOff();
                dtToExport = commonFn.ToDataTable(lstFreelancerRollOffs);
                TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "Freelancer_Roll-Off.xlsx");
                ExportFileName = "Freelancer_Roll-Off.xlsx";
            }
            else if (datas.ReportID == 23)
            {
                ToRows = "AG";
                int total = 0;
                List<string> Jobs = null;
                List<string> Freelancers = null;
                List<string> InvoiceNames = null;
                List<string> InvApprovers = null;
                if (datas.Role == "FREELANCER")
                    lstInvoices = _invoice.GetInvoicesList(datas.StartDate, datas.EndDate, datas.InvoiceStatus == "" ? "ALL" : datas.InvoiceStatus, "", "", "", "REPORT", datas.UserEmailID, "", -1, 0, null, null, out total, out Jobs, out Freelancers, out InvoiceNames, out InvApprovers, null, null, null, null, datas.InvoiceDateType);
                else
                    lstInvoices = _invoice.GetInvoicesList(datas.StartDate, datas.EndDate, datas.InvoiceStatus == "" ? "ALL" : datas.InvoiceStatus, "", "", "", "REPORT", "", "", -1, 0, null, null, out total, out Jobs, out Freelancers, out InvoiceNames, out InvApprovers, null, null, null, null, datas.InvoiceDateType);


                dtToExport = commonFn.ToDataTable(lstInvoices);
                TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "InvoiceDetails.xlsx");
                ExportFileName = "Invoice_Status.xlsx";
            }
            else if (datas.ReportID == 24)
            {
                ToRows = "H";
                lstAdHocMLReport = _report.GetAdHocMLReport();
                dtToExport = commonFn.ToDataTable(lstAdHocMLReport);
                foreach (DataRow datarow in dtToExport.Rows)
                {
                    datarow[3] = Regex.Replace(datarow[3].ToString(), "<<([^>]+)>>", "");
                }
                TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "AdHocMLReport.xlsx");
                ExportFileName = "AdHocMLReport.xlsx";
            }
            else if (datas.ReportID == 25)
            {
                ToRows = "H";
                lstMacMillanFreelancerDetails = _report.GetMacMillanFreelancerDetails();
                lstMacMillanCompletedJobs = _report.GetMacMillanCompletedJobs();
                lstMacMillanPendingJobs = _report.GetMacMillanPendingJobs();
                dtToExport = commonFn.ToDataTable(lstMacMillanFreelancerDetails);
                dtToExport1 = commonFn.ToDataTable(lstMacMillanCompletedJobs);
                dtToExport2 = commonFn.ToDataTable(lstMacMillanPendingJobs);
                TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "MacMillanReport.xlsx");
                ExportFileName = "MacMillanReport_" + DateTime.Now.ToString("ddMMMyyyy") + ".xlsx";
            }
            else if (datas.ReportID == 28)
            {
                byte[] data = DownloadReport(datas.FreelancerName);
                if (data is null)
                    return Ok(new { data, contenttype = "application/octet-stream", filename = "Smart_Assessor_" + DateTime.Now.ToString("ddMMyyyyHHmmss") + ".xlsx", recordcount = 0 });
                else
                    return Ok(new { data, contenttype = "application/octet-stream", filename = "Smart_Assessor_" + DateTime.Now.ToString("ddMMyyyyHHmmss") + ".xlsx", recordcount = 1 });
                //dtToExport = _report.SmartAssessorReportPerTest("0", 1);
            }
            else if (datas.ReportID == 29)
            {
                ToRows = "H";
                List<TrainingVideoReport> _trainingVideoReport = _trainingMaterial.GetTrainingVideoProblemReport(datas.StartDate, datas.EndDate);
                dtToExport = commonFn.ToDataTable(_trainingVideoReport);
                dtToExport.Columns.Remove("TrainingVideoReportId");
                dtToExport.Columns.Remove("TrainingDetailsId");
                dtToExport.Columns.Remove("Anonymous");
                TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "TrainingVideoProblemReport.xlsx");
                ExportFileName = "TrainingVideoProblemReport.xlsx";
            }
            else if (datas.ReportID == 30)
            {
                ToRows = "P";
                DemographicDataReportParam demographicDataReportParam = new DemographicDataReportParam();
                demographicDataReportParam.Customers = datas.Customers;
                lstDemographicDataReport = _DemographicData.GenerateDemographicDataReport(demographicDataReportParam);
                dtToExport = commonFn.ToDataTable(lstDemographicDataReport);
                TemplateFile = Path.Combine(CommonResource.ExcelTemplatePath, "DemographicReport.xlsx");
                ExportFileName = "DemographicDataReport.xlsx";
            }

            try
            {
                byte[] data = _report.DownloadReport(dtToExport, datas.ReportID, datas.ClientCode, TemplateFile, ExportFileName, FromRows, ToRows, HeaderLength, dtToExport1, dtToExport2);
                return Ok(new { data, contenttype = "application/octet-stream", filename = ExportFileName, recordcount = dtToExport.Rows.Count });
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        [HttpPost("GetColumnLetter")]
        public static string GetColumnLetter(int column)
        {
            if (column < 1) return String.Empty;
            return GetColumnLetter((column - 1) / 26) + (char)('A' + (column - 1) % 26);
        }

        [HttpPost("DownloadReport")]
        public byte[] DownloadReport(string UserID)
        {
            int sheetcount = 0;

            using (ExcelPackage package = new ExcelPackage())
            {
                if (UserID == "" || UserID is null)
                    UserID = "0";
                List<SmartAssessorTest> lstSmartAssessorTest = new List<SmartAssessorTest>();
                lstSmartAssessorTest = _smartAssessor.GetSmartAssessorAllTestList(Convert.ToInt16(UserID));
                if (lstSmartAssessorTest.Count() > 0)
                {
                    for (int p = 0; p < lstSmartAssessorTest.Count(); p++)
                    {
                        DataTable dtToExport = _report.SmartAssessorReportPerTest(UserID, lstSmartAssessorTest[p].SmartAssessorTestID);
                        if (dtToExport.Rows.Count > 0)
                        {
                            sheetcount++;
                            package.Workbook.Worksheets.Add(lstSmartAssessorTest[p].SmartAssessorTestName);
                            OfficeOpenXml.ExcelWorksheet worksheet = package.Workbook.Worksheets[sheetcount];

                            dtToExport.Columns.Remove("TestName");
                            dtToExport.Columns.Remove("TestRegistrationID");
                            dtToExport.Columns.Remove("UserID");
                            dtToExport.AcceptChanges();

                            string ToRows = GetColumnLetter(dtToExport.Columns.Count);

                            for (int j = 0; j < dtToExport.Columns.Count; j++)
                            {
                                worksheet.Cells[1, (j + 1)].Value = Convert.ToString(dtToExport.Columns[j].ColumnName);
                            }

                            worksheet.Cells[1, 1, 1, dtToExport.Columns.Count].Style.Font.Bold = true;
                            worksheet.Cells[1, 1, 1, dtToExport.Columns.Count].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                            worksheet.Cells[1, 1, 1, dtToExport.Columns.Count].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                            worksheet.Cells[1, 1, 1, dtToExport.Columns.Count].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                            worksheet.Cells[1, 1, 1, dtToExport.Columns.Count].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                            worksheet.Cells[1, 1, 1, dtToExport.Columns.Count].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;

                            worksheet.Cells["A2"].LoadFromDataTable(dtToExport, false);

                            var modelCells = worksheet.Cells["A2"];
                            var modelRows = dtToExport.Rows.Count + 1;
                            string modelRange = "A2" + ":" + ToRows.ToString() + modelRows.ToString();
                            worksheet.Cells["A2" + ":" + ToRows.ToString() + modelRows.ToString()].Style.Font.SetFromFont(new Font("Calibri", 10));
                            var modelTable = worksheet.Cells[modelRange];
                            // Assign borders
                            modelTable.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                            modelTable.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                            modelTable.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                            modelTable.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;

                            worksheet.Cells.AutoFitColumns();
                            worksheet.Column(3).Style.Numberformat.Format = "dd-MMM-yyyy";
                        }
                    }
                    return package.GetAsByteArray();
                }
                else
                {
                    return null;
                }
            }
        }

        [HttpPost("GenrateReprot")]
        private DataTable GenrateReprot(List<TestResultCompleted> lstTestResultCompleted)
        {
            DataTable FinalData = new DataTable();
            FinalData.Columns.Add("FullName");
            FinalData.Columns.Add("UserID");
            FinalData.Columns.Add("Strength of Match[Corelation]");
            FinalData.Columns.Add("TargetHourlyRate");
            FinalData.Columns.Add("Location");
            FinalData.Columns.Add("CompositeRating");
            FinalData.Columns.Add("OverallQualityofWork");
            FinalData.Columns.Add("Schedule");
            FinalData.Columns.Add("Communication");

            foreach (var item in lstTestResultCompleted)
            {
                foreach (TestCompleted match in item.lstTestCompleted.Take(10))
                {
                    DataRow dataRow = FinalData.NewRow();
                    dataRow["FullName"] = Convert.ToString("" + match.user_first_name);
                    dataRow["UserID"] = match.user_email;
                    dataRow["Strength of Match[Corelation]"] = match.correlation2;
                    dataRow["TargetHourlyRate"] = match.TargetHourlyRate;
                    dataRow["Location"] = match.Location;
                    dataRow["CompositeRating"] = match.OverAllRating;
                    dataRow["OverallQualityofWork"] = match.OverallQualityOfWork;
                    dataRow["Schedule"] = match.AdherenceToSchedule;
                    dataRow["Communication"] = match.Communication;
                    FinalData.Rows.Add(dataRow);
                }
            }
            return FinalData;
        }


    }
}