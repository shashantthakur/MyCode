﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using ESPro.Infrastructure.Service;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AdminManageController : ControllerBase
    {
        private readonly IAdminManage _adminManage;
        private readonly IRegi _IUserRegistration;

        public AdminManageController(IAdminManage AdminDashboard, IRegi IUserRegistration)
        {
            _adminManage = AdminDashboard;
            _IUserRegistration = IUserRegistration;
        }

        public CommonFunctions commonFunctions = new CommonFunctions();

        [HttpGet("get.usersandrolelist")]
        public object GetUsersAndRoleList()
        {
            return _adminManage.GetUsersAndRoleList();
        }


        //[HttpGet("get.usersandroles")]
        //public object GetUsersAndRoles(int UsersId, string sort, string dir, int currentpage, int pageSize)
        //{
        //    List<UserRoleList> Model = new List<UserRoleList>();
        //    Model = _adminManage.GetUsersAndRoleList().ToList();


        //    var data = Model.Where(b => b.UsersId != UsersId).GroupBy(a => new
        //    {
        //        a.UsersId,
        //        a.UsersName,
        //        a.EmailId,
        //        a.RoleId,
        //        a.UserRole,
        //        a.RoleTitle,
        //        a.ClientsId,
        //        a.ClientName,
        //        a.IsActive

        //    }).Select(b => new UserRoleList
        //    {
        //        UsersId = b.Key.UsersId,
        //        UsersName = b.Key.UsersName,
        //        EmailId = b.Key.EmailId,
        //        RoleId = b.Key.RoleId,
        //        UserRole = b.Key.UserRole,
        //        RoleTitle = b.Key.RoleTitle,
        //        ClientsId = b.Key.ClientsId,
        //        ClientName = b.Key.ClientName,
        //        IsActive = b.Key.IsActive
        //    });

        //    //if (!string.IsNullOrEmpty(sort))
        //    //{
        //    //    var param = sort;
        //    //    var propertyInfo = typeof(UserRoleList).GetProperty(param);
        //    //    if (dir == "desc")
        //    //    {
        //    //        data = data.OrderByDescending(x => propertyInfo.GetValue(x, null));
        //    //    }
        //    //    else
        //    //    {
        //    //        data = data.OrderBy(x => propertyInfo.GetValue(x, null));
        //    //    }

        //    //}



        //    //var subdata = commonFunctions.SplitList(data.ToList(), pageSize);
        //    //var subdata = SplitList(data.ToList(), pageSize);
        //    //var response = new
        //    //{
        //    //    Lastpage = subdata.Count(),
        //    //    data = (subdata == null || subdata.Count() == 0) ? data : subdata.ElementAt(currentpage),
        //    //    TotalRecords = Model.Count
        //    //};

        //    var response = commonFunctions.TableResponce(data, sort, dir, currentpage, pageSize);
        //    return response;
        //}


        [HttpPost("get.usersandroles")]
        public object GetUsersAndRoles([FromBody] AdminManageParameters data)
        {
            IEnumerable<UserRoleList> datas = _adminManage.GetUsersAndRoleList();

            CommonFunctions commonFunctions = new CommonFunctions();
            List<string> UserNames = datas.Select(a => a.UsersName).Distinct().ToList();
            List<string> Roles = datas.Select(a => a.RoleTitle).Distinct().ToList();
            List<string> Emails = datas.Select(a => a.EmailId).Distinct().ToList();
            if (!(data.UserNameFilter.Count == 1 && data.UserNameFilter.Where(a => a == "0").Count() > 0))
                datas = datas.Where(a => data.UserNameFilter.Where(b => a.UsersName == b).Count() > 0).ToList();
            if (!(data.RoleFilter.Count == 1 && data.RoleFilter.Where(a => a == "0").Count() > 0))
                datas = datas.Where(a => data.RoleFilter.Where(b => a.RoleTitle == b).Count() > 0).ToList();
            if (!(data.EmailFilter.Count == 1 && data.EmailFilter.Where(a => a == "0").Count() > 0))
                datas = datas.Where(a => data.EmailFilter.Where(b => a.EmailId == b).Count() > 0).ToList();

            var response = commonFunctions.TableResponce(datas, data.sort, data.dir, data.currentpage, data.pageSize);

            var finalresponse = new
            {
                UserNames = UserNames,
                Roles = Roles,
                Emails = Emails,
                response = response
            };

            return finalresponse;
        }

        [HttpPost("get.userswithpreferredclient")]
        public object GetUsersWithPreferredClient([FromBody] AdminManageParameters data)
        {
            IEnumerable<UsersWithPreferredClient> datas = _adminManage.GetUsersWithPreferredClient();

            CommonFunctions commonFunctions = new CommonFunctions();
            List<string> UserNames = datas.Select(a => a.UserName).Distinct().ToList();
            if (!(data.UserNameFilter.Count == 1 && data.UserNameFilter.Where(a => a == "0").Count() > 0))
                datas = datas.Where(a => data.UserNameFilter.Where(b => a.UserName == b).Count() > 0).ToList();

            var response = commonFunctions.TableResponce(datas, data.sort, data.dir, data.currentpage, data.pageSize);

            var finalresponse = new
            {
                UserNames = UserNames,
                response = response
            };

            return finalresponse;
        }


        [HttpPost("update.userswithpreferredclients")]
        public ActionResult UpdateUsersWithPreferredClients([FromBody] AdminManageUsersWithPreferredClients usersPreferredClientDetails)
        {
            ApiResponce apiResponce = new ApiResponce();

            if (_adminManage.UpdateUsersWithPreferredClients(usersPreferredClientDetails) > 0)
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }

        [HttpPost("update.email")]
        public ActionResult UpdateEmailId([FromBody] AdminManage saveEmailId)
        {
            CommonResult commonResult = new CommonResult();
            try
            {
                if (_adminManage.UpdateEmailId(saveEmailId) > 0)
                {
                    string ErrorMsg = "";
                    string FullError = "";
                    List<KeyValuePair<string, string>> keyValuePair = new List<KeyValuePair<string, string>>();
                    keyValuePair.Add(new KeyValuePair<string, string>("Vendor", saveEmailId.FreelancerName));
                    keyValuePair.Add(new KeyValuePair<string, string>("existingemail", saveEmailId.CurrentEmailId));
                    keyValuePair.Add(new KeyValuePair<string, string>("newemail", saveEmailId.NewEmailId));
                    if (CommonResource.InvoicePostRequestAsync<AdminManage>("UpdateVendorEmail", keyValuePair, out ErrorMsg, out FullError))
                    {
                        StringBuilder sbMailBody = new StringBuilder(System.IO.File.ReadAllText(Path.Combine(CommonResource.MailTemplatePath, "FreelancerEmailUpdate.html")));
                        sbMailBody = sbMailBody.Replace("[Name]", saveEmailId.FreelancerName);
                        sbMailBody = sbMailBody.Replace("old_email", saveEmailId.CurrentEmailId);
                        sbMailBody = sbMailBody.Replace("New_email", saveEmailId.NewEmailId);

                        MailService objMail = new MailService();
                        objMail.SendMail(sbMailBody.ToString(), "Email update notification", saveEmailId.NewEmailId, saveEmailId.CurrentEmailId, "");
                        commonResult.ErrorMessage = "Email updated successfully";
                        commonResult.Status = "success";
                    }
                    else
                    {
                        commonResult.ErrorMessage = "iConnect Error: " + ErrorMsg;
                        commonResult.Status = "error";
                    }
                }
                else
                {
                    commonResult.ErrorMessage = "ESPRO Error: Unable to update, please try again";
                    commonResult.Status = "error";
                }
            }
            catch (Exception ex)
            {
                commonResult.ErrorMessage = ex.Message.ToString();
                commonResult.Status = "error";
            }
            return Ok(commonResult);
        }

        [HttpPost("update.usersdetails")]
        public ActionResult UpdateUsersDetails([FromBody] AdminManageUsersDetails usersDetails)
        {
            ApiResponce apiResponce = new ApiResponce();

            if (_adminManage.UpdateUsersDetails(usersDetails) > 0)
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }




        [HttpPost("save.newusersdetails")]
        public ActionResult SaveNewUsersDetails([FromBody] NewUser usersDetails)
        {
            CommonResult CommonResult = new CommonResult();
            if (_adminManage.SaveNewUsersDetails(usersDetails) > 0)
            {
                string Result = _IUserRegistration.ResendUserForotLink(usersDetails.EmailId);
                if (Result != "" && Result != "0")
                {
                    string MailResult = _IUserRegistration.GenerateForgetTokenAndSendMail(Convert.ToInt32(Result), usersDetails.EmailId, usersDetails.UsersName, "ESPro User Created");
                }
                CommonResult.Status = "success";
            }
            else
            {
                CommonResult.Status = "fail";
                CommonResult.ErrorMessage = "The email id already registered with ESPro, please use the different one, or contact to espro customer support.";
            }
            return Ok(CommonResult);
        }

    }
}