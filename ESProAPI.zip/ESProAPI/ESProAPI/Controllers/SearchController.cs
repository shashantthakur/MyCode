﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ESPro.Core.Entity.Search;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using OfficeOpenXml;
using OfficeOpenXml.Style;

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class SearchController : ControllerBase
    {
        public CommonFunctions commonFn = new CommonFunctions();
        private readonly ISearch _ISearch;
        private readonly IClient _IClient;
        private readonly IMaster _IMaster;
        private readonly IUserDetails _IUserDetails;
        private readonly IAgency _agency;

        public IConfiguration _Configuration { get; }
        public SearchController(ISearch seach, IConfiguration configuration, IMaster Master, IUserDetails UserDetails, IAgency AGENCIES, IClient iClient)
        {
            _ISearch = seach;
            _IMaster = Master;
            _IUserDetails = UserDetails;
            _Configuration = configuration;
            _agency = AGENCIES;
            _IClient = iClient;
        }

        [HttpPost("insertUpdatedelete.UserWiseSaveSearch")]
        public async Task<IActionResult> InsertUpdateDeleteSaveSearch([FromBody] SaveSearch saveSearch)
        {
            CommonResult commonResult = new CommonResult();
            var response = _ISearch.InsertUpdateDeleteSaveSearch(saveSearch);

            if (response == "Success")
            {
                if (saveSearch.SaveSearchID == 0)
                    commonResult.ErrorMessage = "Save Search added successfully";
                else
                {
                    if (saveSearch.Action == "Delete")
                        commonResult.ErrorMessage = "Save Search deleted successfully";
                    else
                        commonResult.ErrorMessage = "Save Search updated successfully";
                }
                commonResult.Status = response;
            }
            else
            {
                commonResult.ErrorMessage = response;
                commonResult.Status = "Fail";
            }
            return Ok(commonResult);
        }

        [HttpPost("get.UserWiseSaveSearch")]
        public object GetUserWiseSaveSearch([FromBody] UserWiseSaveSearchParameters datas)
        {
            List<SaveSearch> lstSaveSearch = new List<SaveSearch>();
            lstSaveSearch = _ISearch.GetUserWiseSaveSearch(datas);

            var data = lstSaveSearch.GroupBy(a => new
            {
                a.SaveSearchID,
                a.UserID,
                a.SaveSearchName,
                a.Field,
                a.LevelOfField,
                a.SystemPlatformFamilarity,
                a.LevelOfSystemFamilarity,
                a.Skills,
                a.Stylesheet
            }).Select(b => new SaveSearch
            {
                SaveSearchID = b.Key.SaveSearchID,
                UserID = b.Key.UserID,
                SaveSearchName = b.Key.SaveSearchName,
                Field = b.Key.Field,
                LevelOfField = b.Key.LevelOfField,
                SystemPlatformFamilarity = b.Key.SystemPlatformFamilarity,
                LevelOfSystemFamilarity = b.Key.LevelOfSystemFamilarity,
                Skills = b.Key.Skills,
                Stylesheet = b.Key.Stylesheet,
                isExpanded = false,
                saveSearchInnerData = b.Select(c => new SaveSearchInnerData
                {
                    Languages = c.Languages,
                    Keywords = c.Keywords,
                    Country = c.Country,
                    Agency = c.Agency,
                    FreelancerName = c.FreelancerName,
                    FreelancerNameID = c.FreelancerNameID,
                    PreferedFreelancer = c.PreferedFreelancer,
                    PreferredFreelancerBoolean = c.PreferredFreelancerBoolean,
                    LuminaCertification = c.LuminaCertification
                }).Distinct().ToList()
            });

            var response = commonFn.TableResponce(data, datas.sort, datas.dir, datas.currentpage, datas.pageSize);
            return response;
        }

        [HttpGet("GetFilterList")]
        public List<FilterList> GetFilterList(int UsersId)
        {
            return _ISearch.GetFilterList(UsersId);
        }
        [HttpPost("get.FreelancerSearch")]
        public object Products_Read_Test([FromBody] SearchParameters datas)
        {
            int totalcount = 0;
            //List<FreelancerTabModelAward> lstFreelancerTabModelAward = new List<FreelancerTabModelAward>();
            //lstFreelancerTabModelAward = _ISearch.GetFreelancerData(datas);
            //var response = commonFn.TableResponce(lstFreelancerTabModelAward, datas.sort, datas.dir, datas.currentpage, datas.pageSize);
            //return response;

            List<FreelancerTabModelAward> lstFreelancerTabModelAward = new List<FreelancerTabModelAward>();
            List<FreelancerTabModelAward> lstFreelancerTabModelAward1 = new List<FreelancerTabModelAward>();

            bool IsRestricted = false;
            if (datas.currentuserrole == "CLIENT")
            {
                ESPro.Core.Entity.UserIsRestricted _userIsRestricted = CommonResource.ToCollection<ESPro.Core.Entity.UserIsRestricted>(DbContext.DbUser.ExecuteDataSet("usp_CheckIsRestricted", datas.currentusersid).Tables[0]).FirstOrDefault();
                if (_userIsRestricted != null)
                {
                    IsRestricted = _userIsRestricted.IsRestricted.Value;
                }
            }
            if (datas.currentuserrole == "CLIENT" && IsRestricted)
            {
                datas.IsPreferedFL = true;

                
                if (datas.Discipline != "" || datas.Qualification != "" || datas.Language != "" || Convert.ToString("" + datas.Keywords) != "" || datas.System != "" || datas.Familiarity != "" || datas.Location != "" || datas.Agency != "" || datas.Freelancer != "" || datas.RatingVal != "" || datas.Skill != "" || datas.Stylesheets != "" || datas.IsLuminaCertFL != false)
                {
                    lstFreelancerTabModelAward = _ISearch.GetFreelancerData(datas, out totalcount, true);
                }
                else
                {
                    lstFreelancerTabModelAward = _ISearch.GetFreelancerData(datas, out totalcount);
                }
            }
            else
            {
                lstFreelancerTabModelAward = _ISearch.GetFreelancerData(datas, out totalcount);
            }
            int lastpage = Convert.ToInt32(Math.Ceiling(Convert.ToDecimal(Convert.ToDecimal(totalcount) / Convert.ToDecimal(datas.pageSize))));
            //var response = commonFn.TableResponce(lstFreelancerTabModelAward, datas.sort, datas.dir, datas.currentpage, datas.pageSize);
            //return new
            //{
            //    Lastpage = response.Lastpage,
            //    data = response.data,
            //    TotalRecords = response.TotalRecords,
            //    Newcnt = lstFreelancerTabModelAward.Where(a => a.IsNew > 0).Count()
            //};
            return new
            {
                Lastpage = lastpage,
                data = lstFreelancerTabModelAward,
                TotalRecords = totalcount,
                Newcnt = lstFreelancerTabModelAward.Where(a => a.IsNew > 0).Count()
            };
        }

        [HttpPost("get.DownloadFreelancerSearch")]
        public ActionResult DownloadFreelancerSearch([FromBody] SearchParameters datas)
        {
            int totalcount = 0;
            List<FreelancerTabModelAward> lstFreelancerTabModelAward = new List<FreelancerTabModelAward>();
            lstFreelancerTabModelAward = _ISearch.GetFreelancerData(datas, out totalcount);
            using (ExcelPackage package = new ExcelPackage())
            {
                package.Workbook.Worksheets.Add("Freelancer");
                OfficeOpenXml.ExcelWorksheet worksheet = package.Workbook.Worksheets[1];
                worksheet.Cells[1, 1].Value = "Name";
                worksheet.Cells[1, 2].Value = "Email ID";
                worksheet.Cells[1, 3].Value = "Discipline";
                worksheet.Cells[1, 4].Value = "Skill";
                worksheet.Cells[1, 5].Value = "Stylesheet";
                worksheet.Cells[1, 6].Value = "System/Platform Familiarity";
                worksheet.Cells[1, 7].Value = "Language";
                worksheet.Cells[1, 8].Value = "Location";
                worksheet.Cells[1, 9].Value = "Lumina Certification";
                worksheet.Cells[1, 10].Value = "Rating";
                worksheet.Cells[1, 11].Value = "Comments";
                worksheet.Cells[1, 12].Value = "Profile Last Updated";

                worksheet.Cells[1, 1, 1, 12].Style.Font.Bold = true;
                worksheet.Cells[1, 1, 1, 12].Style.Fill.PatternType = ExcelFillStyle.Solid;
                worksheet.Cells[1, 1, 1, 12].Style.Fill.BackgroundColor.SetColor(Color.Yellow);
                worksheet.Cells[1, 1, 1, 12].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                int i = 2;
                foreach (var item in lstFreelancerTabModelAward)
                {
                    int col = 1;
                    worksheet.Cells[i, col++].Value = item.Username;
                    worksheet.Cells[i, col++].Value = item.User_id;
                    worksheet.Cells[i, col++].Value = item.ExpertArea;
                    worksheet.Cells[i, col++].Value = item.Skills;
                    worksheet.Cells[i, col++].Value = item.Stylesheets;
                    worksheet.Cells[i, col++].Value = item.SystemName;
                    worksheet.Cells[i, col++].Value = item.Language;
                    worksheet.Cells[i, col++].Value = item.Location;
                    worksheet.Cells[i, col++].Value = item.CertificationName;
                    worksheet.Cells[i, col++].Value = item.Rating;
                    worksheet.Cells[i, col++].Value = item.Comments;
                    worksheet.Cells[i, col++].Value = item.LastUpdatedDate;
                    i++;
                }
                worksheet.Cells[1, 1, i - 1, 12].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[1, 1, i - 1, 12].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[1, 1, i - 1, 12].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[1, 1, i - 1, 12].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                worksheet.Column(1).Width = 25;
                worksheet.Column(2).Width = 25;
                worksheet.Column(3).Width = 50;
                worksheet.Column(4).Width = 50;
                worksheet.Column(5).Width = 20;
                worksheet.Column(6).Width = 50;
                worksheet.Column(7).Width = 15;
                worksheet.Column(8).Width = 15;
                worksheet.Column(9).Width = 20;
                worksheet.Column(10).Width = 10;
                worksheet.Column(11).Width = 50;
                worksheet.Column(12).Width = 20;
                worksheet.Column(12).Style.Numberformat.Format = "dd-MMM-yyyy";
                worksheet.Cells.Style.Font.Name = "Calibri";
                worksheet.Cells.Style.Font.Size = 11;
                //worksheet.Cells.Style.WrapText = true;
                //worksheet.Cells[1, 1, i - 1, 11].AutoFitColumns();
                //return File(package.GetAsByteArray(), "application/octet-stream", "InvoiceRepot.xlsx");
                return Ok(new { data = package.GetAsByteArray(), contenttype = "application/octet-stream", filename = "SME_Search_Report_" + DateTime.Now.ToString("ddMMyyyyHHmmss") + ".xlsx" });
            }
            return null;
        }

        [HttpPost("get.FreelancerForFilterSearch")]
        public object GetFreelancerforFilterSearch([FromBody] FilterSearch Search)
        {
            int totalcount = 0;
            var result = _ISearch.GetFreelancersFromFilter(Search, out totalcount);
            // var data = new SelectList(result, "UsersId", "UserName", "UserEmailId");
            return result;
        }

        [HttpGet("get.FreelancerForSearch")]
        public object GetFreelancerforSearch(int currentusersid, string currentuserrole, string ClientCode, string Pmtype, string IsPMRole, string isStaffSearch = "false")
        {
            bool IsPM;
            bool IsStaff;
            //return _ISearch.GetFreelancerTabDetailsQM(currentusersid, Convert.ToString(userRole.QUALITYMANAGER));
            bool.TryParse(isStaffSearch, out IsStaff);
            IsStaff = _ISearch.CheckIsValidForPMView(currentuserrole, IsStaff);
            bool.TryParse(IsPMRole, out IsPM);
            IsPM = _ISearch.CheckIsValidForPMView(currentuserrole, IsPM);
            List<FreelancerTabSearchModel> result = new List<FreelancerTabSearchModel>();
            if (IsPM)
                result = _ISearch.GetFreelancerTabSearchDetailsQM(currentusersid, currentuserrole, ClientCode, Convert.ToString(userRole.QUALITYMANAGER));
            else if (IsStaff)
                result = _ISearch.GetFreelancerTabSearchDetailsQM(currentusersid, currentuserrole, ClientCode, Convert.ToString(userRole.LUMINAOTHERS));
            else
                result = _ISearch.GetFreelancerTabSearchDetailsQM(currentusersid, currentuserrole, ClientCode, Convert.ToString(userRole.FREELANCER));

            //unComment when release in live

            //if (currentuserrole == "AGENCY")
            //{
            //    var agencyresult = _agency.GetUsersAgenciesDetaiils(currentusersid).ToList();
            //    if (agencyresult.Count > 0)
            //    {
            //        result = result.Where(a => a.Agency == agencyresult[0].AgencyName && a.User_role.ToUpper() != "AGENCY").ToList();
            //        if (result == null)
            //            result = new List<FreelancerTabSearchModel>();
            //    }
            //    else
            //        result = new List<FreelancerTabSearchModel>();
            //}
            //else
            //{
            //    result = result.Where(a => string.IsNullOrWhiteSpace(a.Agency) && a.User_role.ToUpper() != "AGENCY" || (a.User_role.ToUpper() == "AGENCY" && !string.IsNullOrEmpty(a.Agency))).ToList();
            //}
            var data = new SelectList(result, "ID", "Username");
            return data;
        }

        [HttpPost("get.MatchingFreelancer")]
        public object FillCompletedTestCorrelation([FromBody] searchMatchingFreelancer datas)
        {
            var ObjtestCompleted = commonFn.FillCompletedTestCorrelationResultAsync(datas.UsersId, datas.SelectedSkilles, datas.UserRoles, datas.SelectedDispline, datas.CurrentRole, datas.CurrentUserId);
            var model = ObjtestCompleted.Result;
            var response = commonFn.TableResponce(model, datas.sort, datas.dir, datas.currentpage, datas.pageSize);
            return response;
        }

        [HttpPost("get.searchtermsdetails")]
        public object GetSearchTermsAcceptedDetails([FromBody] searchMatchingFreelancer datas)
        {
            List<SearchTermsAccepted> searchTermsAccepted = new List<SearchTermsAccepted>();
            return searchTermsAccepted = _ISearch.GetSearchTermsAcceptedDetails(datas.CurrentUserId);
        }

        [HttpPost("save.terms")]
        public ActionResult SaveSearchTerms([FromBody] searchMatchingFreelancer datas)
        {
            CommonResult CommonResult = new CommonResult();
            try
            {
                if (_ISearch.SaveSearchTerms(datas.CurrentUserId) > 0)
                {
                    CommonResult.Status = "success";
                    CommonResult.ErrorMessage = "";
                }
                else
                {
                    CommonResult.Status = "fail";
                    CommonResult.ErrorMessage = "Data not updated, please try again.";
                }
            }
            catch (Exception ex)
            {
                CommonResult.Status = "fail";
                CommonResult.ErrorMessage = ex.Message.ToString();
            }
            return Ok(CommonResult);
        }

        [HttpPost("SaveUsersComment")]
        public ActionResult SaveUsersComment([FromBody] UsersComment datas)
        {
            CommonResult CommonResult = new CommonResult();

            if (_ISearch.SaveUsersComment(datas) > 0)
            {
                CommonResult.Status = "success";
                CommonResult.ErrorMessage = "";
            }
            else
            {
                CommonResult.Status = "fail";
                CommonResult.ErrorMessage = "Data not updated, please try again.";
            }

            return Ok(CommonResult);
        }

        [HttpPost("DeleteUsersComment")]
        public ActionResult DeleteUsersComment([FromBody] UsersComment datas)
        {
            CommonResult CommonResult = new CommonResult();

            if (_ISearch.DeleteUsersComment(datas) > 0)
            {
                CommonResult.Status = "success";
                CommonResult.ErrorMessage = "";
            }
            else
            {
                CommonResult.Status = "fail";
                CommonResult.ErrorMessage = "Data not updated, please try again.";
            }

            return Ok(CommonResult);
        }
        [HttpPost("GetUsersComment")]
        public object GetUsersComment([FromBody] UsersComment datas)
        {
            //usp_GetUsersComment
            return _ISearch.GetUsersComment(datas);
        }

    }
}
