﻿using ESPro.Core.Entity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ESProAPI.Class;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Service;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class CandidateController : ControllerBase
    {

        private readonly ICandidate _ICandidate;
        public IConfiguration _Configuration { get; }
        public CandidateController(ICandidate iCandidate, IConfiguration configuration)
        {
            _ICandidate = iCandidate;
            _Configuration = configuration;
        }

        [HttpPost("SaveCandidateList")]
        public ActionResult SaveCandidateList([FromBody] CandidateList datas)
        {
            CommonResult CommonResult = new CommonResult();

            if (_ICandidate.SaveCandidateList(datas) > 0)
            {
                CommonResult.Status = "success";
                CommonResult.ErrorMessage = "";
            }
            else
            {
                CommonResult.Status = "fail";
                CommonResult.ErrorMessage = "Data not updated, please try again.";
            }

            return Ok(CommonResult);
        }
        [HttpPost("GetCandidateList")]
        //public List<ClientJobDetailsModel> GetClientDashboard(int UsersId)
        public object GetClientDashboard([FromBody] CandidateListParam candidateListParam)
        {
            IEnumerable<CandidateList> datas = _ICandidate.GetCandidateListDashboard(candidateListParam.OwnerId.Value);

            CommonFunctions commonFunctions = new CommonFunctions();


            var response = commonFunctions.TableResponce(datas, candidateListParam.sort, candidateListParam.dir, candidateListParam.currentpage, candidateListParam.pageSize);
            var data = new
            {
                response = response,
                CandidateList = datas
            };

            return data;

            //return response;
        }

        [HttpPost("GetCandidateListUsers")]
        public object GetCandidateListUsers([FromBody] CandidateListParam candidateListParam)
        {
            IEnumerable<CandidateListUsers> datas = _ICandidate.GetCandidateListUsers(candidateListParam.CandidateListId.Value);

            CommonFunctions commonFunctions = new CommonFunctions();


            var response = commonFunctions.TableResponce(datas, candidateListParam.sort, candidateListParam.dir, candidateListParam.currentpage, candidateListParam.pageSize);
            var data = new
            {
                response = response,
                 CandidateListUsers = datas
            };

            return data;

            //return response;
        }

        [HttpPost("GetCandidateListShareUsers")]
        public object GetCandidateListShareUsers([FromBody] CandidateListParam candidateListParam)
        {
            IEnumerable<CandidateListShareUsers> datas = _ICandidate.GetCandidateListShareUsers(candidateListParam.CandidateListId.Value);

            CommonFunctions commonFunctions = new CommonFunctions();


            var response = commonFunctions.TableResponce(datas, candidateListParam.sort, candidateListParam.dir, candidateListParam.currentpage, candidateListParam.pageSize);
            var data = new
            {
                response = response

            };

            return data;

            //return response;
        }

        [HttpGet("GetUserWiseCandidateList")]
        public object GetUserWiseCandidateList(string OwnerId)
        {
            CryptoService cryptoService = new CryptoService();
            int UsersId = Convert.ToInt32(cryptoService.Decrypt(OwnerId));
            IEnumerable<CandidateList> datas = _ICandidate.GetCandidateList(UsersId);

            return datas;


        }

        [HttpPost("GetShareListUsers")]
        public object GetShareListUsers(ShareListParam shareListParam)
        {

            IEnumerable<ShareListUsers> datas = _ICandidate.GetShareListUsers(shareListParam);
            return datas;
        }

        [HttpPost("ShareCandidateList")]
        public ActionResult ShareCandidateList(ShareListMailParam shareListMailParam)
        {
            CommonResult CommonResult = new CommonResult();
            string Error = _ICandidate.GenerateMailShareCandidateList(shareListMailParam);
            if (Error != "")
            {
                CommonResult.Status = "fail";
                CommonResult.ErrorMessage = Error;
            }
            else
            {
                CommonResult.Status = "success";
                CommonResult.ErrorMessage = "";
            }
            return Ok(CommonResult);
        }

        [HttpPost("DeleteCandidateList")]
        public ActionResult DeleteCandidateList(CandidateListParam candidateListParam)
        {
            CommonResult CommonResult = new CommonResult();

            if (_ICandidate.DeleteCandidateList(candidateListParam.CandidateListId.Value) > 0)
            {
                CommonResult.Status = "success";
                CommonResult.ErrorMessage = "";
            }
            else
            {
                CommonResult.Status = "fail";
                CommonResult.ErrorMessage = "Data not updated, please try again.";
            }

            return Ok(CommonResult);
        }


        [HttpPost("SaveCandidateListUser")]
        public ActionResult SaveCandidateListUser([FromBody] CandidateListUserParam datas)
        {
            CommonResult CommonResult = new CommonResult();

            if (_ICandidate.SaveCandidateListUser(datas) > 0)
            {
                CommonResult.Status = "success";
                CommonResult.ErrorMessage = "";
            }
            else
            {
                CommonResult.Status = "fail";
                CommonResult.ErrorMessage = "Data not updated, please try again.";
            }

            return Ok(CommonResult);
        }

        [HttpPost("DeleteCandidateListUser")]
        public ActionResult DeleteCandidateListUser(CandidateListUserParam candidateListUserParam)
        {
            CommonResult CommonResult = new CommonResult();

            if (_ICandidate.DeleteCandidateListUser(candidateListUserParam.CandidateListUsersId.Value) > 0)
            {
                CommonResult.Status = "success";
                CommonResult.ErrorMessage = "";
            }
            else
            {
                CommonResult.Status = "fail";
                CommonResult.ErrorMessage = "Data not updated, please try again.";
            }

            return Ok(CommonResult);
        }

        [HttpPost("UnshareCandidateList")]
        public ActionResult UnshareCandidateList(CandidateListUserParam candidateListUserParam)
        {
            CommonResult CommonResult = new CommonResult();

            if (_ICandidate.UnshareCandidateList(candidateListUserParam.CandidateListShareId.Value) > 0)
            {
                CommonResult.Status = "success";
                CommonResult.ErrorMessage = "";
            }
            else
            {
                CommonResult.Status = "fail";
                CommonResult.ErrorMessage = "Data not updated, please try again.";
            }
            return Ok(CommonResult);
        }


        [AllowAnonymous]
        [HttpGet("AcceptInvitation")]
        public ActionResult AcceptInvitation([FromQuery] string token)
        {
            string ActivationID = _ICandidate.ValidateToken(token);
            string result = "0";
            if (ActivationID != "0")
            {
                int rtn = 0;
                rtn = _ICandidate.AcceptShareList(Convert.ToInt32(ActivationID));
                if (rtn == -1)
                    result = "3";
                else if (rtn >0)
                {
                    result = "1";
                }
                else
                    result = "2";
            }
            else
            {
                result = "2";
            }
          

            CryptoService cryptoService = new CryptoService();
            string Result = cryptoService.Encrypt(result);
            return Redirect(_Configuration["UiUrl"] + "AcceptInvitation?id=" + Result);
        }

    }
}
