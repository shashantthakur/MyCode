﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml;
using OfficeOpenXml.Style;

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class SmartAssessorController : ControllerBase
    {
        private readonly ISmartAssessor _smartAssessor;
        private readonly ICertification _certification;
        public CommonFunctions commonFn = new CommonFunctions();

        public SmartAssessorController(ISmartAssessor smartAssessor, ICertification certification)
        {
            _smartAssessor = smartAssessor;
            _certification = certification;
        }

        [HttpGet("getdownloadpath")]
        public async Task<DownloadPath> GetDownloadPath()
        {
            DownloadPath downloadPath = new DownloadPath();
            downloadPath.FilePath = Convert.ToString(CommonResource.TrainingMaterialPath).Replace("Training", "");
            return downloadPath;
        }

        [HttpPost("get.smartassessortestlist")]
        public object GetSmartAssessorTestList([FromBody] SmartAssessorTestParamaters smartAssessorTestParamaters)
        {
            List<SmartAssessorTest> lstSmartAssessorTest = new List<SmartAssessorTest>();
            lstSmartAssessorTest = _smartAssessor.GetSmartAssessorTestList(smartAssessorTestParamaters);

            var response = commonFn.TableResponce(lstSmartAssessorTest, smartAssessorTestParamaters.sort, smartAssessorTestParamaters.dir, smartAssessorTestParamaters.currentpage, smartAssessorTestParamaters.pageSize);
            var data = new
            {
                response = response
            };
            return data;
            //return _smartAssessor.GetSmartAssessorTestList(smartAssessorTestParamaters.UsersId);
        }


        [HttpPost("GetSmartAssessorTestDetailsEnrolledUser")]
        public object GetSmartAssessorTestDetailsEnrolledUser([FromBody] SmartAssessorTestParamaters smartAssessorTestParamaters)
        {
            List<SmartAssessorTest> datas = _smartAssessor.GetSmartAssessorTestDetailsEnrolledUser(smartAssessorTestParamaters);
            CommonFunctions commonFunctions = new CommonFunctions();
            var response = commonFunctions.TableResponce(datas, smartAssessorTestParamaters.sort, smartAssessorTestParamaters.dir, smartAssessorTestParamaters.currentpage, smartAssessorTestParamaters.pageSize);
            return response;
        }

        [HttpGet("download.excerpt")]
        public async Task<FileStreamResult> Download(string ExcerptFile)
        {
            //var contentType = MimeMapping.MimeUtility.GetMimeMapping(Path.GetExtension(ExcerptFile));
            ////string file = CommonResource.ExcerptPath + "\\" + ExcerptFile;
            //var stream = new FileStream(ExcerptFile, FileMode.Open, FileAccess.Read);

            //var result = new FileStreamResult(stream, contentType);
            //// result.FileDownloadName = "1.pdf";
            //return result;

            var contentType = MimeMapping.MimeUtility.GetMimeMapping(Path.GetExtension(ExcerptFile));
            string file = CommonResource.ExcerptPath + "\\" + ExcerptFile.Replace(CommonResource.ExcerptPath, "");
            var stream = new FileStream(file, FileMode.Open, FileAccess.Read);

            var result = new FileStreamResult(stream, contentType);
            // result.FileDownloadName = "1.pdf";
            return result;
        }

        [HttpPost("AllocateTest")]
        public int AllocateTest([FromBody] AllocateTest allocateTest)
        {
            int cnt = _smartAssessor.AllocateTest(allocateTest);
            return cnt;
        }

        [HttpPost("GetQuestionsOnSmartAssessor")]
        public SkillQuestion GetQuestionsOnSmartAssessor([FromBody] QuestionParam questionParam)
        {

            SkillQuestion _skillQuestion = _smartAssessor.GetQuestionsOnSmartAssessor(questionParam.UserId.Value, questionParam.TestID.Value, questionParam.TestRegistrationId.Value);

            return _skillQuestion;
        }

        [HttpPost("SaveAnswer")]
        public TestResult SaveAnswer([FromBody] QuestionOptionModel questionParam)
        {
            TestResult _testResult = _smartAssessor.SaveTest(questionParam);

            return _testResult;
        }

        [HttpPost("GetSmartAssessorTestResult")]
        public List<SmartAssessorTestResult> GetSmartAssessorTestResult([FromBody] QuestionParam questionParam)
        {
            List<SmartAssessorTestResult> smartAssessorTestResults = _smartAssessor.GetSmartAssessorTestResult(questionParam.UserId.Value, questionParam.TestRegistrationId.Value);
            return smartAssessorTestResults;
        }

        [HttpPost("GetFeedbackQuestionsOnSmartAssessor")]
        public SkillQuestion GetFeedbackQuestionsOnSmartAssessor([FromBody] QuestionParam questionParam)
        {
            SkillQuestion _skillQuestion = _smartAssessor.GetFeedbackQuestionsOnSmartAssessor(questionParam.UserId.Value, questionParam.TestRegistrationId.Value);
            return _skillQuestion;
        }

        [HttpPost("SaveFeedback1Answer")]
        public TestResult SaveFeedback1Answer([FromBody] QuestionOptionModel questionParam)
        {
            TestResult _testResult = _smartAssessor.SaveFeedback1Answer(questionParam);
            return _testResult;
        }

        [HttpPost("GetFeedbackDescQuestionsOnSmartAssessor")]
        public SkillQuestion GetFeedbackDescQuestionsOnSmartAssessor([FromBody] QuestionParam questionParam)
        {
            SkillQuestion _skillQuestion = _smartAssessor.GetFeedbackDescQuestionsOnSmartAssessor(questionParam.UserId.Value, questionParam.TestRegistrationId.Value, questionParam.TestID.Value);
            return _skillQuestion;
        }

        [HttpPost("SaveFeedback2Answer")]
        public TestResult SaveFeedback2Answer([FromBody] QuestionOptionModel questionParam)
        {
            TestResult _testResult = _smartAssessor.SaveFeedback2Answer(questionParam);
            return _testResult;
        }

        [HttpGet("GetSmartAssessorCertificateUser")]
        public object GetSmartAssessorCertificateUser(int TestRegistrationID, string TestType, string sort, string dir, int currentpage, int pageSize)
        {
            IEnumerable<SkillCertificateUser> datas = _certification.GetCertificateUser(TestRegistrationID, TestType);
            CommonFunctions commonFunctions = new CommonFunctions();
            var response = commonFunctions.TableResponce(datas, sort, dir, currentpage, pageSize);

            return response;
            //return datas;
        }

        [HttpGet("DownloadSmartAssessorUserResult")]
        public ActionResult DownloadSmartAssessorUserResult(int TestRegistrationID)
        {
            IEnumerable<SkillCertificateUser> datas = _certification.GetCertificateUser(TestRegistrationID, "SmartAssessor");
            using (ExcelPackage package = new ExcelPackage())
            {
                package.Workbook.Worksheets.Add("Result");
                OfficeOpenXml.ExcelWorksheet worksheet = package.Workbook.Worksheets[1];
                worksheet.Cells[1, 1].Value = "Full Name";
                worksheet.Cells[1, 2].Value = "Test Name";
                worksheet.Cells[1, 3].Value = "Attempts";
                worksheet.Cells[1, 4].Value = "Status";
                worksheet.Cells[1, 5].Value = "ReActive Test";
                worksheet.Cells[1, 1, 1, 5].Style.Font.Bold = true;
                worksheet.Cells[1, 1, 1, 5].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                int i = 2;
                foreach (var item in datas)
                {
                    int col = 1;
                    worksheet.Cells[i, col++].Value = item.FullName;
                    worksheet.Cells[i, col++].Value = item.TestName;
                    worksheet.Cells[i, col++].Value = item.Attempts;
                    worksheet.Cells[i, col++].Value = item.Status;
                    worksheet.Cells[i, col++].Value = item.ReActiveTest;
                    i++;
                }
                worksheet.Cells[1, 1, i - 1, 5].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[1, 1, i - 1, 5].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[1, 1, i - 1, 5].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[1, 1, i - 1, 5].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[1, 1, i - 1, 5].AutoFitColumns();
                return Ok(new { data = package.GetAsByteArray(), contenttype = "application/octet-stream", filename = "SmartAssessor_Result_" + DateTime.Now.ToString("ddMMyyyyHHmmss") + ".xlsx" });
            }
            return null;
        }

        [HttpGet("ReActivateTest")]
        public ActionResult SmartAssessorReActiveTest(int UserID, string TestType)
        {
            CommonResult CommonResult = new CommonResult();
            if (_smartAssessor.SmartAssessorReActiveTest(UserID, TestType) > 0)
                CommonResult.Status = "success";
            else
                CommonResult.Status = "fail";
            return Ok(CommonResult);
        }

        [HttpGet("GetCertificatePassedOn")]
        public object GetCertificatePassedOn(int UserID, string CertificateType)
        {
            List<CertificatePassedOnDetails> datas = _smartAssessor.GetCertificatePassedOn(UserID, CertificateType);
            return datas;
        }

        [HttpPost("addcomment.question")]
        public async Task<IActionResult> AddCommentToQuestion([FromBody] AddCommentToQuestionParameter addCommentToQuestionParameter)
        {
            ApiResponce apiResponce = new ApiResponce();
            Boolean flag = _smartAssessor.AddCommentToQuestion(addCommentToQuestionParameter);
            if (flag)
            {
                apiResponce.Text = "Success";
            }
            else
            {
                apiResponce.Text = "Fail";
            }
            return Ok(apiResponce);
        }
    }
}