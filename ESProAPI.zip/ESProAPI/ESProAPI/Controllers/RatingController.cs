﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESPro.Infrastructure.Class;
using ESPro.Infrastructure.Service;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml;
using OfficeOpenXml.Style;

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class RatingController : ControllerBase
    {
        public CommonFunctions commonFn = new CommonFunctions();
        private readonly IRating _rating;
        private readonly IUserDetails _UserDetails;
        private readonly IInvoice _invoice;

        public RatingController(IRating AdminHome, IUserDetails UserDetails, IInvoice invoice)
        {
            _rating = AdminHome;
            _UserDetails = UserDetails;
            _invoice = invoice;
        }

        [HttpGet("get.ratinguserslist")]
        public object GetRatingUsersList(int UsersId, int currentuserid, string currentrole)
        {
            return _rating.GetRatingUsersList(UsersId, currentuserid, currentrole);
        }

        [HttpPost("post.ratingdetails")]
        public object GetRatingHistory([FromBody] RatingParamaters parameter)
        {
            List<RatingDetails> Model = new List<RatingDetails>();
            Model = _rating.GetRatingHistory(parameter.UsersId, parameter.currentuserid, parameter.currentuserrole).ToList();

            var data = Model.GroupBy(a => new
            {
                a.select,
                a.RatingId,
                a.JobId,
                a.JobNo,
                a.Client,
                a.ISBN13,
                a.Author,
                a.Title,
                a.Edition,
                a.AgencyUser,
                a.FreelancerUserID,
                a.FreelancerName,
                a.ProjectManager,
                a.OverallQualityOfWork,
                a.AdherenceToSchedule,
                a.Communication,
                a.AgencyUserEmailID,
                a.FreelancerEmailID,
                a.ProjectManagerEmail,
                a.InvApproverName,
                a.InvApproverEmail,
                a.InvApproverName2,
                a.InvApproverEmail2
            }).Select(b => new RatingDetails
            {
                select = b.Key.select,
                RatingId = b.Key.RatingId,
                JobId = b.Key.JobId,
                JobNo = b.Key.JobNo,
                Client = b.Key.Client,
                ISBN13 = b.Key.ISBN13,
                Author = b.Key.Author,
                Title = b.Key.Title,
                Edition = b.Key.Edition,
                AgencyUser = b.Key.AgencyUser,
                FreelancerUserID = b.Key.FreelancerUserID,
                FreelancerName = b.Key.FreelancerName,
                ProjectManager = b.Key.ProjectManager,
                OverallQualityOfWork = b.Key.OverallQualityOfWork,
                AdherenceToSchedule = b.Key.AdherenceToSchedule,
                Communication = b.Key.Communication,
                AgencyUserEmailID = b.Key.AgencyUserEmailID,
                FreelancerEmailID = b.Key.FreelancerEmailID,
                ProjectManagerEmail = b.Key.ProjectManagerEmail,
                InvApproverName = b.Key.InvApproverName,
                InvApproverEmail = b.Key.InvApproverEmail,
                InvApproverName2 = b.Key.InvApproverName2,
                InvApproverEmail2 = b.Key.InvApproverEmail2,
                isExpanded = false,
                ratingDetailsInnerData = b.Select(c => new RatingDetailsInnerData
                {
                    //JobId = c.JobId,
                    AgencyUserEmailID = c.AgencyUserEmailID,
                    FreelancerEmailID = c.FreelancerEmailID,
                    ProjectManagerEmail = c.ProjectManagerEmail,
                    InvApproverName = c.InvApproverName,
                    InvApproverEmail = c.InvApproverEmail,
                    InvApproverName2 = c.InvApproverName2,
                    InvApproverEmail2 = c.InvApproverEmail2
                }).Distinct().ToList()
            });

            List<string> Jobs = data.Select(a => a.JobNo).Distinct().ToList();

            if (!(parameter.JobFilter.Count == 1 && parameter.JobFilter.Where(a => a == "0").Count() > 0))
                data = data.Where(a => parameter.JobFilter.Where(b => a.JobNo == b).Count() > 0).ToList();

            var response = commonFn.TableResponce(data, parameter.sort, parameter.dir, parameter.currentpage, parameter.pageSize);
            var finalresponse = new
            {
                Jobs = Jobs,
                response = response
            };
            return finalresponse;


            //if (!string.IsNullOrEmpty(parameter.sort))
            //{
            //    var param = parameter.sort;
            //    var propertyInfo = typeof(RatingDetails).GetProperty(param);
            //    if (parameter.dir == "desc")
            //    {
            //        data = data.OrderByDescending(x => propertyInfo.GetValue(x, null));
            //    }
            //    else
            //    {
            //        data = data.OrderBy(x => propertyInfo.GetValue(x, null));
            //    }

            //}
            //CommonFunctions commonFunctions = new CommonFunctions();
            //var subdata = commonFunctions.SplitList(data.ToList(), parameter.pageSize);
            //var response = new
            //{
            //    Lastpage = subdata.Count(),
            //    data = (subdata == null || subdata.Count() == 0) ? data : subdata.ElementAt(parameter.currentpage),
            //    TotalRecords = Model.Count
            //};
            //var datas = new
            //{
            //    Jobs = Jobs,
            //    response = response
            //};
            //return datas;
        }

        [HttpGet("get.ratingcomments/{JobId}")]
        public object GetRatingComments(int JobId)
        {
            return _rating.GetRatingComments(JobId);
        }

        [HttpGet("get.ratingjobdetails/{JobId}")]
        public object GetRatingJobNoDetails(int JobId)
        {
            return _rating.GetRatingJobNoDetails(JobId);
        }

        [HttpPost("save.ratings")]
        public ActionResult SaveRatingDetails([FromBody] RatingSave saveRating)
        {
            ApiResponce apiResponce = new ApiResponce();
            if (_rating.SaveRatingDetails(saveRating) > 0)
            {
                var roles = _UserDetails.GetUserRoles(Convert.ToInt32(saveRating.UsersId), "FREELANCER");
                if (roles.ToList().Where(a => a.UserRole == "PROJECTMANAGER").Count() == 0)
                {
                    var SendMailTo = _invoice.GetSendMailDetails("FreelancerReview").ToList();
                    string MailSubject = "";
                    if (saveRating.RatingFrom == "NEW")
                        MailSubject = "ESPro: Freelancer Review Completed: "+saveRating.JobNo;
                    else
                        MailSubject = "ESPro: Freelancer Review Updated: " + saveRating.JobNo;
                    string ToMail = "", CCMail = "";
                    if (Convert.ToString(saveRating.AgencyUser) == "" || saveRating.AgencyUser == null)
                    {
                        ToMail = saveRating.FreelancerEmailID;
                        CCMail = saveRating.JobPM + "; " + saveRating.InvApproverEmail + "; " + saveRating.UserEmailID;
                    }
                    else
                    {
                        ToMail = saveRating.AgencyUserEmailID;
                        CCMail = saveRating.JobPM + "; " + saveRating.InvApproverEmail + "; " + saveRating.FreelancerEmailID + "; " + saveRating.UserEmailID;
                    }
                    string BCCMail = SendMailTo[0].BCCMailList;
                    StringBuilder sbMailBody = new StringBuilder(System.IO.File.ReadAllText(Path.Combine(CommonResource.MailTemplatePath, "FreelancerReview.html")));
                    TextInfo textInfo = new CultureInfo("en-US", false).TextInfo;
                    if (saveRating.AgencyUser == "")
                        sbMailBody.Replace("[Name]", textInfo.ToTitleCase(Convert.ToString("" + saveRating.FreelanceName).Trim().ToLower()));
                    else
                        sbMailBody.Replace("[Name]", textInfo.ToTitleCase(Convert.ToString("" + saveRating.AgencyUser).Trim().ToLower()));
                    sbMailBody.Replace("[work]", saveRating.Skill);
                    sbMailBody.Replace("[project]", saveRating.JobNo + ", " + saveRating.Author + ", " + saveRating.Title);
                    sbMailBody.Replace("[Regards]", CommonResource.MailRegards);
                    MailService objMail = new MailService();
                    objMail.SendMail(sbMailBody.ToString(), MailSubject, ToMail, CCMail, BCCMail);
                    //if (saveRating.RatingFrom == "NEW")
                    //{
                    //    _invoice.SaveInvoiceDetails();
                    //}
                }
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }

        [HttpPost("get.DownloadProjectSpecific")]
        public ActionResult DownloadProjectSpecific([FromBody] ProjectSpecific data)
        {
            var comments = _rating.GetRatingComments(Convert.ToInt32("0" + data.jobID));
            var details = _rating.GetRatingJobNoDetails(Convert.ToInt32("0" + data.jobID)).FirstOrDefault();
            var users = _UserDetails.GetUsersDetails(details.UsersId.ToString());
            using (ExcelPackage package = new ExcelPackage())
            {
                package.Workbook.Worksheets.Add("Rating");
                OfficeOpenXml.ExcelWorksheet worksheet = package.Workbook.Worksheets[1];
                worksheet.Cells[1, 1].Value = "Freelancer";
                worksheet.Cells[1, 2].Value = users.personalDetails.FullName;
                worksheet.Cells[2, 1].Value = "Lumina Job Number";
                worksheet.Cells[2, 2].Value =  (data.CurrentUserRole == "CLIENT" && data.TeamType != details.Client) ? "REDACTED" : details.JobNo;
                worksheet.Cells[3, 1].Value = "Client";
                worksheet.Cells[3, 2].Value = (data.CurrentUserRole == "CLIENT" && data.TeamType != details.Client) ? "REDACTED" : details.Client;
                worksheet.Cells[4, 1].Value = "ISBN13";
                worksheet.Cells[4, 2].Value = (data.CurrentUserRole == "CLIENT" && data.TeamType != details.Client) ? "REDACTED" : details.ISBN13;
                worksheet.Cells[5, 1].Value = "Author";
                worksheet.Cells[5, 2].Value = (data.CurrentUserRole == "CLIENT" && data.TeamType != details.Client) ? "REDACTED" : details.Author;
                worksheet.Cells[6, 1].Value = "Title";
                worksheet.Cells[6, 2].Value = (data.CurrentUserRole == "CLIENT" && data.TeamType != details.Client) ? "REDACTED" : details.Title;
                worksheet.Cells[7, 1].Value = "Edition";
                worksheet.Cells[7, 2].Value = (data.CurrentUserRole == "CLIENT" && data.TeamType != details.Client) ? "REDACTED" : details.Edition;
                worksheet.Cells[8, 1].Value = "Skill";
                worksheet.Cells[8, 2].Value = details.Skill;
                worksheet.Cells[9, 1].Value = "Rated On";
                worksheet.Cells[9, 2].Value = (data.CurrentUserRole == "CLIENT" && data.TeamType != details.Client) ? "REDACTED" : Convert.ToDateTime(details.RatedOn).ToString("dd-MMM-yyyy");
                worksheet.Cells[10, 1].Value = "Overall Project Rating";
                worksheet.Cells[10, 2].Value = details.OverallQualityOfWork;
                worksheet.Cells[1, 1, 10, 1].Style.Font.Bold = true;
                worksheet.Cells[1, 1, 10, 2].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[1, 1, 10, 2].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[1, 1, 10, 2].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[1, 1, 10, 2].Style.Border.Right.Style = ExcelBorderStyle.Thin;


                worksheet.Cells[13, 1].Value = "Category";
                worksheet.Cells[13, 2].Value = "Ratings";
                worksheet.Cells[13, 3].Value = "Comments";
                worksheet.Cells[13, 1, 13, 3].Style.Font.Bold = true;
                worksheet.Cells[13, 1, 13, 3].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

                worksheet.Cells[14, 1].Value = "Adherence to Schedule";
                worksheet.Cells[14, 2].Value = 1;
                worksheet.Cells[14, 3].Value = comments.Where(a => a.RatingCategoryId == 1).FirstOrDefault().Comments;
                worksheet.Cells[15, 1].Value = "Overall Quality of Work";
                worksheet.Cells[15, 2].Value = 2;
                worksheet.Cells[15, 3].Value = comments.Where(a => a.RatingCategoryId == 2).FirstOrDefault().Comments;
                worksheet.Cells[16, 1].Value = "Communication";
                worksheet.Cells[16, 2].Value = 3;
                worksheet.Cells[16, 3].Value = comments.Where(a => a.RatingCategoryId == 3).FirstOrDefault().Comments;

                worksheet.Cells[13, 1, 16, 3].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[13, 1, 16, 3].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[13, 1, 16, 3].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[13, 1, 16, 3].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[13, 1, 16, 3].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                worksheet.Cells[13, 1, 16, 3].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                worksheet.Cells[1, 1, 16, 3].AutoFitColumns(10, 50);
                worksheet.Cells[1, 1, 16, 3].Style.WrapText = true;

                //return File(package.GetAsByteArray(), "application/octet-stream", "InvoiceRepot.xlsx");
                return Ok(new { data = package.GetAsByteArray(), contenttype = "application/octet-stream", filename = "Project_Specific_Rating_" + DateTime.Now.ToString("ddMMyyyyHHmmss") + ".xlsx" });
            }
            return null;
        }


        [HttpPost("get.CategorySpecificRating")]
        public object CategorySpecificRating([FromBody] ProjectSpecific Data)
        {
            List<CategorySpecificModel> lstCategorySpecificRatingfnl = new List<CategorySpecificModel>();
            double rATS = 0;
            double rOQW = 0;
            double rCom = 0;
            string ViewType = "";
            try
            {
                int? ratingCategoryId = null;

                var lstCategorySpecificRating = _rating.GetCategorySpecificCategoryDetails(Data.usersid).ToList();
                if (Data.CurrentUserRole == Convert.ToString(userRole.LUMINAOTHERS) || Data.CurrentUserRole == Convert.ToString(userRole.FREELANCER) || Data.CurrentUserRole == Convert.ToString(userRole.FLPROJECTMANAGER))
                {
                    lstCategorySpecificRatingfnl = lstCategorySpecificRating;
                    ViewType = "FLView";
                }
                if (Data.CurrentUserRole == Convert.ToString(userRole.PROJECTMANAGER) || Data.CurrentUserRole == Convert.ToString(userRole.ADMIN) || Data.CurrentUserRole == "CLIENT" || Data.CurrentUserRole == Convert.ToString(userRole.CLIENTADMIN) || Data.CurrentUserRole == Convert.ToString(userRole.LUMINASUPERVISOR) || Data.CurrentUserRole == Convert.ToString(userRole.AGENCY))
                {
                    IEnumerable<CategorySpecificModel> lstCategorySpecificRatingNF = _rating.GetCategorySpecificCategoryDetailsForNonFreelancer(Data.usersid);
                    var virtualList = lstCategorySpecificRatingNF.ToList();

                    lstCategorySpecificRatingNF = virtualList.AsEnumerable();

                    double ATS = 0, OQW = 0, Com = 0;
                    List<CategorySpecificModel> remodel = new List<CategorySpecificModel>();
                    foreach (var item in lstCategorySpecificRatingNF)
                    {
                        ATS += Convert.ToDouble(item.AdherenceToSchedule);
                        OQW += Convert.ToDouble(item.OverallQualityOfWork);
                        Com += Convert.ToDouble(item.Communication);
                        CategorySpecificModel M = new CategorySpecificModel();
                        M = item;
                        if (item.customer.ToUpper().Trim() != Data.TeamType.ToUpper().Trim() && Data.CurrentUserRole == "CLIENT")
                        {
                            M.JobNo = "REDACTED";
                            M.customer = "REDACTED";
                            M.Author = "REDACTED";
                            M.Title = "REDACTED";
                            M.Edition = "REDACTED";
                            M.RatedOn = "REDACTED";
                        }

                        remodel.Add(M);
                    }

                    rATS = Math.Round(ATS / lstCategorySpecificRatingNF.Count(), 1);
                    rOQW = Math.Round(OQW / lstCategorySpecificRatingNF.Count(), 1);
                    rCom = Math.Round(Com / lstCategorySpecificRatingNF.Count(), 1);
                    lstCategorySpecificRatingfnl = remodel;
                    ViewType = "NonFLView";
                }

            }
            catch (Exception ex)
            {

            }
            var Results = commonFn.TableResponce(lstCategorySpecificRatingfnl, Data.sort, Data.dir, Data.currentpage, Data.pageSize);

            var response = new
            {
                Result = Results,
                ATS = rATS,
                OQW = rOQW,
                Com = rCom,
                ViewType = ViewType
            };

            return response;

        }

        [HttpPost("Download.CategorySpecificRating")]
        public ActionResult DownloadCategorySpecificRatingJSON([FromBody] ProjectSpecific Data)
        {
            List<CategorySpecificModel> lstCategorySpecificRatingfnl = new List<CategorySpecificModel>();
            double rATS = 0;
            double rOQW = 0;
            double rCom = 0;
            IEnumerable<CategorySpecificModel> lstCategorySpecificRatingNF = _rating.GetCategorySpecificCategoryDetailsForNonFreelancer(Data.usersid);
            var virtualList = lstCategorySpecificRatingNF.ToList();

            lstCategorySpecificRatingNF = virtualList.AsEnumerable();

            double ATS = 0, OQW = 0, Com = 0;
            List<CategorySpecificModel> remodel = new List<CategorySpecificModel>();
            foreach (var item in lstCategorySpecificRatingNF)
            {
                ATS += Convert.ToDouble(item.AdherenceToSchedule);
                OQW += Convert.ToDouble(item.OverallQualityOfWork);
                Com += Convert.ToDouble(item.Communication);
                CategorySpecificModel M = new CategorySpecificModel();
                M = item;
                if (item.customer != Data.TeamType && Data.CurrentUserRole == "CLIENT")
                {
                    M.JobNo = "REDACTED";
                    M.customer = "REDACTED";
                    M.Author = "REDACTED";
                    M.Title = "REDACTED";
                    M.Edition = "REDACTED";
                    M.RatedOn = "REDACTED";
                }

                remodel.Add(M);
            }

            rATS = Math.Round(ATS / lstCategorySpecificRatingNF.Count(), 1);
            rOQW = Math.Round(OQW / lstCategorySpecificRatingNF.Count(), 1);
            rCom = Math.Round(Com / lstCategorySpecificRatingNF.Count(), 1);
            lstCategorySpecificRatingfnl = remodel;
            using (ExcelPackage package = new ExcelPackage())
            {

                package.Workbook.Worksheets.Add("Rating");
                OfficeOpenXml.ExcelWorksheet worksheet = package.Workbook.Worksheets[1];
                int i = 2;
                worksheet.Cells[i, 1].Style.Font.Bold = true;
                worksheet.Cells[i, 1].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[i, 1].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[i, 1].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[i, 1].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[i++, 1].Value = "Freelancer: " + remodel.FirstOrDefault().FreelancerName;
                i++;
                worksheet.Cells[i, 1].Value = "Overall Quality of Work";
                worksheet.Cells[i++, 2].Value = "AverageRating: " + rOQW;
                worksheet.Cells[i - 1, 1, i - 1, 2].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[i - 1, 1, i - 1, 2].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[i - 1, 1, i - 1, 2].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[i - 1, 1, i - 1, 2].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[i - 1, 1, i - 1, 2].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                worksheet.Cells[i - 1, 1, i - 1, 2].Style.Font.Bold = true;
                worksheet.Cells[i - 1, 1, i - 1, 2].Style.Fill.PatternType = ExcelFillStyle.Solid;
                worksheet.Cells[i - 1, 1, i - 1, 2].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.FromArgb(169, 169, 169));
                foreach (var item in lstCategorySpecificRatingfnl)
                {
                    int j = i;
                    worksheet.Cells[i, 1].Value = "Job #:" + item.JobNo;
                    worksheet.Cells[i++, 2].Value = "Project Rating: " + item.OverallQualityOfWork;
                    worksheet.Cells[i, 1].Value = "Client: " + item.customer;
                    worksheet.Cells[i++, 2].Value = item.OQWC;
                    worksheet.Cells[i++, 1].Value = "Author: " + item.Author;
                    worksheet.Cells[i++, 1].Value = "Title: " + item.Title;
                    worksheet.Cells[i++, 1].Value = "Edition: " + item.Edition;
                    worksheet.Cells[i++, 1].Value = "Rated On: " + item.RatedOn;
                    worksheet.Cells[j + 1, 2, i - 1, 2].Merge = true;
                    worksheet.Cells[j + 1, 2, i - 1, 2].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                    worksheet.Cells[j, 1, j, 2].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    worksheet.Cells[j, 1, i - 1, 2].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    worksheet.Cells[j, 1, i - 1, 2].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    worksheet.Cells[i - 1, 1, i - 1, 2].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;

                }
                i++;
                worksheet.Cells[i, 1].Value = "Adherence to Schedule";
                worksheet.Cells[i++, 2].Value = "AverageRating: " + rATS;
                worksheet.Cells[i - 1, 1, i - 1, 2].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[i - 1, 1, i - 1, 2].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[i - 1, 1, i - 1, 2].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[i - 1, 1, i - 1, 2].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[i - 1, 1, i - 1, 2].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                worksheet.Cells[i - 1, 1, i - 1, 2].Style.Font.Bold = true;
                worksheet.Cells[i - 1, 1, i - 1, 2].Style.Fill.PatternType = ExcelFillStyle.Solid;
                worksheet.Cells[i - 1, 1, i - 1, 2].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.FromArgb(169, 169, 169));
                foreach (var item in lstCategorySpecificRatingfnl)
                {
                    int j = i;
                    worksheet.Cells[i, 1].Value = "Job #:" + item.JobNo;
                    worksheet.Cells[i++, 2].Value = "Project Rating: " + item.AdherenceToSchedule;
                    worksheet.Cells[i, 1].Value = "Client: " + item.customer;
                    worksheet.Cells[i++, 2].Value = item.ASC;
                    worksheet.Cells[i++, 1].Value = "Author: " + item.Author;
                    worksheet.Cells[i++, 1].Value = "Title: " + item.Title;
                    worksheet.Cells[i++, 1].Value = "Edition: " + item.Edition;
                    worksheet.Cells[i++, 1].Value = "Rated On: " + item.RatedOn;
                    worksheet.Cells[j + 1, 2, i - 1, 2].Merge = true;
                    worksheet.Cells[j + 1, 2, i - 1, 2].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                    worksheet.Cells[j, 1, j, 2].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    worksheet.Cells[j, 1, i - 1, 2].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    worksheet.Cells[j, 1, i - 1, 2].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    worksheet.Cells[i - 1, 1, i - 1, 2].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                }
                i++;
                worksheet.Cells[i, 1].Value = "Communication";
                worksheet.Cells[i++, 2].Value = "AverageRating: " + rCom;
                worksheet.Cells[i - 1, 1, i - 1, 2].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[i - 1, 1, i - 1, 2].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[i - 1, 1, i - 1, 2].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[i - 1, 1, i - 1, 2].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[i - 1, 1, i - 1, 2].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                worksheet.Cells[i - 1, 1, i - 1, 2].Style.Font.Bold = true;
                worksheet.Cells[i - 1, 1, i - 1, 2].Style.Fill.PatternType = ExcelFillStyle.Solid;
                worksheet.Cells[i - 1, 1, i - 1, 2].Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.FromArgb(169, 169, 169));
                foreach (var item in lstCategorySpecificRatingfnl)
                {
                    int j = i;
                    worksheet.Cells[i, 1].Value = "Job #:" + item.JobNo;
                    worksheet.Cells[i++, 2].Value = "Project Rating: " + item.Communication;
                    worksheet.Cells[i, 1].Value = "Client: " + item.customer;
                    worksheet.Cells[i++, 2].Value = item.CommC;
                    worksheet.Cells[i++, 1].Value = "Author: " + item.Author;
                    worksheet.Cells[i++, 1].Value = "Title: " + item.Title;
                    worksheet.Cells[i++, 1].Value = "Edition: " + item.Edition;
                    worksheet.Cells[i++, 1].Value = "Rated On: " + item.RatedOn;
                    worksheet.Cells[j + 1, 2, i - 1, 2].Merge = true;
                    worksheet.Cells[j + 1, 2, i - 1, 2].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                    worksheet.Cells[j, 1, j, 2].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                    worksheet.Cells[j, 1, i - 1, 2].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                    worksheet.Cells[j, 1, i - 1, 2].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                    worksheet.Cells[i - 1, 1, i - 1, 2].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                }

                worksheet.Cells[1, 1, i - 1, 2].AutoFitColumns(30, 100);
                worksheet.Cells[1, 2, i - 1, 2].AutoFitColumns(100);
                worksheet.Cells[1, 1, i - 1, 2].Style.WrapText = true;

                return Ok(new { data = package.GetAsByteArray(), contenttype = "application/octet-stream", filename = "Category_Specific_Rating_" + DateTime.Now.ToString("ddMMyyyyHHmmss") + ".xlsx" });
            }

            return null;
        }

        [HttpPost("Download.SkillSpecificRating")]
        public ActionResult DownloadSkillSpecificRatingJSON([FromBody] ProjectSpecific Data)
        {
            IEnumerable<SkillSpecificRatingModel> lstSkillSpecificRating = _rating.GetSkillSpecificCategoryDetails(Data.usersid);
            List<Tuple<bool, SkillSpecificRatingModel, List<SkillSpecificRatingModel>>> lst = new List<Tuple<bool, SkillSpecificRatingModel, List<SkillSpecificRatingModel>>>();
            List<SkillSpecificRatingModel> Items = new List<SkillSpecificRatingModel>();
            foreach (SkillSpecificRatingModel item in lstSkillSpecificRating)
            {
                List<SkillSpecificRatingModel> lsts = SkillSpecificRatingSkillWise(item.Skill, Data.usersid, Data.CurrentUserRole, Data.TeamType).ToList();
                //Tuple<bool, SkillSpecificRatingModel, List<SkillSpecificRatingModel>> items = new Tuple<bool, SkillSpecificRatingModel, List<SkillSpecificRatingModel>>(false, item, lsts);
                //lst.Add(items);
                Items.AddRange(lsts);
            }
            using (ExcelPackage package = new ExcelPackage())
            {
                package.Workbook.Worksheets.Add("Rating");
                OfficeOpenXml.ExcelWorksheet worksheet = package.Workbook.Worksheets[1];
                int i = 1;
                worksheet.Cells[i, 1].Value = "Skill";
                worksheet.Cells[i, 2].Value = "Lumina Job Number";
                worksheet.Cells[i, 3].Value = "Client";
                worksheet.Cells[i, 4].Value = "ISBN-13";
                worksheet.Cells[i, 5].Value = "Author";
                worksheet.Cells[i, 6].Value = "Title";
                worksheet.Cells[i, 7].Value = "Edition";
                worksheet.Cells[i, 8].Value = "Adherence to Schedule";
                worksheet.Cells[i, 9].Value = "Overall Quality of Work";
                worksheet.Cells[i, 10].Value = "Communication";
                worksheet.Cells[i, 11].Value = "Overall Job Rating";
                worksheet.Cells[i, 12].Value = "Adherence to Schedule (comments)";
                worksheet.Cells[i, 13].Value = "Overall Quality of Work(comments)";
                worksheet.Cells[i, 14].Value = "Communication (comments)";

                worksheet.Cells[i, 1, i, 14].Style.Font.Bold = true;
                i++;
                foreach (var item in Items)
                {
                    worksheet.Cells[i, 1].Value = item.Skill;
                    worksheet.Cells[i, 2].Value = item.JobNo;
                    worksheet.Cells[i, 3].Value = item.Customer;
                    worksheet.Cells[i, 4].Value = item.ISBN13;
                    worksheet.Cells[i, 5].Value = item.Author;
                    worksheet.Cells[i, 6].Value = item.Title;
                    worksheet.Cells[i, 7].Value = item.Edition;
                    worksheet.Cells[i, 8].Value = item.AdherenceToSchedule;
                    worksheet.Cells[i, 9].Value = item.OverallQualityOfWork;
                    worksheet.Cells[i, 10].Value = item.Communication;
                    worksheet.Cells[i, 11].Value = item.OverallJobRating;
                    //Commented by shashant on 2nd August 2022, as discussed with GC
                    //worksheet.Cells[i, 12].Value = "NA";
                    //worksheet.Cells[i, 13].Value = "NA";
                    //worksheet.Cells[i++, 14].Value = "NA";
                    worksheet.Cells[i, 12].Value = item.AdherancetoScheduleComment;
                    worksheet.Cells[i, 13].Value = item.OverallQualityofWorkComment;
                    worksheet.Cells[i++, 14].Value = item.CommunicationComment;
                }

                worksheet.Cells[1, 1, i - 1, 14].Style.Border.Top.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[1, 1, i - 1, 14].Style.Border.Left.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[1, 1, i - 1, 14].Style.Border.Right.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[1, 1, i - 1, 14].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                worksheet.Cells[1, 1, i - 1, 14].Style.HorizontalAlignment = ExcelHorizontalAlignment.Left;
                worksheet.Cells[1, 1, i - 1, 14].Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                worksheet.Cells[1, 1, i - 1, 14].AutoFitColumns(10, 50);
                worksheet.Cells[1, 1, i - 1, 14].Style.WrapText = true;

                //return File(package.GetAsByteArray(), "application/octet-stream", "InvoiceRepot.xlsx");
                return Ok(new { data = package.GetAsByteArray(), contenttype = "application/octet-stream", filename = "Skill_Specific_Rating_" + DateTime.Now.ToString("ddMMyyyyHHmmss") + ".xlsx" });
            }

            return null;
        }

        [HttpPost("get.SkillSpecificRating")]
        public object SkillSpecificRatingJSON([FromBody] ProjectSpecific Data)
        {
            string ViewType = "";
            List<SkillSpecificRatingModel> lstSkillSpecificRatingFnl = new List<SkillSpecificRatingModel>();
            try
            {
                IEnumerable<SkillSpecificRatingModel> lstSkillSpecificRating = _rating.GetSkillSpecificCategoryDetails(Data.usersid);

                if (Data.CurrentUserRole == Convert.ToString(userRole.LUMINAOTHERS) || Data.CurrentUserRole == Convert.ToString(userRole.FREELANCER) || Data.CurrentUserRole == Convert.ToString(userRole.FLPROJECTMANAGER))
                {
                    ViewType = "FLView";
                }
                if (Data.CurrentUserRole == Convert.ToString(userRole.PROJECTMANAGER) || Data.CurrentUserRole == Convert.ToString(userRole.ADMIN) || Data.CurrentUserRole == "CLIENT" || Data.CurrentUserRole == Convert.ToString(userRole.CLIENTADMIN) || Data.CurrentUserRole == Convert.ToString(userRole.LUMINASUPERVISOR) || Data.CurrentUserRole == Convert.ToString(userRole.FLPROJECTMANAGER) || Data.CurrentUserRole == Convert.ToString(userRole.AGENCY))
                {
                    ViewType = "NonFLView";
                }
                lstSkillSpecificRatingFnl = lstSkillSpecificRating.ToList();

            }
            catch (Exception ex)
            {

            }
            List<Tuple<bool, SkillSpecificRatingModel, List<SkillSpecificRatingModel>>> lst = new List<Tuple<bool, SkillSpecificRatingModel, List<SkillSpecificRatingModel>>>();
            foreach (SkillSpecificRatingModel item in lstSkillSpecificRatingFnl)
            {
                List<SkillSpecificRatingModel> lsts = SkillSpecificRatingSkillWise(item.Skill, Data.usersid, Data.CurrentUserRole, Data.TeamType).ToList();
                Tuple<bool, SkillSpecificRatingModel, List<SkillSpecificRatingModel>> items = new Tuple<bool, SkillSpecificRatingModel, List<SkillSpecificRatingModel>>(false, item, lsts);
                lst.Add(items);
            }

            var dts = lst.Select(a => new
            {
                Expanding = a.Item1,
                item = a.Item2,
                innerData = a.Item3
            });



            var Result = commonFn.TableResponce(dts, Data.sort, Data.dir, Data.currentpage, Data.pageSize);

            var Response = new
            {
                Data = Result,
                ViewType = ViewType
            };

            return Response;
        }

        [HttpGet]
        public List<SkillSpecificRatingModel> SkillSpecificRatingSkillWise(string Skill, int? usersid, string Role, string TeamType)
        {
            List<SkillSpecificRatingModel> ReturnModelFnl = new List<SkillSpecificRatingModel>();
            try
            {
                IEnumerable<SkillSpecificRatingModel> lstSkillSpecificRating = _rating.GetSkillSpecificCategoryDetailsForNonFreelancer(usersid, Skill);

                var virtualList = lstSkillSpecificRating.ToList();

                lstSkillSpecificRating = virtualList.AsEnumerable();

                if (Role == Convert.ToString(userRole.AGENCY) || Role == Convert.ToString(userRole.PROJECTMANAGER) || Role == Convert.ToString(userRole.ADMIN) || Role == Convert.ToString(userRole.CLIENTADMIN))
                {
                    ReturnModelFnl = lstSkillSpecificRating.ToList();
                }
                else if (Role == "CLIENT")
                {
                    List<SkillSpecificRatingModel> ReturnModel = new List<SkillSpecificRatingModel>();
                    foreach (SkillSpecificRatingModel Rate in lstSkillSpecificRating)
                    {
                        SkillSpecificRatingModel item = new SkillSpecificRatingModel();
                        item = Rate;
                        if (item.Customer.Trim().ToLower() != TeamType.Trim().ToLower())
                        {
                            item.JobNo = "REDACTED";
                            item.Customer = "REDACTED";
                            item.Author = "REDACTED";
                            item.Title = "REDACTED";
                            item.Edition = "REDACTED";
                            item.ISBN13 = "REDACTED";
                            item.RatedOn = "REDACTED";
                        }
                        ReturnModel.Add(item);
                    }

                    ReturnModelFnl = ReturnModel.ToList();
                }

            }
            catch (Exception ex)
            {
            }
            return ReturnModelFnl;
        }

        [HttpPost("get.ProjectSpecificRating")]
        public object ProjectSpecificRating([FromBody] ProjectSpecific Data)
        {
            List<ProjectSpecificCategoryModel> lstProjectSpecificRatingFinal = new List<ProjectSpecificCategoryModel>();
            string IsFreelancer = "";
            try
            {
                IEnumerable<ProjectSpecificCategoryModel> lstProjectSpecificRating = _rating.GetProjectSpecificCategoryDetails(Data.usersid, Data.jobID);
                if (Data.CurrentUserRole == Convert.ToString(userRole.LUMINAOTHERS) || Data.CurrentUserRole == Convert.ToString(userRole.FREELANCER) || Data.CurrentUserRole == Convert.ToString(userRole.FLPROJECTMANAGER))
                {
                    lstProjectSpecificRatingFinal = lstProjectSpecificRating.ToList();
                    IsFreelancer = "FL";
                }
                if (Data.CurrentUserRole == Convert.ToString(userRole.PROJECTMANAGER) || Data.CurrentUserRole == Convert.ToString(userRole.ADMIN) || Data.CurrentUserRole == Convert.ToString(userRole.CLIENTADMIN) || Data.CurrentUserRole == Convert.ToString(userRole.LUMINASUPERVISOR) || Data.CurrentUserRole == Convert.ToString(userRole.AGENCY))
                {
                    lstProjectSpecificRatingFinal = lstProjectSpecificRating.ToList();
                    IsFreelancer = "NonFL";
                }
                else if (Data.CurrentUserRole == "CLIENT")
                {
                    List<ProjectSpecificCategoryModel> remodel = new List<ProjectSpecificCategoryModel>();
                    foreach (ProjectSpecificCategoryModel item in lstProjectSpecificRating)
                    {
                        ProjectSpecificCategoryModel M = new ProjectSpecificCategoryModel();
                        M = item;
                        if (item.Customer.ToUpper().Trim() != Data.TeamType.ToUpper().Trim())
                        {
                            M.JobNo = "REDACTED";
                            M.Customer = "REDACTED";
                            M.ISBN13 = "REDACTED";
                            M.Author = "REDACTED";
                            M.Title = "REDACTED";
                            M.Edition = "REDACTED";
                            M.RatedOn = "REDACTED";
                        }
                        remodel.Add(M);
                    }

                    lstProjectSpecificRatingFinal = remodel;
                }
                else
                {
                    lstProjectSpecificRatingFinal = lstProjectSpecificRating.ToList();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            var Result = commonFn.TableResponce(lstProjectSpecificRatingFinal, Data.sort, Data.dir, Data.currentpage, Data.pageSize);

            var Response = new
            {
                Data = Result,
                IsFreelancer = IsFreelancer
            };

            return Response;
        }

    }
}