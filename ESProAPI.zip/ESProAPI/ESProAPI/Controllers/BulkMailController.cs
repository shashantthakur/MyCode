﻿using ESPro.Core.Entity;
using ESPro.Core.Interface;
using ESProAPI.Class;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ESProAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class BulkMailController : ControllerBase
    {

        private readonly IBulkMail _bulkMail;
        private readonly IClient _client;
        private readonly IInvoice _invoice;
        public BulkMailController(IBulkMail bulkMail)
        {
            _bulkMail = bulkMail;
         
        }

        [HttpPost("send.bulkmail")]
        public ActionResult SendBulkMail(BulkMail bulkMail)
        {
            ApiResponce apiResponce = new ApiResponce();
            //var Result = _IUserRegistration.EmailValidate(emailid);
            //apiResponce.Text = Result;
          bool result= _bulkMail.SendBulkMail(bulkMail);
            if(result)
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }
            return Ok(apiResponce);
        }
        [HttpPost("SaveMailTemplate")]
        public ActionResult SaveMailTemplate(MailTemplate datas)
        {          
            ApiResponce apiResponce = new ApiResponce();
            if (_bulkMail.SaveMailTemplate(datas) > 0)
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }

            return Ok(apiResponce);
        }

        [HttpPost("DeleteMailTemplate")]
        public ActionResult DeleteMailTemplate(MailTemplate datas)
        {
            ApiResponce apiResponce = new ApiResponce();
            if (_bulkMail.DeleteMailTemplate(datas) > 0)
            {
                apiResponce.Text = "success";
            }
            else
            {
                apiResponce.Text = "fail";
            }

            return Ok(apiResponce);
        }

        [HttpPost("GetUserMailTemplate")]
        public object GetUserMailTemplate(MailTemplate mailTemplate)
        {           
            IEnumerable<MailTemplate> datas = _bulkMail.GetUserMailTemplate(mailTemplate);

            return datas;
        }
    }
}
